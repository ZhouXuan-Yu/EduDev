# START_PROMPT · Codex 小智 UI/UX V3.1（设置窗口优先）

你是 EduDev 小智桌面 UI/UX V3.1 **执行 AI**。**你的目标不是生成计划或让截图漂亮，而是先修复真实问题，再完成已批准的 UI 改造；全部必需验收必须有实际 PASS 证据，候选集成通过才允许合并 main，最终 main 通过后才允许 DONE。** 方案 AI 没有修改源码、分支、远端或业务数据，你负责实现和真实验收。

## 一、范围与最高优先级

- **SET-P0 首要目标**：把现有 `App.tsx` 的 settings 页面抽离成独立、顶层、非模态、单实例 Electron `BrowserWindow`；原全局左侧导航保留原样。参考 WorkBuddy 的独立工作窗口和豆包式的轻量设置分组、图标、柔和颜色与自然反馈。
- 设置窗获得焦点时主窗适度弱化，弱化层不阻断点击/输入/滚动/拖动；主窗切回时取消；打开/关闭设置不取消 Pi 任务、不丢 Composer/待办/草稿、不中断其他页面。
- 复用全部 **10 类已有设置功能**：模型、教育技能、能力中心、外部工具、资料与权限、教师记忆（含 PiHistoryMemorySettings）、界面偏好、归档、备份与归档、策略与诊断。搜索需定位真实控件，文案面向教师，不新增不存在的“通知”等假开关。
- **安全不能降级**：独立设置专用最小 typed preload、主进程 sender/webContents/mainFrame/窗口角色与数据 schema 的 allowlist；禁止复制完整 `window.omniEdu` 到子窗，禁止简单把 `settingsSender` 改成任意 sender 均可访问；非法窗口/子 frame/非法导航必须被拒。
- 会话级权限/工作目录/记忆须由主进程可信 sessionId/scope/revision 约束，不能用设置窗本地偏好猜会话。配置保存/撤销/历史、模型凭证、备份/归档、技能/MCP 均沿原真实服务与回执/readback，不复制第二套真源。
- 视觉：浅色、清楚层级、适量语义图标与蓝色主操作，日常/高级分层；Motion 快、轻、可中断、Reduced Motion/性能降级。图片和 HTML 为**非生产视觉提案**，不是真实窗口或配置行为证据。
- 其余首页、我的任务、资料库、教学/学生/组卷/PPT/对话等原 V3 需求**全部保留**；P01/P02 已确认方向，P03 仅详情默认收起已确认，其余页面提案不得擅自升级为已批准的结构变更。

## 二、开始前完整读取

按顺序：`README.md` → `goal.md` → `design/settings-priority/01_SETTINGS_DECISION_AND_SCOPE.md` → `02_SETTINGS_SCREEN_FLOW.md` → `03_SETTINGS_API_AND_OWNERSHIP_MATRIX.md` → `04_TEACHER_COPY_AND_VISUAL_GUIDE.md` → `16_SETTINGS_PRIORITY_IMPLEMENTATION.md` → `17_SETTINGS_ACCEPTANCE_MATRIX.md` → `01_CONFIRMED_SPEC.md` → `02_BASELINE_AND_WIP.md` → `03_GIT_WORKFLOW.md` → `11_PARALLEL_OWNERSHIP.md` → `design/01_SETTINGS_WINDOW_CONTRACT.md` → `02_VISUAL_TOKENS.md` → `03_MOTION_SYSTEM.md` → `04_PAGE_DESIGN_AND_APPROVAL.md` → `05_TEACHER_WORKFLOWS.md` → `04_IMPLEMENTATION_PLAN.md` → `05_BDD_SCENARIOS.md` → `06_ATDD_ACCEPTANCE.md` → `07_TEST_STRATEGY.md` → `08_REQUIREMENT_TRACEABILITY.md` → `09_VERIFICATION_RUNBOOK.md` → `10_QUALITY_GATES.md` → `12_RISK_AND_ROLLBACK.md` → `13_EXECUTION_STATUS.md`。同时读取仓库根 `AGENTS.md`、Master Goal、文档地图、相关 CURRENT、UI-FINAL 原 36 项、`edudev-design` Skill/决策及所有相关活跃 WIP。

**唯一验收标准**：`06_ATDD_ACCEPTANCE.md`。共 **26 REQ、90 项 V3.1 AC（原 74 + 本轮设置新增 16）、36 项历史必需 LG**。每条必须有 REQ→AC→TASK→CODE→TEST→EVIDENCE 映射，初始全部 NOT_RUN。不同文件不得重新独立维护预期标准。

## 三、Phase 0：只读真实审计，不能跳过

2026-11-26 远程只读 main 观察为 `f420db00e4c124a1320aab57c82e65017ee89297`，该次提交涉及 `main/index.ts`、`App.tsx`，执行时先重新核验 `origin/main`、本地 HEAD、所有 worktree、dirty、实际运行构建身份、CI、锁文件和每个文件 owner。

重点核对：`App.tsx` settings activeView、`PiSettingsWorkspace` 十类设置与历史记忆、`SettingsNavigation` 日常/高级、`main/index.ts` 的 BrowserWindow 与 `settingsSender`、`preload/index.ts` 全量 `omniEdu`、当前 config-commit/history/undo/credential 实际接口、事件订阅、会话 scope、数据/备份/技能/权限 owner。逐 REQ 记录 VERIFIED_COMPLETE/PARTIAL/MISSING/DEFECT/TO_VERIFY；已正确的实现保留、不推倒重建；旧验收报告只能在相同源码/构建/数据范围有效时复用。

## 四、Phase 1：保护 WIP 和隔离开发

优先续用包含正确 UI 半成品的已有分支，否则建立独立 `feat/xiaozhi-uiux-v31-*` 分支/worktree。多个 AI 各自独立可写目录，不能在共享 worktree checkout/reset/stash/clean，不能把别人的未提交更改混入提交。跨 main/preload/App/PiSettingsWorkspace/Config/Pi/Memory/Backup 的共享文件先指定 owner 并完成 `templates/CONTRACT_HANDSHAKE.md`。测试使用独立 profile、SQLite/文件副本和隔离端口。

## 五、Phase 2：设置 W2-A..W2-F 先行，先修复再优化

W2-A 独立单例窗口/加载失败恢复；W2-B 焦点蒙层/主窗 Pi 持续/DPI/退出；W2-C 最小 settings preload/IPC 正反安全合同/可信 session scope；W2-D 十类真实设置和教师文案/搜索/键盘；W2-E 模型/普通配置版本撤销/工具技能/权限/三级记忆/备份 readback 与跨窗同步；W2-F Motion/Reduced Motion/长内容/性能/窗口行为回归。每个切片先冻结 REQ/AC，再在相关逻辑上 TDD 红绿重构；纯 CSS 文案使用真实渲染和交互证据。不要为了改 UI 重写 Pi Runtime、数据库、OCR、组卷或 PPT 引擎。

## 六、Phase 3：完整验收扫描与修复闭环

必须逐条实际执行 AC-001..AC-090 及 LG-A01..LG-A36；其中 SET-P0 旧 AC-053..058 + 新 AC-075..090 **全是必需**。对应 Level 1–6：构建/type/适用 lint；TDD 单元；Contract/权限负例；真实 IPC/DB/文件集成；Windows Electron E2E；长任务/资料/组卷/学生与旧 UI 全量回归。AI 行为没有变化时以 diff 证据证明 AI Eval 不适用；有变化则按固定任务评测。

每个 AC 保存：前置数据、步骤、预期、实际、exit、source SHA/构建指纹、运行环境、截图/视频/trace/readback、PASS/FAIL/BLOCKED/NOT_RUN/N/A。**任何必需 FAIL/BLOCKED/NOT_RUN 均不得合并**；只有预先定义的条件性项才允许附证据 N/A。失败必须保存复现→判断根因→最小修复→重测→受影响回归→矩阵更新，禁止删断言/skip/改期望/Mock 冒充真实连接/降低标准。

## 七、Phase 4：独立审查与候选集成

独立审查实际代码 diff、共享 owner、完整 90 AC 和 36 LG、真实视频/读回、安全负例、性能、未确认页面审批状态。Gemini 如真实可用可参与，必须提供真实调用证据；没有则记录不可用并做独立审查，不冒充团队结果。以**最新 main** 构造集成候选并在候选树上验证，SET-P0 和所有合并前必需项 PASS 才允许 MG-01 PASS。

UI-FINAL A35/A36 有合并前后子条件：候选 diff/窗口/构建身份必须合并前通过；“远端 main 包含提交、最终 main 真实窗口”只在 FG-01 合并后验证，避免循环要求。

## 八、Phase 5：按已有授权条件合并与最终验收

仅 MG-01 PASS、共享契约/权限/回归无阻断时串行合并 main。遵守根 AGENTS、分支保护和实际授权，不强推、不覆盖别人的工作树；push/PR/部署分别核对，不扩大权限。合并后 FG-01 必须核验**实际 main 的双窗口**、最终源码/构建/运行 SHA、敏感 IPC 负例、10 类配置/readback、Pi runId/草稿、性能及受影响回归；FG-02 报告完整。任何失败不 DONE，返回修复或标 MERGE_BLOCKED。

## 九、预算、状态和最终输出

同问题无新证据 2 次换诊断；3 次实质尝试无进展记录根因，继续独立工作；每切片最多 8 轮、集成候选最多 3 轮，跨会话累计。预算耗尽为 PAUSED_BUDGET，外部阻塞为 BLOCKED/NEEDS_DECISION/WAITING_INTEGRATION/MERGE_BLOCKED，不得假装成功。

最终提交 `13_EXECUTION_STATUS.md`、`14_ACCEPTANCE_REPORT.md`、`15_MERGE_REPORT.md`、90 AC+36 LG 完整矩阵、REQ 双向追踪、SET-P0 安全/焦点/真实操作证据、源码和 main SHA、构建/窗口身份、命令与 exit、性能 trace、可复现缺陷、回滚/数据恢复。**只有全部必需通过、MG-01 PASS、FG-01/FG-02 PASS，才能标记 DONE。**

**立即开始 Phase 0 只读审计，不询问已经确认的设计，不能在未通过验收时提前合并 main。**
