# V3.1 最新只读核验覆盖旧 V3 记录（2026-11-26）

**当前优先基线：** `main` = `f420db00e4c124a1320aab57c82e65017ee89297`。此次 `main` 提交已经修改 `apps/desktop/src/main/index.ts` 与 `apps/desktop/src/renderer/App.tsx`，所以旧 V3 “最新一次只改 memory 文件/无需核验 UI 差异”的说法已过期；以下旧记录仅作为历史。

静态核验确认：设置仍在 `App.tsx` 的 `activeView=settings` 渲染 `PiSettingsWorkspace`，desktop settings command 也切回 activeView；主进程只有 mainWindow 的常规 BrowserWindow 实例，`settingsSender` 限定 mainWindow webContents/mainFrame；预加载有全量 `window.omniEdu`；`PiSettingsWorkspace` 最新包含 `PiHistoryMemorySettings`，并用 localStorage 推测主窗口当前会话，需要改成受主进程验证的 session scope。详细见 `design/settings-priority/05_REFERENCE_AND_EVIDENCE.md`。实施时执行 AI 必须重新核验 latest main、并行 WIP、本地构建身份、配置及 Pi owner。

# V3 Source Baseline Evidence

## Latest remote observation
- Repository: `ZhouXuan-Yu/EduDev`
- `main`: `d9a87bf2042ffbbd4627cd85e776bd734bd8fe31`
- Commit diff: `apps/desktop/scripts/education/history-memory-r1-state.mjs`, `apps/desktop/src/main/xiaozhi-agent/history/memory.ts`.
- UI code paths were reviewed at parent observation `9b192954e3d64e7d00fe15382a2db34f8351d0cc`; latest main diff did not touch those UI files. Phase 0 must still re-fetch all current files and compare local worktrees.

## Direct repository links
- Main: https://github.com/ZhouXuan-Yu/EduDev/tree/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31
- Root AGENTS: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/AGENTS.md
- Page contracts: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/apps/desktop/src/renderer/ui-system/page-contracts.ts
- Settings workspace: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/apps/desktop/src/renderer/components/office/PiSettingsWorkspace.tsx
- Settings navigation: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/apps/desktop/src/renderer/components/office/SettingsNavigation.tsx
- UI-FINAL acceptance: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/docs/design/system/UI_FINAL_ACCEPTANCE.md
- UI design skill: https://github.com/ZhouXuan-Yu/EduDev/blob/d9a87bf2042ffbbd4627cd85e776bd734bd8fe31/.agents/skills/edudev-design/SKILL.md

## Static facts vs unknowns
Static code reading confirms the component/route mappings in `02_BASELINE_AND_WIP.md`. It does not prove local WIP ownership, Electron runtime identity, database correctness, IPC integration, tests, performance, teacher acceptance or merge state. Those remain TO_VERIFY / NOT_RUN.
