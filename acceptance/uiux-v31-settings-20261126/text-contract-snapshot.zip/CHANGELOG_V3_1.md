# V3.1 相对 V3 的精确变化

## 保留（未删除）
- 原 26 项 REQ、AC-001..074 原断言、历史 UI-FINAL A01..A36、历史 V2 32 项验收映射、原全部页面设计图/审阅状态、并行 Git/WIP/分支隔离与六阶段闭环。

## 提升
- 新明确 P0：设置**真正独立** top-level nonmodal BrowserWindow，不再是 App activeView / React Modal；保留原左栏与主窗工作不中断。
- WorkBuddy 官方独立窗口行为 + 豆包风格设置行/图标与教师文案的视觉参考；焦点状态驱动背景蒙层且不截获主窗点击，跟手/Reduced Motion/性能可降级。
- 10 类现有设置完全保留，TeacherMemory 新增 `PiHistoryMemorySettings` 也必须继续可用；普通设置版本/历史/撤销、权限、技能/MCP、备份真实 readback。
- 最小权限独立 typed preload/IPC sender+mainFrame+window role allowlist、导航与子框架安全负例，禁止复制全量 omniEdu。
- 新增 AC-075..090 共 16 项，合计 90 项 AC；更新 Traceability、Acceptance Matrix、报告、Gate、Goal、Start Prompt、分片顺序和源代码基线。
- 当前 GitHub 远程 main `f420db00e4c124a1320aab57c82e65017ee89297`，其 diff 涉及 App/main，旧 V3 memory-only 观察不再作为当前值。

## 审批边界
- 用户再次确定的是设置独立窗口和豆包/WorkBuddy 的风格方向；本轮新高保真图为视觉提案，不将图中任何合成状态/控件视为已实现业务。
- P01/P02/P03 和其它页面已确认/待确认状态保持原记录，不因本轮设置优先而丢失。

## 工程门禁
- SET-P0：旧 AC-053..058 + 新 AC-075..090 必需，关联 LG-A17/A18/A31/A32。
- MG-01：90 项 AC 与旧 LG 合并前子条件全部 PASS 后才可合并 main。
- FG-01/FG-02：合并后真实 main 双窗口/IPC/配置/任务/性能回归与报告齐全后才 DONE。
