# V3.1 设置专项合并前后报告增量

- SET-P0-A/B/C：NOT_RUN。AC-053..058 与 AC-075..090 每项应有独立证据。
- MG-01：须先完成全部 90 AC、旧 LG 合并前子条件、SET-P0，禁止安全/功能缺失时合并。
- FG-01：最终 main 重新构建并启动**真实独立设置窗口和主窗口**；双窗口焦点/权限/配置/任务 readback 在实际 main 验证。
- FG-02：包含设置两窗口视频、窗口 ID/构建指纹、主进程 IPC 安全负例、十类功能可达、备份/记忆/权限 readback、动效性能和回滚。

以下旧“90 AC”历史表述已被本轮 90 AC 覆盖。

# 15 集成、合并与最终 main 报告模板

## 1. 模块候选（合并前）
- 分支/worktree/模块 HEAD：NOT_RUN
- 当前 main / origin/main SHA：NOT_RUN
- 90 项 V3 AC：NOT_RUN
- 36 项 legacy LG：NOT_RUN
- 旧 UI-FINAL/UI R1 有效证据映射：NOT_RUN
- 独立审查：NOT_RUN
- 未解决缺陷/共享契约：NOT_RUN
- `MG-01`：NOT_RUN（默认禁止合并）

## 2. 集成候选
- 唯一集成负责人/机制：NOT_ASSIGNED
- main 基线 M0 SHA：NOT_RUN
- 合成候选 SHA/tree：NOT_RUN
- 冲突文件/原因/owner/解决 commit：NOT_RUN
- 候选构建/Contract/Integration/E2E/Regression：NOT_RUN
- MG-01 证据索引：NOT_RUN

## 3. 合并操作
- 本地 main 合并授权核对：NOT_RUN
- 仓库分支保护/CI/PR 规则：NOT_RUN
- 合并方式/提交：NOT_RUN
- 本地 main 最终 SHA：NOT_RUN
- 远端 push/PR：按当前根 AGENTS 和明确授权分别记录，不从本地合并推导
- 部署：NOT_RUN（不由本任务书自动授权）

## 4. 合并后 FG-01
- main 是否包含本轮交付 commit：NOT_RUN
- 最终 build fingerprint：NOT_RUN
- 实际运行窗口/源码根：NOT_RUN
- 受影响关键 E2E/回归：NOT_RUN
- 设置窗口 IPC/主窗连续性：NOT_RUN
- 任务/资料/成果/学生 readback：NOT_RUN
- Motion/reduced-motion/performance：NOT_RUN

## 5. FG-02 最终报告完整性
- 90 AC + 36 LG 完整矩阵：NOT_RUN
- REQ→AC→TASK→CODE→TEST→EVIDENCE：NOT_RUN
- 功能缺失项：NOT_RUN
- 未解决问题/风险：NOT_RUN
- 回滚提交集合/数据恢复计划：NOT_RUN
- 用户如何验收和通过标准：NOT_RUN

## 6. 最终状态
`NOT_RUN`。仅 MG-01、FG-01、FG-02 PASS 且所有必需 AC/LG PASS 才能填写 DONE。失败/阻塞时填写 `MERGE_BLOCKED / BLOCKED / NEEDS_DECISION / PAUSED_BUDGET`，不假装完成。
