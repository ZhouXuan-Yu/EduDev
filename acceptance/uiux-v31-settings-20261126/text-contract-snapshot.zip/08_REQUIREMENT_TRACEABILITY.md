# V3.1 需求追踪增量

REQ-17 对应旧 AC-053/054 + 新 AC-075..079；REQ-18 对应旧 AC-055..058 + 新 AC-080..089；REQ-20 对应新 AC-090（并保留 AC-061..064）。其余 26 REQ 范围和旧 AC 不变。所有新 AC 的 TASK-ID 为 `W2-SET-P0`，其 CODE/TEST/EVIDENCE 映射已列入 `acceptance/traceability.csv`。全 90 项必须支持从 REQ 到证据和从 diff 到 REQ 的双向追踪。

# 08 需求追踪：REQ → AC → TASK → CODE → TEST → EVIDENCE

本表共 26 个连续 REQ。`acceptance/traceability.csv` 为机器可读索引；每次实现切片和每次 diff 都必须更新。`06_ATDD_ACCEPTANCE.md` 是唯一预期结果真源。

| REQ | 冻结需求 | 实施切片 | AC / Legacy Gate | 主要代码入口（Phase0复核） | 验证层级 | 通过条件 |
|---|---|---|---|---|---|---|
| REQ-01 | 保留全局左侧导航的结构/顺序/分组/图标/位置 | W0/W3/W9 | AC-001,AC-003 | App.tsx;DesktopFrame.tsx | Route/E2E | 左栏原样且页面切换正常 |
| REQ-02 | 保留页面路由、参数、权限守卫和滚动布局兼容 | W0/W3/W9 | AC-002,AC-004 | App.tsx;DesktopFrame.tsx;WorkbenchPageNavigation.tsx | Route/E2E | 旧入口与深链仍可达 |
| REQ-03 | 首页输入优先和三项教学快捷入口 | W3 | AC-005..008 | PiEducationWorkspace.tsx;App.tsx | Electron E2E | 三入口进入真实既有流程 |
| REQ-04 | Composer、待办、流式、IME、草稿和运行状态保护 | W3/W9 | AC-009..012 | OfficeComposer;PiComposerPendingPanel;PiEducationWorkspace.tsx | TDD/Component/E2E | 原行为不回退 |
| REQ-05 | 历史对话搜索、文件夹、重命名、归档和长历史 | W3/W4 | AC-013 | AiConversationSidebar.tsx;PiEducationWorkspace.tsx | E2E | 历史对话入口保持且归档不删消息 |
| REQ-06 | 我的任务紧凑列表、状态、全范围搜索、分页、详情、审批、恢复 | W4 | AC-014..022 | TeachingTaskWorkspace.tsx;PiRecoveryOverview.tsx;TaskOverviewCard.tsx;PiApprovalInbox.tsx;xiaozhi-workbench.ts | TDD/Contract/E2E | 全量查询/状态/恢复安全 |
| REQ-07 | 资料导入、文件夹批次、目录/标签/格式/状态、名称搜索和分页 | W5 | AC-023..026 | MaterialsWorkspace.tsx;MaterialCatalogFilters.tsx;material-catalog.ts | Contract/DB/E2E | 全库 facets 与分页真实有效 |
| REQ-08 | 资料正文检索、详情、状态、原页、草稿和队列恢复 | W5 | AC-027..032 | MaterialBodyPanel.tsx;MaterialImportPanel.tsx;MaterialLibraryActivity.tsx | Integration/E2E | 来源/版本/队列/readback正确 |
| REQ-09 | 教学工作台五个专业入口 | W6 | AC-033 | WorkbenchHub.tsx;WorkbenchPageNavigation.tsx | Route/E2E | 五个原入口可达 |
| REQ-10 | 教学文件、整包任务、课堂设计、模考汇编 | W6 | AC-034..037 | TeachingArtifactsWorkspace.tsx | Integration/E2E | 真实文件/子视图可用 |
| REQ-11 | 备课本、讲义、题本 | W6 | AC-038..040 | TeacherNotebookWorkspace.tsx;TeachingBookWorkspace.tsx;QuestionNotebookWorkspace.tsx | TDD/E2E | 保存/归档/来源/读回正确 |
| REQ-12 | 组卷 V3 蓝图、题篮、审核、确认、正式导出 | W7 | AC-041..044;LG-A20..A30 | PaperBlueprintWorkspace.tsx;paper contracts/export | TDD/Contract/E2E | 确认快照和文件一致 |
| REQ-13 | 学生工作台的 studentId 上下文 | W8 | AC-045 | StudentWorkbench.tsx;App.tsx | TDD/E2E | 异步切换不串学生 |
| REQ-14 | 学生档案、搜索、学习记录录入和 OCR 校正 | W8 | AC-046..048 | StudentProfileLifecycle.tsx;GlobalSearchWorkspace.tsx;App.tsx | E2E/readback | 本地数据和原图正确 |
| REQ-15 | 错题证据、校正、相似/变式和教师确认 | W8 | AC-049 | MistakesWorkspace.tsx | E2E/readback | 来源类别和教师确认正确 |
| REQ-16 | 学习计划、学习复盘和学习概览 | W8 | AC-050..052 | MasteryPathWorkspace.tsx;ReviewReportWorkspace.tsx;analytics route | E2E/readback | 真实数据和证据，不伪造 |
| REQ-17 | 设置独立非模态单实例窗口与主窗连续性 | W2 | AC-053..054、AC-075..079 | main/index.ts;App.tsx;PiSettingsWorkspace.tsx | TDD/Electron | 设置不打断主任务 |
| REQ-18 | 设置 IPC 最小权限、配置真源、保存和危险操作 | W2 | AC-055..058、AC-080..089 | main/index.ts;preload/index.ts;PiSettingsWorkspace.tsx;SettingsNavigation.tsx | TDD/Contract/E2E | sender安全/保存读回/权限有效 |
| REQ-19 | 统一视觉 Token、HeroUI/lucide 组件边界 | W3/W9 | AC-059..060 | edudev-design skill;theme/tokens;UI components | Static/render/CSSOM | 语义一致且无样式污染 |
| REQ-20 | 统一 Motion 状态、打断/反向、reduced-motion、性能 | W9 | AC-061..064、AC-090 | motion tokens;page components;HeroUI v3 state | E2E/Perf | 无抖闪和显著退化 |
| REQ-21 | Windows 多视口/DPI/缩放 | W9 | AC-065 | DesktopFrame/styles/Electron window | Electron manual/E2E | 关键操作可达 |
| REQ-22 | 键盘/焦点/ARIA/对比度/全状态语义 | W9 | AC-066..067 | page components/accessibility contracts | A11y/E2E | 状态可读、键盘可用 |
| REQ-23 | 完整教师核心跨页面用户旅程 | W8/W10 | AC-068 | App routes;Pi;materials;artifacts;paper;students | E2E/readback | 任务/资料/成果/学生上下文连续 |
| REQ-24 | 旧 UI-FINAL 36 项必需回归 | W0/W10 | AC-069;LG-A01..A36 | UI_FINAL_ACCEPTANCE.md + current implementation | Regression/E2E | 36 项逐项 PASS |
| REQ-25 | CI/构建/追踪/集成候选质量门禁 | W0/W10 | AC-070..071;MG-01;FG-01 | package.json;CI;traceability;git diff | CI/Integration/Audit | 无孤立追踪项，候选通过 |
| REQ-26 | 独立审查、AI 评测条件门禁、页面审批状态 | W9/W10 | AC-072..074 | review report;eval harness;page decision log | Independent review/Conditional AI eval | 独立审查真实、页面未批准不擅自冻结 |

## 双向追踪规则

从需求向下：每项 REQ 必须关联 AC、TASK、实际代码路径、测试入口和证据。

从 diff 向上：每个修改文件必须解释对应 REQ/AC、消费者、共享 owner、测试和证据；无法映射的改动不得夹带。

## 页面级源码入口

- 外壳/导航：`App.tsx`、`DesktopFrame.tsx`、`WorkbenchPageNavigation.tsx`、`WorkbenchHub.tsx`。
- 对话：`PiEducationWorkspace.tsx`、`OfficeComposer`、`PiComposerPendingPanel`、`AiConversationSidebar.tsx`。
- 任务：`TeachingTaskWorkspace.tsx`、`PiRecoveryOverview.tsx`、`TaskOverviewCard.tsx`、`PiApprovalInbox.tsx`、`shared/xiaozhi-workbench.ts`。
- 资料：`MaterialsWorkspace.tsx`、`MaterialLibraryLayout.tsx`、`MaterialLibraryCatalog.tsx`、`MaterialCatalogFilters.tsx`、`MaterialBodyPanel.tsx`、`MaterialImportPanel.tsx`、`shared/material-catalog.ts`。
- 教学成果：`TeachingArtifactsWorkspace.tsx`、`TeacherNotebookWorkspace.tsx`、`TeachingBookWorkspace.tsx`、`QuestionNotebookWorkspace.tsx`、`PaperBlueprintWorkspace.tsx`。
- 学生：`StudentWorkbench.tsx`、`StudentProfileLifecycle.tsx`、`GlobalSearchWorkspace.tsx`、`MistakesWorkspace.tsx`、`MasteryPathWorkspace.tsx`、`ReviewReportWorkspace.tsx`。
- 设置：`main/index.ts`、`preload/index.ts`、`PiSettingsWorkspace.tsx`、`SettingsNavigation.tsx`。
- 设计系统：`.agents/skills/edudev-design/SKILL.md` 和 references、`page-contracts.ts`、实际主题/CSS 入口。

## 证据目录

建议 `acceptance/evidence/<source-sha>/<AC-ID>/` 保存环境、命令日志、真实截图/录屏、trace、readback 和独立审查。脱敏，不保存 API Key、学生真实姓名/照片。
