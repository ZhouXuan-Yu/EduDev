# V3.1 Phase 2 设置 P0 先行切片（覆盖旧 W2 优先级）

**Phase 0** 审计最新源码/WIP/共享 owner，**Phase 1** 建立独立 worktree 和接口握手后，优先执行设置专项。其他独立页面可并行推进，但 **MG-01 不得在设置 AC-053..058、AC-075..090 全部 PASS 前通过**。

| 先行切片 | 内容 | 依赖/风险 | 验收编号 |
|---|---|---|---|
| W2-A | 设置真实窗口身份/单实例/独立 top-level nonmodal；所有入口汇聚 | main owner / P0 | AC-053,075,076 |
| W2-B | 主窗焦点/视觉弱化/任务持续/显示器/DPI/退出 | desktop+Pi owner / P0 | AC-054,077..079 |
| W2-C | 受限 typed preload、IPC sender/frame/window role、阻断任意导航 | preload+config+Pi owner / P0 | AC-055,083..085 |
| W2-D | 十类真实设置组件迁移/重用、教师文案、搜索与键盘 | config/memory/skills/tools owner / P1 | AC-056,080..082,087..088 |
| W2-E | 模型/凭证/ordinary config 历史撤销、跨窗状态、权限/备份 readback | config+backup+Pi owner / P0 | AC-057,058,086,089 |
| W2-F | 视觉图样、Motion、performance/reduced motion、长配置/窄屏、回归 | UI+desktop owner / P1 | AC-090、AC-059..066、LG-A17/A18/A31/A32 |

每个切片按 TDD/契约/Electron 实际测试；W2 的 P0 安全合同和最小允许 API 清单必须先完成并双方签收，再迁移设置交互。绝不为了窗口显示而全量放宽原 IPC。

# 04 实施计划：有限切片、依赖与完成条件

## Phase 与工作切片

| 切片 | 工作内容 | 优先级/依赖 | 适用方法 | 退出证据 |
|---|---|---|---|---|
| W0 / Phase 0 | 只读审计最新 main、WIP、运行根、全部页面/接口/测试、旧 36 项 | P0，无依赖 | SDD、风险分析 | Phase0 审计表完整；REQ 分类；无未归属变更被碰触 |
| W1 / Phase 1 | 独立分支/worktree、所有权握手、测试数据隔离、初始 AC 矩阵 | P0，依赖 W0 | PDD、契约管理 | owner/branch/dirty-path 清单；共享契约签收 |
| W2 | 设置窗口 manager、单实例、非模态生命周期、受限 preload/IPC | P0，依赖 W1 与配置/平台 owner | TDD、Contract、Electron E2E | AC-053..058；真实 sender 正反测试和配置 readback |
| W3 | 全局视觉 Token/组件状态；首页已确认方向；Composer 外壳适配 | P1，依赖 W1/W2 安全边界 | SDD、ATDD、渲染验收 | AC-005..013、059..060；真实组件来源/截图 |
| W4 | 我的任务紧凑列表、全库搜索、过滤、分页、详情面板 | P1，依赖 W1；搜索需共享 query contract owner | TDD（查询/状态）、Contract、E2E | AC-014..022；100/1000 条数据全页搜索/分页证据 |
| W5 | 资料库列表、筛选、详情、原件/正文、队列与草稿 | P1，依赖 W1 | BDD/ATDD、Contract、E2E | AC-023..032；真实资料/原件/队列/readback |
| W6 | 教学工作台、教学文件、备课本、讲义、题本、课堂/模考/整包 | P1，依赖 W5 和页面审批状态 | BDD/ATDD、Regression | AC-033..040；所有旧入口仍可达，真实产物/版本 |
| W7 | 组卷 V3 专业流程与真实导出 | P0/P1，依赖题本/资料源和 D14 合同 | TDD（规则/状态）、Contract、E2E | AC-041..044 + LG-A20..A30；真实题篮/确认/文件 readback |
| W8 | 学生工作台、档案、搜索、录入、错题、计划、复盘、概览 | P1，依赖 W1 和本地学生数据合同 | TDD（studentId/异步边界）、E2E | AC-045..052 + LG-A15/A16；真实 SQLite/文件 readback |
| W9 | Motion System、响应式、DPI、键盘/IME、性能、规范和独立审查 | P1，依赖 W2–W8 受影响部分 | 性能/无障碍/回归 | AC-061..074、AC-090；trace、截图、审查记录、设计 Skill 增量 |
| W10 / Phase 3–5 | 全部 AC/LG 扫描、修复闭环、独立审查、集成候选、main 合并和最终验证 | P0，依赖全部切片 | ATDD、CI、E2E、Regression | MG-01、FG-01、FG-02 全 PASS 才 DONE |

## 实施原则

1. 先修复 P0/P1 已证实问题，再进行视觉升级。
2. 现有实现若满足合同且证据有效，标 `VERIFIED_COMPLETE` 并复用；不为了文件数量重写。
3. 每个切片开始前列 REQ、AC、消费者、所有权、最小 diff、测试和回滚。
4. 关键逻辑按 TDD；低风险纯视觉变化使用真实渲染/交互和对照截图。
5. 任何页面提案未确认时，只实施不改变 IA/业务流程的安全 Token/状态一致性；结构变更先取得用户批准。
6. 每个切片完成后立即运行相关测试并更新矩阵；失败不留到最后。
7. Phase 3 完整扫描所有必需项，不以切片局部通过替代总验收。
8. Phase 4 由非实施视角独立检查代码、测试、证据和缺失功能。
9. Phase 5 只在 MG-01 PASS 后进行；main 最终验证失败不算 DONE。

## 有限修复预算

- 同条件连续 2 次没有新证据：改变诊断方式。
- 3 次实质尝试仍无进展：记录根因/依赖，推进其他独立工作；受阻项保持 FAIL/BLOCKED。
- 每个切片最多 8 轮实质实现/验证；集成候选最多 3 轮。
- 轮次跨执行者、会话和分支累计，不能改名重置。
- 预算耗尽为 `PAUSED_BUDGET`，不得降低 AC、删除测试或合并。
