# V3.1 设置子窗口 owner 握手（强制）

- Desktop/Main owner 管理窗口与聚焦/应用退出，Pi/Agent owner 管理 session/run/审批，Config owner 管理配置版本/密钥/ordinary config/保存，Memory owner 管理教师/L2/历史记忆，Backup owner 管理备份/恢复，UI owner 管理布局与视觉。
- 涉及 `main/index.ts`、`preload/index.ts`、`App.tsx`、`PiSettingsWorkspace.tsx` 的共享写入须**单 writer + 冻结快照 + 签署 API/文件 ownership**；否则 WAITING_INTEGRATION。
- 新设置窗 typed preload 的接口矩阵必须按 `design/settings-priority/03_SETTINGS_API_AND_OWNERSHIP_MATRIX.md` 核验填写，不得继承完整 `window.omniEdu`。当前 10 类和 memory 历史子项必须逐项签收。

# 11 并行开发所有权、共享文件与契约边界

## 1. 角色

- UI 执行 AI：renderer 页面布局、样式、交互投影、设计 Token/Motion 和对应测试。
- 桌面平台/主进程 owner：BrowserWindow 生命周期、主进程窗口 manager、安全 preload/IPC 注册。
- 配置 owner：设置 schema、配置保存时序、凭证、权限、备份和配置事实源。
- Pi/Agent owner：Pi Runtime、runId/event、审批、恢复、任务状态和持久化。
- 资料/题库/组卷 owner：资料索引、OCR、题本、题篮、蓝图、导出和版本。
- 学生/学习记录 owner：studentId、档案、OCR 记录、错题、学习路径、复盘和分析。
- 集成 owner：唯一串行 main 集成人，核对最新 main 和候选。

同一人可兼任多个角色，但必须明确 owner；不得假设一个执行 AI 对所有共享文件拥有写权限。

## 2. 文件所有权矩阵（Phase0 必须填实际 owner）

| 文件/目录 | 默认 owner | UI 可改范围 | 必须协调 |
|---|---|---|---|
| `App.tsx` | desktop shell owner | 页面布局/路由适配的最小改动 | route/guard/Provider/共享状态 |
| `DesktopFrame.tsx` | desktop navigation owner | 外层呈现/焦点修复 | 导航历史/guard/命令 |
| `main/index.ts` | desktop main owner | 设置窗口生命周期的专属增量 | IPC sender、应用退出、窗口管理 |
| `preload/index.ts` | desktop IPC owner | 新增最小 typed settings facade | 每个新增 API 和 schema |
| `PiSettingsWorkspace.tsx`/子组件 | config + UI shared | 教师文案/布局/导航 | 保存时序/权限/数据 schema |
| `PiEducationWorkspace.tsx` | Pi owner | 只改 UI projection | runId/事件/恢复/审批 |
| `OfficeComposer`/`PiComposerPendingPanel` | Pi composer owner | 仅外层容器适配 | 所有内部交互、IME、草稿、队列 |
| `PiRecoveryOverview`/`TaskOverviewCard` | workbench owner | 列表布局/详情显示 | query schema/恢复/任务状态 |
| `shared/xiaozhi-workbench.ts` | workbench contract owner | 需签约后扩展 query | main handler/SQLite/分页/索引 |
| `MaterialsWorkspace`/material components | materials owner | 列表/详情布局 | parse queue/source/draft/index |
| `shared/material-catalog.ts` | materials contract owner | 需签约后扩展 query | SQLite/IPC/facets |
| Paper/QuestionNotebook components | paper/questions owner | 可见布局 | 题源/题篮/版本/导出/教师确认 |
| Student components/contracts | student data owner | 可见布局 | studentId/records/attachments/SQLite |
| Design Skill/references | UI design owner | 追加新决策/规范 | 历史决策不能覆盖 |

## 3. 设置窗口契约握手

必须完成 `templates/CONTRACT_HANDSHAKE.md`：
- 主窗与设置窗身份标识；
- sender/mainFrame/window capability allowlist；
- settings read/write API 的名称、版本、输入输出、错误语义；
- 凭证/敏感字段处理；
- 配置单一事实来源、版本/readback/事件同步；
- session/run 变化时的失效处理；
- 旧设置路由兼容；
- 安全正反测试和回滚；
- 两边 owner 签收。

## 4. 任务搜索契约握手

当前静态观察的 `WorkbenchQuery` task variant 没有 text query 字段。若实现全范围搜索，必须与 workbench/main/SQLite owner 确认：
- query 字段和 schemaVersion；
- 搜索字段（至少明确 sessionTitle/goalExcerpt 是否支持）；
- 是否包含完整 transcript（默认不扩大到全文，全文对话搜索继续走原搜索入口）；
- 全量范围、权限和数据范围；
- 排序稳定性、cursor 与筛选组合；
- 取消/超时/部分数据错误；
- 版本兼容和旧调用；
- TDD/contract/E2E。

## 5. 并行冲突处理

- 同一文件同一时刻只有一个 writer。
- 先冻结接口，UI 用 adapter/独立组件减少 shared file 改动。
- 冲突发生先暂停该文件写入，不影响其他独立切片。
- 不以“我只改样式”为由覆盖另一 AI 的组件结构或测试。
- 所有者未知的修改保持原样，记录后等待协调。
