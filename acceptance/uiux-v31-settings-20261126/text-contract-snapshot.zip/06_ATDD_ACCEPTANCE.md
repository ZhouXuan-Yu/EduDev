# 06 唯一 BDD / ATDD 验收合同（V3）

**本文件是唯一验收断言真源。所有 V3 AC 初始状态均为 `NOT_RUN`。** 报告和 CSV 只引用 ID，不另写一套不同的预期标准。

## 1. 状态与门禁定义
- `PASS`：实际执行并满足 Then，证据绑定当前源码 SHA、运行构建和环境。
- `FAIL`：实际结果不符合 Then，进入修复闭环。
- `BLOCKED`：外部环境/权限/依赖阻止执行；禁止合并。
- `NOT_RUN`：尚未执行或证据不足；禁止合并。
- `N/A`：仅适用于 AC 明确写出条件的情况；必须证明条件不成立并记录审查者。不得事后随意将必需项改为 N/A。
- `LG-A01..LG-A36` 是旧 UI-FINAL 的 36 项必需回归门禁，另有逐项状态，不得删减。
- `MG-01` 是合并前集成候选门禁；`FG-01/FG-02` 是合并后的最终 main 完成门禁，避免循环依赖。

## 2. V3 原有 74 项验收条目（保留原标准）

### AC-001 · REQ-01 · P0 · PRE_MERGE_REQUIRED — 全局左侧导航保持原样
- **Given / 前置条件：** 使用当前正式 Electron 构建，记录原左栏入口/顺序/图标/分组/位置和展开状态。
- **When / 操作：** 逐页打开首页、任务、资料、教学、学生、设置并往返。
- **Then / 唯一预期：** 全局左栏结构、顺序、图标、位置和行为与批准的原设计一致；本轮改动只作用于右侧工作区。
- **FAIL 反例：** 删除/移动/重命名原入口，新增重复导航，或页面切换导致左栏状态异常。
- **验证方式：** 真实 Electron 多页面 E2E + 前后截图对比。
- **证据要求：** 源码 SHA、运行构建指纹、逐页截图、导航录屏、路由清单。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-002 · REQ-02 · P0 · PRE_MERGE_REQUIRED — 旧路由和深链兼容
- **Given / 前置条件：** 已有 route ID、query 参数、旧入口、文件/学生来源引用和权限守卫。
- **When / 操作：** 通过左栏、历史入口、来源跳转、快捷命令和重启恢复进入页面。
- **Then / 唯一预期：** 所有旧入口仍可达，目标对象、权限、参数和返回位置正确。
- **FAIL 反例：** 旧 route 被删除、参数丢失、错误对象打开或权限守卫被绕过。
- **验证方式：** 路由映射审计 + Electron 用户旅程。
- **证据要求：** route→component 映射、深链测试日志、对象 ID 和录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-003 · REQ-01 · P1 · PRE_MERGE_REQUIRED — 导航与页面职责不重复
- **Given / 前置条件：** 左侧导航包含问小智/新建/搜索/我的任务/教学空间/最近对话/资料库/教学工作台/学生工作台/设置等现有入口。
- **When / 操作：** 逐页检查页内导航和任务/历史入口。
- **Then / 唯一预期：** 页内导航只组织当前领域，不复制左栏的最近对话或创建重复任务真源。
- **FAIL 反例：** 出现第二个最近对话列、重复工作台入口或同一对象两套事实。
- **验证方式：** 真实页面检查 + DOM/route 审计。
- **证据要求：** 页面截图、路由列表、数据来源说明。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-004 · REQ-02 · P1 · PRE_MERGE_REQUIRED — 主工作区滚动和窗口层级
- **Given / 前置条件：** 窗口尺寸 1366×768、1920×1080 及窄窗；存在长列表和长正文。
- **When / 操作：** 滚动页面、打开详情/弹层、切页和返回。
- **Then / 唯一预期：** Header/导航/主要操作保持可达；中间内容承担明确滚动；无竞争滚动或遮挡。
- **FAIL 反例：** 整页/详情双重滚动互相抢动、固定操作被遮挡或横向溢出。
- **验证方式：** Electron 多视口实测。
- **证据要求：** viewport/DPR/缩放、截图、滚动录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-005 · REQ-03 · P0 · PRE_MERGE_REQUIRED — 首页输入优先
- **Given / 前置条件：** 空白问小智会话，主窗口可用。
- **When / 操作：** 打开首页并首次进入。
- **Then / 唯一预期：** 标题简短；主输入区域是视觉中心；快捷入口和示例不抢占输入优先级。
- **FAIL 反例：** 首页被统计卡片/高级参数/大量说明挤满，输入框不易发现。
- **验证方式：** 真实 Electron 首屏检查。
- **证据要求：** 1366×768/1920×1080 截图、焦点与输入可达录像。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-006 · REQ-03 · P0 · PRE_MERGE_REQUIRED — 三项教学快捷入口
- **Given / 前置条件：** 现有智能组卷、PPT、题库检索的真实入口和宿主能力可审计。
- **When / 操作：** 分别点击三个快捷入口并检查填充/路由/任务。
- **Then / 唯一预期：** 入口分别对应智能组卷、制作课件 PPT、题库找题；只预填/启动既有合法路径，不虚构服务或创建重复 Agent。
- **FAIL 反例：** 按钮无动作、指向错误功能、模拟生成结果或绕过原权限。
- **验证方式：** 真实 Electron 操作 + session/task/readback。
- **证据要求：** 入口截图、session/task ID、实际下一步录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-007 · REQ-03 · P2 · PRE_MERGE_REQUIRED — 示例提示语
- **Given / 前置条件：** 首页提供少量真实适用的教学示例。
- **When / 操作：** 点击示例并修改后发送。
- **Then / 唯一预期：** 示例只帮助教师表达任务；用户可以编辑；发送后进入原对话流程。
- **FAIL 反例：** 示例不可编辑、强制启动或伪装成真实任务状态。
- **验证方式：** Electron UI 测试。
- **证据要求：** 示例点击/编辑/发送录像、草稿读回。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-008 · REQ-03 · P1 · PRE_MERGE_REQUIRED — 首页布局尺寸适配
- **Given / 前置条件：** 1366×768、1920×1080、800×768 和 100/125/150% 缩放。
- **When / 操作：** 打开空白首页并操作主输入。
- **Then / 唯一预期：** 左栏不变；主输入和三项入口可见且可操作；窄窗可按现有响应式收敛，不出现不可达主操作。
- **FAIL 反例：** 主输入被挤出首屏、入口遮挡或出现横向滚动。
- **验证方式：** 真实 Electron 视口和 DPI 测试。
- **证据要求：** CSS viewport/DPR/native bounds/截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-009 · REQ-04 · P0 · PRE_MERGE_REQUIRED — OfficeComposer 原样保护
- **Given / 前置条件：** 记录改造前 OfficeComposer、底部工具栏、弹层、配置和键盘行为。
- **When / 操作：** 改造后执行附件、模型、技能、命令、审批、发送、停止、队列和 IME 操作。
- **Then / 唯一预期：** 内部 DOM/行为/配置语义保持；仅允许外层布局适配且不重挂载丢稿。
- **FAIL 反例：** 替换/复制 Composer、改变内部行为或丢失附件/草稿/权限。
- **验证方式：** 组件回归 + 正式 Electron E2E。
- **证据要求：** 前后截图、CSSOM、IME 录像、会话草稿读回。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-010 · REQ-04 · P0 · PRE_MERGE_REQUIRED — PiComposerPendingPanel 单一待办入口
- **Given / 前置条件：** 会话存在补填、选择、授权或确认事项。
- **When / 操作：** 待办出现、收起、重开、提交和重启后恢复。
- **Then / 唯一预期：** 复用原 PiComposerPendingPanel；一个事项只有一个有效操作入口；收起不丢选择/输入；焦点和 IME 正确。
- **FAIL 反例：** 新增第二个审批入口、自动抢焦点、收起丢输入或跳过宿主授权。
- **验证方式：** 真实 Pi/renderer 组件/Electron 旅程。
- **证据要求：** 待办 ID、runId、焦点/IME 录像、提交回执。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-011 · REQ-04 · P0 · PRE_MERGE_REQUIRED — 运行过程与最终正文交接
- **Given / 前置条件：** 有真实公开工作说明、工具事件和最终正文的 Pi run。
- **When / 操作：** 观察请求接受→真实过程→工具→最终正文→结束/失败/停止。
- **Then / 唯一预期：** 按原 runId/事件顺序显示真实内容；最终正文边界按既有合同折叠过程一次，正文继续流式；用户重新展开不被后续 token 抢回。
- **FAIL 反例：** 造假思考步骤、隐藏失败、错绑 runId、正文被中断或重复折叠。
- **验证方式：** Pi 事件边界测试 + Electron 实际 run。
- **证据要求：** runId/event cursor/脱敏日志/录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-012 · REQ-04 · P0 · PRE_MERGE_REQUIRED — IME/草稿/长对话连续性
- **Given / 前置条件：** 中文输入法 composing、已有会话草稿、长历史滚动/选字。
- **When / 操作：** 切会话、切页、开设置、追加消息、流式更新和停止。
- **Then / 唯一预期：** IME composing 不误发；草稿按会话隔离；上翻/选字不强制滚底；停止/失败保留已有正文。
- **FAIL 反例：** Enter 误发、草稿串会话、长历史跳底或外壳 remount。
- **验证方式：** Electron E2E + 组件回归。
- **证据要求：** 键盘录像、draft/session ID、消息位置前后截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-013 · REQ-05 · P0 · PRE_MERGE_REQUIRED — 我的任务紧凑列表
- **Given / 前置条件：** 任务量 1、20、100、1000+，覆盖各真实状态。
- **When / 操作：** 打开我的任务并滚动/选择。
- **Then / 唯一预期：** 任务以紧凑行/列表呈现；标题、状态、下一步、更新时间和主要行动清楚；不以大卡片逐条堆叠。
- **FAIL 反例：** 任务量增长导致页面变成大卡片瀑布或关键信息被截断不可访问。
- **验证方式：** 真实 Electron 压力数据。
- **证据要求：** 1/20/100/1000 条截图、渲染性能 trace。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-014 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务状态筛选
- **Given / 前置条件：** 存在 active/review_required/paused/interrupted/completed/ended 等任务。
- **When / 操作：** 逐项筛选、切换全部/当前会话并刷新。
- **Then / 唯一预期：** 筛选值来自真实查询结果；计数与实际数据一致；部分数据不可读时明确标记。
- **FAIL 反例：** 状态映射错误、计数假造或筛选后遗漏数据。
- **验证方式：** workbench query 契约测试 + Electron。
- **证据要求：** 查询参数/返回 ID/计数对照、截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-015 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务全范围搜索
- **Given / 前置条件：** 任务跨多个分页；搜索词只存在于非当前页任务标题/会话标题/可查询任务摘要。
- **When / 操作：** 输入搜索词并执行查询。
- **Then / 唯一预期：** 搜索在服务端/SQLite 完整数据范围生效；返回结果不受当前页限制；搜索字段与索引范围明确。
- **FAIL 反例：** 仅过滤当前 20 条、声称全库搜索但遗漏其他页、搜索正文范围不明确。
- **验证方式：** 新增/扩展版本化 query contract 的单测、契约测试和真实数据库 E2E。
- **证据要求：** query schema/version、跨页测试数据、命中/未命中 ID、SQL/服务日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-016 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务游标分页与大量数据
- **Given / 前置条件：** 至少 1000 条任务，含相同更新时间和边界 cursor。
- **When / 操作：** 连续翻页、返回上一页、改变筛选/搜索后翻页。
- **Then / 唯一预期：** 每页数量符合真实 API（当前静态观察 limit=20）；无重复/漏项；筛选变化重置 cursor；不一次加载全部数据。
- **FAIL 反例：** cursor 失效、重复行、分页顺序不稳定或 UI 本地截断假分页。
- **验证方式：** query contract + 数据库集成 + Electron。
- **证据要求：** 分页 ID 集合、cursor、查询日志、内存/渲染 trace。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-017 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务右侧详情默认收起
- **Given / 前置条件：** 初次打开我的任务，无已选任务。
- **When / 操作：** 选择任务、切换任务、关闭详情、再次打开。
- **Then / 唯一预期：** 详情初始关闭；选择后在右侧按需打开；列表筛选、滚动、页码和选中项保持；关闭后焦点回到原条目。
- **FAIL 反例：** 详情默认占据列表空间、切换后列表重置或焦点丢失。
- **验证方式：** Electron 交互/E2E。
- **证据要求：** 默认/展开/关闭截图、选中 ID、焦点录像。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-018 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务详情与关联成果
- **Given / 前置条件：** 任务具有 goalExcerpt、steps、blockedReasons、关联 artifact。
- **When / 操作：** 选中任务并展开详情，打开关联成果。
- **Then / 唯一预期：** 详情只展示真实可读字段；成果与 sessionId/taskId/artifactVersion 绑定；不可读时诚实显示。
- **FAIL 反例：** 显示假进度、打开错误版本或将未知效果显示完成。
- **验证方式：** 真实 workbench summary + artifact readback。
- **证据要求：** task/session/artifact ID、版本、readback、录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-019 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务返回与恢复安全
- **Given / 前置条件：** 任务存在 resumeCandidate/continuationCandidate/审批/unknownEffect 等情况。
- **When / 操作：** 点击回到原对话或已有恢复入口。
- **Then / 唯一预期：** 个人任务页遵循当前合法路径；未暴露 onRestore 的页面不能伪造直接恢复；未知副作用不自动重放。
- **FAIL 反例：** 绕过 revision/requirementsVersion/审批或自动重放未知操作。
- **验证方式：** TDD + Electron E2E + 宿主 readback。
- **证据要求：** taskId/sessionId/revision/requirementsVersion、审批记录、操作日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-020 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 审批收件箱状态
- **Given / 前置条件：** 存在 pending/approved/executing/executed/rejected/invalidated/uncertain/failed 等审批。
- **When / 操作：** 切换任务总览/审批收件箱、查看、批准/拒绝/核验。
- **Then / 唯一预期：** 状态/资源范围/有效期来自真实审批；操作走原权限接口，失败可刷新核对。
- **FAIL 反例：** 审批状态作假、无权决定、重复提交或只改变 UI 不改变宿主记录。
- **验证方式：** 审批契约测试 + Electron + readback。
- **证据要求：** approval ref/revision/etag、决策回执、刷新后的状态。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-021 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 任务加载/部分/空/失败
- **Given / 前置条件：** 模拟合法空数据、部分源不可用、读取失败和网络/本地索引恢复。
- **When / 操作：** 打开/刷新/重试任务页。
- **Then / 唯一预期：** 空数据、部分不可读、错误和加载状态清晰区分；错误不能被当作 total=0。
- **FAIL 反例：** 读取失败显示“没有任务”或部分结果显示完整。
- **验证方式：** 失败注入 + Electron 状态测试。
- **证据要求：** 源失败码、页面截图、重试日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-022 · REQ-06 · P0 · PRE_MERGE_REQUIRED — 单文件资料导入
- **Given / 前置条件：** 隔离测试目录有合法/不支持/损坏文件。
- **When / 操作：** 点击添加资料、选择文件、取消或确认。
- **Then / 唯一预期：** 本地原件保存结果真实反馈；取消不写入；失败保留原件并可重试。
- **FAIL 反例：** 假导入成功、取消仍写入或损坏文件无反馈。
- **验证方式：** Electron 文件对话框 + 文件 hash/readback。
- **证据要求：** 原文件/目标路径/hash/回执、失败日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-023 · REQ-07 · P0 · PRE_MERGE_REQUIRED — 文件夹批次导入
- **Given / 前置条件：** 文件夹含多格式、重复、失败和可复用文件。
- **When / 操作：** 导入整个文件夹、勾选文件、暂停/继续/停止并重启。
- **Then / 唯一预期：** 批次状态和文件状态分离；原件保留；重启可恢复；部分失败可逐项处理。
- **FAIL 反例：** 批次假完成、重复导入、停止删除原件或重启丢进度。
- **验证方式：** 批次服务集成 + Electron + 文件 readback。
- **证据要求：** batchId、文件计数、hash、恢复前后状态。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-024 · REQ-07 · P0 · PRE_MERGE_REQUIRED — 资料目录/标签/格式/状态筛选
- **Given / 前置条件：** 资料跨多个分页、多个目录标签格式和收录状态。
- **When / 操作：** 组合目录/标签/格式/状态筛选和清除。
- **Then / 唯一预期：** facets 计数覆盖完整数据库；标签“全部命中”语义正确；清除恢复全部资料。
- **FAIL 反例：** 只统计当前页、标签 OR/AND 语义错误或清除后仍残留筛选。
- **验证方式：** CatalogScope 单测 + SQLite/服务集成 + Electron。
- **证据要求：** scope/facets/query 参数、全量数据对照。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-025 · REQ-07 · P0 · PRE_MERGE_REQUIRED — 资料名称搜索和分页
- **Given / 前置条件：** 资料目录超过一个分页，目标名称只在后续页。
- **When / 操作：** 按名称/格式搜索并翻页。
- **Then / 唯一预期：** 服务端 query+offset+scope 生效；总数/页码/hasMore 一致。
- **FAIL 反例：** 只搜索当前页或分页丢失筛选条件。
- **验证方式：** 真实 SQLite/IPC + Electron。
- **证据要求：** 资源 ID 集合、total/offset/hasMore、截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-026 · REQ-07 · P0 · PRE_MERGE_REQUIRED — 资料正文/题意检索
- **Given / 前置条件：** 索引覆盖完整、部分、待处理和无命中资料。
- **When / 操作：** 切换“检索内容”，关键词/题意检索并打开来源。
- **Then / 唯一预期：** 关键词与 hybrid 模式的真实能力/索引覆盖如实呈现；命中可回原文页/片段；部分索引不宣称全库无结果。
- **FAIL 反例：** 把未索引资料当无匹配、伪造语义检索或丢失引用来源。
- **验证方式：** 真实检索服务集成 + Electron。
- **证据要求：** query/mode/index coverage、chunk/source/page、截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-027 · REQ-08 · P1 · PRE_MERGE_REQUIRED — 资料详情默认收起与选中
- **Given / 前置条件：** 资料库初始无选中资源。
- **When / 操作：** 选中资料、关闭详情、切换筛选/分页、再次选中。
- **Then / 唯一预期：** 详情默认收起；选中后按需打开；关闭后列表选择/筛选/滚动保持；窄窗使用不挤压主列表的呈现。
- **FAIL 反例：** 初始占据右侧空间、切换丢选中或详情将列表压成不可读窄缝。
- **验证方式：** Electron 多视口交互。
- **证据要求：** 列表/详情截图、resourceId、滚动和焦点记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-028 · REQ-08 · P0 · PRE_MERGE_REQUIRED — 资料状态分离
- **Given / 前置条件：** 准备原件已保存、正文等待/处理中/部分/失败、可检索、题目待核/已核对等状态。
- **When / 操作：** 导入、刷新、查看资料概要和题目整理。
- **Then / 唯一预期：** 原件保存、正文收录、索引可用、OCR/结构恢复、教师核对分别呈现。
- **FAIL 反例：** 将“已收录”显示为“答案正确”或“已教师核对”。
- **验证方式：** 状态映射单测 + 真实数据 E2E。
- **证据要求：** parseStatus/index status/question verification、截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-029 · REQ-08 · P1 · PRE_MERGE_REQUIRED — 原页预览和本机定位
- **Given / 前置条件：** 真实 PDF/Word 等不同格式资料，包含页码和来源 chunk。
- **When / 操作：** 打开原页、正文、来源引用和定位本机文件。
- **Then / 唯一预期：** 原页/页码/来源绑定正确；不支持格式说明限制；定位文件只在原路径存在时成功。
- **FAIL 反例：** 错误页码、来源错绑、虚构 PDF 预览或原件已丢失仍显示成功。
- **验证方式：** 真实文件/原页预览/OS file location。
- **证据要求：** resourceId/contentHash/page/sourceId、截图、文件存在性。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-030 · REQ-08 · P0 · PRE_MERGE_REQUIRED — 资料草稿保护
- **Given / 前置条件：** 资料元数据、笔记、OCR 校正或结构编辑有未保存修改。
- **When / 操作：** 切换资料、筛选、模式或关闭详情。
- **Then / 唯一预期：** 原有 draft guard 阻止危险切换或保留草稿；保存/放弃结果真实。
- **FAIL 反例：** 草稿丢失、旧版本覆盖新版本或切换后数据串资源。
- **验证方式：** Electron E2E + readback。
- **证据要求：** resourceId/contentHash/draft state、提示和 readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-031 · REQ-08 · P0 · PRE_MERGE_REQUIRED — 收录队列恢复
- **Given / 前置条件：** 队列含 pending/running/succeeded/failed/cancelled 和文件夹批次。
- **When / 操作：** 优先处理、停止单份、停止队列、重试、暂停/继续批次、重启应用。
- **Then / 唯一预期：** 状态来自真实服务；已保存原件不会因停止删除；重启恢复符合合同。
- **FAIL 反例：** 停止被当取消所有、重试丢版本、队列失败伪装完成。
- **验证方式：** queue/batch integration + Electron + readback。
- **证据要求：** task/resource/batch IDs、事件、重启前后状态。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-032 · REQ-08 · P0 · PRE_MERGE_REQUIRED — 教学工作台页内导航
- **Given / 前置条件：** 现有教学页入口 artifacts/notebook/book/question_notebook/paper。
- **When / 操作：** 从教学工作台逐项打开并返回。
- **Then / 唯一预期：** 所有五个专业页面可达，左栏不新增重复入口，返回上下文正确。
- **FAIL 反例：** 旧页被删除或页内导航与左栏冲突。
- **验证方式：** route/Electron E2E。
- **证据要求：** route IDs、逐页截图和导航录像。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-033 · REQ-09 · P0 · PRE_MERGE_REQUIRED — 教学文件列表与搜索
- **Given / 前置条件：** 真实 document artifacts 含不同格式、版本和状态。
- **When / 操作：** 搜索、刷新、选择、打开详情。
- **Then / 唯一预期：** 列表来自真实文件；搜索名称/格式有效；详情按选中对象显示。
- **FAIL 反例：** 合成文件冒充生产、筛选隐藏有效版本或列表/详情错配。
- **验证方式：** Electron + file metadata readback。
- **证据要求：** artifact ID/type/status/version/hash。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-034 · REQ-10 · P0 · PRE_MERGE_REQUIRED — 教学文件版本/来源/导出
- **Given / 前置条件：** 存在已导出/草稿/officeVersion 文件。
- **When / 操作：** 预览、打开原文件、查看版本/来源、回原对话、导出。
- **Then / 唯一预期：** 真实文件路径/版本/来源一致；未导出不能显示交付；PPTX 预览不冒充逐页编辑器。
- **FAIL 反例：** 打开错误版本、下载 HTML 冒充 PPTX、丢来源或假交付。
- **验证方式：** Electron + Office/WPS 实际打开 + hash/readback。
- **证据要求：** artifactId/version/path/hash、应用截图、Office 打开记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-035 · REQ-10 · P1 · PRE_MERGE_REQUIRED — 整包任务子视图
- **Given / 前置条件：** 真实 delivery bundle 包含多项成果和独立状态。
- **When / 操作：** 打开整包任务、逐项核对、返回文件列表。
- **Then / 唯一预期：** 每项成果状态、版本、来源分别展示；整包汇总不掩盖单项失败。
- **FAIL 反例：** 部分失败仍显示整包完成或合并不同版本。
- **验证方式：** 真实 delivery API/Electron。
- **证据要求：** bundleId/artifact IDs/versions/statuses。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-036 · REQ-10 · P1 · PRE_MERGE_REQUIRED — 课堂设计与预演子视图
- **Given / 前置条件：** 现有 classroom/lesson/interactive 能力可用或存在明确依赖。
- **When / 操作：** 打开课堂设计、预演、修改并保存/取消。
- **Then / 唯一预期：** 只呈现现有真实能力；保存与预览来自真实服务；不自动写学生学习事实。
- **FAIL 反例：** 新增第二套课程引擎、虚构互动结果或自动写学生档案。
- **验证方式：** 现有 service/HTML preview + Electron + readback。
- **证据要求：** lesson/plan ID、真实预览、保存/取消回执。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-037 · REQ-10 · P1 · PRE_MERGE_REQUIRED — 模考汇编子视图
- **Given / 前置条件：** 存在真实 mock exam catalog/source references。
- **When / 操作：** 搜索、打开目录、查看原件来源并返回。
- **Then / 唯一预期：** 模考记录和原件来源可核验；无数据/接口时诚实空态/阻断。
- **FAIL 反例：** 固定样例冒充模考记录或来源丢失。
- **验证方式：** catalog/service + Electron。
- **证据要求：** catalog IDs/source references/readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-038 · REQ-11 · P0 · PRE_MERGE_REQUIRED — 备课本 CRUD/归档
- **Given / 前置条件：** 本地备课本及记录存在，含未保存和已归档状态。
- **When / 操作：** 新建、编辑、保存、刷新、归档/恢复、重启。
- **Then / 唯一预期：** SQLite 读回一致；归档只读；未保存草稿保护。
- **FAIL 反例：** 假保存、归档内容被改写或重启丢失。
- **验证方式：** Electron + SQLite readback。
- **证据要求：** notebookId/recordId/revision、前后内容 hash。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-039 · REQ-11 · P0 · PRE_MERGE_REQUIRED — 讲义章节/页面/内容块
- **Given / 前置条件：** 讲义含章节、页面、内容块和版本锁。
- **When / 操作：** 新建、排序、编辑、保存、放弃修改、重开。
- **Then / 唯一预期：** 结构与版本一致；教师修改和协作 patch 遵循原锁/草稿合同。
- **FAIL 反例：** AI 草稿自动落正式库、保存覆盖并发版本或返回丢改动。
- **验证方式：** TDD + Electron + SQLite readback。
- **证据要求：** bookId/pageId/blockId/revision、前后结构。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-040 · REQ-11 · P0 · PRE_MERGE_REQUIRED — 题本筛选/来源/收藏/编辑
- **Given / 前置条件：** 题本含不同题型、难度、来源、分类和待核题。
- **When / 操作：** 搜索筛选、收藏、创建编辑题目、核对来源、返回原题篮。
- **Then / 唯一预期：** 来源类型和教师核对状态清晰；未核对候选不显示已确认；原题数据不被隐式覆盖。
- **FAIL 反例：** 题源混淆、候选覆盖原题或筛选丢失题篮。
- **验证方式：** Electron + question DB readback。
- **证据要求：** questionId/source/version/bookmark/verification state。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-041 · REQ-12 · P0 · PRE_MERGE_REQUIRED — 组卷蓝图与上下文
- **Given / 前置条件：** 存在题库/来源任务/草稿/已保存试卷。
- **When / 操作：** 创建/打开蓝图，切换来源模式，返回并恢复。
- **Then / 唯一预期：** 蓝图/题源/上下文 session 绑定正确；未保存修改受保护；用途不是三个同质入口。
- **FAIL 反例：** 打开错误 session、蓝图变化未标脏或旧草稿被覆盖。
- **验证方式：** TDD + Electron + SQLite/readback。
- **证据要求：** paperId/sessionId/blueprint revision/draft snapshot。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-042 · REQ-12 · P0 · PRE_MERGE_REQUIRED — 持久题篮和混合题源
- **Given / 前置条件：** 题库题、上传/粘贴题、需求命题题、参考卷提取题可用。
- **When / 操作：** 混合来源选题、加入/移除题篮、刷新/重启。
- **Then / 唯一预期：** 同一持久题篮保留题目、来源、父题版本和选择；重复题规则真实；手选题不被自动覆盖。
- **FAIL 反例：** 前端临时数组冒充持久题篮、重复加入、题源丢失或AI补题静默覆盖。
- **验证方式：** Contract + Electron + SQLite readback。
- **证据要求：** basketId/question IDs/source lineage/version before/after。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-043 · REQ-12 · P0 · PRE_MERGE_REQUIRED — 组卷审核和结构校验
- **Given / 前置条件：** 试卷有题型/知识点/难度/配额/分值和题目答案。
- **When / 操作：** 逐题核对、修改题干/答案/图片/分值/顺序和蓝图。
- **Then / 唯一预期：** 题量/总分/题型统计一致；来源和审核失效按合同重置；待核对草稿不能标确认。
- **FAIL 反例：** 分值不一致、来源错配、变更后旧审核仍有效。
- **验证方式：** 业务规则 TDD + Electron。
- **证据要求：** paper snapshot、题目版本、总分计算、审核记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-044 · REQ-12 · P0 · PRE_MERGE_REQUIRED — 正式 Word/PDF/答题卡交付
- **Given / 前置条件：** 有教师确认的真实试卷快照和测试输出目录。
- **When / 操作：** 生成学生版/教师版/答题卡，打开文件并核对分页、题号、图片、公式、答案隔离。
- **Then / 唯一预期：** 正式文件读取同一确认快照；学生版不含答案；格式真实可打开；取消/失败保留草稿。
- **FAIL 反例：** HTML 下载冒充 Word/PDF、答案泄露、导出版本不一致或文件损坏。
- **验证方式：** Electron + Office/WPS/PDF viewer + file hash/readback。
- **证据要求：** paper snapshot/version/export receipt/path/hash/打开记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-045 · REQ-13 · P0 · PRE_MERGE_REQUIRED — 学生工作台同一 studentId 上下文
- **Given / 前置条件：** 存在学生 A、B 及其不同档案/记录。
- **When / 操作：** 选择 A，切换档案/记录/错题/计划/复盘/概览，再选择 B。
- **Then / 唯一预期：** 每个子页面绑定当前 studentId；切换时保护未保存内容；迟到请求不能污染新学生。
- **FAIL 反例：** 页面显示 A 的数据却标题为 B，或切换丢草稿。
- **验证方式：** TDD（异步 epoch/context）+ Electron E2E。
- **证据要求：** studentId、请求 epoch、前后数据截图和 readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-046 · REQ-14 · P0 · PRE_MERGE_REQUIRED — 学生档案 CRUD/导出/归档
- **Given / 前置条件：** 隔离测试 profile 含学生档案和附件。
- **When / 操作：** 新增、编辑、保存、打开目录、导出、归档/恢复。
- **Then / 唯一预期：** 保存成功来自主进程回执并能重开读回；导出文件存在；归档有明确确认。
- **FAIL 反例：** 假成功、导出文件不存在、学生数据被上传或归档误触。
- **验证方式：** Electron + SQLite/file readback。
- **证据要求：** studentId、export path/hash、archive state、审计日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-047 · REQ-14 · P1 · PRE_MERGE_REQUIRED — 学生与记录本地检索
- **Given / 前置条件：** 学生和学习记录分布于多个本地记录。
- **When / 操作：** 输入姓名/标题/正文/标签搜索，打开命中记录再返回。
- **Then / 唯一预期：** 命中学生和记录正确，结果片段和来源可见，返回保留查询。
- **FAIL 反例：** 搜索云端或命中内容错绑学生。
- **验证方式：** 本地 SQLite search E2E。
- **证据要求：** query、studentId/recordId、命中片段、数据源证明。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-048 · REQ-14 · P0 · PRE_MERGE_REQUIRED — 学习记录导入与 OCR 校正
- **Given / 前置条件：** 测试学生有原始错题图片、损坏图片和可识别图片。
- **When / 操作：** 选择学生、添加图片/文字、OCR、校正、保存/取消。
- **Then / 唯一预期：** 原图本地保留；OCR 结果标未核对；教师修正后可保存读回；取消不产生记录。
- **FAIL 反例：** OCR 结果直接当真、原图丢失、损坏文件假成功或重复提交。
- **验证方式：** Electron + OCR host boundary + SQLite/file readback。
- **证据要求：** recordId/image hash/OCR task/status/corrected text。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-049 · REQ-15 · P0 · PRE_MERGE_REQUIRED — 错题证据与相似/变式题
- **Given / 前置条件：** 原题、相似题、AI 变式题和待教师确认项并存。
- **When / 操作：** 查看原图、校正文字、错因、相似/变式题并确认练习。
- **Then / 唯一预期：** 原题来源、相似题本地命中、变式题待核分类清楚；教师确认前不写正式学习结论。
- **FAIL 反例：** 来源类别混淆、AI 变式直接当学生事实或原图被覆盖。
- **验证方式：** 真实数据 E2E + readback。
- **证据要求：** recordId/source lineage/teacher confirmation/练习记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-050 · REQ-16 · P1 · PRE_MERGE_REQUIRED — 学习计划证据边界
- **Given / 前置条件：** 学生有/没有教师确认的本地学习路径。
- **When / 操作：** 打开学习计划并查看模块/练习。
- **Then / 唯一预期：** 只展示已确认路径和可追溯来源；没有路径显示有行动的空态；不生成无数据掌握度百分比。
- **FAIL 反例：** 从模型推测掌握度、伪造图表或无来源结论。
- **验证方式：** SQLite readback + Electron。
- **证据要求：** pathId/confirmation/source record IDs/空态截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-051 · REQ-16 · P0 · PRE_MERGE_REQUIRED — 学习复盘草稿与保存
- **Given / 前置条件：** 学生有时间范围内的真实学习记录。
- **When / 操作：** 生成复盘草稿、编辑正文/家长摘要、保存、重启再读。
- **Then / 唯一预期：** 报告标草稿/已保存/教师确认；每项结论可追源记录；保存后 SQLite readback 一致。
- **FAIL 反例：** 没有证据却生成精确结论、保存不落库或教师编辑丢失。
- **验证方式：** Electron + SQLite readback。
- **证据要求：** reportId/sourceRecordIds/revision/content hash。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-052 · REQ-16 · P1 · PRE_MERGE_REQUIRED — 学习概览真实数据
- **Given / 前置条件：** 学生有真实样本或无样本数据。
- **When / 操作：** 选择时间范围、查看图表、下钻记录。
- **Then / 唯一预期：** 图表显示单位、范围、样本数和来源；空数据不绘制假趋势；筛选结果一致。
- **FAIL 反例：** 无样本时伪造百分比/折线，或图表与记录不一致。
- **验证方式：** Electron + data query/readback。
- **证据要求：** query range/sample count/record IDs/截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-053 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 设置窗口独立非模态单实例
- **Given / 前置条件：** 主窗口已打开；设置未打开。
- **When / 操作：** 从左栏、菜单、对话入口多次打开设置。
- **Then / 唯一预期：** 创建真正独立 BrowserWindow；重复打开聚焦同一实例；不创建模态 Dialog 或第二主应用。
- **FAIL 反例：** 设置只是 activeView、模态弹窗或多次打开产生多个实例。
- **验证方式：** Electron BrowserWindow integration + TDD。
- **证据要求：** window IDs/count/parent/focus/录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-054 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 设置窗口主窗连续性与焦点
- **Given / 前置条件：** 主窗口正在输入/运行 Pi task/显示待办；设置窗已打开。
- **When / 操作：** Alt+Tab、切回主窗、再次聚焦设置、关闭设置。
- **Then / 唯一预期：** 主窗可继续操作；设置聚焦时仅视觉弱化；切回主窗蒙层撤去；关闭不停止 Pi task、不丢草稿。
- **FAIL 反例：** 主窗被模态锁定、遮罩拦截、任务被取消或焦点丢失。
- **验证方式：** Electron E2E + runId/draft readback。
- **证据要求：** window focus events、runId/status、草稿前后值、录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-055 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 设置 IPC 最小权限
- **Given / 前置条件：** 主窗、合法设置窗、未授权 renderer、子 frame 各自存在。
- **When / 操作：** 分别调用允许/不允许的设置、备份、权限和文件接口。
- **Then / 唯一预期：** 合法设置窗只能调用明确 allowlist；主进程校验 sender、mainFrame、窗口身份、capability 和原权限；其他 sender 被拒绝。
- **FAIL 反例：** 为解决 sender 限制而全局放开 IPC 或让子窗读取任意文件/权限。
- **验证方式：** TDD + contract tests + Electron negative tests。
- **证据要求：** sender/frame/window IDs、允许/拒绝结果、脱敏日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-056 · REQ-18 · P1 · PRE_MERGE_REQUIRED — 设置分类和搜索
- **Given / 前置条件：** 当前 settings 真实 10 个分类和设置项。
- **When / 操作：** 按日常/高级分层浏览、搜索设置并定位真实字段。
- **Then / 唯一预期：** 模型/界面/教师记忆/权限/备份等日常入口和技能/工具/诊断高级能力都可达；搜索能定位并聚焦真实控件。
- **FAIL 反例：** 删除已有能力、搜索结果只是静态文本或专业功能不可达。
- **验证方式：** Electron page/route tests。
- **证据要求：** tab IDs、搜索命中、焦点录像、功能入口映射。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-057 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 设置保存、失败和生效语义
- **Given / 前置条件：** 准备可保存配置、无效配置、权限拒绝和保存失败场景。
- **When / 操作：** 修改配置、保存、刷新、切主窗读回。
- **Then / 唯一预期：** 保存/即时生效/重启生效语义真实；成功有主进程回执和读回；失败保留输入且显示作用范围。
- **FAIL 反例：** 只 Toast 成功但数据未保存、失败丢输入或不同保存时序被错误合并。
- **验证方式：** TDD + host integration + readback。
- **证据要求：** config version/readback/diff/error code（脱敏）。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-058 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 设置备份/权限/危险操作
- **Given / 前置条件：** 隔离数据副本和受控备份目录。
- **When / 操作：** 执行备份、校验、恢复、权限变更或危险操作确认。
- **Then / 唯一预期：** 操作对象/范围/影响清楚；仍走原宿主授权；恢复前有备份和验证；UI 不扩大目录范围。
- **FAIL 反例：** 误操作日常数据、权限扩大、备份损坏或只在高级页隐藏风险。
- **验证方式：** Electron + file/db readback + negative permission tests。
- **证据要求：** backup hash/manifest/permission receipt/恢复对照。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-059 · REQ-19 · P1 · PRE_MERGE_REQUIRED — 全局视觉 Token 单一来源
- **Given / 前置条件：** 当前主题/变量/CSS 层和 HeroUI 组件已盘点。
- **When / 操作：** 在首页、任务、资料、教学、学生、设置页面对照颜色、字体、间距和层级。
- **Then / 唯一预期：** 同一语义 Token 一致；蓝主操作/紫 AI/绿完成/琥珀待处理/红失败；图标配文字；色值仍需真实 AA 检查。
- **FAIL 反例：** 逐页随意定义颜色、语义混用或低对比度。
- **验证方式：** CSS token audit + screenshots + contrast computation.
- **证据要求：** Token diff、颜色角色映射、对比度报告、逐页截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-060 · REQ-19 · P1 · PRE_MERGE_REQUIRED — HeroUI/图标组件边界
- **Given / 前置条件：** 当前 HeroUI v3/Pro 版本、OSS/Pro 来源和 lucide-react 已核验。
- **When / 操作：** 检查 Button/Select/Disclosure/Modal/Icon 等交互状态。
- **Then / 唯一预期：** 沿用真实版本 API；无 vendor 修改、无第二套库、无全局污染；hover/focus/pressed/disabled/loading 一致。
- **FAIL 反例：** 错误版本 API、全局 !important、改 vendor 或丢失原厂可访问行为。
- **验证方式：** CSSOM/computed style/source scan + component tests。
- **证据要求：** 组件版本、获胜选择器、CSS 来源、交互截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-061 · REQ-20 · P1 · PRE_MERGE_REQUIRED — 状态变化 Motion System
- **Given / 前置条件：** 准备出现/消失/展开/折叠/移动/替换/加载/成功/失败/取消/恢复场景。
- **When / 操作：** 跨页面执行这些状态变化。
- **Then / 唯一预期：** 同类变化共享 Token/曲线；动效解释空间/状态，不装饰；真实业务状态先变，动画只呈现。
- **FAIL 反例：** 每页独立时长、动画制造假进度或阻断交互。
- **验证方式：** Motion token audit + Electron state matrix.
- **证据要求：** 状态→token 映射、录屏、代码引用扫描。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-062 · REQ-20 · P1 · PRE_MERGE_REQUIRED — 动效中断/反向/跟手
- **Given / 前置条件：** 动画未完成时允许重复操作/拖动/关闭。
- **When / 操作：** 快速反向点击、Esc、切页、拖动面板。
- **Then / 唯一预期：** 从当前可见状态接续；拖动实时跟手；无残影、双弹窗、抖动、焦点错位或业务操作重复。
- **FAIL 反例：** 等待动画完成才能操作、残留遮罩或重复副作用。
- **验证方式：** Electron E2E + state machine tests.
- **证据要求：** 操作序列、最终状态、焦点和事件监听证据。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-063 · REQ-20 · P1 · PRE_MERGE_REQUIRED — Reduced Motion
- **Given / 前置条件：** 系统 `prefers-reduced-motion`/应用减少动态效果启用。
- **When / 操作：** 重复执行菜单、页面、窗口、详情和状态变化。
- **Then / 唯一预期：** 非必要位移/缩放/模糊明显减少；状态变化、焦点、反馈和层级仍可理解。
- **FAIL 反例：** 强制覆盖系统偏好或减少动效后状态无法区分。
- **验证方式：** Electron OS preference test + CSS inspection.
- **证据要求：** 系统偏好、computed styles、前后录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-064 · REQ-20 · P1 · PRE_MERGE_REQUIRED — 动效性能
- **Given / 前置条件：** 同一设备、同一数据、同一构建路径；含长对话、1000 条任务/资料分页和多页预览。
- **When / 操作：** 测滚动、流式输出、设置打开/关闭、详情展开和筛选。
- **Then / 唯一预期：** 以 60Hz 的 16.7ms 帧预算作参考，记录帧长/掉帧/主线程长任务/CPU/GPU/内存前后；无本轮引入的明显性能退化；低性能可关闭 blur/装饰动效。
- **FAIL 反例：** 仅凭主观“丝滑”判通过、没有 before/after、长内容明显卡顿。
- **验证方式：** Chrome/Electron Performance trace + same-machine comparison.
- **证据要求：** 硬件/OS/DPR/刷新率/数据规模、trace、帧长分布。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-065 · REQ-21 · P1 · PRE_MERGE_REQUIRED — 多视口/DPI/窗口缩放
- **Given / 前置条件：** Windows 1366×768、1920×1080、800×768 与 100/125/150% 缩放。
- **When / 操作：** 操作主入口、列表、详情、设置窗、弹层和表单。
- **Then / 唯一预期：** 重要操作可达；无横向溢出、任务栏遮挡、双滚动陷阱；记录 CSS viewport/native bounds/DPR/scale。
- **FAIL 反例：** 把物理像素当 CSS viewport、确认按钮不可见或正文窄到不可读。
- **验证方式：** 真实 Windows/Electron DPI tests.
- **证据要求：** 窗口 bounds、CSS viewport、DPR、系统缩放、截图/录像。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-066 · REQ-22 · P1 · PRE_MERGE_REQUIRED — 键盘/焦点/可访问性
- **Given / 前置条件：** 键盘-only、屏幕阅读器可观察名称、状态颜色和文本。
- **When / 操作：** Tab/Shift+Tab/Enter/Space/Esc、关闭详情/窗口、表单错误、focus return。
- **Then / 唯一预期：** 焦点顺序可理解；图标按钮有 accessible name；展开状态有 aria；焦点可见；普通文本对比达到 WCAG AA 目标。
- **FAIL 反例：** 只靠颜色/hover传达状态、焦点丢失或键盘无法完成主要操作。
- **验证方式：** Accessibility tree + keyboard E2E + contrast audit.
- **证据要求：** AX snapshot、键盘录像、对比度报告。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-067 · REQ-22 · P0 · PRE_MERGE_REQUIRED — 全局状态语义
- **Given / 前置条件：** 覆盖 loading/empty/ready/running/partial/completed/cancelled/failed/retry 适用状态。
- **When / 操作：** 在各页面触发/读取状态。
- **Then / 唯一预期：** 状态词、图标、颜色和下一步语义一致；数据来源是真实服务；失败不当空数据。
- **FAIL 反例：** 同一状态跨页含义不同或无真实来源。
- **验证方式：** 状态映射测试 + Electron 页面矩阵。
- **证据要求：** 状态来源、截图、事件/回执。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-068 · REQ-23 · P0 · PRE_MERGE_REQUIRED — 核心教师 E2E 旅程
- **Given / 前置条件：** 隔离数据中有资料、题库、学生和已保存成果。
- **When / 操作：** 执行：问小智→任务→资料→组卷/PPT成果→教师编辑/确认→回原对话。
- **Then / 唯一预期：** task/session/artifact/resource/student ID 和版本一致；教师能完成完整路径；不存在假成功。
- **FAIL 反例：** 流程断裂、返回错会话、成果版本错配或无法读回。
- **验证方式：** 真实 Electron E2E + SQLite/file readback.
- **证据要求：** 完整录屏、所有业务 ID、文件 hash/readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-069 · REQ-24 · P0 · PRE_MERGE_REQUIRED — UI-FINAL A01–A36 旧门禁映射
- **Given / 前置条件：** 旧 UI-FINAL 36 项固定验收和当前源代码/报告可访问。
- **When / 操作：** 逐项建立 LG-A01..LG-A36 与 V3 REQ/AC/TASK/TEST 映射；A01–A34 完整执行，A35/A36 按 legacy/LEGACY_GATE_MAPPING.md 拆分候选与最终 main 子条件。
- **Then / 唯一预期：** 36 项全部保留；A01–A34 合并前 PASS；A35/A36 的候选子条件合并前 PASS、远端/最终 main 子条件 FG-01 合并后 PASS；未被本轮影响的项目仅在有绑定当前源码 SHA 的有效证据时复用，否则重测。
- **FAIL 反例：** 删除/弱化旧验收、将 NOT_RUN 当通过或没有证据映射。
- **验证方式：** 旧合同审计 + legacy gate matrix。
- **证据要求：** 36 行矩阵、来源链接、当前 SHA、逐项证据。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-070 · REQ-25 · P0 · PRE_MERGE_REQUIRED — 真实构建与 CI 门禁
- **Given / 前置条件：** Phase 0 已核实 package.json、lockfile、CI 和本轮适用脚本。
- **When / 操作：** 运行 build/type/renderer/component/module/Electron smoke 等适用命令。
- **Then / 唯一预期：** 每个命令记录真实 exit code；失败不隐藏；不存在的脚本不编造，使用经说明的等价验证。
- **FAIL 反例：** 只写命令不运行、脚本不存在却报通过、跳过必要门禁。
- **验证方式：** CLI execution + CI run evidence.
- **证据要求：** 命令、时间、exit、stdout/stderr、源码 SHA。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-071 · REQ-25 · P0 · PRE_MERGE_REQUIRED — 双向需求追踪完整
- **Given / 前置条件：** 26 REQ、90 AC、实施任务、代码 diff、测试和证据矩阵已建立。
- **When / 操作：** 从 REQ 查到 TASK/CODE/TEST/EVIDENCE，再从每个 diff 反查 REQ。
- **Then / 唯一预期：** 每项必需需求都有实施或 VERIFIED_COMPLETE 路径、验收、代码位置、测试和证据；每个改动都说明需求与验证。
- **FAIL 反例：** 孤立需求、无测试任务、无证据 PASS 或无归属代码变更。
- **验证方式：** CSV schema validation + independent audit.
- **证据要求：** traceability.csv、diff-to-REQ review、完整性检查。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-072 · REQ-26 · P1 · PRE_MERGE_REQUIRED — 独立结果审查
- **Given / 前置条件：** 有最终 diff、完整 AC 矩阵、失败证据和运行录像。
- **When / 操作：** 由非实施视角审查缺失功能、伪验收、权限、共享改动和回归。
- **Then / 唯一预期：** 审查记录问题分级、证据、采纳/拒绝理由；若无独立 Agent 工具，明确为内部独立审查。
- **FAIL 反例：** 只复述实施 AI 自评或声称未真实调用的 Gemini 已参与。
- **验证方式：** Independent review report.
- **证据要求：** 审查者/模型/输入/输出/发现/决策记录。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-073 · REQ-26 · P1 · PRE_MERGE_REQUIRED — AI 行为评测条件门禁
- **Given / 前置条件：** 本轮 diff 确认是否改变模型、提示词、检索、OCR、工具选择、生成质量或输出语义。
- **When / 操作：** 如有变化，运行固定任务集；如无变化，记录差异证明。
- **Then / 唯一预期：** 有 AI 行为变化时，按模型/配置/数据版本、任务输入、评分依据、输出、时延/成本和人工抽检评测；无变化时仅在证据证明后 N/A。
- **FAIL 反例：** 把普通单测通过当 AI 质量改善，或改变评测标准迎合输出。
- **验证方式：** AI eval runner + human rubric, conditional.
- **证据要求：** model/config/data versions、inputs/outputs、scores、latency/cost、N/A rationale。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`
- **条件性适用规则：** 仅当实际改变 AI 行为时必需；纯 UI 变更可在 Phase 0 证实后 N/A。

### AC-074 · REQ-26 · P0 · PRE_MERGE_REQUIRED — 页面审批状态与样张边界
- **Given / 前置条件：** P01–P03 与 P04–P18/X01–X05 页面审批台账可读。
- **When / 操作：** 执行页面视觉变更并提交截图。
- **Then / 唯一预期：** 只按 CONFIRMED 页面实施结构变化；未确认页面只做安全 Token 一致性或先取得用户批准；样张均标合成数据/非生产。
- **FAIL 反例：** 把提案图当用户批准、从图片新增无真实能力按钮或改变左栏。
- **验证方式：** Decision log review + screenshot metadata audit.
- **证据要求：** 页面审批矩阵、确认记录、前后截图、源映射。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`


## 2A. V3.1 设置专项新增必需验收（SET-P0）

本节为本轮唯一验收真源的增量。所有新增项初始 `NOT_RUN`，与原 AC-053..058 同为必需项，禁止独立把它们标 N/A。

### AC-075 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 真顶层独立非模态窗口
- **Given / 前置条件：** Windows 正式 Electron 构建，主窗已打开且设置当前为主页面路由（旧实现）。
- **When / 操作：** 点击左栏设置并检查 BrowserWindow.getAllWindows()、窗口 parent、modal 标志、系统 Alt+Tab。
- **Then / 唯一预期：** 主进程创建独立 top-level、非模态、非 always-on-top 的设置 BrowserWindow；可单独 Alt+Tab；原设置页不再占用主工作区。
- **FAIL 反例：** 仅切 activeView='settings'、主窗 React Modal、parent/modal 导致主窗不可交互，或强制置顶挡住主窗。
- **验证方式：** 窗口生命周期 TDD + Electron 主进程集成 + Windows 实操。
- **证据要求：** window IDs/owner/mode/bounds/事件日志、Alt+Tab 操作录屏、主窗截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-076 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 入口同一窗口单例和加载失败恢复
- **Given / 前置条件：** 左栏、桌面菜单、问小智设置入口都存在；包含窗口创建中、ready 和加载失败场景。
- **When / 操作：** 从三个入口快速重复点击、窗口创建中再次打开、关闭后重开、模拟加载失败。
- **Then / 唯一预期：** 所有入口归口同一 window manager；creating/ready 只产生一个实例；重复打开聚焦且不重置草稿；加载失败释放引用并可重试。
- **FAIL 反例：** 同屏出现多个设置窗、白屏不消失、失败后无法重试或编辑值丢失。
- **验证方式：** 状态机 TDD + Electron E2E + 失败注入。
- **证据要求：** 窗口计数、creation/focus/closed 时间线、加载错误与重试结果。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-077 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 主窗背景蒙层不阻断交互
- **Given / 前置条件：** 主窗口正在编辑文本，设置窗打开并获得焦点。
- **When / 操作：** 设置聚焦时观察弱化；鼠标点主窗输入/滚动；切回设置、最小化/关闭设置。
- **Then / 唯一预期：** 弱化层仅装饰，pointer-events 不拦截；主窗可点击并继续输入/滚动；主窗获得焦点后弱化及时消失；没有残留。
- **FAIL 反例：** 遮罩锁住主窗、滚动/拖拽被阻断、切回主窗仍变暗，或者点击背景触发危险副作用。
- **验证方式：** 真实 Windows 双窗口 E2E + DOM hit-test + focus event 日志。
- **证据要求：** 焦点与遮罩事件序列、点击/滚动录屏、computed pointer-events 与截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-078 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 多屏、DPI、最小化和应用退出
- **Given / 前置条件：** Windows 100%/125%/150% 缩放与双屏，含第二屏拔除和 1366×768 有效工作区。
- **When / 操作：** 打开/移动/缩放/最小化/还原设置，拔除第二屏，退出主程序。
- **Then / 唯一预期：** 设置窗始终落在可见工作区，标题/关闭/主要操作可达；重新聚焦不白闪；主程序退出后设置窗和订阅安全结束。
- **FAIL 反例：** 窗体屏幕外、DPI 下按钮不可点击、白闪/黑闪，或主程序退出遗留窗口。
- **验证方式：** Electron E2E + Windows DPI/多屏人工实测 + 退出生命周期测试。
- **证据要求：** workArea/native bounds/CSS viewport/DPR/scale、屏幕记录、窗口生命周期日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-079 · REQ-17 · P0 · PRE_MERGE_REQUIRED — 主任务、待办、Composer 在开关设置时不受影响
- **Given / 前置条件：** 原 Pi task 正在运行，主窗有会话草稿、附件、待办和长消息滚动位置。
- **When / 操作：** 开/关设置，反复切焦点，关闭设置，重开主窗原会话。
- **Then / 唯一预期：** runId、任务状态、流式事件、草稿/附件/待办和滚动保持；不重启 Pi、不触发 stop、不重新生成任务。
- **FAIL 反例：** 任务被取消、Composer remount 丢稿、PendingPanel 丢已填字段、未知工具操作被重放。
- **验证方式：** 真实 Pi/Electron E2E + session/run event readback。
- **证据要求：** runId/taskId/event cursor、附件/draft 前后、焦点与窗口录屏。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-080 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 当前十类设置全部可达且不重复数据
- **Given / 前置条件：** 最新 PiSettingsWorkspace 包含 models/skills/capabilities/tools/permissions/teacher-memory/interface/archives/backup/diagnostics 十类。
- **When / 操作：** 在独立窗口中逐一通过分类导航与搜索进入并尝试实际读回。
- **Then / 唯一预期：** 十类均可进入；保留原业务权限与数据；teacher-memory 包括 PiTeacherMemorySettings、PiL2MemorySettings、PiHistoryMemorySettings。
- **FAIL 反例：** 移植后某 tab 缺失、记忆子页遗失、失去真实接口或凭空新增无效设置。
- **验证方式：** 源码映射审计 + Electron 逐页 E2E + 各 owner 签收。
- **证据要求：** 十类映射表、完整操作录屏、实际组件/服务 readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-081 · REQ-18 · P1 · PRE_MERGE_REQUIRED — 教师文案、图标和状态语义
- **Given / 前置条件：** 十类设置具有真实功能与可读/不可读/未配置状态。
- **When / 操作：** 逐项审查分类、设置标签、说明、开关、选中/禁用/失败状态。
- **Then / 唯一预期：** 标签采用教师能理解的用途/结果描述；蓝主操作/紫 AI/绿真实成功/琥珀关注/红风险；图标配文字；不添加假开关。
- **FAIL 反例：** 以 Provider/MCP/Schema 替代日常说明、只靠颜色区分、假保存/假连接、对比不足。
- **验证方式：** 真实 Renderer 视觉对照 + 键盘 + a11y/contrast audit。
- **证据要求：** 最终组件截图、AX tree、Token 对比度、逐条术语映射。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-082 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 设置搜索定位真实控件与焦点
- **Given / 前置条件：** 十类均有搜索条目，含常用设置、归档、备份、模型密钥等真实字段。
- **When / 操作：** 输入关键字/英文别名，键盘选择结果，进入不同分组并按 Esc 清除查询。
- **Then / 唯一预期：** 搜索基于现有设置条目索引，跳转到实际分类及可用控件，焦点可见；不索引密钥值或学生/文件内容；失败不丢输入。
- **FAIL 反例：** 只搜索菜单名称、结果点击空白、泄漏凭证或定位时滚动跳动/丢失焦点。
- **验证方式：** SettingsSearchResults 组件测试 + Electron 键盘 E2E。
- **证据要求：** 查询词、目标 data-testid、AX/focus 录像、错误处理。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-083 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 会话级设置有效范围与变更保护
- **Given / 前置条件：** 主窗有 Session A/B、不同 workspace/权限；子窗显示会话设置。
- **When / 操作：** 开启设置，主窗切换 A→B，继续旧 A 的编辑或授权请求。
- **Then / 唯一预期：** 主进程可信 session scope 和 revision 是权威；子窗明确当前作用会话，切换后刷新/失效旧请求；拒绝跨会话写入。
- **FAIL 反例：** 从子窗 localStorage 猜 sessionId、把 A 权限写进 B、旧请求变成功、新会话自动获得额外授权。
- **验证方式：** 跨窗状态 TDD + IPC Contract + 真实 Session E2E。
- **证据要求：** sessionId/task revision/scope epoch、授权拒绝与读回。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-084 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 设置专用最小 typed preload
- **Given / 前置条件：** 新设置 BrowserWindow、主窗完整 omniEdu preload 和 10 类真实设置 API 依赖已清点。
- **When / 操作：** 以设置窗口运行，查看 exposed API keys；尝试正常配置读写和无关文件/终端/Agent 方法。
- **Then / 唯一预期：** 设置只获得版本化最小 API facade；主进程再校验 sender/mainFrame/window role/schema/业务授权；不暴露通用终端/文件/工具执行。
- **FAIL 反例：** 直接复制完整 window.omniEdu、暴露 nodeIntegration/require/fs、使用 renderer 侧自校验替代主进程安全。
- **验证方式：** Preload API surface test + main IPC negative/positive contract tests。
- **证据要求：** exposed key list、合法/非法 call logs、preload source、权限矩阵。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-085 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 非法 IPC 发送者与导航隔离
- **Given / 前置条件：** 合法设置窗、任意副窗口、子 frame、设置窗重新导航后的 webContents 测试夹具。
- **When / 操作：** 对模型、权限、备份、技能/MCP 和诊断尝试不授权 IPC、跨源导航/弹新窗口。
- **Then / 唯一预期：** 非法 sender/subframe/非设置 role/已变更 origin 均被拒绝；不允许非法导航复用权限；错误码和审计脱敏。
- **FAIL 反例：** 只比较 sender URL、sender 校验返回 true 即全放行、敏感输入出现在 stderr/日志。
- **验证方式：** Electron 安全负例 + CSP/navigation policy 验证。
- **证据要求：** sender/frame/window IDs、CSP/导航阻断事件、脱敏拒绝日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-086 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 模型配置与凭证读写/历史/撤销
- **Given / 前置条件：** 准备当前模型配置、错误密钥、有效密钥的隔离测试替身（不暴露真实凭证）及版本冲突。
- **When / 操作：** 测试连接、保存、查询历史、撤销、重开主窗读回。
- **Then / 唯一预期：** 沿现有 config-commit/save/verify/history/undo 版本化主进程路径；凭证脱敏；回执/读回一致；失败保留输入；不假称即时成功。
- **FAIL 反例：** 双重配置 store、错误状态显示已保存、日志暴露 API key、历史恢复无效版本。
- **验证方式：** Host contract TDD + Electron + config version/readback。
- **证据要求：** credential masking、config version/receipt/history/undo、主/设置窗口读回。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-087 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 工具/技能/能力/会话权限全量回归
- **Given / 前置条件：** 现有技能、能力目录、托管工具、MCP、会话权限与审批测试数据。
- **When / 操作：** 分别打开四类高级页，读权限、试行合法及非法操作、切换会话再刷新。
- **Then / 唯一预期：** 原技能/能力/工具/MCP 和权限路径完整；危险操作保留审批、版本与真实授权范围；设置窗不扩大操作权。
- **FAIL 反例：** 界面复制但调用失败、技能自动放权、MCP 凭证泄漏、无权操作居然成功。
- **验证方式：** 原模块契约回归 + Electron/E2E + 安全负例。
- **证据要求：** 各 tab API/readback/审批结果、原专项测试日志。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-088 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 教师/历史记忆、归档和备份真实读回
- **Given / 前置条件：** 隔离学生/教师数据副本；teacher-memory 三级入口与归档/备份页已有真实记录。
- **When / 操作：** 阅读/修改记忆、查看历史/归档、创建/校验/恢复备份并重启。
- **Then / 唯一预期：** 真实组件可达；个人/团队/会话范围遵循原规则；归档只读；备份成功必须有文件、hash/校验和恢复读回；原数据不丢。
- **FAIL 反例：** 删除历史记忆入口、归档误删内容、备份 Toast 假成功、恢复覆盖日常数据。
- **验证方式：** Integration + isolated DB/file readback + Electron E2E。
- **证据要求：** memory IDs/scope、archive IDs、backup path/hash/manifest、恢复 readback。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-089 · REQ-18 · P0 · PRE_MERGE_REQUIRED — 跨窗口配置版本同步和冲突恢复
- **Given / 前置条件：** 主窗与设置窗同时打开，并具备异步保存/撤销/错误注入场景。
- **When / 操作：** 在设置保存、主窗改变原配置、旧响应迟到，再重启设置窗口。
- **Then / 唯一预期：** 两窗最终显示同一主进程权威版本；过期请求不能覆盖新配置；冲突显示刷新或合适的撤销路径；订阅解除无泄漏。
- **FAIL 反例：** 保存成功仅 UI 本地变更、旧响应覆盖新值、重复事件订阅或关闭设置后泄漏监听。
- **验证方式：** 跨窗集成 TDD + real IPC + readback/事件追踪。
- **证据要求：** config revision/receipt/epoch、两窗截图、事件数量及卸载证据。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

### AC-090 · REQ-20 · P1 · PRE_MERGE_REQUIRED — 设置窗口精致动效、性能与减少动效
- **Given / 前置条件：** 普通 Windows 参考机，设置/主窗双窗口，原生 1366×768/1920×1080/125%/150% DPI，系统 Reduced Motion 开关。
- **When / 操作：** 打开/关闭/移动/切焦点设置、切类、滚动长配置页并对比背景模糊开关。
- **Then / 唯一预期：** 窗口/焦点状态清楚、无黑闪白闪、遮罩残留或重排；基于同机 before/after trace 无明显退化；Reduced Motion 关闭非必要位移和模糊而保留状态提示。
- **FAIL 反例：** 独立窗口看似丝滑但长页掉帧、焦点陷阱、模糊导致 GPU 明显回退或 reduced-motion 无效。
- **验证方式：** 真实 Electron Performance trace + CSS/AX + 对比录屏。
- **证据要求：** 硬件/GPU/刷新率/DPR/native bounds、帧长分布/long tasks、前后视频、reduced-motion 截图。
- **必需级别：** REQUIRED
- **初始状态：** `NOT_RUN`

## 3. 旧 UI-FINAL A01–A36 必需回归

旧验收原文完整保存在 `legacy/UI_FINAL_ACCEPTANCE_36.md`。36 项全部保留为 `LG-A01..LG-A36`，每项都必须映射到 V3 REQ/AC、实际页面/组件、测试入口和证据。只有代码/构建/数据/环境完全匹配的既有有效证据才可复用；否则重新执行。旧验收原文中的 NOT_RUN 不得被本包的设计样张通过所替代。

旧门禁逐项映射见 `legacy/LEGACY_GATE_MAPPING.md` 与 `acceptance/legacy_acceptance_matrix.csv`。36 项初始全部 NOT_RUN。

## 4. 旧 V2 AC-01..AC-32 映射

上一版 `05_ACCEPTANCE_CRITERIA.md` 原文保存在 `legacy/V2_PACKAGE_20261125/`。V2 AC-01..AC-32 不删除；按 `legacy/V2_AC_MAPPING.md` 映射到 V3 AC 或 MG/FG。V3 以本文件作为唯一当前断言标准，避免重复维护。

## 5. 合并与 DONE 门禁

- `MG-01`：AC-001..AC-090 全部 REQUIRED 条目 PASS（条件性 N/A 必须符合合同）；LG-A01..LG-A34 PASS；LG-A35 的“候选 diff/权限/冲突/非强推”部分 PASS；LG-A36 的“集成候选正式窗口启动与构建身份”部分 PASS；追踪完整、diff 归属明确、候选针对最新 main 实际运行通过，才允许合并 main。
- `LG-A35` 原标准中的“远端 main 包含交付提交”属于合并后的子条件，由 `FG-01` 验证；不能要求远端在合并前已包含尚未合并的提交。
- `LG-A36` 原标准中的“最终 main 正式窗口启动”属于合并后的子条件，由 `FG-01` 重验；合并前先在精确集成候选上启动并核验同一构建指纹。该拆分保留原要求并避免门禁循环。
- `FG-01`：合并后验证实际 main 包含本轮交付提交（并按现行授权验证远端 main）；最终构建/运行窗口 SHA 一致；重跑受影响关键 E2E/回归；结果全部 PASS。
- `FG-02`：最终报告、完整矩阵、证据索引、回滚、远端/部署状态齐全。
- 任一必需项 FAIL/BLOCKED/NOT_RUN，禁止合并和 DONE；合并后 FG 失败则状态为 MERGE_BLOCKED，不得 DONE。
