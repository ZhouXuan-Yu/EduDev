# V3.1 设置 P0 真实验证清单

1. **仅 Phase 0 查命令、owner 与 actual HEAD**；使用独立 Electron profile 和安全测试数据副本；不复用教师日常 profile。
2. 真实主窗启动→点击左侧设置→检查独立 BrowserWindow window count/role/非 modal/非 parent/非 always-on-top，三种入口重复打开同一窗口（AC-053,075,076）。
3. 运行 Pi task 和未发送草稿→设置开/关/主窗切焦点/Alt+Tab/移动/关闭→核验 runId/event cursor/Composer/PendingPanel/输入和滚动（AC-054,077,079）。
4. Windows 1366×768、1920×1080、100/125/150% 缩放、双屏移除、设置加载失败/应用退出（AC-078）。
5. 分别列出设置窗 `preload` 能力，尝试合法/非法 sender、子 frame、任意导航、模型/技能/MCP/备份/文件敏感操作（AC-055,084,085）。
6. 十类设置逐项进入，搜索可定位真实控件；会话 A→B 切换、过期作用范围拒绝；模型/ordinary config 保存、历史/撤销与读回（AC-056,080..083,086,089）。
7. TeacherMemory/L2/HistoryMemory、权限与工具、归档、备份校验和恢复走真实隔离服务（AC-058,087,088）。
8. 逐项记录前后截图、窗口证据、性能 trace 和 reduced-motion（AC-081,090），主窗蒙层 click through 必须实测。
9. 旧 UI-FINAL LG-A17/A18/A31/A32 与全部当前受影响回归仍必须 PASS。**任何 P0 FAIL 或 NOT_RUN 禁止合并 main。**

# 09 验证 Runbook：环境、命令、测试数据与实际动作

## 1. 环境身份

Phase 0 填写：
- 仓库根、工作树、branch、HEAD、origin/main SHA；
- Windows 版本、CPU/GPU/内存、屏幕刷新率、DPI/缩放；
- Electron/main/preload/renderer build fingerprint；
- Node/npm、lockfile、HeroUI/Pro/lucide 实装版本；
- 测试 profile、SQLite 副本、文件目录、provider/凭证范围；
- 真实运行窗口与源码 SHA 的对应证明。

不得使用教师日常数据作为破坏性测试对象。使用合成学生/资料/任务数据，明确记录数据类型。

## 2. 命令核验

先执行 `npm run` 或检查 `apps/desktop/package.json`，确认以下静态观察的脚本仍存在；本清单不是“已运行”证明：

```powershell
cd <repo>\apps\desktop
npm run build
npm run test:renderer-components
npm run test:ui-contracts
npm run test:ui-review
npm run test:workbench-ui
npm run test:sidebar-navigation
npm run test:daily-entry
npm run test:education-capabilities
npm run test:education-journeys
npm run test:ui-style-isolation
npm run test:xiaozhi-pi-ui
npm run test:xiaozhi-pi-attachment-entry
npm run test:xiaozhi-pi-composer-send
npm run test:xiaozhi-pi-settings-workspace-ui
npm run test:xiaozhi-pi-settings-local-job
npm run test:xiaozhi-long-history
npm run test:xiaozhi-task-browser-admission
npm run test:xiaozhi-narrow-interface
npm run test:xiaozhi-dpi-interface
npm run test:smoke
```

上述脚本需逐一核验是否存在及内容；不存在的脚本不运行、不虚构。`npm run lint`、`typecheck` 等若未在 package scripts 中证实，不得写为已运行。运行项目现行要求的类型检查、lint 和 CI workflow（若存在）。

根级 `git diff --check`：
```powershell
cd <repo>
git diff --check
```

依赖审计按根 AGENTS 现行规则执行；若存在历史漏洞，记录 baseline 与本轮增量，不为 UI 任务擅自全面升级依赖。

## 3. 测试数据

- 任务：1、20、100、1000+ 条，状态分布齐全，含长标题/长摘要/同更新时间/cursor 边界/部分不可读。
- 对话：短会话、长历史、多个文件夹、已归档、IME 输入和待办。
- 资料：PDF/DOCX/图片/文本，长文件名、多目录/标签/格式/状态、重复文件、损坏文件、未解析/部分索引/来源变更。
- 教学成果：真实隔离 PPTX/DOCX/PDF/XLSX/ZIP 以及多版本/草稿/导出失败。
- 题目/组卷：图文/公式/选项/答案/解析、重复题、来源不同、教师未核对、已确认/失效快照。
- 学生：合成学生 A/B、不同记录、图片、OCR 失败/部分成功、未保存草稿。
- 设置：合法/非法 sender、多个显示器、DPI、配置保存失败、备份恢复、主窗运行 Pi task。
- Motion：菜单/详情/窗口/长列表/长对话，快速反向点击和 reduced-motion。

## 4. 真实业务操作步骤

每项 AC 按合同执行，不得用静态图替代。关键路径：
1. 真实 Electron 启动，记录窗口/源码/构建身份。
2. 从左侧导航进入页面。
3. 使用真实按钮/键盘输入操作。
4. 观察 loading/running/partial/error/success 状态。
5. 检查 SQLite/文件/版本/权限真实 readback。
6. 重启或重新打开对象，核验持久化和恢复。
7. 失败/取消/重试走真实接口，记录副作用和结果。

## 5. 性能测量

- 以 60Hz 的 16.7ms 帧预算作参考，不把它当所有设备的硬件保证。
- 同机、同分辨率/DPR/缩放/数据量/构建方式，采集 before/after。
- 记录帧长分布、掉帧、主线程长任务、CPU/GPU、内存、首屏交互、长列表滚动、流式响应。
- 模糊背景与纯色蒙层分别测；低性能降级 blur/装饰动画。
- 没有可靠基线或测量工具时记录 BLOCKED/TO_VERIFY，不编造 P95/帧率改善。

## 6. 截图/录屏命名

`<AC-ID>-<PAGE>-<CSS-VIEWPORT>-<DPR>-<STATE>-<SOURCE-SHA>.png/mp4`

每份证据附 `environment.json`、命令日志和数据类型说明。截图不能证明持久化/性能/权限；录屏不能替代 readback；Mock 不证明真实服务。
