# V3.1 设置窗口测试补充

独立 BrowserWindow/TDD：单例与创建/销毁状态机、失败重试、焦点事件不留遮罩、DPI/跨屏 workArea；原 Pi runId/task/草稿不中断。

安全/契约：最小 settings preload exposed surface；合法 sender vs 伪造窗口/子框架/非法导航的拒绝；sessionId/配置版本/授权/凭证脱敏和跨窗订阅/解除。

真实集成：10 类设置逐项进入，模型保存/撤销、教师三级记忆、技能/能力/MCP/权限、归档、备份校验/恢复，必须真实宿主回执与 readback。

视觉/E2E：豆包式紧凑设置行、WorkBuddy 式左分类右内容，键盘/IME、标签、a11y、深长页滚动、reduced-motion、蒙层不截获主窗交互；真实 Electron trace，与离线 HTML 区分。

新增 AC-075..090 不得以静态截图、JS 单测或 Mock-only 作为正式 PASS。现有 `test:xiaozhi-pi-settings-workspace-ui`、`test:xiaozhi-pi-settings-local-job`、`test:ui-review` 仅是 Phase 0 可核验的命令入口，执行 AI 需创建相应真实设置子窗 E2E/negative tests 并纳入适用 CI。

# 07 测试策略：风险分层、TDD、Contract、Integration、E2E、Regression、AI Eval、CI

## 1. 风险映射

| 变更类别 | 风险 | 方法 | 必要验证 | 通过条件/证据 |
|---|---|---|---|---|
| 已正确实现且不修改 | L | SDD + 受影响回归 | 当前 SHA/证据核验 | 有效证据绑定当前构建；不重写 |
| 页面间距/文案/颜色 | L/M | 真实渲染对照、组件回归 | 截图、键盘、对比度 | 内容可读、状态一致、无布局退化 |
| 全局 Token/CSS 层 | M/H | CSSOM 审计、视觉回归 | 获胜选择器/层、全页面对照 | 无 vendor/全局污染 |
| 设置窗口生命周期 | H | TDD + Electron integration | 单例、焦点、close、display/DPI | 有效红绿日志和真实窗口证据 |
| IPC sender/权限 | Critical | TDD + Contract + Security negative tests | 合法/非法 sender、mainFrame、allowlist | 非授权调用被拒，合法操作真实读回 |
| 任务搜索/分页/query | H | TDD + Contract + DB integration | 全量数据、cursor、过滤、并发变化 | 跨页搜索正确，无重复/漏项 |
| 任务/资料/学生上下文 | H | TDD（状态/epoch）+ E2E | 切换/迟到请求/草稿保护 | 对象 ID 和版本一致 |
| 资料/题目/组卷数据 | Critical | Contract + Integration + E2E | 文件、SQLite、来源、版本、导出 | 真实 readback 与确认快照一致 |
| Composer/Pi/审批/恢复 | Critical | 原测试回归 + Electron E2E | IME、runId、停止、待办、恢复 | 原行为不回退 |
| Motion/长内容 | M/H | 状态转换测试 + Perf trace | 中断、反向、reduced motion、长列表 | 无残影/显著性能退化 |
| AI 生成/检索/OCR 行为 | Critical | AI Evaluation（仅真实变更时） | 固定任务集、质量/来源/失败 | 评分规则不因结果变化而临时放宽 |

## 2. PDD / SDD / BDD / ATDD 落地

- PDD：`START_PROMPT.md` 和 `goal.md` 作为唯一执行入口；每次续做读取 `13_EXECUTION_STATUS.md` 和失败矩阵。
- SDD：`01_CONFIRMED_SPEC.md`、`design/*`、`08_REQUIREMENT_TRACEABILITY.md`；需求变化必须先更新规格、AC 和追踪。
- BDD：`05_BDD_SCENARIOS.md`；正常/边界/失败/恢复均有 Given/When/Then。
- ATDD：`06_ATDD_ACCEPTANCE.md`；先锁定 AC，再开始实现。报告只填结果，不复制/修改预期。
- TDD：关键状态、查询、权限、幂等、恢复逻辑按红→绿→重构执行；已有正确代码不故意破坏造红灯。

## 3. TDD 必选适用范围

1. 设置窗口 open/focus/close 单例、显示器 workArea、退出清理。
2. IPC sender/window/mainFrame allowlist 正反判断。
3. 设置配置读取/保存/版本读回和跨窗同步。
4. 任务搜索 query validation、完整范围检索、cursor 稳定、筛选状态重置。
5. 任务/资料/学生切换时的 request epoch、迟到响应隔离、草稿保护。
6. 题篮幂等、来源/版本变化使确认失效、导出 snapshot 绑定。
7. 队列暂停/取消/重试/恢复和未知副作用不重放。
8. 所有新增状态转换、权限判断和数据校验。

有效红灯必须因目标行为缺失/错误而失败。环境没启动、依赖缺失、测试本身语法错不算有效红灯。修复测试本身需引用冻结规格并记录。

## 4. Contract Testing

验证：
- Renderer → typed preload → main handler → domain service/SQLite/file。
- query schema/version、返回类型、错误语义、事件顺序、幂等键、权限和 sender。
- 数据/文件/导出接口的版本、来源、readback、取消和失败恢复。
- 设置子窗口使用最小 allowlist，不继承主窗口全部 API。
- `Mock` 只能证明 mock 合同；真实服务要求必须使用真实隔离环境。

## 5. Integration Testing

按依赖边界覆盖：
- 设置窗 + preload/main + 配置服务；
- 任务列表 + workbench summary + session/task store；
- 资料目录 + 本地文件 + parse queue + index；
- 题本/题篮 + 组卷蓝图 + 导出；
- 学生记录 + OCR/附件 + SQLite；
- 教学文件 + Office preview/version/export。
记录真实服务、版本、数据 profile、错误注入和恢复。

## 6. E2E Testing

从教师可见入口开始，不允许从数据库直接写入后声称用户旅程通过。至少覆盖：
- 首页→快捷任务→原对话→任务→成果→修改→回对话；
- 我的任务→全范围搜索→筛选/分页→详情→原会话；
- 资料导入→队列→检索→原页→题目校正→题本/题篮；
- 组卷蓝图→题篮→逐题核对→教师确认→真实文件导出；
- 学生选择→新增记录/OCR→错题校正→计划/复盘；
- 主窗任务运行→打开设置→主窗继续→配置保存读回→关闭设置。

## 7. Regression

- UI-FINAL A01–A36 全部保留为 LG-A01..A36。
- 上一版 V2 AC-01..AC-32 全部在 `legacy/V2_AC_MAPPING.md` 映射到 V3 AC/MG/FG。
- 受保护 OfficeComposer/PiComposerPendingPanel/Pi Runtime/审批/停止/恢复/历史/资料/题篮/导出均运行受影响回归。
- main 前移、冲突解决、共享契约变化后重跑受影响项；旧 PASS 不自动继承。

## 8. AI Evaluation

默认本轮为 UI/交互改造，不改变模型行为，AI Evaluation 可在 Phase 0 证明后 N/A。若实际修改 prompt、model routing、tool selection、OCR、检索、生成结果或 AI 决策，则：
- 固定测试任务集和真实/合成数据标记；
- 记录模型/provider/version/参数/提示词/索引数据版本；
- 定义正确性、来源、完整性、教师可用性、失败恢复评分；
- 保存输入、输出、评分、时延/成本（可获取时）；
- 人工抽检，禁止事后改评分标准迎合输出。

## 9. CI Quality Gates

先核对实际 `package.json`、lockfile 和 `.github/workflows`。只运行真实存在的命令；未发现的命令不得编造。至少对本轮相关内容执行 build、类型/renderer 组件测试、相关模块/contract/E2E、`git diff --check`。不机械要求所有层级用于纯文案改动，但 AC 指定的验证不能省略。
