# V3.1 验收覆盖（当前有效）

- REQ：26 项原有编号不变。
- ATDD：**90 项 AC-001..AC-090**，其中 V3 原 74 项 + 本轮 16 项设置窗口 AC-075..090；全部初始 `NOT_RUN`。
- 历史 UI-FINAL：36 项 LG-A01..A36 原样保留并映射，所有生产验收初始 `NOT_RUN`。
- 设计重点：SET-P0 由旧 AC-053..058 与新 AC-075..090 组成，不得因为视觉图漂亮绕过 IPC/配置/任务真实验证。
- 真实源码观察 main：`f420db00e4c124a1320aab57c82e65017ee89297`；最新运行构建、并行 WIP、owner、CI 待 Phase0 核验。
- Level：静态/构建、TDD、Contract、Integration、E2E、Regression、Windows DPI/无障碍/性能，条件 AI Eval。

# V3 验收覆盖摘要

- REQ：26 项，连续编号 REQ-01..REQ-26。
- V3 ATDD：90 项 AC-001..AC-090。
- 历史必需回归：36 项 LG-A01..LG-A36，对应 UI-FINAL A01..A36。
- V2 历史验收：32 项 AC-01..AC-32，完整保留并映射到 V3。
- 必需验证层级：静态/构建、单元/TDD、Contract、Integration、E2E、Regression、性能/无障碍；AI Evaluation 仅在真实 AI 行为变化时适用。
- 当前生产状态：全部 NOT_RUN；本包校验不代表产品通过。
- 合并前：所有 AC、LG-A01..A34、A35/A36 候选子条件必须 PASS。
- 合并后：FG-01 复验 A35/A36 最终子条件及实际 main；FG-02 完成报告。FG 未通过不允许 DONE。
