# Acceptance CSV 使用说明

- `acceptance_matrix.csv`：90 项 V3 AC + 36 项 legacy LG，初始全部 NOT_RUN。
- `legacy_acceptance_matrix.csv`：旧 A01–A36 到 V3 AC 的映射。
- `traceability.csv`：REQ→AC→TASK→CODE→TEST→EVIDENCE 索引。
- 断言内容唯一来源：根目录 `06_ATDD_ACCEPTANCE.md`。
- 报告文件只记录状态和证据，不复制或另行修改预期结果。
- 证据目录建议 `acceptance/evidence/<source-sha>/<AC-ID>/`。
- 状态只允许 PASS/FAIL/BLOCKED/NOT_RUN/N/A；N/A 必须符合 AC 中预定义条件。
