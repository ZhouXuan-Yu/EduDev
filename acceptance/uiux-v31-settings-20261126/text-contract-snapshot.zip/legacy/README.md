# Legacy 保留区

- `V2_PACKAGE_20261125/` 是上一版工程包的完整解压快照，原文件不改写。
- `UI_FINAL_ACCEPTANCE_36.md` 是项目原有 36 项必需回归清单。
- `LEGACY_GATE_MAPPING.md` 将 A01–A36 映射到 V3 AC。
- `V2_AC_MAPPING.md` 将上一版 AC-01..AC-32 映射到 V3。
- 当前唯一验收标准仍是根目录 `06_ATDD_ACCEPTANCE.md`；Legacy 文件用于证明历史需求未丢失，不另立一套新标准。
