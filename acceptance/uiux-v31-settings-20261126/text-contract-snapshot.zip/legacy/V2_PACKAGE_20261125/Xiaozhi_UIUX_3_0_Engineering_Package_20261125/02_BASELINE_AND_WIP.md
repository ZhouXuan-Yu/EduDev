# 02 代码观察、真实基线与半成品接续（只读）

## A. 本轮确实核对过的远程快照（OBSERVED_REMOTE）

查询：2026-11-25 GitHub Connector；仓库 `ZhouXuan-Yu/EduDev`；main 观察到 SHA `0dc86d8e65789063b006550022d8492e8a3fb440`。以下**只证明远程文本存在**，不是本地运行结果：

| 文件/区域 | 观察（固定快照） | 风险/后续策略 |
|---|---|---|
| `apps/desktop/src/main/index.ts` | `createWindow()` 创建 `BrowserWindow`，使用 contextIsolation=true、nodeIntegration=false、sandbox=true，mainWindow 单例 | 设置独立窗口需新增受控生命周期，避免重复主程序实例 |
| 同文件 `settingsSender` 与注册函数 | 部分设置、备份、更新和其他 IPC 的 sender 限制为 `mainWindow.webContents` 的 mainFrame | **P0：不能复制设置子树后直接放宽所有 IPC**；建立小范围允许列表与真实 sender 校验 |
| `apps/desktop/src/renderer/App.tsx` | `activeView==='settings'` 时渲染 `PiSettingsWorkspace`；另有菜单/对话跳设置入口 | UI 路由重定向、设置窗口打开入口和历史返回不应双重渲染 |
| `PiSettingsWorkspace.tsx` | 现有标签、搜索、`PiModelSettings`、技能/MCP/权限/教师记忆/备份/诊断/界面等；会读 `window.omniEdu`、会话状态、`useWorkbenchPreferences` | 优先复用业务组件；跨窗口 session/上下文/配置状态是关键兼容问题 |
| `SettingsNavigation.tsx` | 现有“日常设置/高级与诊断”折叠逻辑及按钮；单独能力中心等入口 | 避免二次复制导航，统一图标与教师语言 |
| `PiSettingsWorkspace` CSS | 已设置两栏与 `@media(prefers-reduced-motion:reduce)` | 已有响应式和减少动效应继承，不重写整套 vendor |
| `DesktopFrame.tsx` | desktop command、navigation guard、未保存阻断；原 `settings` 命令流入页面 | 不得绕过 guard 或中断草稿/任务；新窗回退有兼容路径 |
| `TeachingTaskWorkspace.tsx` | `personal` 模式复用 `PiRecoveryOverview` | 我的任务与教学任务视觉重复有来源，优化层级不新建状态事实 |
| `MaterialsWorkspace.tsx` | 使用既有目录/过滤/正文面板与 `useMaterialDraftGuard` | 保留筛选、任务关联和未保存保护；长标题与详情在真实数据上校准 |
| `apps/desktop/package.json` | `@heroui/react:^3.2.2`、`@heroui/styles:^3.2.2`、`electron:43.8.3`、`lucide-react:^0.468.0`（其中 UI 包在 devDependencies）；已有 build/renderer/smoke/settings/导航脚本 | 锁文件实际版本、构建及 CI **尚未运行**；不擅自升级或加动画库 |
| `.agents/skills/edudev-design` / references | D05、D09、D10、D15；白灰主色、输入保护、渐进披露、HeroUI 边界 | 新用户要求覆盖旧视觉限制必须在台账建 D16+ 决议，不破坏旧产品规则 |
| `page-contracts.ts` | 仍有 `settings` page contract；约束配置分组、保存/失败可见 | 变更窗口形态时同步 page contract，不改业务语义 |

## B. 不可作为最新完成证据的历史材料

- `docs/ui-audit/20261124-1848/` 的 13 张 PNG：采集仅 12 页面＋1 详情，记录状态 PARTIAL；采集构建与源码版本没有确定关联，题本/讲义/学生大量状态只有空态。
- 历史画面提示资料详情挤、学生新增保存不在首屏、任务标题截断，以及设置像普通页面；只是**审计线索**，须在最新代码与窗口复核。
- 旧 `UI-FINAL` 36 项与 `XIAOZHI_UI_UX_R1_20261124` 的 28 项分别是**旧任务验收合同**，不是此次已通过证据。Phase 0 应生成 `legacy-gates-map.md`，列受影响/不受影响/不可继承并说明来源。

## C. WIP/真实工作区（全部 TO_VERIFY，不能编造）

1. `git worktree list --porcelain`、每个工作树 `git status --short --branch`、`git branch -avv`、`git fetch --prune`（需网络和授权，仅执行 AI 在隔离环境操作）。
2. 确认 `origin/main` 实际 HEAD、正在使用哪个目录启动 Electron、renderer 构建 SHA/资源哈希；当前用户原本有 `D:/WorkProject/EduProject` 等目录线索，**不能凭线索确定今天真实工作目录**。
3. 列出 UI R1、UI-FINAL、配置/记忆/数据库等并行工作的负责人、分支、尚未提交内容；每份半成品标 `KEEP / PORT / REPAIR / SUPERSEDED / OWNER_UNKNOWN`。未确认归属不得移动或删除。
4. 校验锁文件、node_modules、Electron renderer/main/preload 版本，核对 `main` IPC sender 各渠道及配置事件向哪个窗口广播；检查 `getXiaozhiSettings`、`saveXiaozhiSettings`、`getDataRoot` 等真实边界。
5. 核对 `.github/workflows` 是否存在与当前模块相关的 CI、检查运行脚本和支持的 Windows 运行环境。没有就记录 N/A/TO_VERIFY，不虚构命令。
6. 建立隔离用户数据根、测试凭证/模拟 provider 标记和真实 provider 测试边界；不能直接在日常配置上测重置/删除/备份恢复。

## D. 接续而非重做

- 已有完整正确实现：只补足缺失证据与受影响回归。
- 仍在进行中的正确半成品：优先续用其分支与 commit 依赖，必要时在独立 worktree 上移植可归属变更；保留原始现场及回滚路径。
- 与配置 AI 同改 `PiSettingsWorkspace`、preload/main IPC、`SettingsPrimitives` 时，UI 优先只改样式/导航包装，配置方负责保存权限与 schema；若必须改共享文件，先锁定短窗口由指定拥有者串行合入并双方验收。
- 若现有窗口或样式已满足 AC，仅记录 `ALREADY_VERIFIED`，不可为追求“方案文件数量”重写。

## E. Phase 0 交付

填写 `templates/PHASE0_AUDIT.md`，至少包含一份当前 `git` 身份表、真实启动命令、文件所有权矩阵、旧 AC 映射、窗口与 IPC 调用图、3 个样板页最新截图、性能基线和 REQ 分类。审计输出不能把 `OBSERVED_REMOTE` 写成 `ALREADY_VERIFIED`。
