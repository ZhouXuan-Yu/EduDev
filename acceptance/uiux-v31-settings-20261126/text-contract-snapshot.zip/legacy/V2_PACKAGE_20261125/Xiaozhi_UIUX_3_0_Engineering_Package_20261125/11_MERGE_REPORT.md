# 11 主线集成、最终运行与回滚报告模板

> 生成时未执行任何分支、提交、合并、push 或部署。本文件只待执行 AI 填写。

## 模块候选
- 候选分支/worktree/module SHA：NOT_RUN
- 当前 main 及更新后 `origin/main` SHA：NOT_RUN
- 相关变更文件/共享接口 owner/配置 AI 版本：NOT_RUN
- AC-01..32 及旧受影响回归最终状态：NOT_RUN
- 模块是否具备合并资格：NO（未验收）

## 串行集成记录
- 集成负责人/机制（不能只填文本锁）：NOT_ASSIGNED
- 候选 SHA/基线 SHA/冲突列表/原因和责任：NOT_RUN
- 合并方式（merge/rebase/cherry-pick，遵守仓库策略）：NOT_RUN
- 合并前/冲突处理后/主线前移后的相关测试：NOT_RUN
- 本地 main 实际是否包含交付提交/证据：NOT_RUN
- 远端 push、PR、部署的独立授权检查与执行状态：NOT_RUN（不可按本地合并授权推导）
- 主线最终 SHA、构建/运行目录/窗口与代码同一性：NOT_RUN

## 最终核对
- 真实设置子窗口单例/IPC 安全/草稿不断流/配置读回：NOT_RUN
- 任务→资料/成果→教师编辑→返回对话：NOT_RUN
- 动效/长内容/reduced motion/性能：NOT_RUN
- 数据与外部副作用检查：NOT_RUN
- 代码回滚提交范围与数据/配置恢复区分：NOT_RUN

## 最终状态
`NOT_RUN`。仅全部必选 AC PASS、有效主线集成及最终适用回归 PASS，才可填写 `DONE`。否则准确选择 `WAITING_INTEGRATION` / `MERGE_BLOCKED` / `BLOCKED` / `NEEDS_DECISION` / `PAUSED_BUDGET` / `CANCELLED`。
