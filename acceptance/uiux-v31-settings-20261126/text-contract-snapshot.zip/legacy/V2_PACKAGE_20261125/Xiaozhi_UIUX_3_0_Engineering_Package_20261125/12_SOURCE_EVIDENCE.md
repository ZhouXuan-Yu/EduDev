# 12 项目源码与外部设计参考来源（证据目录）

> 本包实际核查时间：2026-11-25；只读 GitHub 远端 `main`，SHA `0dc86d8e65789063b006550022d8492e8a3fb440`。GitHub Connector 返回的源码文件 SHA 与路径并不证明本地 Electron 运行质量。历史截图来自 2026-11-24 截图提交，状态 PARTIAL。执行时仍应重新核对最新 main/工作树。

## 源码静态观察路径（按上述 SHA 固定）

- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/main/index.ts — 单主窗口 BrowserWindow、contextIsolation/sandbox、`settingsSender` 主窗限制、配置和备份/更新 IPC、退出生命周期。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/App.tsx — 设置仍作为主 renderer 的 activeView 页面；我的任务与教学工作台入口。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/components/office/PiSettingsWorkspace.tsx — 设置分类、搜索、业务子组件与状态/权限依赖。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/components/office/SettingsNavigation.tsx — 日常/高级导航。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/components/desktop/DesktopFrame.tsx — 导航历史/guard/桌面菜单。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/components/product/TeachingTaskWorkspace.tsx — 复用任务 overview。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/src/renderer/components/product/MaterialsWorkspace.tsx — 资料列表、状态、未保存 guard。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/apps/desktop/package.json — Electron / HeroUI v3 / lucide-react 与脚本。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/.agents/skills/edudev-design/references/decisions.md — D05/D09/D10/D15 历史约束。
- https://github.com/ZhouXuan-Yu/EduDev/blob/0dc86d8e65789063b006550022d8492e8a3fb440/AGENTS.md — 根目录 Pi/SQLite、并行、用户数据、安全与 Git 授权合同。
- https://github.com/ZhouXuan-Yu/EduDev/tree/db9056a6633b1fad14f652840810ae889c65c1ca/docs/ui-audit/20261124-1848 — 历史 13 图，仅 PARTIAL、构建与源码关联未确认。

## 成熟方案与官方依据（只用作规范判断，不是小智已达标）

- WorkBuddy 官方系统设置： https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Setting — 独立设置窗口、主窗口继续操作、重复打开聚焦、关闭不终止任务。
- Apple HIG Motion： https://developer.apple.com/design/human-interface-guidelines/motion — 动效要有解释力、简短、可取消、尊重偏好。
- Electron BrowserWindow： https://www.electronjs.org/docs/latest/api/browser-window/ — BrowserWindow、focus、modal/nonmodal、窗口生命周期与安全能力。
- HeroUI v3 Releases： https://heroui.com/en/docs/react/releases/v3-0-0 — 组件状态驱动动画与 reduced motion。
- HeroUI v3 Modal Migration： https://heroui.com/en/docs/react/migration/modal — v3 API 与旧 `motionProps` 差别，防错套 API。
- web.dev 动画性能： https://web.dev/articles/animations-overview — transform/opacity、渲染和帧预算。
- WCAG 2.2 Animation from Interactions： https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html — 非必要交互动效的减少/禁用。
- WCAG 2.2 Contrast Minimum： https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html — 正文对比度。

## 引用纪律

不能以竞品截图、旧 HTML 静态样张、remote read、未执行的 package.json 命令证明运行成功。没有实测 Electron/cross-window IPC/perf 的项目始终是 `TO_VERIFY`，由执行 AI 在 Phase 0/验收阶段补证据。
