# 07 代码所有权、接口、状态、权限和跨模块合同

## 所有权分区

| 范围 | UI 执行 AI 可以做 | 保护/协作要求 |
|---|---|---|
| renderer `ui-system/*`、应用自有页面 CSS、设置导航包装 | 全局 token、Motion、视觉状态、布局修复、教师文案 | 避免改 HeroUI vendor，组件内部状态需保持官方语义 |
| `PiSettingsWorkspace`、`SettingsNavigation` | UI 容器与可发现性/文案 | 配置 AI 共享文件；先确认 owner 与运行中的改动 |
| `main/index.ts`／新增受控设置窗口 manager | 新开/聚焦/关闭设置独立窗，必要 IPC sender 边界 | 桌面平台 owner；只在接口冻结和授权下小范围修改 |
| `preload/index.ts`／shared typed contracts | 新增最小化设置窗调用桥与窗口身份 | IPC/security owner 串行；保持兼容，不扩大现有 renderer 可调用权限 |
| Pi Runtime、任务/事件、数据库、记忆、模型选择、权限核心 | **不得改变事实来源或运行机制** | 配置/底座 AI 独占；差异提合同，UI 只消费真实状态 |
| `OfficeComposer`、工具栏、`PiComposerPendingPanel`、队列 | 回归验证/必要外围样式 | 默认受保护，不能替换、重挂载或悄悄调整行为 |
| `.agents/skills/edudev-design`/references | 新版规范文档和决策覆盖日志 | 保留 D01–D15 历史；最新用户指示优先，但不删除旧事实 |

## 窗口主合同（设置 R1，目标而非现状）

- 唯一 `SettingsWindowManager`（实施时可使用等价现有管理器），创建非模态独立窗口；单例 open/focus/close，生命周期与主窗口、应用退出严格区分。
- 初始展示：应用边界内安全加载同源本地 renderer 的专用设置入口；**不能打开任意 URL 或把外部链接注入窗口**。外链继续走现有宿主外开策略；默认禁止 `window.open`，保留 CSP/本地 frame 隔离。
- 安全首选：`contextIsolation: true`、`nodeIntegration: false`、`sandbox: true` 和匹配构建输出的受控 preload；禁止 `webSecurity:false`、禁用 `sandbox` 或给子窗口注入 Node API。
- 必须识别 `sender.webContents.id`、`senderFrame`、窗口生命期、允许的操作类别；设置窗口只获得设置 UI **必要的**最小读写/检查权限；敏感保存和权限操作仍由现有主进程校验原会话、版本和权限。
- `settings:getDeepSeek`、`settings:saveDeepSeek` 等当前仅主窗口 sender 的路径，以及 `registerXiaozhiIpc`/备份/更新/权限各接口必须盘点。不能把通用 `settingsSender` 改成“任意窗口都可访问”，不能只看窗口名称就授权。优先专用 `settingsSenderAllowlist`/validated endpoint；未授权调用失败并记录可检查错误。
- 窗口内读取的是与主窗口同一配置/SQLite/任务真源；保存必须读取回执、失败保留未保存输入，必要时主窗口经真实事件或重新查询更新。不能用共享 localStorage 代替配置真源。
- 当前 `PiSettingsWorkspace` 依赖 `useWorkbenchPreferences`、会话 ID、快照和原 window.omniEdu。抽为独立入口前核对 Provider/上下文是否在子 renderer 正确创建；不能用默认空会话绕过权限限制。需要保存窗口入参时只传可验证 ID/界面状态，不传原始材料/密钥明文。
- 焦点：设置打开主动获得焦点；主窗失焦只做可降级视觉弱化，不遮挡输入事件；切回主窗背景恢复；关闭设置恢复触发点（在主窗仍存在时）及合理焦点。Esc 仅在无危险操作/未保存内容风险时关闭，或先进行明确保护。
- 窗口屏幕坐标限制在显示器 workArea 内；最小尺寸、DPI/缩放、窗口重开与屏幕拔插后可达；不创建多个副本。
- 主窗口关闭/应用退出、设置中备份/权限操作、异步回调迟到与重启恢复，必须用明确的 state/session/generation guard，避免泄漏监听和重复副作用。

## 关键跨模块契约（不凭空改 schema）

| 合同 | 消费方 | 权威方 | 测试边界 |
|---|---|---|---|
| `window.omniEdu.getXiaozhiSettings/saveXiaozhiSettings` | 设置 UI | 原主进程设置服务 | 版本、校验、失败、真实读回、密钥脱敏 |
| `listAiConversations/getXiaozhiSnapshot` | 设置授权/任务投影 | Pi/SQLite 事实 | sessionId 绑定、晚到结果隔离、冷启恢复 |
| `selectXiaozhiWorkspace` 与权限更改 | 用户授权页 | Permission Engine | 不得从界面提升权限、错误明确、重复操作安全 |
| `onXiaozhiEvent` 等订阅 | 多窗口 UI | 主进程事件源 | 退订、重复窗口、迟到/跨任务隔离 |
| `DesktopFrame` 导航和草稿保护 | 主窗口 | renderer 主窗口 | 打开设置不产生丢稿的路由切换；back/forward 不错乱 |
| `PiComposerPendingPanel`/OfficeComposer | 问小智 | Pi 宿主 | IME、排队、停止、授权、恢复、焦点保持 |
| 资料目录、题库、任务成果 | 资料/教学 UI | SQLite/文件/任务源 | 文件 readback、题源/版本与确认身份不丢 |

**接口合同优先级**：schema、错误码、保存时机和授权由当前实际代码验证；上述名称只是远程静态快照，不构成要求新增同名接口。触发技术差异时以差异单签署并在 `01_CONFIRMED_PLAN`/AC 更新真实契约。不得为满足“开独立窗”直接复制完整主窗口 preload 权限。
