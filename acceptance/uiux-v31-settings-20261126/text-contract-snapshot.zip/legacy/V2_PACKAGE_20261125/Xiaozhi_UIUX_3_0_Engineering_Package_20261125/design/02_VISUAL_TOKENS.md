# DESIGN-02 Xiaozhi Visual Tokens v3（设计候选，不是已覆盖主题）

## 视觉主旨

工作台以白/中性灰为大面积底色；蓝色用于主操作和选中；紫色仅作 AI 语义、绿色用于真实完成、琥珀用于需处理、红色用于风险或失败。图标为视觉线索而不是唯一信息载体。深浅状态均需文字/图标辅助和足够对比度。此规范修订旧 D05 的“蓝色唯一重点”限制，但**不引入全站玻璃拟态和装饰渐变**。

## Color Token 候选

| 变量 | 候选值 | 用途/边界 |
|---|---|---|
| `--xz-bg-canvas` | `#F6F8FB` | 应用外围/导航浅底，不用于正文弱对比 |
| `--xz-bg-surface` | `#FFFFFF` | 主体/设置内容 |
| `--xz-bg-muted` | `#F1F4F8` | 轻区分区域/hover 前背景 |
| `--xz-border-subtle` | `#E5EAF0` | 必要分隔，禁止每组重复围框 |
| `--xz-text-primary` | `#1F2937` | 正文/标题 |
| `--xz-text-secondary` | `#596579` | 次信息与描述（实施复核对比） |
| `--xz-brand-600` | `#2563EB` | 主按钮/选中蓝，白字时验证 AA |
| `--xz-brand-700` | `#1D4ED8` | 蓝色小文字/链接 |
| `--xz-ai-700` | `#6D35C7` | AI 标识深紫文字/图标 |
| `--xz-ai-tint` | `#F1EBFF` | AI 状态低饱和底 |
| `--xz-success-700` | `#166D53` | 成功状态深色，非全段绿色 |
| `--xz-success-tint` | `#E5F6F0` | 成功底 |
| `--xz-attention-700` | `#8D520B` | 需处理提示深色 |
| `--xz-attention-tint` | `#FFF3DE` | 等待教师/提醒底 |
| `--xz-danger-700` | `#A42F3F` | 失败/危险文字 |
| `--xz-danger-tint` | `#FCECEE` | 错误背景 |
| `--xz-focus-ring` | `#2563EB` | 可见键盘焦点轮廓 |

颜色不是状态唯一表示：必须有图标/状态词，例如 `待教师确认`、`已保存`、`保存失败`，不要只有绿点或红点。文本/可交互对比以 WCAG AA 为目标：普通文字 ≥4.5:1，大文字与重要 UI 图形按适用标准核查；上述色值需在真实环境做全状态自动/人工对比度计算，未测不得视为已通过。

## Typography 与密度

- 默认中文系统无衬线，遵循 Windows 环境回退；UI 正文建议 14–15px，对话阅读 16px，页标题 22–26px、分区 16–18px；说明文本原则上 ≥13px，高密度表格要提供视口与缩放可读性。
- 4/8px 节奏：space 4/8/12/16/24/32，主内容页边距可 24–32px；文本行高界面 1.45–1.65、长文阅读可到 1.7。
- 单层信息卡片 12–16px 圆角，按钮 8–12px，独立设置窗外观候选 16px，最终依操作系统窗体能力决定；避免把每段文字各自套卡。
- 核心按钮不依赖 Hover 才出现，危险行为需要明确 label；列表筛选项/任务状态可紧凑，核心阅读材料不牺牲字号。

## 图标与组件

- 保持现有 `lucide-react` 与 HeroUI v3/本地 Pro；基础图标建议 18–20px、主要动作 20–24px，描边粗细统一（以现有实际配置为准，不逐页硬编码任意粗细）。
- 统一语义示例：`MessageCircle` 问小智、`ListTodo` 任务、`Library` 资料、`BookOpenCheck` 教学、`Users` 学生、`Settings` 设置；`Sparkles` AI、`CheckCircle2` 完成、`Clock3` 等待、`AlertCircle` 失败。
- 禁用原生 `select/summary` 粗黑三角直接暴露；优先已有 `AppSelect`/HeroUI disclosure；受保护 `AppNativeSelect` 的适配策略需保留真实表单语义。不要用纯文本 `>`、`▼` 拼图标。
- Hover、Pressed、Selected、Focus、Disabled、Loading 明确区分；Focus 不可因视觉柔和而删除；Tooltip 不是唯一文字来源。
- 组件来源记录：OSS、Pro、本地 adapted、现有自有 wrapper 各自真实来源/版本，不能把 OSS 冒称 Pro。避免全局 `button/input` CSS、`!important` 铺盖和重复主题导入。

## Shadow / Surface / Motion

- 阴影只用于独立设置窗/浮层及必要的提升层级；主体列表与分组更多依靠留白和细分隔线。
- 只允许设置窗口背景“视觉退后”专用静态遮罩或轻模糊，在焦点变化时撤除；普通业务页面不增加全屏透明玻璃。
- 动效 token 集中于 `design/03_MOTION_SYSTEM.md`，不要在 Visual 文档复制另一组时间数值。

## 来源与升级落地

优先通过已有 Theme/Token Source 映射新应用变量，单一来源管理；先测 CSS specificity、dark/light 环境与 HeroUI 当前真实 API 后再改主题。历史 D05、D13、D15 不删，新增 D16+ 说明“语义多色与设置单独背景弱化”升级。样张色值从未直接成为生产变量；需经实机对比和 AC-13,14 才能发布。
