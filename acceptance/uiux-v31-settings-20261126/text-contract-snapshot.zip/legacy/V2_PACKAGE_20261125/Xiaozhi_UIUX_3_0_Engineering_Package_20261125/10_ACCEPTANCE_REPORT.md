# 10 模块验收报告模板（实施前全部 NOT_RUN）

> 当前为模板，**不得在方案生成阶段填写 PASS**。`05_ACCEPTANCE_CRITERIA.md` 是唯一的验收标准真源；本报告仅引用 AC ID 和实测证据，不复制独立期望值。

## 运行身份（执行方填写）
- 日期/执行 AI/负责者：NOT_RUN
- worktree 路径/分支/模块 HEAD / 当前 `origin/main`：NOT_RUN
- Electron app/main/preload/renderer 构建指纹、进程与窗口：NOT_RUN
- 测试数据根/profile、权限范围、配置版本：NOT_RUN
- 操作系统/缩放/DPR/分辨率/输入法/机器 CPU/GPU/内存：NOT_RUN

## 验收结果索引

| AC | 状态 PASS/FAIL/BLOCKED/NOT_RUN | 证据文件与命令 | 失败/边界/复测 SHA |
|---|---|---|---|
| AC-01..AC-32 | NOT_RUN（逐项展开填写） | 待执行 | 待执行 |

## 工程与用户旅程分级
- 单元/契约测试：NOT_RUN
- 构建/类型/组件/CI：NOT_RUN
- 正式 Electron 主/设置窗口交互：NOT_RUN
- 真实设置配置 readback：NOT_RUN
- 真实任务、资料、成果回读：NOT_RUN
- 性能前后 trace：NOT_RUN
- reduced motion/键盘/IME/缩放：NOT_RUN
- 老 UI-FINAL 36 项、UI R1 28 项受影响映射：NOT_MAPPED
- Gemini 独立复核：NOT_RUN / UNAVAILABLE（待执行方如实确认）
- GPT/第二审阅者审查：NOT_RUN
- 教师主观试用：NOT_RUN（不得冒称）

## 待修复缺陷与闭环
| 缺陷 ID | 证据/步骤 | 真实原因与版本 | 方案和有效修改次数 | 回归/结果 |
|---|---|---|---|---|
| TO_FILL | | | | |

## 最终判定
`NOT_RUN`（默认）。必选 AC 任一 FAIL/BLOCKED/NOT_RUN 不可写模块全部通过；产品主观接受与工程验收须分别报告。正式模块通过不等于 main 集成完成或远端发布。项目范围外未就绪业务必须明确列出，不用假数据掩盖。
