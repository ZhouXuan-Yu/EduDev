# 验收唯一来源说明

唯一验收断言真源为工程包根目录 `05_ACCEPTANCE_CRITERIA.md`。`traceability.csv` 只作 REQ→W→AC 导航，不维护独立的 Then/预期。`10_ACCEPTANCE_REPORT.md` 为执行结果模板；任何 PASS 需来源、命令、数据、运行版本和可审查证据。`AC-01..AC-30、AC-32` 是模块门禁，`AC-31` 是集成完成门禁，禁止循环要求先合并再允许集成。
