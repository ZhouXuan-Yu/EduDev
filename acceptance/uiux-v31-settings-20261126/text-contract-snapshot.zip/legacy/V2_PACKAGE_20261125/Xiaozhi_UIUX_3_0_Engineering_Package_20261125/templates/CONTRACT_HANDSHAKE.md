# 跨模块接口握手单（设置窗口/配置模块）

- 请求方（UI owner）/确认方（配置或平台 owner）：TO_VERIFY
- 双方 branch / commit / WIP 文件与当前状态：TO_VERIFY
- 调用功能名称、输入/输出 schema/版本：TO_VERIFY
- senderFrame/webContents/权限检查函数与身份来源：TO_VERIFY
- 对应 main/preload/shared/renderer 路径及负责写者：TO_VERIFY
- 当前行为/期望行为差异、错误与失败恢复：TO_VERIFY
- 单一配置事实来源、保存/生效时机、readback：TO_VERIFY
- 并发写入和版本冲突处理、窗口关闭时未保存状态：TO_VERIFY
- 双方交接时间、迁移提交、受影响 AC、证明记录：TO_VERIFY
- 若未协调：保留现有功能，标记 BLOCKED；不自行新造保存路径或扩大权限。
