# Phase 0 实际现场审计表（初始全为 TO_VERIFY）

- 日期/执行者/仓库与工作树：TO_VERIFY
- 最新 origin/main SHA / 观察时 main SHA：TO_VERIFY / 0dc86d8e65789063b006550022d8492e8a3fb440（仅远程参考）
- 所有 worktree、分支、脏改动、commit、owner：TO_VERIFY
- 执行中配置/模型/记忆/数据库等模块的共享文件：TO_VERIFY
- 构建实机入口、main/preload/renderer 资源 hash：TO_VERIFY
- package-lock、实装 HeroUI、Electron、Node、组件来源：TO_VERIFY
- Win DPI/分辨率/GPU/性能初始基线：TO_VERIFY
- `PiSettingsWorkspace` 当前依赖及所有 settings API：TO_VERIFY
- `settingsSender`/registerXiaozhiIpc/备份/Windows Update 等允许窗口来源：TO_VERIFY
- 现有任务→成果→返回的身份/runId/持久化：TO_VERIFY
- UI-FINAL 36 项、UI R1 28 项受影响列表及原结果可信度：TO_VERIFY
- 适用 package.json 脚本与 CI：TO_VERIFY
- Gemini/GPT 外部独立审查通路、权限及实际结果：TO_VERIFY

## REQ 实现分类表（逐项填写）
| REQ ID | 当前代码证据路径/版本 | 分类 ALREADY_VERIFIED/PARTIAL/BUG/MISSING/TO_VERIFY | 留/修/补/重构 | 对应 W/AC |
|---|---|---|---|---|
| REQ-01..REQ-18 | TO_VERIFY | TO_VERIFY | TO_VERIFY | 详见 01 |

## 开工阻断确认
- 哪个真实安全/并行问题阻止开工？
- 谁有权修改共享文件？
- 本轮第一条最小可复现 AC 是什么？
- 如何保护原 WIP 与日常 SQLite/资料？
