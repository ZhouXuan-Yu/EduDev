# 旧 UI 受影响回归映射（Phase 0 填写）

远程源码已有旧 `UI-FINAL` 36 项和 UI-R1 28 项的验收文字；**此前是否实际 PASS 未经本包验证**。不能把“上一轮交付了 Goal”写成“本轮兼容已证实”。

| 旧合同/AC | 当前确切测试代码或历史证据 SHA | 本轮受影响组件/REQ | 可继承原证据？为什么 | 需执行的回归/结果 |
|---|---|---|---|---|
| UI-FINAL A01..A36（逐个展开） | TO_VERIFY | TO_VERIFY | TO_VERIFY | NOT_RUN |
| UI-R1 UIR1-01..28（逐个展开） | TO_VERIFY | TO_VERIFY | TO_VERIFY | NOT_RUN |

原则：只复测受影响条目但覆盖所有受保护行为；旧证据若身份/构建不一致、fixture/模拟场景无法证明真实运行，应标 `NOT_REUSABLE`。旧门禁如因新用户决定被覆盖，记录明确决策和对应新 AC，不“删除测试取得通过”。
