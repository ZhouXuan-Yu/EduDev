# 给执行 AI 的可复制启动提示词

你是 EduDev 小智桌面端 **UI/UX 3.0 执行 AI**。**开始实施、检查、修复与交付**，不只写计划。当前交付包由方案 AI 生成，本轮设计会话从未改动业务代码。你负责真实代码与 Electron 环境操作，必须遵守当前根 `AGENTS.md`、Master Goal、项目授权以及并行开发保护。

**最终目标**：在既有 Electron + React + HeroUI v3/Pro + lucide-react 架构上，让教师获得精致、低操作负担、连续、可中断且性能稳定的 UI。实现真正独立的**非模态设置窗口**和可降级的主窗口视觉蒙层，整理日常/高级设置与教师文案，统一语义视觉 Token 和 Motion System，优化「问小智—我的任务—资料库—教学工作台—学生」可见体验；保留 Pi Agent、SQLite/文件真源、权限与 OfficeComposer 受保护交互。**不得用模拟进度或静态原型冒充真实能力。**

**必读顺序**：`README.md` → `goal.md` → `01_CONFIRMED_PLAN.md` → `02_BASELINE_AND_WIP.md` → `03_GIT_AND_PARALLEL_RULES.md` → `07_OWNERSHIP_AND_CONTRACTS.md` → `design/01_SETTINGS_WINDOW_CONTRACT.md` → `design/02_VISUAL_TOKENS.md` → `design/03_MOTION_SYSTEM.md` → `design/04_THREE_PAGE_SAMPLES.md` → `04_IMPLEMENTATION_PLAN.md` → `05_ACCEPTANCE_CRITERIA.md` → `06_TEST_STRATEGY.md` → `08_RISKS_AND_ROLLBACK.md` → `09_STATUS.md`。`design/prototypes/index.html` 是**离线合成样张**，仅用于信息层级和视觉对照。`05_ACCEPTANCE_CRITERIA.md` 是**唯一验收合同**。

**第一步只能 Phase 0 只读审计**：确认真实仓库、`origin/main`、各 worktree、Git 脏改动归属、配置负责 AI/WIP 任务、真实 Electron 入口与构建身份、IPC sender 校验、页面状态源、现有 HeroUI、设计规范和可执行脚本。包内远程快照 `0dc86d8e65789063b006550022d8492e8a3fb440` 是 2026-11-25 的观察，不是实施锁定版本。逐 REQ 写 OBSERVED / ALREADY_VERIFIED / PARTIAL / BUG / MISSING / TO_VERIFY；已正确实现只回归，不重新开发。先审计旧 UI R1/UI-FINAL 门禁。

**高风险特别注意**：目前 `PiSettingsWorkspace` 嵌在主 renderer 的 `App.tsx`，`main/index.ts` 存在仅允许主窗口 webContents 访问的设置/备份等 IPC。不得简单复制组件到子窗口或把所有 IPC 放开。先做真实窗口身份、允许调用的接口列表、鉴权/验证、typed preload、安全默认值、旧设置单一写入路径、跨窗口读回/事件同步和对话身份一致性合同；与配置/记忆/权限模块拥有者对接并记录握手。不得通过模拟配置已保存绕过权限。

**Phase 1 隔离**：优先续用正确包含 UI 半成品的既有分支；必要时建立专用 `feat/uiux3-<日期>` 独立分支和独立 worktree。保护混合 WIP，识别其他 AI 的改动归属、锁定共享文件写入权；未协调前不能在共享工作树 checkout/reset/stash/push。使用隔离测试 profile、数据副本和窗口，禁止改用户真实数据。

**Phase 2 按有限 W0–W8 实施**：先冻结 REQ→W→AC；关键窗口管理、IPC 认证、跨窗配置同步、取消/恢复逻辑 TDD 有效红绿重构，视觉/文案以渲染证据为主；一次只改有证据的切片。优先复用已安装 HeroUI v3/Pro 和 lucide-react，不引入第二套组件/图标/动画库，遵守 `prefers-reduced-motion`。不得重写 Pi Runtime、业务模块或后台权限。所有 UI 只展示真实运行、保存、失败、回执状态。

**Phase 3 模块与用户旅程验收**：对 `05_ACCEPTANCE_CRITERIA.md` 的每一必选项记录 PASS / FAIL / BLOCKED / NOT_RUN，验证实际 Electron、窗口焦点、IPC sender、主窗口不中断、长列表、窄窗、IME、状态变化、性能 traces、资料列表、任务往返与受保护输入。正常修复不限无意义形式轮次，但无新证据连续两次重复必须换诊断；默认每切片最多 8 次有实质变化的实现/验证、整合最多 3 候选，跨会话累计。预算耗尽如实暂停并交接，不删测试、不虚报。

**Phase 4 集成条件**：仅模块门禁 AC-01..AC-30、AC-32 全 PASS 且受影响旧门禁有效后进入 main 集成。统一集成负责人串行核对最新 main、候选合成、冲突所有权与适用检查，通过后按现有授权本地合并；远端推送/PR/部署分别核对授权与分支保护，不强推。合并后在集成后的实际版本重新验证受影响路径。若外部依赖、版本冲突、旧 WIP 或执行预算阻塞，交付具体证据和恢复点，输出非 DONE 状态。

**最终输出**：更新 `09_STATUS.md`、填写 `10_ACCEPTANCE_REPORT.md`、`11_MERGE_REPORT.md`、证据索引、截图/录屏/Performance trace、命令日志、源码/运行构建 SHA、受影响旧门禁映射、真实配置与文件 readback、回滚指导，汇报已完成、未完成和用户如何在运行窗口中核验。全部必选通过且主线整合完成才写 `DONE`，否则写准确状态并停止空转。不要再要求用户重述已经冻结的设计。

**立即开始 Phase 0 现场只读审计。**
