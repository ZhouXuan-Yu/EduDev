# 03 Git 独立分支、worktree、并行归属与串行集成协议

## 必须遵守

- 本设计包**不创建分支、不 push、不合并**。以下只约束收到包的执行 AI。
- 第一动作只读审计所有现存 worktree、remote、脏改动、所有权和任务状态；确认 branch 来源后才可以创建分支。
- 一执行者一独立可写 worktree＋一分支，优先续用已经包含当前 UI WIP 且无其他写入者的正确分支。示例名称 `feat/xiaozhi-uiux3-YYYYMMDD` 仅建议，不代表已经创建。
- 不从只含 main 的干净新分支重做其他 AI 已完成半成品；不在共享目录 checkout、stash、reset、clean、rebase 或删除未归属变更。
- 模块开发可并行、**主线集成只允许一个真实负责人**；文件式“合并锁”只是提醒，不能替代实际 Git/仓库权限与串行排队机制。

## WIP 盘点分类表（执行 AI 填写）

| 路径/文件 | 所属模块 | owner/branch/commit | 未提交修改 | 动作 KEEP/PORT/REPAIR/DEFER | 证据 |
|---|---|---|---|---|---|
| `apps/desktop/src/main/index.ts` | 桌面平台 / 设置窗口 | TO_VERIFY | TO_VERIFY | 只读至 owner 确认 | TO_VERIFY |
| `apps/desktop/src/preload/index.ts` | IPC 契约 | TO_VERIFY | TO_VERIFY | 跨模块串行 | TO_VERIFY |
| `PiSettingsWorkspace.tsx` 及配置子组件 | UI + 配置 | TO_VERIFY | TO_VERIFY | 仅在接口冻结后修改 | TO_VERIFY |
| UI tokens/Skill | UI | TO_VERIFY | TO_VERIFY | UI owner 主导 | TO_VERIFY |
| Agent/SQLite/模型/记忆实现 | 他模块 | TO_VERIFY | TO_VERIFY | READ_ONLY | TO_VERIFY |

## 依赖协调与受控迁移

1. 若旧 WIP 散落于混合脏工作树，先记录文件、差异、依赖、功能验收以及原 owner 同意的目标位置；转移前保留原备份/commit，不整包 `git add -A`。
2. 多方涉及同一文件采用“共享接口先冻结、单 owner 短暂写入、其他方通过 adapter/独立组件”的方式。发生重叠先停相关写操作，其他切片可继续。
3. 任何配置 schema、保存时机、权限策略更改须书面接口差异、兼容性和双方签收；无确认时 UI 仅呈现当前既有能力，不新造配置实现。
4. 测试环境彼此隔离：Electron profile、SQLite 副本、临时文件目录、API 凭证、端口、缓存、构建输出和截图前缀不能与其他 AI 共用可写路径。

## 集成门槛与串行步骤（执行阶段）

A. 模块候选：模块门禁 AC-01..AC-30、AC-32 的验证及适用旧门禁 PASS；`git diff --check`、构建/测试/回归证据齐全。未通过禁止自称可合并。

B. 更新 `origin/main`，取得最新 SHA `M0`；统一集成负责人在隔离工作树构造 `M0+UI` 候选，记录真实合成身份、冲突列表/修复归属；对提交范围和别的未就绪模块逐项复核。

C. 冲突修复后运行受影响契约/组件/实际 Electron/性能检查。新 main 前移再评估冲突与重测；不得把旧候选 PASS 自动继承。

D. 依**已有明确授权**和仓库 branch protection/PR 规则进行本地合并及可允许的远端操作。不可强推、不可禁用检查。远端 push、PR、部署是不同动作，分别报告是否获授权和是否执行。

E. 集成后核对 `git merge-base --is-ancestor <UI交付commit> main` 等祖先关系（依实际主线/合并策略）；记录最终 SHA、已运行软件构建身份和必要回归。失败为 `MERGE_BLOCKED`，不得写 `DONE`。

## 退出与恢复

- 到预算/外部依赖阻塞时，提交可安全提交且仅本模块归属的成果（需有授权），冻结 WIP 状态和候选 SHA；绝不为“干净”清掉别人改动。
- 代码回滚优先审查撤销特定 UI 变更的 `revert`；配置/文件副作用另有恢复计划，不能简单重置共享 main 或删除用户数据。
