# 小智 UI/UX 3.0：工程化执行包（2026-11-25）

> **包状态：DESIGN_PACKAGE_READY，实施/测试/合并均 NOT_RUN。** 本包由方案 AI 只读审查公开 GitHub 代码并编写，未修改 EduDev 仓库、未创建分支、未运行正式 Electron，也未接触开发者本机的 WIP/用户数据。
>
> **模块：EduDev 桌面端 UI/UX 视觉与动效升级**。执行目标是教师能够自然完成教学任务：AI 对话优先、任务连续、精致稳定的组件、设置独立非模态窗口、状态驱动动效以及真实可验证的完成状态。

## 接手者如何使用

1. 首先阅读 `START_PROMPT.md`（运行指令），接着完整阅读 `goal.md`（唯一总任务）。
2. 阅读 `01_CONFIRMED_PLAN.md` → `02_BASELINE_AND_WIP.md` → `03_GIT_AND_PARALLEL_RULES.md` → `07_OWNERSHIP_AND_CONTRACTS.md`。
3. 阅读设计合同：`design/01_SETTINGS_WINDOW_CONTRACT.md` → `design/02_VISUAL_TOKENS.md` → `design/03_MOTION_SYSTEM.md` → `design/04_THREE_PAGE_SAMPLES.md`，以及 `design/prototypes/index.html`（仅离线演示，**不等于真实 Electron 方案**）。
4. 阅读 `04_IMPLEMENTATION_PLAN.md` → `05_ACCEPTANCE_CRITERIA.md`（**唯一的验收断言真源**）→ `06_TEST_STRATEGY.md` → `08_RISKS_AND_ROLLBACK.md`。
5. 接续 `09_STATUS.md` 的 Phase 0，实施时填写 `10_ACCEPTANCE_REPORT.md`、`11_MERGE_REPORT.md`、`templates/*`；如可用 Gemini 审查，按照 `design/05_REVIEW_AND_CONSULTATION.md` 出证据。
6. 源码基线与官方指南见 `12_SOURCE_EVIDENCE.md`，内部映射见 `acceptance/traceability.csv`。不得把包内离线原型作为验收 PASS。

## 采用的工程方法：必须有动作、有证据

| 方法 | 唯一主要文件 | 执行阶段动作 | 证据与通过条件 |
|---|---|---|---|
| PDD（Prompt-Driven） | START_PROMPT.md / goal.md | 自主执行、限域、收口，生成可续做回执 | 任务回执包含版本/完成状态/证据；非计划即完成 |
| SDD | 01_CONFIRMED_PLAN.md / design/* | 冻结 REQ 与产品合同，变更时记录影响 | REQ → W → AC 全部可追踪，设计无擅自改写 |
| BDD | 05_ACCEPTANCE_CRITERIA.md | 从给定—当—则操作真实用户场景 | 真实 Electron 或相应层级复现；结果可观察 |
| ATDD | 05_ACCEPTANCE_CRITERIA.md | 实施前冻结唯一 AC 标准 | 每条 AC 有前置/动作/预期/反例/证据/必选 |
| TDD | 06_TEST_STRATEGY.md | 仅关键 IPC 授权、窗口状态、设置状态、幂等、恢复逻辑走红绿重构 | 有有效红灯→绿灯→回归的命令和报告 |
| 契约/集成 | 07_OWNERSHIP_AND_CONTRACTS.md | 主进程→typed preload→renderer→本地持久化与 UI 验证 | 不放宽 IPC；真实设置读回与跨窗一致性证据 |
| CI/门禁 | 06_TEST_STRATEGY.md | 执行仓库实际存在的适用脚本、集成候选和 main 回归 | 记录命令、SHA、通过与跳过理由；不能凭截图代替 |
| AI 评测 | 06_TEST_STRATEGY.md | **本轮不改模型行为，默认 N/A**；若变更模型/提示/检索才补行为评测 | 变更影响和评测输入/版本/产出/评分依据 |

## 依赖与授权

- 已确认：由**另一位执行 AI**改代码、操作测试并依已授权规则管理 Git；当前设计会话只交付包。
- 开发必须有独立分支、独立可写 worktree/目录；集成需统一串行负责人并核对最新 `origin/main`。
- `main` 本地合并须所有必需验收 PASS 后方可执行；远端 push/PR/部署的边界以最新项目 AGENTS 与实际授权为准，逐项报告，不把“可本地合并”冒充部署授权。
- 不覆盖其他执行者的本地脏改动，不改数据库/模型/Harness/记忆权限事实来源，不安装第二套 UI 图标库。
- 参照旧 UI-FINAL 的 36 项和 UI R1 的 28 项建立**受影响回归映射**，不擅自宣称旧任务完成或用旧截图充当最新验收。

## 完成与停止

只有全部本轮必选 AC 通过、主线集成要求满足、最终来源/构建/窗口/证据一致且报告齐全，才为 `DONE`。否则应准确标记 `BLOCKED`、`NEEDS_DECISION`、`WAITING_INTEGRATION`、`MERGE_BLOCKED`、`PAUSED_BUDGET` 或 `CANCELLED`，并记录从哪里继续。预算不是敷衍验收的理由。
