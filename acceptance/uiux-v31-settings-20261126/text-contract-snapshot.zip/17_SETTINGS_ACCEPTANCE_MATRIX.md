# 17 SET-P0 验收执行登记（仅引用唯一 ATDD，不另定义断言）

> 每项预期行为、反例和证据详见 `06_ATDD_ACCEPTANCE.md`。本文件是执行登记/排查入口，所有生产状态初始 NOT_RUN。

| AC | 分组 | 测试入口（执行时按真实脚本核验） | 证据类型 | 状态 |
|---|---|---|---|---|
| AC-053 | 独立 BrowserWindow | main/window manager TDD + Electron | window IDs、非模态录屏 | NOT_RUN |
| AC-054 | 主窗任务连续性 | Pi/Electron E2E | runId、draft、焦点 | NOT_RUN |
| AC-055 | IPC 最小权限 | typed preload + main 负例 | sender/role allowlist | NOT_RUN |
| AC-056 | 设置分类搜索 | 真实设置十类 E2E | 控件/焦点/内容截图 | NOT_RUN |
| AC-057 | 配置保存读回 | config host + Electron | revision/receipt/readback | NOT_RUN |
| AC-058 | 备份/权限危险操作 | 隔离数据库/文件 | 备份 hash/权限结果 | NOT_RUN |
| AC-075..079 | 窗口/焦点/蒙层/DPI/不中断 | 状态机 + Windows Electron | 窗口计数、视频、runId | NOT_RUN |
| AC-080..085 | 十类功能、文案、搜索、会话 scope、最小 preload、非法导航 | UI + IPC Contract/Electron | 目录映射、正反 sender、AX/focus | NOT_RUN |
| AC-086..089 | 配置/凭证/工具技能/记忆备份/跨窗同步 | host Integration + DB/file readback | 版本回执、原件/权限与订阅 | NOT_RUN |
| AC-090 | Motion/性能/减少动效 | Windows Electron Performance | 前后 trace、DPI、fps/帧长 | NOT_RUN |

**SET-P0_ACCEPTED：** 上述全部 REQUIRED AC PASS 且关联 LG-A17/A18/A31/A32 真实回归 PASS。任何 FAIL/BLOCKED/NOT_RUN 禁止合并 main，也禁止将本专项标已完成。
