# 03 Git 分支、worktree、并行开发与 main 集成

## 1. 目标

本模块必须在独立 Git 分支开发；保护并行模块和已有半成品。**所有必需验收与集成候选验证通过前，禁止合并 main。**

## 2. Phase 0 只读盘点

执行：
- `git status --short --branch`
- `git branch -avv`
- `git worktree list --porcelain`
- `git remote -v`
- `git log -n 20 --oneline --decorate`
- 核对 `origin/main` 与本地 main 差异（先确认网络/授权）。
- 每个 worktree 读取 dirty paths、未跟踪文件、当前 owner、执行任务、提交和依赖。

上述命令只列核验动作，不代表已运行。先读取根 AGENTS 与项目 Git 授权规则。

## 3. 分支与工作树

- 优先续用包含本 UI 正确 WIP 的现有分支；只有没有合适 WIP 分支时，才从正确依赖基线创建 `feat/xiaozhi-uiux-v3-YYYYMMDD`。
- 每个执行者一份独立可写 worktree 和分支；禁止多 AI 在同一目录并行写入。
- 不得在共享工作树 `checkout/switch/reset/clean/stash/rebase`；不得用 `git add -A` 提交混合他人改动。
- 未知归属文件先标 `OWNER_UNKNOWN`，不迁移、不覆盖、不删除。
- WIP 分类：`KEEP / PORT / REPAIR / DEFER / SUPERSEDED / OWNER_UNKNOWN`。迁移前保留原始 commit/patch/备份并验证。
- `main/index.ts`、`preload/index.ts`、`App.tsx`、`PiSettingsWorkspace.tsx`、共享样式 Token、`page-contracts.ts` 等共享文件需明确 owner 和短时写入窗口。

## 4. 实施期间

- 只提交本模块明确归属文件；每个 commit 关联 REQ/W/AC。
- 不把其他模块改动夹带到 UI 分支；不擅自改配置 schema、Pi Runtime、数据库、权限或记忆契约。
- 跨模块共享契约先签 `templates/CONTRACT_HANDSHAKE.md`，记录双方 owner、版本、变更、兼容性、测试和回滚。
- 独立测试 profile、SQLite 副本、临时文件、端口、日志和凭证；禁止测试写入教师日常数据根。
- 每个阶段提交前运行 `git diff --check`，检查 `git diff --stat` 和逐文件 diff。

## 5. 合并前硬门禁

只有同时满足以下条件才允许合并 main：
1. `06_ATDD_ACCEPTANCE.md` 中 AC-001..AC-090 全部合并前必需项 PASS（预定义条件性 N/A 需有证据）。
2. UI-FINAL A01–A34 旧必需回归门禁 PASS（或有绑定当前 SHA/构建/数据环境的有效证据复用）。
3. LG-A35 的候选 diff/owner/权限/冲突/非强推子条件 PASS。
4. LG-A36 的精确集成候选正式窗口启动/构建身份子条件 PASS。
5. 不存在任何合并前必需 FAIL/BLOCKED/NOT_RUN。
6. `MG-01` 集成候选 PASS。
7. REQ→AC→TASK→CODE→TEST→EVIDENCE 双向追踪完整。
8. 没有未解决共享接口冲突、未归属 diff 或阻断性缺陷。
9. 最新 main SHA 已刷新，合成候选针对该 SHA 验证。
10. 按根 AGENTS/仓库分支保护和现有授权执行。

LG-A35 原标准中的“远端 main 已包含交付提交”与 LG-A36 原标准中的“最终 main 正式窗口启动”是合并后子条件，必须在 FG-01 复验；不能要求尚未合并的提交提前出现在远端 main。其候选子条件必须在 MG-01 前 PASS。

## 6. 串行集成

- 主线集成必须由唯一真实集成负责人串行执行；文件“锁”不能替代真实 Git 权限和排队机制。
- 先更新最新 main，记录 M0 SHA，构造 `M0 + UI` 集成候选；处理冲突后必须重新运行受影响检查。
- main 前移后旧候选 PASS 不自动继承；重新评估冲突并重跑受影响门禁。
- 禁止强推、禁用 CI、删除保护、移动他人分支或 reset 共享 main。
- 合并后核验 main 祖先关系/提交包含，运行 `FG-01`，确认源码、构建、运行窗口一致。
- push/PR/部署分别遵循项目当前授权；部署不能从合并授权推导。

## 7. 停止与恢复

出现 owner 不明、共享写冲突、分支保护阻断、测试环境冲突、合并冲突无法安全解决时，标 `WAITING_INTEGRATION` 或 `MERGE_BLOCKED`，保留工作树、提交、证据和恢复第一步，不清理现场。
