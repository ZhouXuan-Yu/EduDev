# 16 SET-P0 设置窗口优先工程任务书

## 当前冻结目标

**真正 Electron 独立 top-level 非模态单实例设置窗口**，而非在主窗口内切换 settings 页面或弹出 React Modal。窗口外观参考 WorkBuddy 的设置层级和豆包的简洁控件/图标配色，后台主窗口轻弱化但持续可操作；任务不停、草稿不丢、原功能与权限不失效。

## 代码依据

最新远程 main（2026-11-26）：`f420db00e4c124a1320aab57c82e65017ee89297`。静态检查到 App.tsx/activeView settings、PiSettingsWorkspace、10 分类/历史记忆子模块、主进程 settingsSender mainWindow-only、preload 全量 omniEdu。**执行需重新审计最新本地代码和并行 WIP，不能直接照搬。**

## 先行分片顺序

- W2-A：最小窗口 manager、单实例、非模态/非置顶、加载失败/关闭/退出幂等与多入口汇聚。
- W2-B：聚焦状态/非阻断蒙层、主窗继续任务、跨显示器/DPI 与 reduced-motion。
- W2-C：设置专用 typed preload/IPC allowlist、非法 sender/subframe/导航正反测试及会话 scope。
- W2-D：复用 10 类真实设置和现有搜索、日常/高级分组、教师文案、HeroUI/lucide Token；教师/L2/历史记忆一个不丢。
- W2-E：模型与凭证、普通配置版本/撤销、权限、技能/能力/MCP、归档、备份的真实回执/读回和跨窗同步。
- W2-F：性能/键盘/IME/长配置/焦点返回/重试/失败/Reduced Motion 实机验收。

允许 W2-A/B 与 W2-C 由拥有者在不同 worktree/文件所有权下并行，但共享 `main/index.ts`、`preload/index.ts`、`App.tsx` 时必须单 writer/协调快照，不能多个 AI 同时改一个文件。

## 验收唯一权威

- 原 74 AC + 新 AC-075..090 = **90 AC**；其中设置专题旧 AC-053..058 + 新 AC-075..090 全部 REQUIRED。
- 旧 UI-FINAL A01..A36 全保留，尤其 LG-A17/A18/A31/A32。
- 每项 AC 预期仅维护在 `06_ATDD_ACCEPTANCE.md`；本文件只列行动和证据，不修改断言。
- SET-P0 未通过，MG-01 禁止 PASS/合并 main。模块通过不等于 main 完成；仍需 FG-01/FG-02。
- 缺配置/安全/记忆/备份 owner 握手导致无法安全验证时，状态 BLOCKED/WAITING_INTEGRATION，不得放宽权限或假装实现。

## 正确的终止

全部设置专题 AC 与关联旧 LG PASS、业务运行/性能/安全证据齐全后可标 `SET-P0_ACCEPTED`；**整个 UI V3.1** 的 DONE 还需要全部 90 AC、36 LG、MG-01、FG-01、FG-02 通过。
