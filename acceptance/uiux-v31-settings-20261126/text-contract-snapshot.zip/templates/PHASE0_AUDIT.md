# Phase 0 只读审计模板

- 日期/执行者：
- 仓库根：
- 最新 origin/main SHA：
- 当前 HEAD/branch/worktree：
- `git status --short --branch`：
- `git worktree list --porcelain`：
- 运行目录/窗口/PID/build fingerprint：
- Node/npm/lockfile/HeroUI/Pro/lucide/Electron 版本：
- CI workflows/package scripts：
- UI/配置/记忆/数据库/Agent owner：
- 共享文件和 WIP：
- 当前有效 UI-FINAL 36 项证据：
- 当前 UI R1 证据：
- 每个 REQ 状态（VERIFIED_COMPLETE/PARTIAL/MISSING/DEFECT/TO_VERIFY）：
- 页面审批矩阵：
- 风险/阻塞：
- Phase 0 结论（只读）：
- 允许进入 Phase 1 的条件：
