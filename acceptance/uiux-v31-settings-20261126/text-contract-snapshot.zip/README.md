# V3.1 设置窗口优先修订（2026-11-26）

本包基于上一轮 V3 **完整继承** 26 REQ、旧 74 AC、36 项 UI-FINAL 回归以及所有逐页原型；新增 SET-P0 16 项 AC，总数 **90 项**。最新远程 main 只读观察 `f420db00e4c124a1320aab57c82e65017ee89297`；执行时须重新审计。

**本轮首要任务：把设置从 App 的 activeView 页面抽离成真正独立的 Electron 非模态窗口。** 参考 WorkBuddy 独立窗口与不中断主任务、豆包轻量设置行与清楚文案；柔和蒙层不能阻断主窗操作；十类真实设置与历史记忆、备份/权限等功能全保留。

**首先阅读：** `START_PROMPT.md` → `goal.md` → `design/settings-priority/01_SETTINGS_DECISION_AND_SCOPE.md` → `02_SETTINGS_SCREEN_FLOW.md` → `03_SETTINGS_API_AND_OWNERSHIP_MATRIX.md` → `04_TEACHER_COPY_AND_VISUAL_GUIDE.md` → 新图/HTML → 再按旧 README 的完整顺序阅读全部文件。**唯一验收真源仍是 `06_ATDD_ACCEPTANCE.md`（90 AC）**。

- 视觉图：`design/settings-priority/P18_SETTINGS_INDEPENDENT_WINDOW_VISUAL_PROPOSAL.png`
- 可离线操作 HTML：`design/settings-priority/SETTINGS_VISUAL_PROTOTYPE.html`（仅视觉演示，不是真 Electron）
- Chromium HTML 截图：`design/settings-priority/SETTINGS_VISUAL_PROTOTYPE_BROWSER.png`（仅网页截图）
- 设置专题目标与验收指引：`16_SETTINGS_PRIORITY_IMPLEMENTATION.md`、`17_SETTINGS_ACCEPTANCE_MATRIX.md`。

本轮无代码修改、无分支/合并/推送/部署；所有生产 AC/LEGACY/MG/FG 初始 NOT_RUN。

## 以下为上一轮 V3 原有说明（遇到日期/优先级/数量冲突，以 V3.1 头部及最新专项合同为准）

# 小智 UI/UX V3：AI 工程化开发执行包

**版本：V3 · 2026-11-26**  
**包状态：`V3_PACKAGE_READY / PRODUCTION_NOT_RUN`**  
**仓库：** https://github.com/ZhouXuan-Yu/EduDev  
**本次最新远程 main 观察：** `f420db00e4c124a1320aab57c82e65017ee89297`

> 本包由方案整理方生成。没有修改 EduDev 业务代码，没有创建分支，没有提交、合并、推送或部署。所有产品验收状态初始为 `NOT_RUN`。ZIP 自身的文件完整性验证不等于应用验收。

## 1. 本包目标

将小智桌面端 UI/UX 3.0 的已确认要求、逐页设计记录、当前源码基线、实施协议、BDD/ATDD、测试方法、双向追踪、质量门禁、并行开发规则和交付模板整理为一个可独立交给 Codex 或其他编程 AI 执行的工程包。

核心目标：**优先修复真实问题，再完成已确认优化；不得在功能缺失、必需测试未通过或真实业务行为未验证时宣称完成或合并 main。**

## 2. 强制读取顺序

1. `START_PROMPT.md`：执行入口。
2. `goal.md`：唯一总任务和完成定义。
3. `01_CONFIRMED_SPEC.md`：产品与冻结规格。
4. `02_BASELINE_AND_WIP.md`：最新源码观察、未知事实和 Phase 0 审计要求。
5. `03_GIT_WORKFLOW.md`、`11_PARALLEL_OWNERSHIP.md`：分支、worktree、并行所有权。
6. `design/01_SETTINGS_WINDOW_CONTRACT.md`、`design/02_VISUAL_TOKENS.md`、`design/03_MOTION_SYSTEM.md`、`design/04_PAGE_DESIGN_AND_APPROVAL.md`、`design/05_TEACHER_WORKFLOWS.md`。
7. `04_IMPLEMENTATION_PLAN.md`。
8. `05_BDD_SCENARIOS.md`。
9. `06_ATDD_ACCEPTANCE.md`：**唯一的 V3 验收断言真源**。
10. `07_TEST_STRATEGY.md`、`08_REQUIREMENT_TRACEABILITY.md`、`09_VERIFICATION_RUNBOOK.md`、`10_QUALITY_GATES.md`。
11. `12_RISK_AND_ROLLBACK.md`、`13_EXECUTION_STATUS.md`。
12. 执行期间填写 `14_ACCEPTANCE_REPORT.md`、`15_MERGE_REPORT.md`，并更新 `acceptance/` 下矩阵。

## 3. 交付内容

- 根目录 18 项核心文件：README、启动提示词、Goal、规格、基线、Git、计划、BDD、ATDD、测试策略、追踪、Runbook、质量门禁、并行所有权、风险回滚、状态、验收报告、合并报告。
- `design/`：设置窗口合同、视觉 Token、Motion System、页面审批矩阵、教师工作流映射、官方参考。
- `design/page-prototypes/`：2026-11-26 的 20 张页面/状态原型、原始截图、分组总览、审阅画廊及源文件。
- `design/v2-prototypes/`：上一版设置/任务/资料库离线样板。
- `legacy/V2_PACKAGE_20261125/`：上一版完整 V2 工程包，原样保留。
- `legacy/UI_FINAL_ACCEPTANCE_36.md`：项目原有 UI-FINAL 36 项验收基线。
- `acceptance/`：V3 90 项 AC、旧 A01–A36 回归门禁、REQ→AC→TASK→CODE→TEST→EVIDENCE 追踪 CSV。
- `templates/`：Phase 0 审计、共享契约握手、旧门禁映射模板。

## 4. 验收规模与状态

| 范围 | 数量 | 初始状态 |
|---|---:|---|
| V3.1 产品/工程 AC | 90 | 全部 `NOT_RUN` |
| UI-FINAL 历史必需回归门禁 | 36 | 全部 `NOT_RUN`，逐项映射 |
| V2 AC | 32 | 已建立映射；V3 AC 覆盖，原文留档 |
| REQ | 26 | 需 Phase 0 核实实现状态 |
| 质量门禁 | MG-01、FG-01、FG-02 | `NOT_RUN` |

条件性 AC 只有在其合同内明确的适用条件不成立、且有证据时才能标记 `N/A`。其余必需项不得事后改为 N/A。

## 5. 页面设计审批状态（不能混淆）

- P01「问小智首页」：`CONFIRMED_VISUAL_DIRECTION`。
- P02「我的任务」：`CONFIRMED_DIRECTION`。
- P03「资料库」：整页仍为 `PROPOSED / PENDING_VISUAL_APPROVAL`；“详情默认收起”这一交互决定已确认。
- P04–P17、X01–X05：`PROPOSED / NOT_USER_APPROVED`；P18 独立窗口行为已确认，新视觉图仍为 `PROPOSED_VISUAL_DETAIL`。

所有页面图片都只是视觉参考，不是实际运行截图或业务功能证据。全局左侧导航必须保留当前真实设计；所有页面改造先核对最新源码和真实能力。未获用户确认的页面结构提案不得被执行 AI 静默升级为冻结产品决策。允许先做不改变页面 IA/业务路径的安全视觉一致性改进。

## 6. 方法落地索引

| 方法 | 文件 | 实际动作 | 证据/通过条件 |
|---|---|---|---|
| PDD | `START_PROMPT.md`、`goal.md` | 将意图转成自包含执行指令；持续续做 | 执行状态、版本、缺陷与证据 |
| SDD | `01_CONFIRMED_SPEC.md`、`design/*` | 冻结 REQ、设计状态和变更边界 | 每项 REQ 映射任务/AC |
| BDD | `05_BDD_SCENARIOS.md` | Given/When/Then 覆盖真实教师流程 | 可复现输入和观察结果 |
| ATDD | `06_ATDD_ACCEPTANCE.md` | 实施前锁定唯一验收合同 | 90 AC + 36 legacy gates |
| TDD | `07_TEST_STRATEGY.md` | 关键状态/权限/幂等逻辑红绿重构 | 有效红灯、绿灯、回归日志 |
| Contract Testing | `07_TEST_STRATEGY.md`、`11_PARALLEL_OWNERSHIP.md` | 校验 main/preload/renderer/SQLite/文件契约 | 正反调用和 readback |
| Integration Testing | `07_TEST_STRATEGY.md` | 验证真实模块依赖连接 | 真实服务/文件/事件证据 |
| E2E | `05_BDD_SCENARIOS.md`、`09_VERIFICATION_RUNBOOK.md` | 从教师入口走到成果、保存和返回 | Electron 录屏、ID、版本、readback |
| Regression | `06_ATDD_ACCEPTANCE.md` | V3 AC 与 UI-FINAL 36 项旧门禁 | 逐项 PASS 及证据 |
| AI Evaluation | `07_TEST_STRATEGY.md` | 仅当实际改变模型/提示/检索/OCR/生成行为时执行 | 固定数据、模型配置、评分和输出 |
| CI Quality Gates | `09_VERIFICATION_RUNBOOK.md`、`10_QUALITY_GATES.md` | 只运行仓库实际存在的脚本 | 命令、exit code、SHA、日志 |
| Acceptance-Driven Loop | `04_IMPLEMENTATION_PLAN.md`、`10_QUALITY_GATES.md` | FAIL→定位→修复→重测→回归→更新矩阵 | 无必需项未通过才可进入集成 |

## 7. 重要边界

- 本轮方案 AI 只生成交付材料，不修改业务代码或 Git。
- 执行 AI 必须先读取根 `AGENTS.md`、Master Goal、文档地图和模块当前合同。
- 最新用户决定优先于旧视觉文档；旧决策台账只能追加新决策，不得删除历史。
- 不改 Pi Runtime、Harness、SQLite/文件事实来源、权限模型、学生数据边界、OfficeComposer 和 `PiComposerPendingPanel` 的既有契约。
- 不能用原型、Mock、静态图、单测或“按钮存在”冒充真实业务完成。
- 所有必需 AC 为 PASS 后才允许 main 集成；合并后仍需 FG-01/FG-02 验证最终 main，才能 DONE。

## 8. 开始执行

接收 AI 先执行 Phase 0 的只读审计，填写 `templates/PHASE0_AUDIT.md` 和 `13_EXECUTION_STATUS.md`。不得先大规模改样式或复制原型。
