# UI-P03 资料库｜设计提案（待用户审阅）

> 状态：**PROPOSED_VISUAL**，当前不代表已确认方案或已实现功能。资料库页面全部基于当前正式业务能力设计。

## 一、教师的真实目标
进资料库后快速知道：怎样添加资料、怎么找资料、是否已收录/可检索、怎样看原件和核对题目。不要求教师理解 OCR/索引/队列技术细节，但状态必须诚实。

## 二、页面结构（保持全局左侧导航原样）
- 页头「资料库」，副标题「整理教材、试卷和教学资料，随时查找与核对」。右上主操作「添加资料」，次操作「导入整个文件夹」「从文件夹勾选导入」（项目当前已有）。
- 轻量处理队列摘要；运行中、等待、失败项可点击展开原有「收录与处理／文件夹批次与恢复／题库归档与检索状态」，**折叠不卸载未保存的表单**。
- 资料库内部目录/标签栏可优化，不是新增全局主导航；显示「全部资料」「待处理」「读取失败」、教学目录和标签，沿真实数据库 facets。
- 主区通过「资料 / 检索内容」切换：资料模式中显示名称搜索、格式及收录状态筛选，下面紧凑行表格（名称及格式图标/来源或文件大小、收录状态、更新时间），底部真实分页/计数。
- **默认不打开右详情**；点击文件再按需打开，内容拥挤时优先侧滑抽屉或占用主工作区的完整详情，不将整份原文强塞在窄栏。详情导航保留概要/原页/正文/题目与校正/阅读笔记/处理详情等现有可用项；原页仅在适用格式出现。
- 采用蓝色主动作，PDF/Word/Markdown 格式用少量柔和辅助色；「可用于查找」绿，「待处理/部分收录」橙，「读取失败」红，但**图标与状态文字必须同时出现**。
- 不新增未经验证的“智能自动归类”或“全库任意字段排序”，不以 AI 生成图片的文字反推真实能力。

## 三、大数据与窄窗
- 数百/数千文件：真实后端检索/过滤/服务端分页。已加载部分数据不能代替全库结果。
- 宽窗口：内部目录区约180–200px＋主列表＋按需详情约340–400px；窄窗口优先折叠内部目录/详情，确保列表与点击区域可读。
- 筛选与分页后保留可控状态，遇到未保存目录、笔记、校对草稿，使用现有 `canChangeSource`、`useMaterialDraftGuard` 等保护行为。
- `loading/empty/no-match/error/partial/retry/cancel` 分别可辨认，后台收录不中断浏览；本机原件、已收录正文、可检索、题目已核对是不同事实，不得合并成“已完成”。

## 四、只读源码核验（GitHub main `9b192954e3d64e7d00fe15382a2db34f8351d0cc`，实施时重读）
- `MaterialsWorkspace.tsx`：目录列表、名称搜索、服务端 `listMaterialCatalog`、格式/状态/目录/标签筛选、分页、文件夹导入/选择性导入、后台队列、停止/重试、草稿保护、详情选择。
- `material-library-ui/MaterialLibraryLayout.tsx`：资料/检索内容双模式，内部资料目录，处理队列展开。
- `MaterialLibraryCatalog.tsx`：名称、收录状态、更新时间三列；文件格式和大小放在名称区。
- `MaterialLibraryNavigation.tsx` / `MaterialCatalogFilters.tsx`：来源于数据库的目录和标签 facets，快速范围、格式和状态筛选。
- `MaterialTextSearch.tsx`：关键词/混合正文检索，须保留真实覆盖情况与来源定位。
- `MaterialBodyPanel.tsx`：概要、正文、原页、题目与校正、阅读笔记、处理信息、定位文件、AI 整理等功能。
- `MaterialImportPanel.tsx` / `MaterialLibraryActivity.tsx`：文件夹批次进度、恢复和任务控制。
- `shared/material-catalog.ts`：`query+offset+scope{directory,tags,format,state}`；暂无排序字段，不得凭空新增前端假排序。

## 五、可参考的成熟组件与方法
- HeroUI v3 Table：https://heroui.com/en/docs/react/components/table （先核对项目实际版本，不能以新官网 API 硬套旧源码）
- Atlassian Dynamic Table：https://atlassian.design/components/dynamic-table/ （大列表分页/状态）
- Atlassian Filter Button：https://atlassian.design/components/button/filter-button/usage （筛选的可见状态）
- Material 3 Side sheets：https://www.getbook.com/en/book/material-design-3/components/side-sheets/guidelines （非阻断上下文详情）

## 六、仍待确认
资料库页面采用「原左全局导航＋内部目录/标签＋主列表＋按需展开详情」；视觉稿只用于逐页校准，未经用户确认不作为执行任务的已冻结设计。

## 七、视觉稿登记
- 图像：`assets/03_materials_LIBRARY_PROPOSED_visual.png`，状态 `PROPOSED_VISUAL / SYNTHETIC_SAMPLE`，仅为本轮用户审阅。
- 图像中额外出现的批量勾选框及每行更多操作、目录名称、数字、模拟文件等**不得解释为当前源码确认功能**；如果要求实施必须先核验真实接口及风险。图中“部分正文可查”仅是视觉语言示意，具体状态语义以真实 `materialReadiness()`、任务回执和领域合同为准。
- 保持全局左栏不变；选中资料时显示右栏，未选中时右栏默认收起；用户是否接受需下一轮明确答复。
