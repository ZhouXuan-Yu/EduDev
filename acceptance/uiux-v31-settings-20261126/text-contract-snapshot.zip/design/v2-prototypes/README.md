# 三页离线交互样板

打开 `index.html` 即可查看，无后端、无网络、无依赖。顶部切换 **A 独立设置窗口视觉 / B 我的任务 / C 资料库**，点击模拟控件有离线提示。所有示例标题、进度和按钮均为**合成设计数据**，文件/任务没有真实读写，不是实际组件或 Electron 子窗口，不能用于正式 UI E2E 或性能 PASS。此样板内的设置弹层只是一个窗口外观示意；实际开发必须按照 `design/01_SETTINGS_WINDOW_CONTRACT.md` 建真正非模态 Electron BrowserWindow 并通过 IPC/权限验收。

该设计样板不使用 HeroUI 源码，其配色/布局只是对照稿；正式产品须复用项目已安装 HeroUI v3/Pro/lucide-react。浏览器窗口缩放时可观察响应式布局，系统 reduced motion 会禁非必要过渡，但不能替代 Windows DPI/IME/真实性能测试。
