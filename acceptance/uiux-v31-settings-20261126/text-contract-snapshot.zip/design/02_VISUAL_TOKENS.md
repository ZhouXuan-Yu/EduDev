# DESIGN-02 Xiaozhi Visual Tokens V3（候选值，非生产主题）

## 1. 视觉主旨

教师工作区采用白/中性灰为大面积底色，语义色帮助识别功能和状态；左侧全局导航保持原样。页面之间统一字体、间距、图标和状态，但不把所有信息做成卡片。优先用留白、分组、细分隔和清楚的标题层级。

## 2. 颜色 Token 候选

| Token | 候选值 | 用途 |
|---|---|---|
| `--xz-bg-canvas` | `#F6F8FB` | 工作区外层浅底 |
| `--xz-bg-surface` | `#FFFFFF` | 主内容/设置内容 |
| `--xz-bg-muted` | `#F1F4F8` | 次级分组/hover |
| `--xz-border-subtle` | `#E5EAF0` | 必要分隔 |
| `--xz-text-primary` | `#1F2937` | 正文/标题 |
| `--xz-text-secondary` | `#596579` | 辅助文字 |
| `--xz-brand-600` | `#2563EB` | 主操作/选中蓝 |
| `--xz-brand-700` | `#1D4ED8` | 链接/小尺寸蓝色文字 |
| `--xz-ai-700` | `#6D35C7` | AI/课件语义紫 |
| `--xz-ai-tint` | `#F1EBFF` | AI 浅色背景 |
| `--xz-success-700` | `#166D53` | 真实完成/成功 |
| `--xz-success-tint` | `#E5F6F0` | 成功浅色背景 |
| `--xz-attention-700` | `#8D520B` | 待处理/需教师核对 |
| `--xz-attention-tint` | `#FFF3DE` | 待处理浅色背景 |
| `--xz-danger-700` | `#A42F3F` | 失败/危险文字 |
| `--xz-danger-tint` | `#FCECEE` | 失败浅色背景 |
| `--xz-focus-ring` | `#2563EB` | 键盘焦点 |

以上均为候选值；正式实施必须映射至当前主题单一真源，并在实际背景/控件/禁用/hover/pressed 状态重新测量对比度。普通文字 WCAG AA 目标为 4.5:1；不能只测基础色对比。

## 3. 颜色语义

- 蓝色：主要行动、当前选中、链接。
- 紫色：AI 能力、PPT/课件等创作类功能。
- 绿色：真实完成、保存成功、教师已确认。
- 琥珀：待处理、等待教师核对、部分完成需关注。
- 红色：失败、危险、不可恢复操作。
- 灰色：中性、禁用、辅助信息。

颜色不能作为唯一信息：状态必须同时有中文标签/图标；不能只用绿点表示完成。

## 4. 字体与密度

- Windows 中文系统字体回退以当前项目为准；UI 常规 14–15px，对话正文约 16px，标题 22–26px，分区标题 16–18px，辅助文字原则上不低于 13px。
- 间距节奏 4/8/12/16/24/32px。
- 长文阅读行高可到 1.7；常规界面约 1.45–1.65。
- 控件圆角 8–12px；内容卡片 12–16px；不为所有行套卡片。
- 任务/资料列表紧凑，但标题、状态和操作必须可读、可访问。

## 5. 图标与组件

- 使用当前 HeroUI v3/现有 Pro 和 lucide-react；图标尺寸按项目真实规范统一（建议 18–20px 常规、20–24px 主要动作）。
- 语义示例：问小智 `MessageCircle`、任务 `ListTodo`、资料 `Library`、教学 `BookOpenCheck`、学生 `Users`、设置 `Settings`、AI `Sparkles`、完成 `CheckCircle2`、等待 `Clock3`、失败 `AlertCircle`。
- 图标与文字共同表达；Tooltip 不是唯一标签。
- 禁止直接暴露原生 select/summary 粗黑三角；复用现有 AppSelect/HeroUI disclosure；保留受保护 AppNativeSelect 的表单语义。
- Hover/Pressed/Selected/Focus/Disabled/Loading 状态一致；Focus 不可删除。
- 禁止全局 `button/input` 样式污染、全局 `!important`、修改 vendor CSS。

## 6. Surface / Shadow

- 主内容主要依靠留白、对齐和细分隔线。
- 阴影用于独立设置窗/浮层和必要的层级提示，不给每个列表行加厚重阴影。
- 仅设置窗口允许背景视觉退后；普通业务页面不加全屏玻璃效果。

## 7. 升级流程

1. Phase 0 找到当前 Theme/Token 单一真源和 CSS layer 顺序。
2. 核对 HeroUI 实装版本和真实 API。
3. 建立变量映射与视觉回归。
4. 对全部页面做基础/hover/focus/selected/disabled/loading/error 状态检查。
5. 验证对比度、Windows DPI 和暗色设置（若当前产品只支持浅色，则不擅自新增暗色）。
6. 只有真实生产组件验证后才将候选 Token 标为正式。
