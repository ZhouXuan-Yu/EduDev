# DESIGN-06 官方与成熟设计参考

以下用于解释设计取舍，不是小智已通过验收的证据，也不授权复制第三方产品的业务/视觉实现。

- Apple Human Interface Guidelines — Motion: https://developer.apple.com/design/human-interface-guidelines/motion
- Electron BrowserWindow API: https://www.electronjs.org/docs/latest/api/browser-window
- Electron Security: https://www.electronjs.org/docs/latest/tutorial/security
- HeroUI React docs: https://heroui.com/en/docs/react
- HeroUI v3 release / animation and reduced motion: https://heroui.com/en/docs/react/releases/v3-0-0
- web.dev animation performance: https://web.dev/articles/animations-overview
- W3C WCAG 2.2: https://www.w3.org/TR/WCAG22/
- W3C Animation from Interactions: https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html
- Atlassian Dynamic Table: https://atlassian.design/components/dynamic-table/
- Atlassian Filter Button: https://atlassian.design/components/button/filter-button/usage

执行 AI 必须在实施时核验当前官方文档和项目实际依赖版本。不能把文档示例 API 直接复制到不同版本。
