# 小智 UI/UX V3 页面视觉审阅与审批状态（修订）

**修订说明：** 本文件覆盖旧页面审阅包中“首页、任务页、资料库三项均已确认”的过期概括。以 `page-decisions/00_PAGE_DECISION_LOG.md` 和本文件审批矩阵为准。

- P01 问小智首页：`CONFIRMED_VISUAL_DIRECTION`。
- P02 我的任务：`CONFIRMED_DIRECTION`。
- P03 资料库：`PROPOSED / PENDING_VISUAL_APPROVAL`；只确认“资料详情默认收起、选中后按需展开”。
- P04–P18、X01–X05：全部 `PROPOSED / NOT_USER_APPROVED`。

## 全局硬约束
- 原全局左侧导航结构、顺序、分组、图标、位置与行为保留。
- 所有页面改造必须以执行时最新 main、真实功能、真实 route、service、data contract 和测试为依据。
- 图片中的所有任务、学生、资料、数字和文件均为合成数据。
- OfficeComposer、PiComposerPendingPanel、Pi Runtime、审批、恢复、文件/SQLite 真源和权限合同受保护。
- 不得根据原型图新增当前源码不存在的按钮、接口、状态或业务闭环。

## 页面审批表
| ID | 页面/场景 | 状态 | 当前允许的实现范围 |
|---|---|---|---|
| P01 | 问小智首页 | CONFIRMED_VISUAL_DIRECTION | 依已确认输入优先与三项快捷入口实现 |
| P02 | 我的任务 | CONFIRMED_DIRECTION | 紧凑列表、真实筛选/分页、右侧详情默认收起 |
| P03 | 资料库 | PROPOSED；详情默认收起已确认 | 仅可做安全视觉一致性；整页结构待确认 |
| P04–P18 | 其余正式页面 | PROPOSED | Token/状态一致性可做；结构变更需用户确认 |
| X01–X05 | 关键业务状态/子视图 | PROPOSED | 仅按现有真实功能映射，不新增路由或业务能力 |

## 原型真实性
20 张 PNG 为静态设计渲染，不是 Chromium/Electron 生产截图。此前本地浏览器策略阻止 file:///本地 HTTP 预览，因此没有宣称 HTML 交互原型通过浏览器验收。设置窗跨窗口行为必须真实 Electron 验收。
