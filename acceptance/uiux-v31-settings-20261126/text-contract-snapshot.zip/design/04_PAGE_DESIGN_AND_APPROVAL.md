# V3.1 设置 P18 的审批状态覆盖旧描述

P18 **独立非模态设置窗口形态**：用户已再次明确确认（CONFIRMED_WINDOW_BEHAVIOR）；设置轻盈、清楚、适度图标配色，参考豆包和 WorkBuddy（CONFIRMED_STYLE_DIRECTION）。本轮新图 `design/settings-priority/P18_SETTINGS_INDEPENDENT_WINDOW_VISUAL_PROPOSAL.png` 是视觉提案（PROPOSED_VISUAL_DETAIL），不能自动把图中具体状态、按钮及像素升级为已确认业务功能。其它 P01/P02/P03/P04–P17/X01–X05 的已有审批状态不变。

# DESIGN-04 页面设计与审批矩阵

## 1. 全局硬约束

- 左侧全局导航保留原样；图片如与真实左栏有差异，以用户提供的原始截图和最新代码为准。
- 页面结构以实施时最新源码/真实功能为依据；原型图不授权新增业务能力。
- 合成学生/资料/任务/计数/文件仅作视觉样例。
- 页面提案未确认时，执行 AI 只可做不改变 IA/业务流程的安全视觉一致性修复；显著布局/交互结构变更需先用户确认。
- 生产页面必须由真实 HeroUI v3/Pro 组件实现并实机验证。

## 2. 页面审批矩阵

| ID | 页面/场景 | 当前状态 | 用户已确认内容 | 图片/代码映射 |
|---|---|---|---|---|
| P01 | 问小智首页 | CONFIRMED_VISUAL_DIRECTION | 输入优先、三项快捷入口、原左栏 | `page-prototypes/reference/P01_ai_home_CONFIRMED.png` |
| P02 | 我的任务 | CONFIRMED_DIRECTION | 紧凑列表、状态筛选/分页、大量任务、右侧详情默认收起、原左栏不变 | `reference/P02_tasks_CONFIRMED_direction.png` |
| P03 | 资料库 | PROPOSED / PENDING_VISUAL_APPROVAL | 仅“详情默认收起、选中后展开”已确认 | `reference/P03_library_APPROVED_direction.png`；文件名不代表审批 |
| P04 | 教学工作台 | PROPOSED | 真实五个教学页内入口 | `screens/P04_teaching.png` |
| P05 | 教学文件 | PROPOSED | 真实文件/版本/预览/来源 | `screens/P05_artifacts.png` |
| P06 | 备课本 | PROPOSED | 真实本地笔记和记录 | `screens/P06_notebook.png` |
| P07 | 讲义 | PROPOSED | 章节/页面/内容块 | `screens/P07_book.png` |
| P08 | 题本 | PROPOSED | 题目/来源/收藏/筛选 | `screens/P08_question_notebook.png` |
| P09 | 智能组卷 | PROPOSED视觉 | 组卷业务合同仍沿 D14/UI-FINAL；图片非新业务授权 | `screens/P09_paper.png` |
| P10 | 学生工作台 | PROPOSED | 先选学生、上下文绑定 | `screens/P10_student_workbench.png` |
| P11 | 学生档案 | PROPOSED | 真实 CRUD/导出/归档 | `screens/P11_students.png` |
| P12 | 查找学生与记录 | PROPOSED | 本地检索 | `screens/P12_search.png` |
| P13 | 添加学习记录 | PROPOSED | 学生选择/OCR/校正 | `screens/P13_intake.png` |
| P14 | 错题与练习 | PROPOSED | 原图/校正/来源/教师确认 | `screens/P14_mistakes.png` |
| P15 | 学习计划 | PROPOSED | 仅教师确认路径 | `screens/P15_mastery.png` |
| P16 | 学习复盘 | PROPOSED | 真实记录证据/草稿/保存 | `screens/P16_review.png` |
| P17 | 学习概览 | PROPOSED | 真实数据/样本范围 | `screens/P17_analytics.png` |
| P18 | 独立设置窗口 | PROPOSED视觉 | 独立非模态窗口形态已确认 | `screens/P18_settings.png` |
| X01 | 对话执行中 | PROPOSED | 使用真实 Pi 事件；Composer 受保护 | `screens/X01_ai_running.png` |
| X02 | PPT 成果预览 | PROPOSED | 只映射现有 PPTX 预览/版本/来源，不冒称逐页编辑器 | `screens/X02_ppt.png` |
| X03 | 整包任务 | PROPOSED | 教学文件已有子视图 | `screens/X03_deliveries.png` |
| X04 | 课堂设计与预演 | PROPOSED | 现有课堂设计/预演子视图 | `screens/X04_classroom.png` |
| X05 | 模考汇编 | PROPOSED | 现有模考汇编子视图 | `screens/X05_mockexams.png` |

## 3. 页面级功能映射

完整的源码入口/教师价值/业务边界见 `PAGE_DESIGN_REVIEW.md`。实施前必须按最新 main 重新核验，特别是：
- `TeachingArtifactsWorkspace` 内 files/deliveries/classrooms/mockExams；
- `WorkbenchPageNavigation` 的教学 5 页、学生 7 页；
- `StudentWorkbench` 的 studentId 选择和上下文；
- `PaperBlueprintWorkspace` 的 blueprint/review/delivery 阶段；
- `PiSettingsWorkspace` 当前 10 类设置和 `SettingsNavigation` 日常/高级分类。

## 4. 设计审批规则

- 用户确认某页后，更新本文件、`00_PAGE_DECISION_LOG.md` 和项目 `edudev-design` decisions 追加项；记录日期、页面 ID、图像 SHA、批准范围。
- 不得把一张图片的视觉批准扩大为图片中每个按钮/字段/业务流程都批准。
- 若图片与真实功能不一致，以最新源码和用户冻结合同为准；标 `TO_VERIFY` 或 `NEEDS_DECISION`，不能自行补造能力。
- 未确认页面可以应用全局 Token/状态一致性，不得擅自大幅重构布局/IA。
