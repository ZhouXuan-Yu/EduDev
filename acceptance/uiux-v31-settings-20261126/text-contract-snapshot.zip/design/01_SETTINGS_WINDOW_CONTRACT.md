# V3.1 设置窗口优先规范（当前有效）

本文件旧 V3 内容继续保留，但本轮更完整合同以 `design/settings-priority/01_SETTINGS_DECISION_AND_SCOPE.md`、`02_SETTINGS_SCREEN_FLOW.md`、`03_SETTINGS_API_AND_OWNERSHIP_MATRIX.md` 为准。**设置必须是真正 top-level nonmodal Electron BrowserWindow（不是 React Modal/activeView 子页）**，主窗蒙层不可截获交互；真实十类设置（含历史记忆）以及配置/权限 readback 均为必需；新增 AC-075..090 归入唯一 `06_ATDD_ACCEPTANCE.md`。

# DESIGN-01 独立设置窗口合同（V3）

**产品决定：CONFIRMED（独立非模态窗口）；技术实现：TO_VERIFY。** 本文定义产品行为，不代表生产代码已经实现。

## 1. 教师目标

教师需要调整小智设置时，不应离开正在进行的备课、对话或任务。设置打开后是独立窗口；主窗口可继续使用；设置关闭不终止 Pi task、不清除草稿。

## 2. 窗口合同

- 真正 Electron `BrowserWindow`，非模态、单实例。
- 重复打开设置聚焦现有窗口，不新建实例、不重置表单。
- 设置窗口取得焦点时，主窗口可视觉弱化（轻遮罩/可选静态轻模糊）；切回主窗口时遮罩立即撤除，主窗口仍可点击。
- 不使用 `modal: true` 或主 renderer Dialog 冒充独立设置窗。
- 关闭设置只关闭设置 renderer，不调用 Pi stop/cancel；任务继续。
- 窗口尺寸/位置受显示器 `workArea` 和 DPI 约束；多屏移除、缩放变化后恢复到可见范围。
- 推荐初始工作区约 960×660 CSS 等价尺寸；建议最小 760×540，最终以当前页面内容/Windows DPI 实测校准，不为固定尺寸牺牲可达性。
- 左侧设置分类栏建议 210–240px；右侧单一内容滚动区；日常设置优先，高级与诊断按需展开。
- 模糊、阴影、圆角、位移均可性能降级；独立性、非模态、焦点、权限和真实保存不可降级。

## 3. 信息架构

保留所有现有设置能力，不得因简化界面删除：
- 日常：模型与连接、界面偏好、教师记忆、资料与权限、本地数据/备份等当前已有常用功能；
- 高级与诊断：教育技能、能力中心、外部工具/MCP、策略与诊断等；
- 归档/备份的具体归属以当前 `SettingsNavigation` 与真实配置合同为准，不能仅凭示意图重组丢入口。
- 搜索应命中真实设置项并定位到实际控件；不能只显示静态搜索结果。
- 不展示不存在的通知/同步/系统开关；没有真实接口的设置不能伪造。

## 4. 交互与状态

### Open / Focus / Close
1. 主窗口点击设置入口 → 请求主进程打开/聚焦设置窗。
2. 主进程校验调用方身份、窗口状态和权限；已有实例则 focus。
3. 设置 renderer 通过受限 preload 读取脱敏配置视图。
4. 主窗失焦时只显示视觉弱化；主窗再次获得焦点时蒙层撤除。
5. 设置关闭时销毁设置 renderer；不停止主窗口任务，焦点合理返回触发区域。

### Save / Readback
- 区分即时生效、显式保存、需要重启生效、待验证的设置。
- 保存中、成功、失败均基于主进程真实回执；成功后必须按版本或 readback 核对。
- 失败保留用户输入，不显示“已保存”。
- 两个窗口共享唯一配置真源；不建立第二套 store。
- 会话/权限/配置版本变化时，旧异步结果不能覆盖新状态。

### Keyboard / Draft
- Tab 顺序、Focus visible、Esc、关闭按钮和焦点返回明确。
- 未保存配置/敏感操作关闭前按真实保存合同保护，不静默丢弃。
- IME composing 不误提交。
- 关闭设置不清理主窗口输入草稿、待办、附件、滚动位置或任务状态。

## 5. 安全与 IPC

当前静态观察显示 `main/index.ts` 有针对主窗口 `webContents`/`mainFrame` 的 `settingsSender` 限制。子窗口不能直接复制主窗口全部 preload 权限。

执行 AI 必须：
- Phase 0 枚举设置读取/写入/备份/权限相关 IPC；
- 为设置窗口建立最小 typed API allowlist；
- 主进程同时校验 sender、mainFrame、窗口身份和 capability；
- 保留 `contextIsolation:true`、`sandbox:true`、`nodeIntegration:false`；
- 对未知 sender、子 frame、伪造消息执行负向测试；
- 原配置服务继续为单一事实源；
- 配置 owner 与 desktop main/preload owner 签署接口握手；
- 未完成安全合同前保留旧设置页面兼容入口。

## 6. 禁止

- 全量放开 IPC；
- 设置窗直接访问 Node/fs 或任意本地路径；
- 设置窗保存一份独立配置副本；
- 用 Toast 假装保存；
- 模态 Dialog 冒充独立窗口；
- 打开/关闭设置触发 Pi task stop/cancel；
- 用高性能设备截图掩盖低性能 GPU 黑闪/掉帧。

## 7. 必需验收

对应 `AC-053..AC-058`。必须在真实 Windows/Electron 验证窗口单例、主窗连续、合法/非法 sender、保存/失败/readback、DPI/多屏和关闭恢复。静态原型不构成 PASS。
