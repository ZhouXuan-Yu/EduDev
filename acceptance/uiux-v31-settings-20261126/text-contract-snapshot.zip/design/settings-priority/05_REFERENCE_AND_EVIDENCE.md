# SET-P0-REF · 成熟参考与源码核验依据

## 一、参考来源（2026-11-26）

- WorkBuddy 官方系统设置：https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Setting 。明确独立窗口、重复打开聚焦既有窗口、关闭不停止任务；设置采用左导航+右内容。
- Electron 官方 BrowserWindow：https://www.electronjs.org/docs/latest/api/browser-window/ 。父子窗口与 modal 规则：modal 会禁用父窗；非模态独立顶层窗口应避免 parent 导致 always-on-top 阻挡主窗。
- Electron Context Isolation：https://www.electronjs.org/docs/latest/tutorial/context-isolation/ 。保持 contextIsolation + 最小桥接。
- Electron Security：https://www.electronjs.org/docs/latest/tutorial/security 。检查导航、外部链接、加载和 IPC 边界。
- HeroUI v3 组件文档：https://heroui.com/en/docs/react/components/modal 。仅用于设置窗**内部**确实需要的弹层，不用于把整个设置页伪装成 Electron 独立窗口。
- 豆包桌面设置视觉参考（2026-02-09 第三方截图，不保证最新 UI）：https://www.landiannews.com/archives/111778.html 。仅参考简洁的分类/控件、生活化文案；不得复制不存在的功能。

## 二、最新仓库观察（2026-11-26）

- GitHub main SHA：`f420db00e4c124a1320aab57c82e65017ee89297`。本次提交包含 main/index.ts、App.tsx 等变更，必须在执行 Phase 0 再核验。
- `apps/desktop/src/renderer/App.tsx`：仍以 activeView 切换 settings，并渲染 `<PiSettingsWorkspace .../>`；`desktop:command` 的 settings 命令仍设置 activeView。
- `apps/desktop/src/main/index.ts`：主进程只有 mainWindow 的 BrowserWindow 初始化；`settingsSender` 仍以 mainWindow webContents/mainFrame 为条件。
- `apps/desktop/src/preload/index.ts`：现有 omniEdu API 范围很大，含 Pi、工具、配置、资料及学生操作；不应全量给新子窗。
- `apps/desktop/src/renderer/components/office/PiSettingsWorkspace.tsx`：10 分类，`teacher-memory` 最新还包括 `PiHistoryMemorySettings`；组件读取当前会话部分使用主窗口 localStorage 的 `xiaozhi.current-session.v1`，子窗迁移时必须改为经主进程验证的会话作用范围。
- `apps/desktop/src/renderer/components/office/SettingsNavigation.tsx`：已有日常/高级导航划分，尽量复用。
- `apps/desktop/package.json`：HeroUI 3.2.x、Electron 43.x、已有设置和 Electron/UI smoke 脚本；真实实装版本以锁文件/当前工作树核验。

以上是远程只读代码观察，不是本地工作树/当前正在运行应用的完整审计。不可提前填写已实现/通过/已合并。
