# SET-P0 · 独立设置窗口产品与视觉合同 · V3.1

**本轮产品确定（CONFIRMED）：** 设置从当前主窗口页面中抽离，改为真正独立、非模态、单实例的 Electron 桌面窗口；主窗口原左侧导航与页面不变；设置窗口有柔和的背景弱化；主窗口可继续使用，关闭设置不影响正在运行的小智任务。

**视觉稿状态（PROPOSED VISUAL REFERENCE）：** `P18_SETTINGS_INDEPENDENT_WINDOW_VISUAL_PROPOSAL.png` 为本轮设计建议，已确定视觉语言和信息架构方向，不视为每个像素、开关状态或控件已获用户确认，更不等于代码实现。**实施必须以最新真实设置功能为依据。**

## 1. 为什么这么设计

参考成熟实践，WorkBuddy 官方设置文档明确描述独立设置窗口、主窗口不被占用、重复打开聚焦既有窗口、关闭不影响任务；豆包公开桌面界面给出轻量分类、细致控件和可理解文案的视觉借鉴（部分图像来自第三方报道，只作为视觉参考）。Electron 官方明确 modal child disables parent，因此禁止通过 `modal:true` 或主窗口 React Modal 假冒独立非模态设置窗。

## 2. 窗口层级（最终行为）

- 设置以独立 **top-level BrowserWindow** 建立，由应用主进程管理与关闭；不要依赖 OS parent/child 的 always-on-top 行为，避免阻挡可操作的主窗口。
- `modal:false`，不使用 `setAlwaysOnTop(true)` 强行覆盖主窗口；用户可以 Alt+Tab 或点击主窗继续工作。
- 单例：所有当前设置入口（左栏底部/桌面菜单/对话里的设置入口）调用同一窗口管理器；再次打开聚焦现有设置窗，不重建 React 树、不丢失未提交编辑。
- 初次创建 `show:false`，完成安全加载和首帧准备后 `show/focus`；超时/加载失败给可恢复错误，不永久留下空白或隐形窗口。
- 关闭设置只关闭该 BrowserWindow，不触发 Pi stop/任务取消；主窗关闭/应用退出必须安全清理设置窗和订阅，不遗留悬浮进程。
- 主窗切回后，设置窗可继续存在但不保持置顶；主窗当前任务照常继续。
- 显示器 workArea、DPI/缩放、多显示器切换、移动、最小化、最大化、断开显示器后可见性均要验收；不能把窗口坐标落到屏幕外。

## 3. 背景蒙层的精确定义

- 打开/聚焦设置窗时，**仅对主窗口内容做轻度、可降级的视觉弱化**（建议灰蓝遮罩 14–24% 和非常轻的静态模糊，最终由真实设备测量）；这不是模态锁。
- 主窗弱化层不参与命中测试：应用本身可采用 `pointer-events:none` 和 `aria-hidden=true` 的装饰层，不能阻断主窗口的鼠标、键盘、拖拽、滚动或输入。
- 当主窗获得焦点、设置窗失焦/最小化/关闭时立即清除弱化层；窗口聚焦频繁变化不能产生闪烁、遮罩残留或焦点循环。
- 系统 `prefers-reduced-motion` 或设备性能不足时直接移除位移/背景模糊，仅保留必要的状态区分。**禁止把跨窗口蒙层实现为一个覆盖整个桌面的透明 BrowserWindow**（风险更高、跨屏/命中测试困难）。

## 4. 外观与布局

- 保持小智已有浅灰全局侧边栏原样；设置窗内部使用自己的窄分类导航，不对全局左栏做任何调整。
- 建议默认约 960×660 CSS 等价尺寸；最小宽高、位置和滚动区依实际屏幕 workArea 与 Windows DPI 测试决定，不固定写死导致 1366×768 不可用。
- 轻盈浅色，边界干净，圆角约 16px，低对比阴影；蓝色用于选中/主动作，紫色用于 AI，绿色真实成功，琥珀警告，红色危险。**不把所有卡片做成渐变背景。**
- 头部：设置标题、短副标题可选、右侧明确关闭；设置窗不增加第二套主应用导航。
- 内部左侧：搜索设置、日常设置、按需高级设置；图标色彩配中文标签，选择态清楚。
- 右侧：当前分类标题、用途说明、按功能分组的设置行、真实控件和紧邻保存反馈；普通设置不堆嵌套卡片。
- 高级功能按需进入，不能隐藏实际权限风险或破坏性操作确认。
- 一类设置只保留一个滚动主区。需要长篇文字/表格时显示有边界的滚动，而非把关闭/保存按钮推到不可达区域。

## 5. 现有功能必须完整保留

当前 `PiSettingsWorkspace` 静态核验有 10 个 tab ID：
`models / skills / capabilities / tools / permissions / teacher-memory / interface / archives / backup / diagnostics`。
现有 `SettingsNavigation` 也已经按日常/高级展示，不能重造两套配置数据。

1. 模型与连接：`PiModelSettings`、连接/默认模型、实际保存、校验、凭证脱敏。
2. 教育技能：`PiSkillSettings` 与原技能授权、导入、启用等能力。
3. 能力中心：`PiCapabilityCenter` 及当前任务上下文。
4. 外部工具：`PiManagedTools`、`PiMcpSettings`，真实调用权仅由原宿主授权。
5. 资料与权限：当前会话的工作目录、`PiPermissionSettings`、`PiEnvironmentSettings`、`PiMemoryScope`；明确“会话级”作用范围。
6. 教师记忆：`PiTeacherMemorySettings`、`PiL2MemorySettings`、**最新** `PiHistoryMemorySettings`，不得遗漏历史记忆子模块。
7. 界面偏好：原 `sidebar`、`aside`、`files` 和追加消息 `followUp/steer`，保留现有保存/生效时序。
8. 归档：本地历史会话/目录和只读归档记录查看。
9. 备份与归档：本地备份、校验和恢复，必须使用独立数据副本验收。
10. 策略与诊断：`PiResolvedAgentConfig`、决策/候选历史、诊断等只读或受控功能。

**不要新增不存在的“系统通知”“账号会员”“同步开关”让演示稿显得完整。** 凡真实 API 尚不存在，按设计规范标不可用/待扩展，不自建无关业务。

## 6. 安全与跨窗口数据

主窗口目前持有完整 `window.omniEdu` preload facade，且 `main/index.ts` 中 `settingsSender` 主要校验主窗口 webContents/mainFrame；在新设置窗直接复制主 preload 或全量放宽 sender 等于扩大攻击面。

- 新设置窗使用**最小权限、独立 typed preload facade**。按上述 10 分类逐接口列允许调用清单；在 main 端再校验 sender/webContents ID + mainFrame + 设置窗角色 + 参数 schema + 原本业务授权；拒绝所有未知/子框架/被导航后的 sender。
- 受限 preload 不提供终端、普通文件读写、Agent 工具执行、无关学生/资料操作等大权限。
- 设置窗仅通过原配置服务进行保存、版本核验和读回，不创建第二份可独立写入的配置真源。
- 主窗与设置窗通过有版本/epoch 的事件同步或显式刷新；旧事件不能覆盖最新修改。`ordinary config-commit / config-undo / config-history` 等当前存在的配置接口应先核对版本、回执和授权，再迁移可见配置页。
- 会话级权限/工作目录/记忆不能从设置窗自己的 `localStorage` 猜测“当前会话”。主进程或经过主进程校验的当前会话上下文提供可信 sessionId；切换主窗会话时展示“设置作用于哪个会话”，旧操作须经过版本校验。
- API Key 仍由原安全存储/主进程管理，不出现在 window title、URL/hash、调试日志、错误正文或可复制快照；不重复创建 secrets store。
- `contextIsolation:true`、`sandbox:true`、`nodeIntegration:false`、拒绝意外导航/新窗口打开，保持 CSP/加载路径边界。
- 配置/平台/Pi owner 必须签 `templates/CONTRACT_HANDSHAKE.md` 后再启用窗口业务读写。

## 7. 验收和非目标

见 AC-053..058 + 新增 AC-075..090；所有验收均需要真实 Electron、源 SHA/构建指纹及必要 SQLite/file readback。视觉 PNG/离线 HTML 不能作为窗口独立性、IPC 安全或任务不中断 PASS 证据。

非目标：不重写 Pi/模型/记忆/权限/备份业务，不引入新框架，不删除原设置能力，不改变全局左侧导航，不以模拟状态伪装真实保存。
