# SET-P0-CONTRACT · 子窗口最小权限 IPC / 所有权矩阵

> 此处是**需要现场补齐的契约模板**，不是现成 channel 名称清单。主进程绝不能单纯将 `settingsSender` 改为“main 或 settings 任意 sender 即放行所有接口”。

## 0. 角色

- desktop/main owner：BrowserWindow 管理、窗口身份、主窗蒙层事件、加载和退出。
- preload/contracts owner：独立 settings preload、输入输出类型、allowlist、负向测试。
- config owner：模型/密钥/ordinary config save/undo/history/设置保存语义与凭证保护。
- Pi owner：runId/任务不中断、会话授权、审批、能力、技能和工具接口边界。
- teacher-memory owner：长期/二级/历史记忆实际接口。
- backup owner：数据根、校验/恢复/外部副作用。
- UI owner：设置分组、搜索、焦点、样式与 Motion。

## 1. 必须从源码盘点的 UI 分类

| Tab ID | 现有子组件 | 敏感级别 | 新子窗允许能力 | 需 owner 签收 |
|---|---|---|---|---|
| models | PiModelSettings | SECRET | 查询脱敏配置/原受控写入/验证 | config |
| interface | WorkbenchPreferences + composer follow-up | PREF | 原偏好读写、回执、跨窗同步 | UI + config |
| teacher-memory | PiTeacherMemorySettings / PiL2MemorySettings / PiHistoryMemorySettings | PERSONAL | 仅原安全读写和操作确认 | memory |
| permissions | PiPermissionSettings / PiEnvironmentSettings / PiMemoryScope | HIGH RISK | 绑定有效 session 的权限视图/受控审批/工作目录选择 | Pi + config |
| backup | DataBackupPanel / WindowsUpdatePanel 等当前适用入口 | HIGH RISK | 原备份校验/恢复/更新，窗口身份与危险确认 | backup |
| archives | OfficeConversation 归档查看 | PERSONAL | 仅授权会话的归档列表/脱敏只读读取 | Pi + config |
| skills | PiSkillSettings | PRIVILEGED | 已核验技能管理与权限 | Pi/skills |
| capabilities | PiCapabilityCenter | PRIVILEGED | 原 registry/verification 与任务 scope | Pi/registry |
| tools | PiManagedTools / PiMcpSettings | PRIVILEGED | 经权限验证的工具/MCP 管理 | Pi/tools |
| diagnostics | PiResolvedAgentConfig / PiDecisionHistory / PiCandidateHistory / PiDiagnostics | SENSITIVE | 只读脱敏诊断/有权限操作 | Pi |

**具体 channel 名、版本、输入 schema、返回/错误和是否支持设置窗独立调用由执行 AI 在 Phase 0 逐条核验填入 `templates/SETTINGS_IPC_AUDIT.csv`，本文件不编造。**

## 2. 强制反例

- 不受信任 BrowserWindow / 新开的 iframe / 非 mainFrame / 非设置窗口 webContents 无权调用敏感设置 API。
- 恶意 renderer 导航到外网/本地文件后不能复用原设置特权。
- 即便合法设置窗口，也不允许调用与该窗口类别无关的“运行任意命令”“文件全盘读取”“绕过教师审批”等 API。
- 不能在 renderer 使用裸 fs、child_process、nodeIntegration、完整 `window.omniEdu` 高权限副本。
- 非法/过时的 sessionId、过期修订号、失效授权必须返回显式错误，不能 silent success。
- 凭证不在日志、URL、状态广播、截图或窗口标题泄露。

## 3. 配置状态真源

沿现有真实版本化设置接口（静态检查到 `getXiaozhiSettings`、`commitXiaozhiConfig`、`getXiaozhiConfigHistory`、`undoXiaozhiConfig`、`stageXiaozhiCredential`、`saveXiaozhiSettings`、`verifyXiaozhiCredential` 等当前 preload 方法）选取适用的**原始**宿主路径，不重新发明第二套配置服务。实际可用性、输入类型、权限以最新源码核验为准。

## 4. 保存证据

成功操作必须有配置版本/revision/receipt + 独立读取结果；失败保留编辑状态；跨窗读取显示同一个值；并发变化需要 conflict 或刷新判断。敏感操作只在隔离数据副本验收。
