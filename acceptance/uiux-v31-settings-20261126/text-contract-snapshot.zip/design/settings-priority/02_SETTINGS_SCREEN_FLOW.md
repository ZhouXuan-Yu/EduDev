# SET-P0-FLOW · 独立设置窗口完整状态机

## 一、主进程状态（建议，不假设现有代码已实现）

`CLOSED → CREATING → READY → VISIBLE_FOCUSED ↔ VISIBLE_UNFOCUSED → CLOSING → CLOSED`。
此外：`CREATE_FAILED / LOAD_FAILED / MINIMIZED / APP_QUITTING`。所有状态变化必须幂等，窗口关闭事件只清理该窗口；重复启动/关闭不能竞态产生双实例。

| 事件 | 条件 | 预期 | 错误恢复 |
|---|---|---|---|
| 左栏/菜单/对话打开设置 | CLOSED | 创建一次 top-level BrowserWindow，准备就绪后显示 | 失败清理引用、主窗提示重试 |
| 重复打开 | VISIBLE/CREATING | 复用已有窗口，已就绪则 focus；creating 则等待同一次创建 | 不创建第二实例 |
| 从主窗切回设置 | settings ready | 设置获得焦点、保留分类/输入 | 原会话 scope 变化时刷新提示 |
| 点击主窗 | settings visible | 主窗获得焦点、蒙层解除、可操作 | 不阻塞 pointer |
| 关闭设置 | saving false | 关闭子窗，订阅清理，主任务继续 | 不终止 Pi |
| 关闭设置 | 未保存/进行中 | 按原配置保存协议保护或明确取消/等待（真实失败可恢复） | 不悄悄放弃编辑 |
| 主窗最小化 | settings visible | 系统默认切窗逻辑，设置仍是可用独立窗 | 不强制 always-on-top |
| App quit | any | 主进程统一清理，按既有 shutdown 等待持久任务结算 | 不遗留独立进程 |
| 显示器移除/DPI 改变 | any | 保证设置窗口在当前可用 workArea 内，布局重排 | 必需控件可达 |

## 二、主窗蒙层状态

`OVERLAY_OFF` 默认；设置窗口实际获得焦点且主窗未聚焦时切 `OVERLAY_ON`；主窗 focus、设置 minimize/close/hidden 时切 OFF。无论 ON/OFF 装饰层都不截获鼠标/键盘。系统减少动效时切换不播放空间动画；负载高时不加 blur。

## 三、保存与更新状态

`IDLE → DIRTY → SAVING → SAVED_VERIFIED / SAVE_FAILED / CONFLICT`。部分设置原本即时保存，则 UI 如实表达即时回执，不能强制统一“保存”按钮。失败保留表单值。跨窗变更以主进程最新版本/readback 为准，旧响应丢弃。

## 四、会话级设置状态

`NO_SESSION / BOUND(sessionId,version) / SESSION_CHANGED / REVOKED / STALE`。会话来源必须受主进程验证；不能从设置窗本地 preference 推断用户当前授权目录。会话变更时先提示作用对象并让旧请求失效，不隐式写到新会话。

## 五、可访问性

设置分类键盘可达，Tab/Shift+Tab/Enter/Space/Esc 正确，切换分类聚焦目标标题/控件，关闭后的焦点由 OS/应用协调返回。IME 组词期间快捷键不提交。屏幕阅读器能识别设置类别、开关状态和保存状态。
