# V3.1 最新代码观察补充 · OBSERVED_REMOTE / TO_VERIFY

- 最新可读取 GitHub `main`: `f420db00e4c124a1320aab57c82e65017ee89297`（2026-11-26）；此次提交涉及 `apps/desktop/src/main/index.ts`、`apps/desktop/src/renderer/App.tsx`，旧 V3 静态结论不可自动继承。
- `App.tsx` 仍用 settings activeView 路由和 `<PiSettingsWorkspace>` 渲染；`desktop:command` 中 `settings` 仍切 activeView。
- `main/index.ts` 主窗口 createWindow + `settingsSender` 限主 webContents/mainFrame，尚未在静态检查中看到独立设置 BrowserWindow manager；执行需最新源码二次搜索验证。
- `preload/index.ts` 的 `window.omniEdu` 是很大的 facade，不能全量暴露给设置窗。
- `PiSettingsWorkspace` 当前 10 分类、TeacherMemory 含 `PiHistoryMemorySettings`；有 `useWorkbenchPreferences`/`EduShell`/本地会话偏好等主 renderer 依赖，不能直接把组件复制到第二 renderer，必须复用真正配置服务并补上下文与订阅/保存。
- 最新设置 `commitXiaozhiConfig / getXiaozhiConfigHistory / undoXiaozhiConfig / stageXiaozhiCredential` 等接口需主进程 owner 按权限和版本核验；不得模拟保存。
- 新增设置高风险事项/接口审计：`design/settings-priority/03_SETTINGS_API_AND_OWNERSHIP_MATRIX.md`；执行 Phase 0 重新核实本地 WIP、owner、API 与 CI。

其余历史映射和 WIP 保护规则继续生效。以下旧基线段只作为 2026-11-26 较早时刻的历史观察。

# 02 最新源码基线、已有实现与 WIP 接续要求

## 1. 远程 main 只读观察

- 仓库：`ZhouXuan-Yu/EduDev`
- 较早时刻核验的历史远程 `main`（V3 原记录）：`d9a87bf2042ffbbd4627cd85e776bd734bd8fe31`，不作为当前最新。
- 该历史提交 diff 只涉及：
  - `apps/desktop/scripts/education/history-memory-r1-state.mjs`
  - `apps/desktop/src/main/xiaozhi-agent/history/memory.ts`
- UI 源码在前一观察 `9b192954e3d64e7d00fe15382a2db34f8351d0cc` 已核对，因当时核对的 main 只改变上述 memory 文件，UI 路径未在最新提交中变化。**执行时仍必须重新获取 origin/main 和本地 worktree，不得将静态 SHA 当执行基线。**
- 方案生成阶段没有本地仓库访问、运行 Electron、运行构建或测试。当前本机 worktree、未提交改动、其他 AI 负责人、当前运行构建身份全部 `TO_VERIFY`。

## 2. 已观察的页面与组件映射

| 功能 | 已观察入口/文件 | 真实能力线索与实施边界 |
|---|---|---|
| 应用外壳/路由 | `apps/desktop/src/renderer/App.tsx`、`components/desktop/DesktopFrame.tsx` | 全局左侧导航、activeView、导航历史、守卫和桌面命令；不能直接重构 App 树或丢旧路由 |
| 问小智 | `components/office/PiEducationWorkspace.tsx` | Pi 会话、runId 事件、任务恢复、待办、附件、模型状态、工作台入口 |
| Composer | `OfficeComposer`、`PiComposerPendingPanel` 及相关组件 | 受保护；不复制/替换，不改变 IME、草稿、发送、队列、停止和审批 |
| 我的任务 | `components/product/TeachingTaskWorkspace.tsx`、`components/office/workbench/PiRecoveryOverview.tsx`、`TaskOverviewCard.tsx`、`PiApprovalInbox.tsx` | 任务/审批真实查询；`PiRecoveryOverview` 使用 `limit:20`、cursor、状态过滤和全部/当前会话范围；任务卡有真实下一步、详情和成果关联 |
| 任务 query contract | `apps/desktop/src/shared/xiaozhi-workbench.ts` | task query 静态观察包含 filter/sessionId/cursor/limit/taskId，没有 text query 字段。全库搜索需新增版本化合同和真实服务端/SQLite 查询，不能在已加载 20 条上本地过滤冒充全量搜索 |
| 任务恢复 | `PiRecoveryOverview.tsx`、`PiEducationWorkspace.tsx` | 恢复需核对 taskId/sessionId/revision/requirementsVersion、原审批和未知副作用；个人任务列表当前未传 `onRestore`，不可在视觉改造中擅自增加绕过校验的直接恢复 |
| 对话历史 | `components/office/PiEducationWorkspace.tsx`、`components/AiConversationSidebar.tsx` | 有会话文件夹、搜索、重命名、归档、最近对话；任务页不再复制历史对话列 |
| 资料库 | `components/product/MaterialsWorkspace.tsx` | `listMaterialCatalog(query, offset, scope)`；资料/正文检索、目录/标签/格式/状态、刷新、分页、导入、后台任务、草稿 guard |
| 资料目录/详情 | `material-library-ui/MaterialLibraryLayout.tsx`、`MaterialLibraryCatalog.tsx`、`MaterialLibraryActivity.tsx`、`MaterialBodyPanel.tsx`、`MaterialCatalogFilters.tsx`、`MaterialLibraryNavigation.tsx` | 内部目录/标签和资料列表；选中资料才出现详情；原页/正文/题目校正/阅读笔记/元数据和队列需保留 |
| 资料批次 | `MaterialImportPanel.tsx`、`MaterialLibraryActivity.tsx` | 文件夹批次、暂停/继续/选择/重试，应用重启后恢复；不伪造导入完成 |
| 资料 query contract | `apps/desktop/src/shared/material-catalog.ts` | query+offset+scope（目录/标签/格式/状态），facets 从全库提供；正文查询与目录查询分离 |
| 教学文件 | `components/product/TeachingArtifactsWorkspace.tsx` | `files/deliveries/classrooms/mockExams` 子视图；真实文件列表、预览、版本、来源、回对话 |
| 教学页内导航 | `components/product/WorkbenchPageNavigation.tsx`、`WorkbenchHub.tsx` | 教学页：artifacts/notebook/book/question_notebook/paper；学生页：students/search/intake/mistakes/mastery/review/analytics |
| 备课本 | `components/TeacherNotebookWorkspace.tsx` | 备课本/记录、创建编辑保存、归档/恢复、刷新 |
| 讲义 | `components/TeachingBookWorkspace.tsx` | 章节/页面/内容块、保存、版本锁、未保存保护 |
| 题本 | `components/QuestionNotebookWorkspace.tsx` | 本地题目、筛选、收藏、分类、来源、题目编辑和题篮返回 |
| 组卷 | `components/PaperBlueprintWorkspace.tsx` | 蓝图、来源上下文、草稿恢复、阶段（blueprint/review/delivery）、确认和真实导出；沿用 D14 组卷 V3 业务合同 |
| 学生工作台 | `components/product/StudentWorkbench.tsx` | 先选择学生；同一 studentId 切换档案/记录等；selection preference 不等于业务数据真源 |
| 学生档案 | `components/StudentProfileLifecycle.tsx` | 保存、打开本地目录、导出档案、归档及确认 |
| 学生搜索 | `components/GlobalSearchWorkspace.tsx` | 本地 SQLite 学生和学习记录搜索 |
| 错题 | `components/MistakesWorkspace.tsx` | 原图、OCR、校正、错因/相似/变式来源，教师确认 |
| 学习计划 | `components/MasteryPathWorkspace.tsx` | 读取教师确认的本地学习路径；不自动推断掌握度 |
| 学习复盘 | `components/ReviewReportWorkspace.tsx` | 复盘条件、SQLite 草稿、证据记录、编辑和保存 |
| 设置 | `components/office/PiSettingsWorkspace.tsx`、`SettingsNavigation.tsx` | 已有 10 类设置：models/skills/capabilities/tools/permissions/teacher-memory/interface/archives/backup/diagnostics；日常/高级分层已有实现 |
| 设置主进程 | `apps/desktop/src/main/index.ts`、`src/preload/index.ts` | 静态观察存在 `settingsSender` 限制主窗口 webContents/mainFrame；独立设置窗需要最小 allowlist 和受控 preload，不能放宽所有 IPC |
| 页面合同 | `apps/desktop/src/renderer/ui-system/page-contracts.ts` | 18 个已接受页面元数据；只提供页面描述，不提供业务数据/IPC 权限 |
| 项目设计规范 | `.agents/skills/edudev-design/SKILL.md`、`references/decisions.md`、`visual-system.md`、`page-contracts.md`、`interaction-contracts.md`、`verification.md` | 当前 Skill 仍记录 UI-FINAL-2026-11-03；最新用户决定必须以追加决策方式升级，不删历史 |

## 3. 已知问题/待核验

| 项目 | 当前事实 | 执行动作 |
|---|---|---|
| 设置窗口 | 仍作为主 renderer 页面渲染 `PiSettingsWorkspace` | 真实核验并实施独立非模态窗口 |
| 设置 IPC | 部分 IPC sender 绑定 mainWindow | 设计最小白名单、正反 sender 测试 |
| 任务全库搜索 | 当前 task query contract 无 query 字段 | 新增服务端/SQLite 搜索合同并验证全库；或如产品决策不允许扩展，停止展示全库搜索 UI 并记录 NEEDS_DECISION |
| 任务恢复 | my_tasks 页面当前不传 `onRestore` | 只显示“回到原对话”；原恢复路径在 Pi workbench 内核验 |
| 资料详情 | 选中资料后才渲染详情 | 保持默认关闭，优化按需打开/宽屏/窄屏表现 |
| 教学文件 | 文件、整包、课堂、模考已是同一 workspace 子视图 | 不新增独立路由或重复业务 |
| 页面样板 | P04–P18/X01–X05 为合成提案 | 不把图中虚构控件当功能合同 |

## 4. 必须重新核验的本地事实

- `git worktree list --porcelain`、`git status --short --branch`、`git branch -avv`、`git remote -v`、当前 `origin/main` SHA。
- 所有 UI/配置/记忆/数据库并行 AI 的 branch、commit、dirty paths、owner 和可写目录。
- 实际运行目录、启动命令、Electron 进程、main/preload/renderer 构建身份。
- `package-lock.json` / lockfile 实装版本、HeroUI OSS/Pro 来源和实际 CSS 导入顺序。
- 当前 CI workflow、package scripts、相关失败基线。
- 当前 36 项 UI-FINAL 是否有有效正式验收报告；没有证据不能假定通过。
- 现有 UI R1/其他专项任务是否仍有活跃 WIP；不要覆盖。

## 5. 当前项目可见的测试命令（从 package.json 静态观察）

以下命令曾在 `apps/desktop/package.json` 中出现；Phase 0 必须重新确认仍存在、脚本内容和适用性，不能把命令列出视为已运行：
- `npm run build`
- `npm run test:renderer-components`
- `npm run test:ui-contracts`
- `npm run test:ui-review`
- `npm run test:workbench-ui`
- `npm run test:sidebar-navigation`
- `npm run test:daily-entry`
- `npm run test:education-capabilities`
- `npm run test:education-journeys`
- `npm run test:ui-style-isolation`
- `npm run test:xiaozhi-pi-ui`
- `npm run test:xiaozhi-pi-attachment-entry`
- `npm run test:xiaozhi-pi-composer-send`
- `npm run test:xiaozhi-pi-settings-workspace-ui`
- `npm run test:xiaozhi-pi-settings-local-job`
- `npm run test:xiaozhi-long-history`
- `npm run test:xiaozhi-task-browser-admission`
- `npm run test:xiaozhi-narrow-interface`
- `npm run test:xiaozhi-dpi-interface`
- `npm run test:smoke`

这些命令不是要求无差别全部运行；按变更风险与 AC 适用性执行，所有必需 AC 仍须有可执行验证。未发现/未核验的 lint 命令不得编造。

## 6. 状态标签

本文件中的远程代码观察为 `OBSERVED_REMOTE`，不代表本地/运行已验证。所有未实测项目为 `TO_VERIFY`。不得把原型截图、静态文件、GitHub 源码文本当成真实 Electron/数据库/文件验证。
