# V3.1 先行验收状态

- 旧 AC-001..074 + 新 AC-075..090，共 **90 项全部 NOT_RUN**（本包生成阶段）。
- 设置专项 SET-P0 = NOT_RUN，独立 Electron 主/设置双窗口测试尚未执行。
- 本报告中的 AC-075..090 已插入 V3 原矩阵；任何旧“74 NOT_RUN”是历史模板的过期汇总，执行时必须汇总 90 项。

# 14 模块验收报告（执行前模板）

> 06_ATDD_ACCEPTANCE.md 是唯一验收标准。本报告只记录实际结果，不改写预期。初始所有项 NOT_RUN。

## 运行身份
- 执行者/日期：NOT_RUN
- repo/worktree/branch/HEAD/origin-main：NOT_RUN
- Electron/main/preload/renderer build fingerprint：NOT_RUN
- Windows/CPU/GPU/内存/屏幕刷新率/DPI/缩放：NOT_RUN
- 测试 profile/SQLite 副本/文件目录/凭证范围：NOT_RUN

## V3 AC 矩阵
| AC-ID | 状态 | 实际结果 | 命令/操作 | 证据路径 | 源码 SHA / 构建指纹 | 缺陷/复测 |
|---|---|---|---|---|---|---|
| AC-001 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-002 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-003 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-004 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-005 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-006 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-007 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-008 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-009 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-010 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-011 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-012 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-013 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-014 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-015 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-016 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-017 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-018 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-019 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-020 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-021 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-022 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-023 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-024 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-025 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-026 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-027 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-028 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-029 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-030 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-031 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-032 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-033 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-034 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-035 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-036 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-037 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-038 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-039 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-040 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-041 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-042 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-043 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-044 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-045 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-046 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-047 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-048 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-049 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-050 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-051 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-052 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-053 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-054 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-055 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-056 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-057 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-058 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-059 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-060 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-061 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-062 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-063 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-064 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-065 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-066 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-067 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-068 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-069 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-070 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-071 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-072 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-073 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-074 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |

| AC-075 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-076 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-077 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-078 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-079 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-080 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-081 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-082 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-083 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-084 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-085 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-086 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-087 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-088 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-089 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |
| AC-090 | NOT_RUN | 未执行 | 待执行 | 待执行 | 待执行 | - |

## UI-FINAL 36 项旧回归矩阵
| LG-ID | 合并前子条件状态 | 合并后子条件状态 | 对应 V3 AC | 证据 |
|---|---|---|---|---|
| LG-A01 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A02 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A03 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A04 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A05 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A06 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A07 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A08 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A09 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A10 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A11 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A12 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A13 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A14 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A15 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A16 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A17 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A18 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A19 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A20 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A21 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A22 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A23 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A24 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A25 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A26 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A27 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A28 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A29 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A30 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A31 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A32 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A33 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A34 | NOT_RUN | N/A（无独立 post-merge 子条件） | 见 legacy/LEGACY_GATE_MAPPING.md | 待执行 |
| LG-A35 | NOT_RUN（候选 diff/owner/权限/冲突/非强推） | NOT_RUN（远端 main 包含交付提交，FG-01） | MG-01 / FG-01 | 待执行 |
| LG-A36 | NOT_RUN（集成候选窗口/构建身份） | NOT_RUN（最终 main 窗口/最终报告，FG-01/02） | MG-01 / FG-01 / FG-02 | 待执行 |

## 独立审查与 AI 评测
- 独立审查：NOT_RUN
- Gemini：NOT_RUN / UNAVAILABLE（按 AC-072 如实记录）
- AI Evaluation：NOT_RUN / N/A（只有确认未改 AI 行为才允许 N/A）

## 功能缺失/缺陷闭环
| 缺陷 ID | 关联 REQ/AC | 复现与根因 | 修复 commit | 重测/回归证据 | 状态 |
|---|---|---|---|---|---|
| TO_FILL | | | | | OPEN |

## 完成判定
- V3 AC：0 PASS / 0 FAIL / 0 BLOCKED / 90 NOT_RUN（初始模板值，执行后更新）
- Legacy：0 PASS / 0 FAIL / 0 BLOCKED / 36 NOT_RUN（初始模板值；A35/A36 分别记录合并前/后子条件）
- MG-01：NOT_RUN
- FG-01：NOT_RUN
- FG-02：NOT_RUN
- 最终状态：NOT_RUN。任何必需项 FAIL/BLOCKED/NOT_RUN 都禁止合并和 DONE。
