# V3.1 设置专项新增高风险

- **P0 IPC 权限扩大：** 若新设置窗可调用任意文件/终端/Agent、伪造 sender 成功，则禁止合并，保留原设置路径并撤销本轮安全扩张。
- **P0 会话作用范围错绑：** 设置窗不可从自己 localStorage 猜当前 sessionId；主窗切换和过期授权必须使旧请求失败；错绑即 BLOCKED。
- **P0 备份/记忆/密钥写错真源：** 先验证主进程唯一事实源和版本/readback；失败保留数据/操作记录，不能通过 UI Toast 掩盖。
- **P1 跨屏/DPI 黑闪/蒙层残留：** 同机 Electron 测试；优先禁用可选 blur 和位移而非改成 modal。
- **P1 现有十类设置功能遗漏：** 不能因改独立窗只留下模型和界面两类；所有现有 tab 继续可达，owner 逐项签收。
- **回滚：** 在新窗口全量验收通过前保留旧设置路由兼容层；回退窗口集成不回退用户真实配置，不强推 main。

# 12 风险、异常处理与回滚

| 风险 | 级别 | 触发/表现 | 预防与验证 | 失败出口/回滚 |
|---|---|---|---|---|
| 设置子窗口 IPC 被拒 | P0 | 新窗口能显示但不能读写 | sender/mainFrame/allowlist 正反测试 | 保留旧设置页入口，BLOCKED；不放宽所有 IPC |
| 设置 IPC 过宽 | P0 | 未授权窗口可访问配置/文件 | capability allowlist、安全负例 | 立即停止集成，撤销权限扩张 |
| 主窗口任务被中断 | P0 | 开关设置导致 Pi stop/remount | runId/草稿/焦点 E2E | 回退窗口入口，保留主窗状态 |
| 任务搜索只搜当前页 | P0 | 大量任务结果遗漏 | query contract + 1000 条数据库测试 | 不展示全库搜索，标 BLOCKED/NEEDS_DECISION |
| 任务恢复越权/重放 | P0 | 未核验副作用被重放 | 原 task revision/approval/unknownEffect 守卫 | 关闭新增恢复入口，沿原对话路径 |
| 资料状态混淆 | P0 | 已保存被误显示为可检索/题目已核 | 状态源逐项映射 | 恢复真实状态语义 |
| 题目/试卷来源丢失 | P0 | AI 改编覆盖原题/确认未失效 | source lineage/revision/readback | 停止导出，恢复原快照 |
| 学生上下文串号 | P0 | 迟到请求覆盖新 studentId | request epoch/context tests | 阻断切换或恢复原对象 |
| 未保存草稿丢失 | P0 | 切页/关闭/重启丢输入 | draft guard/readback | 禁止危险切换，恢复草稿 |
| CSS 污染 HeroUI | P1 | 全局规则覆盖 vendor | CSSOM/specificity audit | 回退本轮样式增量 |
| Motion 抖动/掉帧 | P1 | 长列表/对话卡顿 | same-device before/after trace | 降级 blur/位移/装饰动画 |
| reduced-motion 失效 | P1 | 系统减少动效仍大量移动 | OS preference/Electron test | 禁用非必要空间动画 |
| 页面提案被误当确认 | P1 | 未批准布局被直接实现 | page approval matrix | 回退结构改造，保留安全 Token |
| WIP 覆盖 | P0 | 共享工作树/分支混写 | worktree/owner/dirty diff 审计 | 停止写入，保留现场 |
| main 前移/合并冲突 | P0 | 候选 SHA 过时 | 串行集成、候选重建 | MERGE_BLOCKED，重新验证 |
| 真实数据被用于测试 | P0 | 删除/覆盖教师数据 | 隔离 profile/副本/权限范围 | 停止测试，按数据恢复协议处理 |
| 测试假通过 | P0 | skip/mock/缩小范围 | G-01..G-06 和独立审查 | 取消 PASS，重跑完整合同 |

## 回滚原则

- 代码回滚：优先针对本模块提交做审查性 revert；不得 reset/clean/强推共享 main。
- 数据回滚：配置、SQLite、原始文件、导出和权限副作用分别恢复；代码 revert 不等于数据恢复。
- 设置窗口回退：保留旧设置页兼容入口，只有新窗口完全验收后才可移除旧路径。
- 任务/文件操作重试前先核验 receipt、ID、hash 和副作用；不能重复点击假设幂等。
- 运行中 Pi task 不因 UI 回滚/关闭设置而被自动停止；按原 runtime 状态处理。
