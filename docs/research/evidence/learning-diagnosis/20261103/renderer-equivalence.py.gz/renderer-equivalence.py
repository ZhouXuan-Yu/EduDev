from pathlib import Path
import re,json,os,hashlib
R=Path.cwd();a=R/'apps/desktop/out/renderer/assets';b=Path('D:/WorkProject/EduProject/apps/desktop/out/renderer/assets');h=lambda s:hashlib.sha256(s).hexdigest()
key=lambda p:re.sub(r'-[A-Za-z0-9_-]{8}(\.[^.]+)$',r'\1',p.name)
all_a={p.name:p for p in a.iterdir() if p.suffix in ['.js','.css']};all_b={p.name:p for p in b.iterdir() if p.suffix in ['.js','.css']};same=set(all_a)&set(all_b);pa={n:all_a[n] for n in same};pb={n:all_b[n] for n in same};left=[p for n,p in all_a.items() if n not in same];right=[p for n,p in all_b.items() if n not in same];extra_a={key(p):p for p in left};extra_b={key(p):p for p in right};assert len(extra_a)==len(left) and len(extra_b)==len(right) and set(extra_a)==set(extra_b);pa.update(extra_a);pb.update(extra_b)
files={pa[k].name:pb[k].name for k in pa};tokens={};reverse={};rx=re.compile(r'_[A-Za-z0-9_-]+_[a-z0-9]{5,8}_\d+')
for k in pa:
 x=pa[k].read_text(encoding='utf-8');y=pb[k].read_text(encoding='utf-8');xs=rx.findall(x);ys=rx.findall(y);assert len(xs)==len(ys),(k,'class count')
 for one,two in zip(xs,ys):
  assert one.rsplit('_',2)[0]==two.rsplit('_',2)[0],(k,one,two)
  assert tokens.get(one,two)==two and reverse.get(two,one)==one,(k,'class mapping conflict');tokens[one]=two;reverse[two]=one
# Only exact generated class tokens and corresponding build asset names may differ.
file_rx=re.compile('|'.join(map(re.escape,sorted(files,key=len,reverse=True))))
rows=[]
for k in pa:
 raw=pa[k].read_bytes();daily=pb[k].read_bytes();x=raw.decode('utf-8').replace('\r\n','\n');y=daily.decode('utf-8').replace('\r\n','\n');x=rx.sub(lambda m:tokens[m.group()],x);x=file_rx.sub(lambda m:files[m.group()],x);assert x==y,(k,'non-generated code differs')
 rows.append({'source':pa[k].name,'daily':pb[k].name,'sourceSha256':h(raw),'dailySha256':h(daily),'canonicalBothSha256':h(x.encode()),'bytesIdentical':raw==daily})
v={'ok':True,'method':'Every JS/CSS asset must match exactly after CRLF normalization and one-to-one consistent generated CSS module tokens / corresponding Vite hashed asset filenames substitution. No other code or CSS declaration is normalized. Source files are not edited.','files':rows,'filesCount':len(rows),'classTokens':len(tokens),'bytesIdentical':sum(x['bytesIdentical'] for x in rows)}
p=Path(os.environ['TEMP'])/'s05-diagnosis-renderer-equivalence-20261103.json';p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v[k] for k in ['ok','filesCount','classTokens','bytesIdentical']}))

