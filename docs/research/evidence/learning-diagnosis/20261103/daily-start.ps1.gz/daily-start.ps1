﻿Set-Location -LiteralPath 'D:\WorkProject\EduProject\apps\desktop'
npm start *> "$env:TEMP\s05-diagnosis-daily-start-20261103.log"
exit $LASTEXITCODE
