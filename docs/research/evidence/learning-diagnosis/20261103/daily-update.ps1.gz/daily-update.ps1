﻿$ErrorActionPreference='Stop'
$dailyRoot='D:\WorkProject\EduProject'
$rows=@(Get-CimInstance Win32_Process -Filter "Name='electron.exe'" | Where-Object {$_.CommandLine -eq 'D:\WorkProject\EduProject\apps\desktop\node_modules\electron\dist\electron.exe D:\WorkProject\EduProject\apps\desktop\out\main\index.js'})
if($rows.Count -ne 1){throw 'Expected exactly one owned daily main'}
$daily=Get-Process -Id $rows[0].ProcessId
$foreign=@(Get-Process -Name electron -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowHandle -ne 0 -and $_.Id -ne $daily.Id} | ForEach-Object {@{pid=$_.Id;hwnd=$_.MainWindowHandle.ToInt64();startUtc=$_.StartTime.ToUniversalTime().ToString('o')}})
$dirty=@('docs/integrations/ANATOMY.md','科普课件使用.md','docs/integrations/ANATOMY_用法与提示词规范.md') | ForEach-Object {@{path=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $dailyRoot $_)).Hash.ToLower()}}
$before=@{pid=$daily.Id;hwnd=$daily.MainWindowHandle.ToInt64();startUtc=$daily.StartTime.ToUniversalTime().ToString('o');foreign=$foreign;dirtyDocuments=$dirty;source=(git -C $dailyRoot rev-parse HEAD);main=(Get-Item "$dailyRoot\apps\desktop\out\main\index.js").Length}
$before | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$env:TEMP\s05-diagnosis-daily-before-20261103.json" -Encoding utf8
if(-not $daily.CloseMainWindow()){throw 'Normal close was not sent'}
$end=(Get-Date).AddSeconds(30)
while((Get-Process -Id $daily.Id -ErrorAction SilentlyContinue) -and (Get-Date) -lt $end){Start-Sleep -Milliseconds 200}
if(Get-Process -Id $daily.Id -ErrorAction SilentlyContinue){throw 'Daily remains alive; no force stop used'}
git -C $dailyRoot switch --detach 14805e638be604911c506cf4c87dffe5274280a5
if($LASTEXITCODE -ne 0){throw 'Detached checkout failed'}
foreach($item in $dirty){if((Get-FileHash -LiteralPath (Join-Path $dailyRoot $item.path)).Hash.ToLower() -ne $item.sha256){throw 'Foreign document changed'}}
foreach($item in $foreign){$p=Get-Process -Id $item.pid -ErrorAction Stop;if($p.MainWindowHandle.ToInt64() -ne $item.hwnd -or $p.StartTime.ToUniversalTime().Ticks -ne ([DateTime]$item.startUtc).ToUniversalTime().Ticks){throw 'Foreign window changed'}}
Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"$env:TEMP\s05-diagnosis-daily-start-20261103.ps1") -WindowStyle Hidden | Out-Null
@{closed=$before.pid;foreign=$foreign.Count;documents=$dirty.Count;source=(git -C $dailyRoot rev-parse HEAD)} | ConvertTo-Json -Compress
