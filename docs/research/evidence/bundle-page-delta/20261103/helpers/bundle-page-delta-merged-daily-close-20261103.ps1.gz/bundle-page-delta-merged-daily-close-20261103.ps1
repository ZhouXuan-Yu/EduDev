$ErrorActionPreference='Stop'
$dailyRoot='D:\WorkProject\EduProject'
if((git -C $dailyRoot rev-parse HEAD) -ne '421b4ffd53a1445ae1e78184627be0b0d5031d22'){throw 'Daily source changed'}
if((git -C $dailyRoot branch --show-current)){throw 'Daily attached branch; do not move it'}
$rows=@(Get-CimInstance Win32_Process -Filter "Name='electron.exe'"|Where-Object {$_.CommandLine -eq 'D:\WorkProject\EduProject\apps\desktop\node_modules\electron\dist\electron.exe D:\WorkProject\EduProject\apps\desktop\out\main\index.js'})
if($rows.Count -ne 1 -or $rows[0].ProcessId -ne 385428){throw 'Daily process changed'}
$daily=Get-Process -Id $rows[0].ProcessId
$dirty=@(git -C $dailyRoot -c core.quotepath=false ls-files -m -o --exclude-standard|ForEach-Object {if($_ -notmatch '\.md$'){throw 'Overlapping non-document change'};@{path=$_;sha256=(Get-FileHash -LiteralPath (Join-Path $dailyRoot $_)).Hash.ToLower()}})
$foreign=@(Get-Process -Name electron|Where-Object {$_.Id -ne $daily.Id -and $_.MainWindowHandle -ne 0}|ForEach-Object {@{pid=$_.Id;hwnd=$_.MainWindowHandle.ToInt64();startUtc=$_.StartTime.ToUniversalTime().ToString('o')}})
$files=Get-ChildItem -LiteralPath "$dailyRoot\apps\desktop\out" -Recurse -File
$record=@{source=(git -C $dailyRoot rev-parse HEAD);pid=$daily.Id;hwnd=$daily.MainWindowHandle.ToInt64();startUtc=$daily.StartTime.ToUniversalTime().ToString('o');foreign=$foreign;dirtyDocuments=$dirty;main=(Get-Item "$dailyRoot\apps\desktop\out\main\index.js").Length;mainSha=(Get-FileHash "$dailyRoot\apps\desktop\out\main\index.js").Hash.ToLower();preload=(Get-Item "$dailyRoot\apps\desktop\out\preload\index.cjs").Length;files=@{count=$files.Count;bytes=($files|Measure-Object Length -Sum).Sum}}
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$env:TEMP\bundle-page-delta-merged-daily-before-20261103.json" -Encoding utf8
if(-not $daily.CloseMainWindow()){throw 'Normal close failed'}
if(-not $daily.WaitForExit(15000)){throw 'Daily still running; no forced termination'}
@{normalClose=$record.pid;foreign=$foreign.Count;dirty=$dirty.Count}|ConvertTo-Json -Compress

