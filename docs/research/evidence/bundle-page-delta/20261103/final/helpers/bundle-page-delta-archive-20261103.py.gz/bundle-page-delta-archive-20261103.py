from pathlib import Path
import os,json,hashlib,gzip,csv,io,subprocess
repo=Path(r'C:\Users\ZhouXuan\.codex\worktrees\e147\EduProject');tmp=Path(os.environ['TEMP']);os.chdir(repo)
feature='421b4ffd53a1445ae1e78184627be0b0d5031d22';merged='e1c62305dc395c3c59f8f9628e94d91151eded5d'
folder=Path('docs/research/evidence/bundle-page-delta/20261103');folder.mkdir(parents=True,exist_ok=True)
manifest={'schemaVersion':1,'scope':'Scoped synthetic bundle/HTML/PPT outputs, original native transcript, screenshots and test/build/process metadata only. No teacher databases/profiles, credentials or executable builds.','files':[]}
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text('utf-8-sig'))
def archive(p,name):
 p=Path(p);raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=folder/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
 assert gzip.decompress(packed)==raw
 manifest['files'].append({'path':str(dest.relative_to(folder)).replace('\\','/'),'originalPath':str(p),'originalBytes':len(raw),'originalSha256':sha(raw),'compressedBytes':len(packed),'compressedSha256':sha(packed)})
formalRoot=tmp/'xiaozhi-load-change-ICTPDE';formal=load(formalRoot/'report.json');coldRoot=tmp/'bundle-page-delta-merged-cold-20261103';cold=load(coldRoot/'report.json')
daily=load(tmp/'bundle-page-delta-merged-daily-20261103.json');before=load(tmp/'bundle-page-delta-daily-before-20261103.json');initialDaily=load(tmp/'bundle-page-delta-daily-20261103.json')
assert formal['ok'] and len(formal['checks'])==3 and cold['ok'] and len(cold['checks'])==3
assert daily['source']==merged and daily['mainSha']==daily['sourceMainSha']==cold['mainHash']
for p in sorted(tmp.glob('bundle-page-delta-*.log')):archive(p,'logs/'+p.name)
for p in sorted(tmp.glob('bundle-page-delta-*.ps1')):archive(p,'helpers/'+p.name)
archive(tmp/'bundle-page-delta-merged-cold-20261103.mjs','helpers/merged-cold.mjs')
for p in sorted(tmp.glob('bundle-page-delta-*daily*.json')):archive(p,'daily/'+p.name)
for name in ['xiaozhi-bundle-lnEIwu','xiaozhi-bundle-3KGZZJ','xiaozhi-bundle-DzR7MV','xiaozhi-bundle-BFGaaE','xiaozhi-page-lifetime-PCE0Xt','xiaozhi-page-lifetime-OKDXyU','xiaozhi-page-lifetime-VicZAU','xiaozhi-page-lifetime-xzUNZY','xiaozhi-load-change-iiOt6u','xiaozhi-load-change-DoKlCH','xiaozhi-load-change-IvsNFy']:
 r=tmp/name
 for p in r.glob('report.json'):archive(p,'attempts/'+name+'/report.json')
 for p in r.glob('failure.png'):archive(p,'attempts/'+name+'/failure.png')
for p in formalRoot.glob('*'):
 if p.is_file() and p.suffix in ['.json','.png']:archive(p,'formal/'+p.name)
for p in formalRoot.rglob('*.jsonl'):archive(p,'formal/native/'+p.name)
for p in coldRoot.glob('*'):
 if p.is_file() and p.suffix in ['.json','.png']:archive(p,'merged-cold/'+p.name)
for record in formal['before']['files']+formal['after']['files']:
 p=Path(record['path']);assert sha(p.read_bytes())==record['sha256'];archive(p,'outputs/'+p.name)
for name in ['fx01-fixture.mjs','presentation-fixture.mjs']:archive(repo/'apps/desktop/scripts/xiaozhi-agent'/name,'fixture/'+name)
(folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sourceFiles=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',feature],text=True).splitlines()
source=load(tmp/'xiaozhi-bundle-lnEIwu/report.json');baseline=load(tmp/'xiaozhi-page-lifetime-PCE0Xt/report.json');lifetime=load(tmp/'xiaozhi-page-lifetime-OKDXyU/report.json')
assert source['ok'] and len(source['checks'])==12 and lifetime['ok'] and len(lifetime['checks'])==3
out=repo/'apps/desktop/out';outFiles=[p for p in out.rglob('*') if p.is_file()]
summary={
 'schemaVersion':1,'date':'2026-11-03','slice':'E03/S02/S04/S06 original bundle page-delta and changed-load synchronization; E07 bounded hidden-page lifetime',
 'status':'Engineering subitems implemented; full AT remains5/252, Goal active',
 'source':{'base':'895d9566bde8c18e96cd0426f9a6fd7c07fd9e23','feature':feature,'integratedMain':'79a5568','merged':merged,'formalReportBase':formal['source'],'formalPrecommitMainHash':formal['mainHash'],'finalMainHash':daily['mainSha'],'sourceFiles':{p:sha((repo/p).read_bytes()) for p in sourceFiles},'note':'Formal3 ran before feature commit with the exact feature build hash. Merged build/TSC/245 components and original saved-session readonly3 then passed; the three production feature files are byte-identical to421b4ff.'},
 'requirements':['REQ-E03-03','REQ-S02-08','REQ-S04-08','REQ-S06-05','REQ-E07-04','REQ-E07-05'],
 'result':{'before':'Single office_create_document accepted current-version presentationEdit but office_deliver_files inherited its schema and rejected the same edit. Hidden-window RAF may suspend, and destroying WebContents at timeout did not settle an unresolved callback.',
 'after':'Original bundle reuses preparePresentationEdit exact saved source/version/hash/page merge. Selected pages/fields only; unchanged edit carries original saved receipt after fresh disk check, without target/draft/version creation or renewed content-inspection claim. One original bundle review, original failure/cancel/resume boundaries. Hidden static page callback races host timeout/cancel; two-RAF refresh also has50ms fallback. No relaxed numeric/interaction/content checks.',
 'physics':'Synthetic10cm cube, densities600/1000kg/m3,g10:4N gives total10N,max10N,net0,neutral boundary;5N gives11N/10N/1N and downward force without bottom contact. PPT pages2/6 and page6 notes change; page2 notes and every other selected-field complement remain. HTML default/readout/diagram/reset agree at1366x768 and1920x1080. Default zero-load example and question count retained.',
 'data':'No new tables, shared protocol, IPC/preload, runtime, dependency or approval card. Original teacher bundle decision, draft lineage, native transcript, file checks and artifact versions reused.'},
 'tests':{'sourceBundle':12,'hiddenPageLifetime':3,'expectedFailureReproduction':1,'rendererComponents':245,'finalBuildTsc':True,'formalPiAndCold':3,'mergedOriginalReadonlyCold':3,'sourceDetails':source['checks'],'lifetime':lifetime,'baseline':baseline,'commands':['node scripts/xiaozhi-agent/delivery-bundle-smoke.mjs','node scripts/xiaozhi-agent/static-page-lifetime-electron.mjs --baseline (before production fix)','node scripts/xiaozhi-agent/static-page-lifetime-electron.mjs','npm run build','npm run test:renderer-components','node scripts/xiaozhi-agent/fx01-load-change-electron.mjs','node %TEMP%/bundle-page-delta-merged-cold-20261103.mjs (archived helper)','git diff --check'], 'notRepeated':'No unrelated207/import/full Office/WPS/frozen14 matrix. After merge only relevant build,245 components and zero-model original cold checks repeated.'},
 'formal':{'ok':True,'output':str(formalRoot),'durationMs':formal['durationMs'],'checks':formal['checks'],'errors':formal['errors'],'fixture':formal['fixture'],'before':formal['before'],'after':formal['after'],'inspections':formal['inspections'],'wire':formal['wire'],'boundary':formal['boundary']},
 'mergedCold':cold,'daily':daily,'initialDaily':initialDaily,
 'failedAttempts':[
 {'scope':'source smoke helper','result':'Static import loader timing, source capture kind assertion, correct rejection after source drift, fixture-expanded pagination and null-vs-undefined loop corrected. Exact owned pagination node48144 stopped. Final12passed, original logs/reports retained.'},
 {'scope':'formal helper and product','runs':[{'root':'xiaozhi-load-change-iiOt6u','result':'Missing required task plan, actual task_plan_required;1local response'},{'root':'xiaozhi-load-change-DoKlCH','result':'Task plan present; pending hidden inspection before review,90s outer timeout;2local responses'},{'root':'xiaozhi-load-change-IvsNFy','result':'Explicit engine and180s budget still stalled;2local responses'}],'result':'Did not treat longer waits as repair. Real isolated unresolved callback reproducer proves host lifetime defect, then corrected production race/RAF and final3passed.'},
 {'scope':'lifetime helper','result':'Initial bundled helper externalized @openmaic/dsl and failed to launch, then normal-value check omitted dataRoot argument. Helpers corrected without changing product contract; baseline reproduces and final3passed.'},
 {'scope':'merged readonly helper','result':'First helper treated stored relative session_file as absolute, failed before launch; resolved below owned data/xiaozhi-pi. Final readonly3passed, original failed log retained.'},
 {'scope':'daily verification','result':'Initial snapshot observed5other windows: four original long-lived windows unchanged; extra381528 ended before verification without any task command targeting it. Merged snapshot also includes collaborator temporary test window386932; its lifecycle separately recorded. Three dirty documents hashed unchanged. No force close or foreign process termination.'}],
 'requests':{'paid':0,'newSliceLocalSyntheticResponses':14,'formalSuccess':9,'failedFormalResponses':5,'mergedCold':0,'note':'Exact emitted fixture response records, not generic fetch attempt count. Prior20paid DeepSeek allowance exhausted. No teacher material uploaded.'},
 'performance':{'beforeDaily':{'main':before['main'],'files':before['files'],'preload':before['preload']},'featureSource':{'main':3770280,'files':455,'bytes':35220448,'preload':37712},'featureDaily':{'main':initialDaily['main'],'files':initialDaily['files'],'preload':initialDaily['preload']},'finalSource':{'main':(out/'main/index.js').stat().st_size,'files':len(outFiles),'bytes':sum(p.stat().st_size for p in outFiles),'preload':(out/'preload/index.cjs').stat().st_size},'finalDaily':{'main':daily['main'],'files':daily['files'],'preload':daily['preload']},'featureMainDelta':1893,'featureDailyOutputDelta':2111,'callbackReproductionMs':baseline['timeout']['elapsedMs'],'callbackSettlesMs':lifetime['timeout']['elapsedMs'],'formalWholeJourneyMs':formal['durationMs'],'boundary':'Single watchdog reproduction, not comparable P95 or general speed improvement. No per-token work added. Whole out bytes may differ with worktree copied vendor line endings; main and preload hashes checked; do not claim all455files byte-identical.'},
 'audit':{'reusedThisTurn':True,'dependenciesChanged':False,'existing':{'high':8,'moderate':26,'low':8,'critical':0,'exit':1},'evidence':'docs/research/AGENT_REPAIRED_RUN_S02_20261103.json#audit'},
 'unverified':['Complete FX01 default/4N/5N/6N and REVIEW matrix','Natural provider reasoning and independent teaching quality','Complete S04 alcohol/lecture and S06 all-material linked changes','S01 source/answer-book completeness and other S02 graph/conditions/multiple methods','Native Office/WPS/installer and physical drag/IME; LogonUI locked','P95,peak memory and full rollback rehearsal'],
 'rollback':'Revert feature421b4ff while retaining subsequent collaborator commits. No destructive schema/data migration. Preserve original/new files, artifact lineage, native transcript and teacher edits. A full rollback was not rehearsed.',
 'evidence':{'manifest':str(folder/'manifest.json').replace('\\','/'),'files':len(manifest['files']),'allOriginalAndCompressedHashesVerified':True}}
path=Path('docs/research/AGENT_BUNDLE_PAGE_DELTA_20261103.json');path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'evidence':str(path),'files':len(manifest['files']),'dailyPid':daily['pid'],'main':daily['main']},ensure_ascii=False))
