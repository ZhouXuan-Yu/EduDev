from pathlib import Path
import os,json,csv,io
repo=Path(r'C:\Users\ZhouXuan\.codex\worktrees\e147\EduProject');os.chdir(repo)
r=json.loads(Path('docs/research/AGENT_BUNDLE_PAGE_DELTA_20261103.json').read_text('utf-8'))
evidence='docs/research/AGENT_BUNDLE_PAGE_DELTA_20261103.json';manifest='docs/research/evidence/bundle-page-delta/20261103/manifest.json';feature=r['source']['feature'];merged=r['source']['merged'];daily=r['daily'];count=r['evidence']['files']
heading='## 2026-11-03 整包局部改页与4N→5N联动（工程子项已实现）'
product='原整包交付现复用单文件PPT的精确版本局部修改：只合并指定页字段，保留其他页、备注和旧文件；同值PPT携带原保存回执，不新建版本。原整包一次预览确认保持。实际4N→5N时，PPT第2/6页和第6页备注、HTML默认值/读数/图示/重置同步；其他页、无载荷例子和题量保留。'
architecture='office_deliver_files在创建子草稿前调用既有preparePresentationEdit，保留来源版本/hash、幂等、原BoundEffect/审批/取消/部分恢复。未变化文件做新鲜磁盘回读，不声称重新内容检查。withStaticOfficePage以宿主停止Promise结算悬挂回调；隐藏DOM两帧等待加50ms兜底，原数值/交互检查不放松。无新依赖、表、共享协议、IPC/preload、Runtime或审批卡。'
tests='源整包12、隐藏窗口正常/超时/取消3、245组件和最终build/TSC通过；原Pi对话→一次整包确认→真实8页PPT/HTML→局部更新→冷启3项通过。合入主线79a5568为e1c6230后，再做build/TSC、245组件及原文件双尺寸只读冷启3项，0模型/工具重放、0renderer错误。合成成功旅程9次响应，失败尝试另5次保留，合计14次本地合成响应，0新增付费。'
state='完整AT仍5/252、Goal active；REQ-E03-03/S02-08/S04-08/S06-05及相关E07-04/05仅工程部分实现。完整FX01/独立REVIEW、S04酒精及讲义、S06全部材料联动待集中验收，不将本轮受控两文件结果扩成整条通过。协作者续题原文修复及独立答案质量失败的事实保留。'
nextstep='下一继续S01/S02原题/答案依据、独立核验和条件/图形/多解讲解，再沿原S03及S/T依赖；本轮已通过的整包合并、修复汇总、版本/恢复不重复建设。原生Office/WPS、安装包、物理拖窗/IME未重验；LogonUI仍锁定。'
perf=f"仅本功能主包3768387→3770280B（+1893B）；日常455件out35216175→35218286B（+2111B），preload37712B不变。合入协作者后主包{daily['main']}B、{daily['files']['count']}件out{int(daily['files']['bytes'])}B；C/D main与preload hash相同，未宣称全部out逐字节相同。没有每token新增工作，P95/峰值未测。"
runtime=f"功能{feature[:7]}，整合{merged[:7]}。D:/WorkProject/EduProject以自身依赖npm start构建启动整合版本，正常关闭382716及385428，新PID{daily['pid']}/HWND{daily['hwnd']}可见且响应。原4长期窗口身份及3脏文档hash保持；额外临时协作者窗口生命周期单列在证据，未被本任务关闭。0教师消息。"
ref=f'证据：{evidence}；{manifest}（{count}件限定范围压缩原始证据，原始/压缩hash已核）。回退仅revert421b4ff，保留协作者提交、全部旧/新成果及native谱系；完整回退未演练。audit沿用本轮既有42（8高26中8低0严重、exit1），依赖未变。'
learning='销毁WebContents不保证executeJavaScript/打印Promise结束，宿主必须独立结算超时和取消；锁屏/隐藏页面也可能暂停requestAnimationFrame，不能仅加大外层测试等待。原80ms deadline在639ms外部看门狗时仍悬挂，修复后单例201ms结束；这不是P95或整体提速。源测试的加载器时机、来源kind、源变动时正确拒绝、fixture增长后的分页及undefined终点均已修正，保留失败日志。冷读脚本须把session_file解析到受控data/xiaozhi-pi，不能假定绝对路径。代码图检索等待无结果后终止只读查询，定点查看已知文件，不重索引或放松生产条件。'
fixtures='不修改冻结FX01及原默认答案。新fx01-load-change-electron.mjs复用原完整HTML/presentation fixture，派生主线载荷4/5；实际核对总力10/11N、最大浮力10N、未触底向下合力0/1N、图示位置130/170、双尺寸/重置，ZIP逐件核对只slides2/6与notes6变化。static-page-lifetime-electron.mjs用永不返回回调复现原悬挂，核对超时、取消、正常返回及所有权清理。'
def prepend(name,paras):
 p=Path(name);raw=p.read_bytes();assert heading.encode() not in raw,name
 newline=b'\r\n' if b'\r\n' in raw else b'\n';cut=raw.find(b'\n')+1
 section=('\n'+heading+'\n\n'+'\n\n'.join(paras)+'\n\n').encode('utf-8').replace(b'\n',newline)
 p.write_bytes(raw[:cut]+section+raw[cut:])
updates={
 '1.Agent.md':[architecture,'同值携带原文件不等于新内容检查通过；只按实际保存、源版本及新鲜readback陈述结果。本轮不新增工作规则。'],
 '2.Memory.md':[product,tests,runtime,state,nextstep,ref],
 '3.Learning.md':[learning,ref],
 '4.Wiki.md':[architecture,'工具入口与证据：'+evidence],
 'docs/goal/CURRENT_STATE.md':[product,tests,runtime,state,nextstep,ref],
 'docs/goal/CAPABILITY_MATRIX.md':[product,architecture,state,ref],
 'docs/goal/ACCEPTANCE.md':[tests,perf,state,ref],
 'docs/goal/DECISIONS.md':[architecture,'复用原精确版本编辑与整包集中确认，不另建Runtime/账本/审阅卡；没有新增付费请求授权。',ref],
 'docs/goal/WORK_PROGRESS.md':[product,tests,runtime,perf,state,nextstep,ref],
 'docs/goal/XIAOZHI_CODEX_GOAL.md':[product,state,nextstep,ref],
 'docs/goal/XIAOZHI_AGENT_DELIVERY_GOAL.md':[product,state,nextstep,ref],
 'docs/architecture/CURRENT.md':[architecture,ref],
 'docs/product/CURRENT.md':[product,state,nextstep,ref],
 'docs/acceptance/CURRENT.md':[tests,perf,state,ref],
 'docs/integrations/CURRENT.md':[architecture,runtime,ref],
 'docs/product/PRD-XIAOZHI-AGENT-DELIVERY.md':[product,state,ref],
 'docs/acceptance/XIAOZHI_AGENT_ACCEPTANCE.md':[tests,state,ref],
 'docs/acceptance/XIAOZHI_AGENT_FIXTURES.md':[fixtures,tests,state,ref],
 'docs/26_FRONTEND_E2E_COVERAGE_MATRIX.md':[product,tests,runtime,state,ref],
}
for name,paras in updates.items():prepend(name,paras)
# The frozen contract remains a historical preimplementation statement; append achieved result.
p=Path('docs/goal/AGENT_DELIVERY_IMPLEMENTATION.md');raw=p.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';cut=raw.find(b'\n')+1;section=('\n'+heading+'\n\n'+product+'\n\n'+tests+'\n\n'+state+'\n\n'+ref+'\n\n').encode().replace(b'\n',nl);p.write_bytes(raw[:cut]+section+raw[cut:])
p=Path('docs/acceptance/XIAOZHI_AGENT_TRACEABILITY.csv');raw=p.read_bytes();rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'),newline='')));fields=list(rows[0]);passed={x['需求ID'] for x in rows if x['验收状态']=='通过'};reqs=set(r['requirements']);changed=[]
addition='421b4ff整包精确版本局部编辑/同值携带，4N→5N两文件联动；源12、隐藏窗口3、原Pi及冷启3通过；整合e1c6230 build/TSC/245组件/原记录冷读3通过，0新付费。完整AT待集中验收'
for row in rows:
 if row['需求ID'] not in reqs:continue
 row['实施状态']='部分实现';row['验收状态']='待集中验收';row['实际结果']=(row['实际结果']+'；' if row['实际结果'] else '')+addition
 row['证据路径']=(row['证据路径']+'；' if row['证据路径'] else '')+evidence
 row['执行者']='Codex';row['执行时间']='2026-11-03';row['源码SHA']=feature+' / '+merged;row['运行根']='D:/WorkProject/EduProject（自身构建运行）；e147隔离合成正式旅程'
 row['样本revision/hash']=r['formal']['fixture']+' / main '+daily['mainSha'];row['备注']=(row['备注']+'；' if row['备注'] else '')+'工程子项已实现；仅所述两文件/生命周期范围，完整AT未通过且不计已实现'
 changed.append(row['需求ID'])
stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\r\n');writer.writeheader();writer.writerows(rows);encoded=stream.getvalue().encode('utf-8');p.write_bytes(encoded)
assert len(rows)==252 and len(changed)==6 and len(passed)==5 and {x['需求ID'] for x in rows if x['验收状态']=='通过'}==passed
assert encoded.count(b'\r\n')==253 and not encoded.startswith(b'\xef\xbb\xbf')
a=Path('docs/acceptance/XIAOZHI_AGENT_ACCEPTANCE.md').read_bytes();assert a.count(b'\r')-a.count(b'\r\n')==1,'Preserve historical bare CR'
print(json.dumps({'documents':len(updates)+1,'traceRows':len(rows),'changed':changed,'fullPassed':len(passed),'manifest':count},ensure_ascii=False))
