Set-Location -LiteralPath 'D:\WorkProject\EduProject\apps\desktop'
& npm.cmd start *> (Join-Path $env:TEMP 'bundle-page-delta-final-daily-start-20261103.log')
exit $LASTEXITCODE


