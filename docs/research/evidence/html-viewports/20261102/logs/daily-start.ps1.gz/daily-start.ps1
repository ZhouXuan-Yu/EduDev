Set-Location -LiteralPath 'D:\WorkProject\EduProject\apps\desktop'
& npm.cmd start *> (Join-Path $env:TEMP 'e06-html-viewports-daily-start-20261102.log')
exit $LASTEXITCODE
