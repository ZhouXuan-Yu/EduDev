﻿
$script:coverCharsRemaining=8192
function Find-PartialTextCover($slide,$textRect,$covers){
 $possible=@($covers | Where-Object { $_.z -gt $textRect.z -and $_.x -lt $textRect.x+$textRect.w -and $_.x+$_.w -gt $textRect.x -and $_.y -lt $textRect.y+$textRect.h -and $_.y+$_.h -gt $textRect.y })
 if(-not $possible.Count){return @{unchecked=$false}}
 $shape=$null;$range=$null;$character=$null;$unchecked=$false
 try {
  $shape=$slide.Shapes.Item([int]$textRect.index)
  if([int]$shape.Id -ne [int]$textRect.id){return @{unchecked=$true}}
  $range=$shape.TextFrame.TextRange;$text=[string]$range.Text
  # Native code-unit indexing is independently checked below. Complex script/cluster layout stays unchecked.
  if($text -match '[^\x09-\x0d\x20-\x7e\u3000-\u303f\u3400-\u9fff\uff00-\uffef]'){return @{unchecked=$true}}
  $scan=[Math]::Min($text.Length,4096);if($scan -lt $text.Length){$unchecked=$true}
  for($i=0;$i -lt $scan;$i++){
   if([char]::IsWhiteSpace($text[$i]) -or [char]::IsControl($text[$i])){continue}
   if($script:coverCharsRemaining -le 0 -or $script:coverPageRemaining -le 0){return @{unchecked=$true}}
   $script:coverCharsRemaining--;$script:coverPageRemaining--
   try {
    $character=$range.Characters($i+1,1)
    if([string]$character.Text -cne $text.Substring($i,1)){return @{unchecked=$true}}
    $x=[double]$character.BoundLeft;$y=[double]$character.BoundTop;$w=[double]$character.BoundWidth;$h=[double]$character.BoundHeight
    if([double]::IsNaN($x+$y+$w+$h) -or [double]::IsInfinity($x+$y+$w+$h) -or $w -le 0 -or $h -le 0){$unchecked=$true;continue}
    foreach($cover in $possible){
     if($cover.x -le $x -and $cover.y -le $y -and $cover.x+$cover.w -ge $x+$w -and $cover.y+$cover.h -ge $y+$h){
      return @{unchecked=$true;finding=@{code='rendered_text_partly_covered';page=[int]$slide.SlideIndex;object=[int]$textRect.id;cover=[int]$cover.id;character=$i+1}}
     }
     if($cover.x -lt $x+$w -and $cover.x+$cover.w -gt $x -and $cover.y -lt $y+$h -and $cover.y+$cover.h -gt $y){$unchecked=$true}
    }
   }finally{if($character -and [Runtime.InteropServices.Marshal]::IsComObject($character)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($character)};$character=$null}
  }
  return @{unchecked=$unchecked}
 }catch{return @{unchecked=$true}}
 finally{
  if($range -and [Runtime.InteropServices.Marshal]::IsComObject($range)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($range)}
  if($shape -and [Runtime.InteropServices.Marshal]::IsComObject($shape)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shape)}
 }
}

$script:calls=0;$script:mockText='A B';$script:wrong=$false;$script:invalid=$false;$script:broken=$false
$range=[pscustomobject]@{Text=$script:mockText}
$range | Add-Member ScriptMethod Characters {param($start,$length)
 $script:calls++;if($script:broken){throw 'native failure'}
 $x=($start-1)*10;if($script:invalid){$x=[double]::NaN}
 $value=$script:mockText.Substring($start-1,1);if($script:wrong){$value='wrong'}
 return [pscustomobject]@{Text=$value;BoundLeft=$x;BoundTop=0;BoundWidth=5;BoundHeight=10}
}
$shape=[pscustomobject]@{Id=4;TextFrame=[pscustomobject]@{TextRange=$range}}
$shapes=[pscustomobject]@{};$shapes | Add-Member ScriptMethod Item {param($index) return $script:testShape}
$script:testShape=$shape;$slide=[pscustomobject]@{SlideIndex=6;Shapes=$shapes}
$text=@{id=4;index=1;z=1;x=0;y=0;w=30;h=10}
$results=@();function Test-Cover($name,$cover,$page=512,$total=8192){
 $script:calls=0;$script:coverPageRemaining=$page;$script:coverCharsRemaining=$total
 $actual=Find-PartialTextCover $slide $text @($cover)
 return @{name=$name;actual=$actual;calls=$script:calls;pageRemaining=$script:coverPageRemaining;totalRemaining=$script:coverCharsRemaining}
}
$cover=@{id=9;z=2;x=20;y=0;w=5;h=10}
$results+=Test-Cover 'covered-visible-character' $cover
$results+=Test-Cover 'whitespace-gap' @{id=9;z=2;x=10;y=0;w=5;h=10}
$results+=Test-Cover 'behind-text' @{id=9;z=0;x=20;y=0;w=5;h=10}
$results+=Test-Cover 'no-overlap' @{id=9;z=2;x=40;y=0;w=5;h=10}
$results+=Test-Cover 'stroke-only' @{id=9;z=2;x=2;y=0;w=1;h=10}
$results+=Test-Cover 'page-exhausted' $cover 0
$results+=Test-Cover 'deck-exhausted' $cover 512 0
$results+=Test-Cover 'page-hard-bound' $cover 1
$results+=Test-Cover 'deck-hard-bound' $cover 512 1
$script:wrong=$true;$results+=Test-Cover 'index-mismatch' $cover;$script:wrong=$false
$script:invalid=$true;$results+=Test-Cover 'nonfinite-bounds' $cover;$script:invalid=$false
$script:broken=$true;$results+=Test-Cover 'native-exception' $cover;$script:broken=$false
$range.Text=[char]0x0627;$results+=Test-Cover 'complex-script' $cover;$range.Text=$script:mockText
$shape.Id=7;$results+=Test-Cover 'object-mismatch' $cover
ConvertTo-Json -InputObject $results -Depth 6 -Compress
