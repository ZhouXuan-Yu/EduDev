﻿
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
$application=$null;$presentation=$null;$job=$null;$owned=$false
$result=@{schemaVersion='xiaozhi.powerpoint-render.v1';ok=$false;error='unavailable'}

$glyphReady=$false;$glyphRemaining=32000
try{Add-Type -AssemblyName PresentationCore,WindowsBase;$glyphReady=$true}catch{}
function Find-MissingGlyphs([string]$text,[string]$font){
 if(-not $glyphReady -or $text.Length -gt $script:glyphRemaining){return @{unchecked=$true;points=@()}}
 $script:glyphRemaining-=$text.Length
 $drawing=$null;$context=$null
 try{
  $drawing=New-Object Windows.Media.DrawingGroup;$context=$drawing.Open()
  $typeface=New-Object Windows.Media.Typeface($font)
  $formatted=New-Object Windows.Media.FormattedText($text,[Globalization.CultureInfo]::GetCultureInfo('zh-CN'),[Windows.FlowDirection]::LeftToRight,$typeface,24,[Windows.Media.Brushes]::Black,1.0)
  $context.DrawText($formatted,(New-Object Windows.Point(0,0)));$context.Close();$context=$null
  $points=New-Object 'Collections.Generic.HashSet[string]'
  $pending=New-Object 'Collections.Generic.Stack[object]';$pending.Push($drawing)
  while($pending.Count){
   $node=$pending.Pop()
   if($node -is [Windows.Media.DrawingGroup]){foreach($child in $node.Children){$pending.Push($child)}}
   elseif($node -is [Windows.Media.GlyphRunDrawing]){
    $run=$node.GlyphRun;$characters=-join $run.Characters
    for($i=0;$i -lt $characters.Length;$i++){
     if([char]::IsLowSurrogate($characters[$i])){continue}
     $category=[Globalization.CharUnicodeInfo]::GetUnicodeCategory($characters,$i)
     if($category -in @('Control','Format','SpaceSeparator','LineSeparator','ParagraphSeparator')){continue}
     $point=[char]::ConvertToUtf32($characters,$i)
     if(($point -ge 0xFE00 -and $point -le 0xFE0F) -or ($point -ge 0xE0100 -and $point -le 0xE01EF)){continue}
     $cluster=if($run.ClusterMap.Count){[int]$run.ClusterMap[$i]}else{$i}
     if($cluster -lt $run.GlyphIndices.Count -and $run.GlyphIndices[$cluster] -eq 0){[void]$points.Add(('U+{0:X4}' -f $point));if($points.Count -ge 16){break}}
    }
   }
  }
  return @{unchecked=$false;points=@($points | Sort-Object)}
 }catch{return @{unchecked=$true;points=@()}}
 finally{if($context){$context.Close()}}
}


$script:coverCharsRemaining=8192
function Find-PartialTextCover($slide,$textRect,$covers){
 $possible=@($covers | Where-Object { $_.z -gt $textRect.z -and $_.x -lt $textRect.x+$textRect.w -and $_.x+$_.w -gt $textRect.x -and $_.y -lt $textRect.y+$textRect.h -and $_.y+$_.h -gt $textRect.y })
 if(-not $possible.Count){return @{unchecked=$false}}
 $shape=$null;$range=$null;$character=$null;$unchecked=$false
 try {
  $shape=$slide.Shapes.Item([int]$textRect.index)
  if([int]$shape.Id -ne [int]$textRect.id){return @{unchecked=$true}}
  $range=$shape.TextFrame.TextRange;$text=[string]$range.Text
  # Native code-unit indexing is independently checked below. Complex script/cluster layout stays unchecked.
  if($text -match '[^\x09-\x0d\x20-\x7e\u3000-\u303f\u3400-\u9fff\uff00-\uffef]'){return @{unchecked=$true}}
  $scan=[Math]::Min($text.Length,4096);if($scan -lt $text.Length){$unchecked=$true}
  for($i=0;$i -lt $scan;$i++){
   if([char]::IsWhiteSpace($text[$i]) -or [char]::IsControl($text[$i])){continue}
   if($script:coverCharsRemaining -le 0 -or $script:coverPageRemaining -le 0){return @{unchecked=$true}}
   $script:coverCharsRemaining--;$script:coverPageRemaining--
   try {
    $character=$range.Characters($i+1,1)
    if([string]$character.Text -cne $text.Substring($i,1)){return @{unchecked=$true}}
    $x=[double]$character.BoundLeft;$y=[double]$character.BoundTop;$w=[double]$character.BoundWidth;$h=[double]$character.BoundHeight
    if([double]::IsNaN($x+$y+$w+$h) -or [double]::IsInfinity($x+$y+$w+$h) -or $w -le 0 -or $h -le 0){$unchecked=$true;continue}
    foreach($cover in $possible){
     if($cover.x -le $x -and $cover.y -le $y -and $cover.x+$cover.w -ge $x+$w -and $cover.y+$cover.h -ge $y+$h){
      return @{unchecked=$true;finding=@{code='rendered_text_partly_covered';page=[int]$slide.SlideIndex;object=[int]$textRect.id;cover=[int]$cover.id;character=$i+1}}
     }
     if($cover.x -lt $x+$w -and $cover.x+$cover.w -gt $x -and $cover.y -lt $y+$h -and $cover.y+$cover.h -gt $y){$unchecked=$true}
    }
   }finally{if($character -and [Runtime.InteropServices.Marshal]::IsComObject($character)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($character)};$character=$null}
  }
  return @{unchecked=$unchecked}
 }catch{return @{unchecked=$true}}
 finally{
  if($range -and [Runtime.InteropServices.Marshal]::IsComObject($range)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($range)}
  if($shape -and [Runtime.InteropServices.Marshal]::IsComObject($shape)){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shape)}
 }
}

try {
 Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;using System.ComponentModel;
public sealed class XiaozhiRenderJob:IDisposable {
 [StructLayout(LayoutKind.Sequential)]struct Basic {public long PerProcess,PerJob;public uint Flags;public UIntPtr Min,Max;public uint Active;public UIntPtr Affinity;public uint Priority,Scheduling;}
 [StructLayout(LayoutKind.Sequential)]struct Io {public ulong R,W,O,RB,WB,OB;}
 [StructLayout(LayoutKind.Sequential)]struct Extended {public Basic Basic;public Io Io;public UIntPtr Process,Job,PeakProcess,PeakJob;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateJobObject(IntPtr attributes,string name);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetInformationJobObject(IntPtr job,int kind,IntPtr value,uint size);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
 [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint process);
 IntPtr handle;
 public XiaozhiRenderJob(IntPtr process){handle=CreateJobObject(IntPtr.Zero,null);if(handle==IntPtr.Zero)throw new Win32Exception();var value=new Extended();value.Basic.Flags=0x2000;var size=Marshal.SizeOf(value);var ptr=Marshal.AllocHGlobal(size);try{Marshal.StructureToPtr(value,ptr,false);if(!SetInformationJobObject(handle,9,ptr,(uint)size)||!AssignProcessToJobObject(handle,process)){Dispose();throw new Win32Exception();}}finally{Marshal.FreeHGlobal(ptr);}}
 public void Dispose(){if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;}}
}
'@
 $request=Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $env:XIAOZHI_RENDER_ROOT 'request.json') | ConvertFrom-Json
 $useWps=$request.officeEngine -eq 'wps' -or ($request.officeEngine -ne 'microsoft' -and -not [type]::GetTypeFromProgID('PowerPoint.Application'))
 $engineName='PowerPoint'
 if($useWps){
  $wpsProg='KWPP.Application';$wpsSwitch='wpp';$wpsCollection='Presentations'

 $beforeWps=@(Get-Process wps,wpp,et -ErrorAction SilentlyContinue | ForEach-Object {$_.Id})
 $start=[DateTime]::UtcNow
 $application=New-Object -ComObject $wpsProg
 [uint32]$officeId=0
 try{[void][XiaozhiRenderJob]::GetWindowThreadProcessId([IntPtr]([int64]$application.Hwnd),[ref]$officeId)}catch{}
 $identity='hwnd'
 if($officeId -eq 0){
  $servers=@(Get-CimInstance Win32_Process -Filter "Name='wps.exe'" | Where-Object {
   $_.CommandLine -match ('/prometheus /'+$wpsSwitch+' /Automation -Embedding') -and $_.CreationDate.ToUniversalTime() -ge $start.AddSeconds(-1) -and $beforeWps -notcontains $_.ProcessId
  })
  if($servers.Count -ne 1){throw 'busy'}
  $officeId=[uint32]$servers[0].ProcessId;$identity='registered-automation-start-time'
 }
 $server=Get-Process -Id $officeId
 if($beforeWps -contains [int]$officeId -or $server.StartTime.ToUniversalTime() -lt $start.AddSeconds(-1) -or $server.Path -notlike '*\WPS Office\*\office6\*' -or @('wps.exe',($wpsSwitch+'.exe')) -notcontains [IO.Path]::GetFileName($server.Path) -or [int]$application.($wpsCollection).Count -ne 0){throw 'busy'}
 $job=New-Object XiaozhiRenderJob($server.Handle);$owned=$true
 [IO.File]::WriteAllText((Join-Path $env:XIAOZHI_RENDER_ROOT 'owned.json'),(@{pid=[int]$officeId;start=$server.StartTime.ToUniversalTime().ToString('o');identity=$identity;engine=$wpsProg} | ConvertTo-Json -Compress))

  $engineName='WPS Presentation'
 }else{
 if(Get-Process POWERPNT -ErrorAction SilentlyContinue){throw 'busy'}
 $start=[DateTime]::UtcNow
 $application=New-Object -ComObject PowerPoint.Application
 [uint32]$officeId=0;[void][XiaozhiRenderJob]::GetWindowThreadProcessId([IntPtr]([int64]$application.HWND),[ref]$officeId)
 $server=Get-Process -Id $officeId
 if($server.ProcessName -ne 'POWERPNT' -or $server.StartTime.ToUniversalTime() -lt $start.AddSeconds(-1) -or $application.Presentations.Count -ne 0){throw 'busy'}
 $owned=$true;$job=New-Object XiaozhiRenderJob($server.Handle)
 [IO.File]::WriteAllText((Join-Path $env:XIAOZHI_RENDER_ROOT 'owned.json'),(@{pid=[int]$officeId;start=$server.StartTime.ToUniversalTime().ToString('o')} | ConvertTo-Json -Compress))
 }
 $application.AutomationSecurity=3;$application.DisplayAlerts=1
 $presentation=$application.Presentations.Open((Join-Path $env:XIAOZHI_RENDER_ROOT 'input.pptx'),-1,0,0)
 $pageCount=[int]$presentation.Slides.Count
 if($pageCount -ne [int]$request.pages -or $pageCount -lt 1 -or $pageCount -gt 64){throw 'page_count_changed'}
 $width=1600;$height=[int][Math]::Round($width*[double]$presentation.PageSetup.SlideHeight/[double]$presentation.PageSetup.SlideWidth)
 if($height -gt 1600){$height=1600;$width=[int][Math]::Round($height*[double]$presentation.PageSetup.SlideWidth/[double]$presentation.PageSetup.SlideHeight)}
 if($width -lt 16 -or $height -lt 16){throw 'unsupported'}
 $findings=New-Object 'Collections.Generic.List[object]'
 $fontSet=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 Add-Type -AssemblyName System.Drawing
 $collection=New-Object Drawing.Text.InstalledFontCollection
 foreach($family in $collection.Families){[void]$fontSet.Add($family.Name);foreach($language in @(1033,2052)){try{[void]$fontSet.Add($family.GetName($language))}catch{}}}
 foreach($font in @($request.fonts)){if($font -and -not $font.StartsWith('+') -and -not $fontSet.Contains($font)){if($findings.Count -lt 128){$findings.Add(@{code='font_missing';font=$font;page=0})}}}
 $collection.Dispose()
 $shapeCount=0;$renderBytes=0
 for($index=1;$index -le $pageCount;$index++){
  $slide=$presentation.Slides.Item($index)
  try {
   $textRects=New-Object 'Collections.Generic.List[object]';$covers=New-Object 'Collections.Generic.List[object]';$shapeIndex=0
   $script:coverPageRemaining=512
   $layoutPartial=$false;$glyphPartial=[bool]$request.embeddedFonts
   $animated=$true
   try{$animated=$slide.TimeLine.MainSequence.Count -gt 0 -or $slide.TimeLine.InteractiveSequences.Count -gt 0}catch{}
   foreach($shape in $slide.Shapes){
    $shapeIndex++
    $shapeCount++;if($shapeCount -gt 8192){throw 'too_large'}
    try {
     if($shape.HasTextFrame -eq -1 -and $shape.TextFrame.HasText -eq -1){
      $range=$shape.TextFrame.TextRange
      try {
       if(([double]$range.BoundTop -lt -1 -or [double]$range.BoundLeft -lt -1 -or [double]$range.BoundTop+[double]$range.BoundHeight -gt [double]$presentation.PageSetup.SlideHeight+1 -or [double]$range.BoundLeft+[double]$range.BoundWidth -gt [double]$presentation.PageSetup.SlideWidth+1) -and $findings.Count -lt 128){$findings.Add(@{code='rendered_text_outside';page=$index})}
       if([double]$shape.Rotation -eq 0 -and [double]$range.BoundHeight -gt [double]$shape.Height+2 -and $findings.Count -lt 128){$findings.Add(@{code='rendered_text_overflow';page=$index})}
       if($shape.Visible -eq -1 -and [double]$shape.Rotation -eq 0 -and [double]$range.BoundWidth -gt 0 -and [double]$range.BoundHeight -gt 0){
        if($textRects.Count -lt 256){$textRects.Add(@{id=[int]$shape.Id;index=$shapeIndex;z=[int]$shape.ZOrderPosition;x=[double]$range.BoundLeft;y=[double]$range.BoundTop;w=[double]$range.BoundWidth;h=[double]$range.BoundHeight})}else{$layoutPartial=$true}
       }else{$layoutPartial=$true}
       if($shape.Visible -eq -1){
        $font=[string]$range.Font.Name
        if($request.embeddedFonts -or -not $font -or $font.StartsWith('+')){$glyphPartial=$true}
        else{
         $coverage=Find-MissingGlyphs ([string]$range.Text) $font
         if($coverage.unchecked){$glyphPartial=$true}
         foreach($point in $coverage.points){if($findings.Count -lt 126){$findings.Add(@{code='system_glyph_missing';page=$index;object=[int]$shape.Id;point=$point})}else{$glyphPartial=$true}}
        }
       }
      }finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($range)}
     }
     if($shape.Type -eq 6 -or $shape.HasTable -eq -1){$layoutPartial=$true;$glyphPartial=$true}
     if($shape.Visible -eq -1 -and $shape.Type -eq 1 -and [double]$shape.Rotation -eq 0 -and $shape.AutoShapeType -eq 1){
      if($shape.Fill.Visible -eq -1 -and $shape.Fill.Type -eq 1 -and [double]$shape.Fill.Transparency -le 0.001){
       if($covers.Count -lt 256){$covers.Add(@{id=[int]$shape.Id;z=[int]$shape.ZOrderPosition;x=[double]$shape.Left;y=[double]$shape.Top;w=[double]$shape.Width;h=[double]$shape.Height})}else{$layoutPartial=$true}
      }
     }
    }finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shape)}
   }
   foreach($textRect in $textRects){$fullyCovered=$false;foreach($cover in $covers){
    if($cover.z -gt $textRect.z -and $cover.x -le $textRect.x -and $cover.y -le $textRect.y -and $cover.x+$cover.w -ge $textRect.x+$textRect.w -and $cover.y+$cover.h -ge $textRect.y+$textRect.h){
     $fullyCovered=$true
     if($animated){$layoutPartial=$true}else{if($findings.Count -lt 126){$findings.Add(@{code='rendered_text_covered';page=$index;object=$textRect.id;cover=$cover.id})}else{$layoutPartial=$true}}
     break
    }
   }
    if(-not $fullyCovered -and -not $animated){
     $partial=Find-PartialTextCover $slide $textRect $covers
     if($partial.unchecked){$layoutPartial=$true}
     if($partial.finding){if($findings.Count -lt 126){$findings.Add($partial.finding)}else{$layoutPartial=$true}}
    }
   }
   if(($layoutPartial -or $animated) -and $findings.Count -lt 128){$findings.Add(@{code='layer_coverage_partial';page=$index})}
   if($glyphPartial -and $findings.Count -lt 128){$findings.Add(@{code='glyph_coverage_partial';page=$index})}
   $output=Join-Path $env:XIAOZHI_RENDER_ROOT ('page-'+$index+'.png')
   $slide.Export($output,'PNG',$width,$height)
   $pageBytes=(Get-Item -LiteralPath $output).Length;$renderBytes+=$pageBytes
   if($pageBytes -gt 3145728 -or $renderBytes -gt 100663296){Remove-Item -LiteralPath $output;throw 'too_large'}
  }finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($slide)}
 }
 $result=@{schemaVersion='xiaozhi.powerpoint-render.v1';ok=$true;pages=$pageCount;width=$width;height=$height;engine=$engineName;version=[string]$application.Version;findings=@($findings.ToArray())}
}catch {
 $code=$_.Exception.Message
 if($code -notin @('busy','too_large','unsupported','page_count_changed')){$code='unavailable'}
 $result.error=$code
}finally {
 if($presentation){try{$presentation.Close()}catch{};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($presentation)}
 if($application){if($owned){try{if($application.Presentations.Count -eq 0){$application.Quit()}}catch{}};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($application)}
 if($job){$job.Dispose()}
}
[Console]::Out.WriteLine(($result | ConvertTo-Json -Depth 5 -Compress))
if(-not $result.ok){exit 1}
