﻿$ErrorActionPreference='Stop'
$dailyRoot='D:\WorkProject\EduProject'
$rows=@(Get-CimInstance Win32_Process -Filter "Name='electron.exe'"|Where-Object {$_.CommandLine -eq 'D:\WorkProject\EduProject\apps\desktop\node_modules\electron\dist\electron.exe D:\WorkProject\EduProject\apps\desktop\out\main\index.js'})
if($rows.Count -ne 1){throw 'Expected one exact daily main process'}
Add-Type 'using System;using System.Runtime.InteropServices;public class S02ScienceReviewVerify{[DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr h);[DllImport("user32.dll")]public static extern bool ShowWindowAsync(IntPtr h,int n);}'
$daily=Get-Process -Id $rows[0].ProcessId
if($daily.MainWindowHandle -eq 0){throw 'Daily native window missing'}
if(-not [S02ScienceReviewVerify]::IsWindowVisible($daily.MainWindowHandle)){$null=[S02ScienceReviewVerify]::ShowWindowAsync($daily.MainWindowHandle,5)}
if(-not $daily.Responding -or -not [S02ScienceReviewVerify]::IsWindowVisible($daily.MainWindowHandle)){throw 'Daily not visible/responding'}
$before=Get-Content -LiteralPath "$env:TEMP\s02-science-plan-daily-before-20261103.json" -Raw|ConvertFrom-Json
foreach($item in $before.foreign){$p=Get-Process -Id $item.pid;if($p.StartTime.ToUniversalTime().Ticks -ne ([DateTime]$item.startUtc).ToUniversalTime().Ticks -or $p.MainWindowHandle.ToInt64() -ne $item.hwnd){throw 'Foreign window changed'}}
foreach($item in $before.dirtyDocuments){if((Get-FileHash -LiteralPath (Join-Path $dailyRoot $item.path)).Hash.ToLower() -ne $item.sha256){throw 'Foreign document changed'}}
$files=Get-ChildItem -LiteralPath "$dailyRoot\apps\desktop\out" -Recurse -File
$record=@{source=(git -C $dailyRoot rev-parse HEAD);pid=$daily.Id;startUtc=$daily.StartTime.ToUniversalTime().ToString('o');hwnd=$daily.MainWindowHandle.ToInt64();responding=$daily.Responding;visible=$true;commandLine=$rows[0].CommandLine;closedNormally=$before.pid;foreign=$before.foreign;dirtyDocuments=$before.dirtyDocuments;main=(Get-Item "$dailyRoot\apps\desktop\out\main\index.js").Length;preload=(Get-Item "$dailyRoot\apps\desktop\out\preload\index.cjs").Length;mainSha=(Get-FileHash "$dailyRoot\apps\desktop\out\main\index.js").Hash.ToLower();sourceMainSha=(Get-FileHash 'C:\Users\ZhouXuan\.codex\worktrees\e147\EduProject\apps\desktop\out\main\index.js').Hash.ToLower();files=@{count=$files.Count;bytes=($files|Measure-Object Length -Sum).Sum};teacherMessagesSent=0;paidRequests=0;locked=[bool](Get-Process -Name LogonUI -ErrorAction SilentlyContinue)}
if($record.mainSha -ne $record.sourceMainSha){throw 'Source/daily main mismatch'}
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$env:TEMP\s02-science-plan-daily-20261103.json" -Encoding utf8
@{pid=$record.pid;hwnd=$record.hwnd;source=$record.source;main=$record.main;preload=$record.preload;files=$record.files;foreign=$record.foreign.Count;dirty=$record.dirtyDocuments.Count;locked=$record.locked}|ConvertTo-Json -Compress
