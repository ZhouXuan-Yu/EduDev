﻿Set-Location -LiteralPath 'D:\WorkProject\EduProject\apps\desktop'
& npm.cmd start *> (Join-Path $env:TEMP 's02-repair-summary-daily-start-20261103.log')
exit $LASTEXITCODE
