$ErrorActionPreference='Stop'
$base=(Resolve-Path 'test-results').Path
$install=Get-Content -LiteralPath (Join-Path $base 'c06-install-20261102.json') -Raw | ConvertFrom-Json
$target=[IO.Path]::GetFullPath($install.Target)
if(!$target.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Install target is outside owned test directory'}
$exe=Join-Path $target '小智.exe'
$live=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -eq $exe})
if($live.Count){throw 'Close owned test application before uninstall'}
$reports=@(Get-ChildItem (Join-Path $base 'xiaozhi-agent') -Directory -Filter 'pi-windows-installer-ui-*' | ForEach-Object { $p=Join-Path $_.FullName 'report.json';if(Test-Path $p){$r=Get-Content $p -Raw|ConvertFrom-Json;if($r.mode -eq 'installed' -and $r.success -and $r.installDir -eq $target){$r}}})
if($reports.Count -ne 1){throw 'Require exactly one passing installed startup report'}
$r=$reports[0]
$importRoot=Join-Path $base 'goal/kb-s0/packaged-1793552641506'
$kept=@((Join-Path $r.bootstrap.dataRoot 'app.db'),(Join-Path $importRoot 'data/app.db'),(Join-Path $importRoot '教师教案.md'),(Join-Path $importRoot '教师讲义.docx'),(Join-Path $importRoot '题目照片.png'),(Join-Path $importRoot '扫描题页.pdf'),(Join-Path $importRoot '长教材.txt'))
$before=@(foreach($f in $kept){[pscustomobject]@{Path=$f;Sha256=(Get-FileHash -LiteralPath $f).Hash}})
$uninstallers=@(Get-ChildItem -LiteralPath $target -File -Filter '*Uninstall*.exe')
if($uninstallers.Count -ne 1){throw 'Unexpected uninstaller set'}
$uninstaller=$uninstallers[0].FullName
if(!$uninstaller.StartsWith($target+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Uninstaller outside owned installation'}
$process=Start-Process -FilePath $uninstaller -ArgumentList '/S' -WindowStyle Hidden -Wait -PassThru
$deadline=(Get-Date).AddSeconds(50)
while(((Test-Path -LiteralPath $exe) -or (Test-Path -LiteralPath $uninstaller)) -and (Get-Date) -lt $deadline){Start-Sleep -Milliseconds 250}
$after=@(foreach($f in $before){[pscustomobject]@{Path=$f.Path;Exists=(Test-Path -LiteralPath $f.Path);Sha256=$(if(Test-Path -LiteralPath $f.Path){(Get-FileHash -LiteralPath $f.Path).Hash});Before=$f.Sha256}})
$shortcutAfter=@(foreach($s in $install.ShortcutsBefore){[pscustomobject]@{Path=$s.Path;Exists=(Test-Path -LiteralPath $s.Path);Sha256=$(if(Test-Path -LiteralPath $s.Path){(Get-FileHash -LiteralPath $s.Path).Hash});BeforeExists=$s.Exists;BeforeHash=$s.Hash}})
$remaining=@(Get-CimInstance Win32_Process | Where-Object {$_.ExecutablePath -eq $exe -or $_.ExecutablePath -eq $uninstaller} | Select-Object ProcessId,ExecutablePath)
$record=[ordered]@{Completed=(Get-Date).ToString('o');Uninstaller=$uninstaller;ParentExitCode=$process.ExitCode;Target=$target;ExecutableRemoved=!(Test-Path -LiteralPath $exe);UninstallerRemoved=!(Test-Path -LiteralPath $uninstaller);DataFiles=$after;ProfilePreserved=(Test-Path -LiteralPath $r.launch.userData);Shortcuts=$shortcutAfter;RemainingOwnedProcesses=$remaining;Boundary='NSIS may delegate self-removal to a child; final filesystem/process readback is authoritative. Only isolated synthetic profiles/data checked, not a whole clean machine or user-data recovery qualification'}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $base 'c06-uninstall-20261102.json') -Encoding utf8
if(!$record.ExecutableRemoved -or !$record.UninstallerRemoved -or $remaining.Count -or @($after|Where-Object {!$_.Exists -or $_.Sha256 -ne $_.Before}).Count -or @($shortcutAfter|Where-Object {$_.Exists -ne $_.BeforeExists -or $_.Sha256 -ne $_.BeforeHash}).Count){throw 'Uninstall/retention readback failed; preserve scene'}
$record | ConvertTo-Json -Depth 8

