$ErrorActionPreference='Stop'
$base=(Resolve-Path 'test-results').Path
$target=Join-Path $base 'c06-installed-20261102'
$installer=(Resolve-Path 'test-results/c06-nsis-20261102/Xiaozhi-Setup-0.1.0-x64.exe').Path
if(Test-Path -LiteralPath $target){throw 'Owned install target already exists'}
$roots=@('HKCU:/Software/Microsoft/Windows/CurrentVersion/Uninstall','HKLM:/Software/Microsoft/Windows/CurrentVersion/Uninstall','HKLM:/Software/WOW6432Node/Microsoft/Windows/CurrentVersion/Uninstall')
$prior=@(foreach($r in $roots){if(Test-Path $r){Get-ChildItem $r | ForEach-Object {$v=Get-ItemProperty $_.PSPath;if($v.DisplayName -match '小智|Omni.?Edu'){[pscustomobject]@{Key=$_.PSPath;DisplayName=$v.DisplayName;Location=$v.InstallLocation}}}}})
if($prior.Count){throw 'Prior installation exists; preserve it and do not install'}
$shortcuts=@(foreach($p in @((Join-Path ([Environment]::GetFolderPath('Desktop')) '小智.lnk'),(Join-Path ([Environment]::GetFolderPath('Programs')) '小智.lnk'))){[pscustomobject]@{Path=$p;Exists=(Test-Path -LiteralPath $p);Hash=$(if(Test-Path -LiteralPath $p){(Get-FileHash -LiteralPath $p).Hash})}})
$record=[ordered]@{Started=(Get-Date).ToString('o');Target=$target;Installer=$installer;InstallerSha256=(Get-FileHash -LiteralPath $installer).Hash;PriorRegistry=$prior;ShortcutsBefore=$shortcuts;Boundary='Current payload, per-user NSIS; test config disables shortcut creation; existing D source app and user data preserved'}
$process=Start-Process -FilePath $installer -ArgumentList @('/S',('/D='+$target)) -WindowStyle Hidden -Wait -PassThru
$record.ExitCode=$process.ExitCode
$record.Ended=(Get-Date).ToString('o')
$record.ExecutableExists=Test-Path -LiteralPath (Join-Path $target '小智.exe')
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $base 'c06-install-20261102.json') -Encoding utf8
if($process.ExitCode -ne 0 -or !$record.ExecutableExists){throw 'Installation failed; preserve evidence'}
$record | ConvertTo-Json -Depth 8
