﻿$ErrorActionPreference='Stop'
$dailyRoot='D:\WorkProject\EduProject'
$sourceRoot='C:\Users\ZhouXuan\.codex\worktrees\e147\EduProject'
$before=Get-Content -LiteralPath "$env:TEMP\s05-retest-daily-before-20261103.json" -Raw | ConvertFrom-Json
$rows=@(Get-CimInstance Win32_Process -Filter "Name='electron.exe'" | Where-Object {$_.CommandLine -eq 'D:\WorkProject\EduProject\apps\desktop\node_modules\electron\dist\electron.exe D:\WorkProject\EduProject\apps\desktop\out\main\index.js'})
if($rows.Count -ne 1){throw 'Expected one daily main'}
$daily=Get-Process -Id $rows[0].ProcessId
Add-Type 'using System;using System.Runtime.InteropServices;public class LearningRetestDaily{[DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr h);[DllImport("user32.dll")]public static extern bool ShowWindowAsync(IntPtr h,int n);}'
if($daily.MainWindowHandle -eq 0){throw 'Daily native window missing'}
if(-not [LearningRetestDaily]::IsWindowVisible($daily.MainWindowHandle)){$null=[LearningRetestDaily]::ShowWindowAsync($daily.MainWindowHandle,5)}
if(-not $daily.Responding -or -not [LearningRetestDaily]::IsWindowVisible($daily.MainWindowHandle)){throw 'Daily not visible/responding'}
foreach($item in $before.foreign){$p=Get-Process -Id $item.pid -ErrorAction Stop;if($p.MainWindowHandle.ToInt64() -ne $item.hwnd -or $p.StartTime.ToUniversalTime().Ticks -ne ([DateTime]$item.startUtc).ToUniversalTime().Ticks){throw 'Foreign window changed'}}
foreach($item in $before.dirtyDocuments){if((Get-FileHash -LiteralPath (Join-Path $dailyRoot $item.path)).Hash.ToLower() -ne $item.sha256){throw 'Foreign document changed'}}
$sourceOut=Join-Path $sourceRoot 'apps/desktop/out'
$dailyOut=Join-Path $dailyRoot 'apps/desktop/out'
$relative=@('main/index.js','preload/index.cjs','main/office-generator.js','main/buoyancy-demo.json')+@(Get-ChildItem -LiteralPath "$sourceOut/main" -File -Filter 'office-pdf-renderer-*.js' | ForEach-Object {'main/'+$_.Name})
$bundles=@()
foreach($file in $relative){$sourceFile=Join-Path $sourceOut $file;$dailyFile=Join-Path $dailyOut $file;$s=(Get-FileHash -LiteralPath $sourceFile).Hash.ToLower();$d=(Get-FileHash -LiteralPath $dailyFile).Hash.ToLower();if($s -ne $d){throw ('Runtime bundle mismatch: '+$file)};$bundles+=@{file=$file;bytes=(Get-Item -LiteralPath $dailyFile).Length;sourceSha256=$s;dailySha256=$d}}
$renderer=Get-ChildItem -LiteralPath (Join-Path $dailyOut 'renderer/assets') -Filter 'index-*.js' -File | Where-Object {(Get-Content -LiteralPath $_.FullName -Raw).Contains('training-unanswered-days')}
if(@($renderer).Count -ne 1){throw 'New diagnosis renderer missing'}
$equivalence=Get-Content -LiteralPath "$env:TEMP\s05-retest-renderer-equivalence-20261103.json" -Raw | ConvertFrom-Json
if(-not $equivalence.ok -or $equivalence.filesCount -ne 308){throw 'Renderer equivalence proof missing'}
foreach($asset in $equivalence.files){
 $sp=Join-Path (Join-Path $sourceOut 'renderer/assets') $asset.source
 $dp=Join-Path (Join-Path $dailyOut 'renderer/assets') $asset.daily
 if((Get-FileHash -LiteralPath $sp).Hash.ToLower() -ne $asset.sourceSha256 -or (Get-FileHash -LiteralPath $dp).Hash.ToLower() -ne $asset.dailySha256){throw 'Renderer changed after equivalence proof'}
}
$entry=@($equivalence.files | Where-Object {$_.daily -eq $renderer.Name})
if($entry.Count -ne 1){throw 'Diagnosis renderer proof missing'}
$bundles+=@{file=('renderer/assets/'+$renderer.Name);bytes=$renderer.Length;sourceSha256=$entry[0].sourceSha256;dailySha256=$entry[0].dailySha256;bytesIdentical=$entry[0].bytesIdentical;canonicalEquivalent=$true}
$files=Get-ChildItem -LiteralPath $dailyOut -File -Recurse
$record=@{source=(git -C $dailyRoot rev-parse HEAD);pid=$daily.Id;hwnd=$daily.MainWindowHandle.ToInt64();startUtc=$daily.StartTime.ToUniversalTime().ToString('o');visible=$true;responding=$daily.Responding;commandLine=$rows[0].CommandLine;closedNormally=$before.pid;foreign=$before.foreign;dirtyDocuments=$before.dirtyDocuments;bundles=$bundles;out=@{files=$files.Count;bytes=($files|Measure-Object Length -Sum).Sum};locked=[bool](Get-Process -Name LogonUI -ErrorAction SilentlyContinue);teacherMessagesSent=0;paidRequests=0;rendererEquivalence=@{files=$equivalence.filesCount;bytesIdentical=$equivalence.bytesIdentical;classTokens=$equivalence.classTokens;method=$equivalence.method}}
$record | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath "$env:TEMP\s05-retest-daily-20261103.json" -Encoding utf8
$record | ConvertTo-Json -Depth 10 -Compress
