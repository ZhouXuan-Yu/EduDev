import sys,json,zipfile,xml.etree.ElementTree as ET,fitz
with zipfile.ZipFile(sys.argv[1]) as z:
 r=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};text='\n'.join(n.text or '' for n in r.findall('.//w:t',ns));images=[n for n in z.namelist() if n.startswith('word/media/')];size=r.find('.//w:pgSz',ns).attrib
d=fitz.open(sys.argv[2]);pages=[]
for p in d:
 spans=[s for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['text'].strip()];pages.append({'size':[p.rect.width,p.rect.height],'text':p.get_text(),'bounds':[s['bbox'] for s in spans]})
print(json.dumps({'docxText':text,'images':images,'docxSize':size,'pages':pages},ensure_ascii=True))
