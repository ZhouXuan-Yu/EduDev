import sys,json,zipfile,xml.etree.ElementTree as E,fitz
r={}
for file in sys.argv[1:]:
 if file.endswith('.pptx'):
  with zipfile.ZipFile(file) as z:
   slides=[];notes=[]
   for i in range(1,9):
    slides.append([n.text or '' for n in E.fromstring(z.read(f'ppt/slides/slide{i}.xml')).iter() if n.tag.endswith('}t')]);notes.append([n.text or '' for n in E.fromstring(z.read(f'ppt/notesSlides/notesSlide{i}.xml')).iter() if n.tag.endswith('}t')])
   r[file]={'slides':slides,'notes':notes}
 elif file.endswith('.docx'):
  with zipfile.ZipFile(file) as z:r[file]={'text':' '.join(n.text or '' for n in E.fromstring(z.read('word/document.xml')).iter() if n.tag.endswith('}t'))}
 else:
  d=fitz.open(file);r[file]={'text':' '.join(p.get_text() for p in d),'sizes':[[p.rect.width,p.rect.height] for p in d]}
print(json.dumps(r,ensure_ascii=True))
