import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {_electron} from 'playwright';
import {productEntry} from '../../scripts/product-navigation.mjs';
import {openMaterialDisclosure} from '../../scripts/education/material-disclosure-ui.mjs';
const root='D:/WorkProject/EduProject-kb-run/flow-1gb-20261111';
const runtime=JSON.parse(fs.readFileSync(root+'/ai-quality-v3-runtime.json'));
const baseline=JSON.parse(fs.readFileSync(root+'/ai-quality-v3-before.json'));
const batchId=baseline.targetBatch;
const sql=(query,args=[],file=root+'/data/app.db')=>{const db=new DatabaseSync(file,{readOnly:true});try{db.exec('PRAGMA busy_timeout=5000');return db.prepare(query).all(...args);}finally{db.close();}};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const report={at:new Date().toISOString(),runtime,batchId,checks:[],rendererErrors:[],callsBefore:sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n};
const save=()=>fs.writeFileSync(root+'/ai-quality-final-cold.json',JSON.stringify(report,null,2));
let app,page;
async function until(action){const deadline=Date.now()+120000;while(Date.now()<deadline){const value=await action();if(value)return value;await new Promise(resolve=>setTimeout(resolve,300));}throw Error('Local recovery timed out');}
async function launch(){
  const env={...process.env,OMNI_EDU_DATA_ROOT:root+'/data',OMNI_EDU_REPO_ROOT:path.resolve('../..'),OMNI_EDU_E2E_DIALOG_MODE:'1',OMNI_EDU_E2E_VISIBLE:'0',OMNI_EDU_XIAOZHI_PI:'1'};
  for(const key of ['ELECTRON_RUN_AS_NODE','NODE_OPTIONS','ELECTRON_RENDERER_URL'])delete env[key];
  app=await _electron.launch({args:[runtime.entry,'--user-data-dir='+root+'/profile'],cwd:process.cwd(),env,timeout:90000});
  page=await app.firstWindow();page.setDefaultTimeout(60000);page.on('pageerror',error=>report.rendererErrors.push(error.message));
}
async function notebook(question){
  await productEntry(page,'teaching').click();await page.getByRole('button',{name:'题本',exact:true}).click();
  if(!await page.getByTestId('question-notebook-filter-grade').isVisible())await page.getByTestId('question-notebook-filter-toggle').click();
  await page.getByTestId('question-notebook-filter-grade').fill('');await page.getByTestId('question-notebook-filter-subject').fill('');
  await page.getByTestId('question-notebook-search').fill(question.stem.slice(0,45));
  const card=page.getByTestId('question-notebook-card-'+question.id);await card.waitFor();
  await card.getByTestId('native-picture-open').click();
  await until(()=>card.getByTestId('native-picture-image').evaluate(image=>image.complete&&image.naturalWidth>0));
  const image=await card.getByTestId('native-picture-image').evaluate(image=>({src:image.src,width:image.naturalWidth,height:image.naturalHeight}));
  const archive=JSON.parse(question.archive_json);
  assert.equal(createHash('sha256').update(Buffer.from(image.src.split(',')[1],'base64')).digest('hex'),archive.native.roles.question.figures[0].sha256);
  return {width:image.width,height:image.height};
}
try{
  const bankBefore=hash(sql('SELECT * FROM question_bank_items ORDER BY rowid'));
  await launch();await page.setViewportSize({width:1366,height:768});
  report.questions=[];
  for(const file of ['ai-quality-recover-live.json','ai-quality-v3-recover-live.json']){
    const prior=JSON.parse(fs.readFileSync(root+'/'+file));assert(prior.success&&prior.closed);
    const question=sql('SELECT id,stem,archive_json FROM question_bank_items WHERE id=?',[prior.question.id])[0];
    const archive=JSON.parse(question.archive_json);assert.equal(archive.state,'ai_needs_review');
    const image=await notebook(question);await page.setViewportSize({width:1920,height:1080});
    await page.getByTestId('question-notebook-card-'+question.id).scrollIntoViewIfNeeded();
    report.questions.push({id:question.id,policy:archive.ai.policy,state:archive.state,image});
  }
  assert.deepEqual(report.questions.map(q=>q.policy),['native-reviewed.v2','native-reviewed.v3']);
  report.callsAfter=sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n;assert.equal(report.callsAfter,report.callsBefore);
  assert.equal(hash(sql('SELECT * FROM question_bank_items ORDER BY rowid')),bankBefore);
  assert.deepEqual(report.rendererErrors,[]);report.success=true;report.checks.push('Final build cold-reads both v2 and v3 original figures through the notebook, keeps every bank row and makes zero provider calls');
}catch(error){report.success=false;report.error=String(error.stack||error);process.exitCode=1;}
finally{if(app)await app.close();report.closed=true;save();console.log(JSON.stringify({success:report.success,questions:report.questions,callsBefore:report.callsBefore,callsAfter:report.callsAfter,error:report.error}));}
