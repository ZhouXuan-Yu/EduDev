import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {_electron} from 'playwright';
import {productEntry} from '../../scripts/product-navigation.mjs';
import {openMaterialDisclosure} from '../../scripts/education/material-disclosure-ui.mjs';
const root='D:/WorkProject/EduProject-kb-run/flow-1gb-20261111';
const runtime=JSON.parse(fs.readFileSync(root+'/ai-quality-v3-runtime.json'));
const baseline=JSON.parse(fs.readFileSync(root+'/ai-quality-v3-before.json'));
const batchId=baseline.targetBatch;
const sql=(query,args=[],file=root+'/data/app.db')=>{const db=new DatabaseSync(file,{readOnly:true});try{db.exec('PRAGMA busy_timeout=5000');return db.prepare(query).all(...args);}finally{db.close();}};
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const report={at:new Date().toISOString(),runtime,batchId,checks:[],rendererErrors:[],callsBefore:sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n};
const save=()=>fs.writeFileSync(root+'/ai-quality-v3-recover-live.json',JSON.stringify(report,null,2));
let app,page;
async function until(action){const deadline=Date.now()+120000;while(Date.now()<deadline){const value=await action();if(value)return value;await new Promise(resolve=>setTimeout(resolve,300));}throw Error('Local recovery timed out');}
async function launch(){
  const env={...process.env,OMNI_EDU_DATA_ROOT:root+'/data',OMNI_EDU_REPO_ROOT:path.resolve('../..'),OMNI_EDU_E2E_DIALOG_MODE:'1',OMNI_EDU_E2E_VISIBLE:'0',OMNI_EDU_XIAOZHI_PI:'1'};
  for(const key of ['ELECTRON_RUN_AS_NODE','NODE_OPTIONS','ELECTRON_RENDERER_URL'])delete env[key];
  app=await _electron.launch({args:[runtime.entry,'--user-data-dir='+root+'/profile'],cwd:process.cwd(),env,timeout:90000});
  page=await app.firstWindow();page.setDefaultTimeout(60000);page.on('pageerror',error=>report.rendererErrors.push(error.message));
}
async function notebook(question){
  await productEntry(page,'teaching').click();await page.getByRole('button',{name:'题本',exact:true}).click();
  if(!await page.getByTestId('question-notebook-filter-grade').isVisible())await page.getByTestId('question-notebook-filter-toggle').click();
  await page.getByTestId('question-notebook-filter-grade').fill('');await page.getByTestId('question-notebook-filter-subject').fill('');
  await page.getByTestId('question-notebook-search').fill(question.stem.slice(0,45));
  const card=page.getByTestId('question-notebook-card-'+question.id);await card.waitFor();
  await card.getByTestId('native-picture-open').click();
  await until(()=>card.getByTestId('native-picture-image').evaluate(image=>image.complete&&image.naturalWidth>0));
  const image=await card.getByTestId('native-picture-image').evaluate(image=>({src:image.src,width:image.naturalWidth,height:image.naturalHeight}));
  const archive=JSON.parse(question.archive_json);
  assert.equal(createHash('sha256').update(Buffer.from(image.src.split(',')[1],'base64')).digest('hex'),archive.native.roles.question.figures[0].sha256);
  return {width:image.width,height:image.height};
}
try{
  await launch();await page.setViewportSize({width:1366,height:768});
  const batch=sql('SELECT resource_id FROM material_ai_batches WHERE id=?',[batchId])[0];
  const resource=sql('SELECT id,title FROM teacher_resources WHERE id=?',[batch.resource_id])[0];
  await productEntry(page,'materials').click();await page.getByTestId('materials-search').fill(resource.title);
  await page.getByTestId('material-'+resource.id).getByRole('button').click();await page.getByRole('button',{name:'题目与校正',exact:true}).click();
  await openMaterialDisclosure(page.getByTestId('material-ai-panel'));
  const article=page.locator('[data-testid="material-ai-batch"][data-batch-id="'+batchId+'"]');
  await article.getByTestId('material-ai-recover-response').click();
  await until(()=>sql('SELECT status FROM material_ai_units WHERE batch_id=?',[batchId])[0].status==='review');
  const questions=sql('SELECT q.id,q.stem,q.archive_json FROM material_ai_members m JOIN question_bank_items q ON q.id=m.question_id WHERE m.batch_id=?',[batchId]);
  assert.equal(questions.length,1);const question=questions[0],archive=JSON.parse(question.archive_json);
  assert.equal(archive.state,'ai_needs_review');assert(!archive.issues.includes('answer_conflict'));assert.equal(archive.ai.policy,'native-reviewed.v3');assert(archive.issues.includes('ai_mismatch'));
  report.question={id:question.id,state:archive.state,issues:archive.issues,figures:archive.native.roles.question.figures.length};
  report.audits=sql('SELECT policy,changes_json,error FROM material_ai_response_recoveries WHERE response_id IN(SELECT id FROM material_ai_response_receipts WHERE batch_id=?)',[batchId]);
  assert.equal(report.audits.at(-1).policy,'native-response-recovery.v3');
  report.image=await notebook(question);await page.setViewportSize({width:1920,height:1080});
  await page.getByTestId('question-notebook-card-'+question.id).scrollIntoViewIfNeeded();
  report.checks.push('Original recovery button archives the source-bound result as an explicit analysis-uncertain review; original figure is readable at both viewports');
  await app.close();app=undefined;await launch();await page.setViewportSize({width:1366,height:768});
  await notebook(question);
  report.callsAfter=sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n;assert.equal(report.callsAfter,report.callsBefore);
  report.preserved={};
  for(const table of ['teacher_resources','resource_chunks','question_bank_items','material_ai_response_receipts','material_word_document_versions']){
    const current=hash(sql('SELECT * FROM '+table+' WHERE rowid<=? ORDER BY rowid',[baseline.facts[table].maxRowid]));
    assert.equal(current,baseline.facts[table].sha);report.preserved[table]=current;
  }
  const original=sql('SELECT * FROM material_ai_units WHERE batch_id<>? ORDER BY rowid',[batchId],root+'/ai-quality-v3-before.db');
  assert.deepEqual(sql('SELECT * FROM material_ai_units WHERE batch_id<>? ORDER BY rowid',[batchId]),original);
  const old=sql('SELECT * FROM material_ai_units WHERE batch_id=?',[batchId],root+'/ai-quality-v3-before.db')[0];
  const current=sql('SELECT * FROM material_ai_units WHERE batch_id=?',[batchId])[0];
  for(const field of ['input_json','first_json','image_sha','ordinal','batch_id'])assert.equal(current[field],old[field]);
  const audits=sql('SELECT * FROM material_ai_response_recoveries ORDER BY response_id,policy',[],root+'/ai-quality-v3-before.db');
  for(const row of audits)assert.deepEqual(sql('SELECT * FROM material_ai_response_recoveries WHERE response_id=? AND policy=?',[row.response_id,row.policy])[0],row);
  assert.equal(sql("SELECT status FROM material_import_batches WHERE id=?",['batch_4cc3f35f-50cd-456d-a2be-e01ac0312ff0'])[0].status,'paused');
  assert.equal(sql("SELECT status FROM material_folder_ai WHERE batch_id=?",['batch_4cc3f35f-50cd-456d-a2be-e01ac0312ff0'])[0].status,'paused');
  assert.deepEqual(report.rendererErrors,[]);report.success=true;
  report.checks.push('Cold restart retains the recovered question; all original bank rows, source facts, receipts, prior audits and other units match the backup; no model calls');
}catch(error){report.success=false;report.error=String(error.stack||error);process.exitCode=1;}
finally{if(app)await app.close();report.closed=true;save();console.log(JSON.stringify({success:report.success,question:report.question,callsBefore:report.callsBefore,callsAfter:report.callsAfter,error:report.error}));}
