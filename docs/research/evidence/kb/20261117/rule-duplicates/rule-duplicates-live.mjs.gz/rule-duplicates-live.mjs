import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {_electron} from 'playwright';
import {productEntry} from '../../scripts/product-navigation.mjs';
const root = 'D:/WorkProject/EduProject-kb-run/flow-1gb-20261111';
const runtime = JSON.parse(fs.readFileSync(root + '/rule-duplicates-runtime.json'));
const baseline = JSON.parse(fs.readFileSync(root + '/rule-duplicates-20261117-before.json'));
const groups = JSON.parse(fs.readFileSync(root + '/rule-duplicate-before.json')).groups;
const fullAudit = JSON.parse(fs.readFileSync(root + '/rule-duplicates-full-audit.json'));
const file = root + '/rule-duplicates-live.json';
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
function sql(query, values = [], database = root + '/data/app.db') {
  const db = new DatabaseSync(database, {readOnly: true});
  try { db.exec('PRAGMA busy_timeout=5000'); return db.prepare(query).all(...values); } finally { db.close(); }
}
function facts() {
  return Object.fromEntries([['teacher_resources', 'id'], ['resource_chunks', 'id'], ['question_bank_items', 'id'],
    ['material_ai_units', 'batch_id,ordinal'], ['material_ai_response_receipts', 'rowid'],
    ['material_word_document_versions', 'resource_id,version,digest']].map(([table, order]) => [table, hash(sql('SELECT * FROM ' + table + ' ORDER BY ' + order))]));
}
const report = {at: new Date().toISOString(), runtime, checks: [], progress: [], rendererErrors: [], ui: [], before: facts()};
assert.deepEqual(report.before, baseline.protectedFacts);
let app, page;
const save = () => fs.writeFileSync(file, JSON.stringify(report, null, 2));
async function launch() {
  const env = {...process.env, OMNI_EDU_DATA_ROOT: root + '/data', OMNI_EDU_REPO_ROOT: path.resolve('../..'), OMNI_EDU_E2E_VISIBLE: '0', OMNI_EDU_E2E_DIALOG_MODE: '1', OMNI_EDU_XIAOZHI_PI: '1'};
  for (const key of ['ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL', 'NODE_OPTIONS', 'OMNI_EDU_RULE_DUPLICATES']) delete env[key];
  app = await _electron.launch({args: [runtime.entry, '--user-data-dir=' + root + '/profile'], cwd: process.cwd(), env, timeout: 90000});
  page = await app.firstWindow(); page.setDefaultTimeout(60000); page.on('pageerror', error => report.rendererErrors.push(error.message));
  await page.setViewportSize({width: 1366, height: 768});
}
async function status() {
  const value = await page.evaluate(() => window.omniEdu.getMaterialQuestionStatus());
  const row = sql('SELECT value_json FROM app_settings WHERE key=?', ['xiaozhi.question-origins.cursor.v1'])[0];
  const state = {at: new Date().toISOString(), cursor: JSON.parse(row?.value_json || '{}').cursor || 0, associating: value.associating, folded: value.foldedDuplicates, needsAttention: value.needsAttention};
  report.progress.push(state); save(); return state;
}
async function notebook(showSourceCandidates) {
  return page.evaluate(async showSourceCandidates => {
    const ids = []; let total = 0;
    for (let offset = 0; offset < 10000; offset += 50) {
      const part = await window.omniEdu.listQuestionNotebook({showSourceCandidates, limit: 50, offset});
      total = part.total; ids.push(...part.items.map(item => item.id)); if (ids.length >= total) break;
    }
    return {ids, total};
  }, showSourceCandidates);
}
async function openNotebook() {
  await productEntry(page, 'teaching').click(); await page.getByRole('button', {name: '题本', exact: true}).click();
  if (!await page.getByTestId('question-notebook-filter-grade').isVisible()) await page.getByTestId('question-notebook-filter-toggle').click();
  await page.getByTestId('question-notebook-filter-grade').fill(''); await page.getByTestId('question-notebook-filter-subject').fill('');
}
try {
  await launch();
  await status();
  await new Promise(resolve => setTimeout(resolve, 3000));
  const interrupted = await status();
  await app.close(); app = undefined;
  const cursorAtClose = JSON.parse(sql('SELECT value_json FROM app_settings WHERE key=?', ['xiaozhi.question-origins.cursor.v1'])[0].value_json).cursor;
  await launch(); const resumed = await status(); assert(resumed.cursor >= cursorAtClose);
  report.resume = {beforeClose: interrupted.cursor, committedAtClose: cursorAtClose, afterOpen: resumed.cursor};
  const deadline = Date.now() + 20 * 60 * 1000;
  let current = resumed;
  while (current.associating && Date.now() < deadline) {await new Promise(resolve => setTimeout(resolve, 4000)); current = await status();}
  assert.equal(current.associating, false, JSON.stringify(current));
  assert.equal(current.folded, fullAudit.count);
  const defaults = await notebook(false), raw = await notebook(true);
  assert.equal(raw.total, 3182); assert.equal(raw.ids.length, raw.total);
  const mapping = sql("SELECT question_id,duplicate_of,duplicate_key FROM material_question_members WHERE duplicate_key<>''");
  const defaultIds = new Set(defaults.ids), rawIds = new Set(raw.ids);
  for (const pair of fullAudit.audit) {
    assert(!defaultIds.has(pair.question_id));
    assert(rawIds.has(pair.question_id));
    assert(rawIds.has(pair.duplicate_of));
  }
  report.pairs = groups.map(group => {
    assert.equal(group.ids.length, 2);
    const records = group.ids.map(id => mapping.find(row => row.question_id === id)); assert(records.every(Boolean));
    const keeper = records.find(row => !row.duplicate_of), duplicate = records.find(row => row.duplicate_of); assert(keeper && duplicate);
    assert.equal(duplicate.duplicate_of, keeper.question_id); assert(defaultIds.has(keeper.question_id)); assert(!defaultIds.has(duplicate.question_id));
    assert(group.ids.every(id => rawIds.has(id))); return {resourceId: group.resourceId, keeper: keeper.question_id, duplicate: duplicate.question_id};
  });
  report.defaultCount = defaults.total; report.rawCount = raw.total;
  await openNotebook(); await page.getByTestId('question-notebook-source-candidates').check();
  const selected = report.pairs[0], question = sql('SELECT source_title,archive_json FROM question_bank_items WHERE id=?', [selected.duplicate])[0];
  const query = question.source_title;
  await page.getByTestId('question-notebook-search').fill(query);
  const list = await page.evaluate(query => window.omniEdu.listQuestionNotebook({query, showSourceCandidates: true, limit: 50}), query);
  const index = list.items.findIndex(item => item.id === selected.duplicate); assert(index >= 0 && index < 50);
  await page.getByTestId('question-notebook-card-' + list.items[0].id).waitFor();
  for (let offset = 20; offset <= index; offset += 20) {await page.getByTestId('question-notebook-next').click(); await page.getByTestId('question-notebook-card-' + list.items[offset].id).waitFor();}
  const card = page.getByTestId('question-notebook-card-' + selected.duplicate); await card.waitFor();
  for (const [width, height] of [[1366, 768], [1920, 1080]]) {
    await page.setViewportSize({width, height}); const control = page.getByTestId('question-notebook-source-candidates');
    await control.scrollIntoViewIfNeeded(); const box = await control.boundingBox(); assert(box && box.x >= 0 && box.x + box.width <= width);
    report.ui.push({width, height, rawControlReachable: true});
  }
  await card.getByTestId('pi-material-source-open').first().click(); await page.getByTestId('materials-body-location').waitFor();
  const queue = page.getByTestId('materials-queue-toggle');
  if (await queue.getAttribute('aria-expanded') !== 'true') await queue.click();
  const diagnostics=page.getByTestId('materials-diagnostics');
  await diagnostics.getByRole('button',{name:'题库归档与检索状态',exact:true}).click();
  await page.getByTestId('material-question-status').getByText(new RegExp(fullAudit.count+' 条重复记录已折叠')).waitFor();
  report.checks.push('All 54 independently audited duplicates collapse in the default notebook and remain in the original-candidate view; original source and count feedback are reachable');
  await app.close(); app = undefined; await launch();
  const cold = await page.evaluate(() => window.omniEdu.getMaterialQuestionStatus()); assert.equal(cold.foldedDuplicates, fullAudit.count);
  assert.equal(sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n, 710);
  const batches = await page.evaluate(() => window.omniEdu.listMaterialBatches({schemaVersion: 'xiaozhi.material-import-batch.v1', offset: 0}));
  report.import = batches.batches.find(batch => batch.id === 'batch_4cc3f35f-50cd-456d-a2be-e01ac0312ff0');
  report.folderAi = await page.evaluate(batchId => window.omniEdu.getMaterialFolderAi({schemaVersion: 'xiaozhi.material-folder-ai.v1', batchId}), report.import.id);
  assert.equal(report.import.status, 'paused'); assert.equal(report.folderAi.status, 'paused');
  report.after = facts(); assert.deepEqual(report.after, report.before);
  const membership = database => hash(sql('SELECT extraction_key,resource_id,question_id FROM material_question_members ORDER BY question_id', [], database));
  assert.equal(membership(root + '/data/app.db'), membership(root + '/rule-duplicates-20261117-before.db'));
  assert.deepEqual(report.rendererErrors, []); report.success = true;
  report.checks.push('Cold startup retains completed folding, business facts and extraction identities keep exact SHA, no additional model calls');
} catch (error) {report.success = false; report.error = String(error.stack || error); process.exitCode = 1;}
finally {if (app) await app.close(); report.closed = true; save(); console.log(JSON.stringify({success: report.success, folded: report.progress.at(-1)?.folded, progress: report.progress.at(-1), error: report.error}));}
