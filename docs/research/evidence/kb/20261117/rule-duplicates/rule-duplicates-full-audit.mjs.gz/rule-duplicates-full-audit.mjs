import '../../scripts/office-agent/register-source.mjs';import fs from 'node:fs';import {DatabaseSync} from 'node:sqlite';import {createHash} from 'node:crypto';import assert from 'node:assert/strict';
const {extractMaterialQuestionWindow}=await import('../../src/main/assets/material-question-extract.ts');const {materialBodyVersion}=await import('../../src/main/assets/material-source.ts');
const root='D:/WorkProject/EduProject-kb-run/flow-1gb-20261111',db=new DatabaseSync(root+'/data/app.db',{readOnly:true});
const rows=db.prepare("SELECT m.question_id,m.duplicate_of,m.resource_id FROM material_question_members m WHERE m.duplicate_of<>'' ORDER BY m.question_id").all();
const normalize=row=>Object.fromEntries(Object.entries(row).filter(([key])=>!['id','created_at','updated_at','archive_json'].includes(key)).map(([key,value])=>[key,key==='tags'?JSON.parse(value):key==='document_json'&&!value?null:value]));
const audit=[];
for(const pair of rows){
 const row=db.prepare('SELECT q.*,m.extraction_key FROM question_bank_items q JOIN material_question_members m ON m.question_id=q.id WHERE q.id=?').get(pair.question_id);
 const kept=db.prepare('SELECT q.*,m.extraction_key FROM question_bank_items q JOIN material_question_members m ON m.question_id=q.id WHERE q.id=?').get(pair.duplicate_of);
 const a=JSON.parse(row.archive_json),b=JSON.parse(kept.archive_json);const sa=a.sources,sb=b.sources;delete a.sources;delete b.sources;
 const ra={...row},rb={...kept};delete ra.extraction_key;delete rb.extraction_key;assert.deepEqual(normalize(ra),normalize(rb));assert.deepEqual(a,b);
 const r=db.prepare('SELECT * FROM teacher_resources WHERE id=?').get(pair.resource_id);const cursor=Math.floor(sa[0].offset/16)*16;
 const chunks=db.prepare('SELECT * FROM resource_chunks WHERE resource_id=? ORDER BY chunk_index,id LIMIT 17 OFFSET ?').all(r.id,cursor);
 const units=chunks.slice(0,16).map((c,i)=>({resourceId:r.id,version:r.content_hash,title:r.original_file_name,offset:cursor+i,chunk:{id:c.id,resourceId:r.id,chunkIndex:c.chunk_index,contentMd:c.content_md,containsPersonalData:!!c.contains_personal_data,pageNumber:c.page_number}}));
 const candidates=extractMaterialQuestionWindow(units,r.parse_engine,chunks.length>16,cursor);
 const position=(sources,receipt)=>{
  for(const source of sources){const u=units.find(u=>u.offset===source.offset);assert(u);assert.equal(source.version,r.content_hash);assert.equal(materialBodyVersion({...u.chunk,id:source.chunkId}),source.bodyVersion);}
  return candidates.find(q=>createHash('sha256').update(r.id+'\0'+r.content_hash+'\0numbered-text.v1\0'+JSON.stringify(sources)+'\0'+q.key).digest('hex')===receipt)?.key;
 };
 const pa=position(sa,row.extraction_key),pb=position(sb,kept.extraction_key);assert(pa!==undefined);assert.equal(pa,pb);
 for(const id of [pair.question_id,pair.duplicate_of]){assert.equal(db.prepare('SELECT COUNT(*) n FROM question_notebook_bookmarks WHERE question_id=? AND bookmarked=1').get(id).n,0);assert.equal(db.prepare('SELECT COUNT(*) n FROM question_notebook_category_links WHERE question_id=?').get(id).n,0);assert.equal(db.prepare('SELECT COUNT(*) n FROM question_bank_usage WHERE question_id=?').get(id).n,0);}
 audit.push({...pair,position:pa,sourceAndAllFieldsMatch:true,teacherProtected:false});
}
fs.writeFileSync(root+'/rule-duplicates-full-audit.json',JSON.stringify({at:new Date().toISOString(),count:audit.length,resources:new Set(audit.map(r=>r.resource_id)).size,audit},null,2));console.log(JSON.stringify({allFolded:rows.length,resources:new Set(audit.map(r=>r.resource_id)).size,proved:audit.length}));db.close();
