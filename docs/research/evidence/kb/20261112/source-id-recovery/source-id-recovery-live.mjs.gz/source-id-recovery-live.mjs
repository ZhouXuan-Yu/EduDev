import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {_electron} from 'playwright';
import {productEntry} from '../../scripts/product-navigation.mjs';
const root = 'D:/WorkProject/EduProject-kb-run/flow-1gb-20261111';
const baseline = process.env.SOURCE_RECOVERY_BASELINE === '1';
const runtime = JSON.parse(fs.readFileSync(root + (baseline ? '/prepared.json' : '/source-id-recovery-runtime.json')));
const displaced = new Set(JSON.parse(fs.readFileSync(root + '/word-drawing-facts-final.json')).chunkChanges.flatMap(row => row.oldIds));
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
function sql(query, values = []) {
  const db = new DatabaseSync(root + '/data/app.db', {readOnly: true});
  try { return db.prepare(query).all(...values); } finally { db.close(); }
}
function facts() {
  return Object.fromEntries([
    ['teacher_resources', 'id'], ['resource_chunks', 'id'], ['question_bank_items', 'id'],
    ['material_ai_units', 'batch_id,ordinal'], ['material_ai_response_receipts', 'rowid'],
    ['material_word_document_versions', 'resource_id,version,digest'],
  ].map(([table, order]) => [table, hash(sql('SELECT * FROM ' + table + ' ORDER BY ' + order))]));
}
const questions = sql('SELECT id,stem,source_title,archive_json FROM question_bank_items ORDER BY created_at,id')
  .map(row => ({...row, archive: JSON.parse(row.archive_json || '{}')}))
  .filter(row => row.archive.sources?.some(source => displaced.has(source.chunkId)));
const sources = [...new Map(questions.flatMap(q => q.archive.sources).map(source => [JSON.stringify(source), source])).values()];
const selected = [];
for (const question of questions) if (!selected.some(saved => saved.archive.sources[0].resourceId === question.archive.sources[0].resourceId)) selected.push(question);
const report = {at: new Date().toISOString(), baseline, runtime, checks: [], rendererErrors: [], questions: questions.length,
  kinds: Object.fromEntries([...new Set(questions.map(q => q.archive.extractor))].map(kind => [kind, questions.filter(q => q.archive.extractor === kind).length])),
  uniqueSources: sources.length, reads: [], ui: [], before: facts()};
const file = root + (baseline ? '/source-id-recovery-before.json' : '/source-id-recovery-live.json');
const save = () => fs.writeFileSync(file, JSON.stringify(report, null, 2));
let app, page;
async function launch() {
  const env = {...process.env, OMNI_EDU_DATA_ROOT: root + '/data', OMNI_EDU_REPO_ROOT: path.resolve('../..'), OMNI_EDU_E2E_VISIBLE: '0', OMNI_EDU_E2E_DIALOG_MODE: '1', OMNI_EDU_XIAOZHI_PI: '1'};
  for (const key of ['ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL', 'NODE_OPTIONS', 'OMNI_EDU_SOURCE_ID_RECOVERY']) delete env[key];
  app = await _electron.launch({args: [runtime.entry, '--user-data-dir=' + root + '/profile'], cwd: process.cwd(), env, timeout: 90000});
  page = await app.firstWindow(); page.setDefaultTimeout(45000);
  page.on('pageerror', error => report.rendererErrors.push(error.message));
  await page.setViewportSize({width: 1366, height: 768});
}
async function openQuestionSource(question) {
  await productEntry(page, 'teaching').click();
  await page.getByRole('button', {name: '题本', exact: true}).click();
  if (!await page.getByTestId('question-notebook-filter-grade').isVisible()) await page.getByTestId('question-notebook-filter-toggle').click();
  await page.getByTestId('question-notebook-filter-grade').fill('');
  await page.getByTestId('question-notebook-filter-subject').fill('');
  await page.getByTestId('question-notebook-source-candidates').check();
  const query = question.source_title.trim().slice(0, 120);
  assert(query, 'No usable source search line');
  await page.getByTestId('question-notebook-search').fill(query);
  const result = await page.evaluate(async ({query, id}) => {
    const items = []; let total = 0;
    for (let offset = 0; offset < 5000; offset += 50) {
      const part = await window.omniEdu.listQuestionNotebook({query, showSourceCandidates: true, limit: 50, offset});
      total = part.total; items.push(...part.items.map(item => ({id: item.id})));
      if (items.some(item => item.id === id) || offset + part.items.length >= total) break;
    }
    return {items, total};
  }, {query, id: question.id});
  const index = result.items.findIndex(item => item.id === question.id);
  report.searchDiagnostics = {questionId: question.id, total: result.total, index};
  assert(index >= 0, JSON.stringify(report.searchDiagnostics));
  await page.getByTestId('question-notebook-card-' + result.items[0].id).waitFor();
  for (let offset = 20; offset <= index; offset += 20) {
    await page.getByTestId('question-notebook-next').click();
    await page.getByTestId('question-notebook-card-' + result.items[offset].id).waitFor();
  }
  const card = page.getByTestId('question-notebook-card-' + question.id);
  await card.waitFor();
  await card.getByTestId('pi-material-source-open').first().click();
  if (baseline) {
    await card.getByTestId('pi-material-source-error').waitFor();
    report.ui.push({questionId: question.id, status: 'source_changed'});
  } else {
    await page.getByTestId('materials-source-recovery').waitFor();
    await page.getByTestId('materials-body-location').waitFor();
    for (const [width, height] of [[1366, 768], [1920, 1080]]) {
      await page.setViewportSize({width, height});
      const status = page.getByTestId('materials-source-recovery');
      await status.scrollIntoViewIfNeeded(); const box = await status.boundingBox();
      assert(box && box.x >= 0 && box.x + box.width <= width);
      report.ui.push({questionId: question.id, width, height, status: 'recovered'});
    }
  }
}
try {
  assert.equal(questions.length, 38); assert.equal(sources.length, 11);
  await launch();
  for (const source of sources) {
    const started = performance.now();
    const value = await page.evaluate(async source => {
      try { const view = await window.omniEdu.getMaterialSource(source); return {ok: true, recovery: view.recovery, chunk: view.body.chunks[0]}; }
      catch (error) { return {ok: false, error: String(error)}; }
    }, source);
    if (baseline) { assert.equal(value.ok, false); assert(value.error.includes('source_changed')); }
    else {
      assert(value.ok, value.error); assert.equal(value.recovery.schemaVersion, 'xiaozhi.material-source-recovery.v1');
      assert.notEqual(value.chunk.id, source.chunkId);
      const fields = [source.chunkId, value.chunk.chunkIndex, value.chunk.contentMd, value.chunk.containsPersonalData];
      if (value.chunk.pageNumber) fields.push({pageNumber: value.chunk.pageNumber});
      assert.equal(hash(fields), source.bodyVersion);
    }
    report.reads.push({source, status: baseline ? 'source_changed' : 'recovered', ms: performance.now() - started});
  }
  for (const q of selected) await openQuestionSource(q);
  if (!baseline) {
    await app.close(); app = undefined; await launch();
    await openQuestionSource(selected[0]);
    report.checks.push('Cold restart reopens the original stored reference through the same source button');
  }
  const batches = await page.evaluate(() => window.omniEdu.listMaterialBatches({schemaVersion: 'xiaozhi.material-import-batch.v1', offset: 0}));
  report.import = batches.batches.find(b => b.id === 'batch_4cc3f35f-50cd-456d-a2be-e01ac0312ff0');
  report.folderAi = await page.evaluate(batchId => window.omniEdu.getMaterialFolderAi({schemaVersion: 'xiaozhi.material-folder-ai.v1', batchId}), report.import.id);
  assert.equal(report.import.status, 'paused'); assert.equal(report.folderAi.status, 'paused');
  assert.equal(sql('SELECT SUM(calls) n FROM material_ai_batches')[0].n, 710);
  report.after = facts(); assert.deepEqual(report.after, report.before); assert.deepEqual(report.rendererErrors, []);
  report.checks.push('All protected resource/chunk/question/unit/response/history rows keep their exact SHA, import and folder AI stay paused, zero provider calls');
  report.success = true;
} catch (error) { report.success = false; report.error = String(error.stack || error); process.exitCode = 1; }
finally { if (app) await app.close(); report.closed = true; save(); console.log(JSON.stringify({success: report.success, baseline, questions: report.questions, kinds: report.kinds, sources: report.uniqueSources, ui: report.ui.length, error: report.error})); }
