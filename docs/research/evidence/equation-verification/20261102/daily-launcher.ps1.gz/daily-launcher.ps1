Set-Location -LiteralPath 'D:\WorkProject\EduProject\apps\desktop'
& npm.cmd start *> (Join-Path $env:TEMP 's02-equation-daily-start-20261102.log')
exit $LASTEXITCODE
