import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const root='D:/WorkProject/EduProject-harness/apps/desktop';
await import(pathToFileURL(root+'/scripts/office-agent/register-source.mjs'));
const {createTerminalTool}=await import(pathToFileURL(root+'/src/main/xiaozhi-agent/tools/terminal.ts'));
const {assertFileWritesEnabled}=await import(pathToFileURL(root+'/src/main/xiaozhi-agent/file-write-policy.ts'));
const output=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/i,'$1'));
const workspace=path.join(output,'workspace');fs.mkdirSync(workspace);
const outside=path.join(output,'outside-canary.txt');const marker='SYNTHETIC_OUTSIDE_WORKSPACE_CANARY';fs.writeFileSync(outside,marker,{flag:'wx'});
let loopbackCalls=0;const server=http.createServer((_request,response)=>{loopbackCalls++;response.writeHead(200,{'content-type':'text/plain'});response.end('SYNTHETIC_NETWORK_CANARY');});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const address=server.address();
const tool=createTerminalTool({workspace,secret:'',sanitize:async value=>value,beforeExecute:assertFileWritesEnabled});
const quote=value=>"'"+value.replaceAll("'","''")+"'";
try{
 const read=await tool.execute('phase3_outside_read',{cmd:'Get-Content -LiteralPath '+quote(outside)+' -Raw',timeout:15},new AbortController().signal);
 assert.equal(read.details.terminal.state,'completed',JSON.stringify(read));assert(read.details.terminal.output.includes(marker));
 const network=await tool.execute('phase3_loopback_network',{cmd:'(Invoke-WebRequest -UseBasicParsing -Uri '+quote('http://127.0.0.1:'+address.port+'/canary')+').Content',timeout:15},new AbortController().signal);
 assert.equal(network.details.terminal.state,'completed',JSON.stringify(network));assert(network.details.terminal.output.includes('SYNTHETIC_NETWORK_CANARY'));assert.equal(loopbackCalls,1);
 const report={success:true,head:'ab59604cf9937818ed387def21e737ade12264df',scope:'Actual existing createTerminalTool and its production beforeExecute callback, synthetic owned temp files and loopback only, no host.start/model/out changes',observations:[{name:'cwd fails to bound filesystem access',workdir:workspace,canary:outside,actual:read.details.terminal},{name:'cwd and env filter do not constrain network',loopbackCalls,actual:network.details.terminal}]};
 fs.writeFileSync(path.join(output,'terminal-canary-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({success:true,observations:report.observations.map(item=>item.name),output}));
}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
