import {samePaperExportIntent,copyPaperExportIntent,type PaperExportIntent} from '../../../shared/paper-export';
import {paperExportSendError} from './paper-export-request';
import { createPiSessionNavigation } from './pi-session-navigation';
import {continuationPrompt} from './continue-task';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import type { AiConversationWorkspace } from '../../../shared/contracts';
import type { XiaozhiWorkspaceSnapshot,XiaozhiStartInput, XiaozhiAgentEvent } from '../../../shared/xiaozhi-agent';
import { createEventReceiver,type XiaozhiEventSynchronization } from '../../../shared/xiaozhi-event-receiver';
import {OfficeSynchronization,OfficeSynchronizationNotice} from './OfficeSynchronization';
import { XIAOZHI_SETTINGS_SCHEMA, XIAOZHI_SETTINGS_ERRORS, type XiaozhiSettingsView } from '../../../shared/xiaozhi-settings';
import { applyXiaozhiEvent, XIAOZHI_ERRORS } from '../../../shared/xiaozhi-projection';
import {publicMessageText,type XiaozhiMessagePresentation} from '../../../shared/xiaozhi-message-presentation';
import { AiConversationSidebar } from '../AiConversationSidebar';
import { PiConversationSurface } from './PiConversationSurface';
import {PiGoalControl} from './PiGoalControl';
import { OfficeComposer } from './OfficeComposer';
import {PiThinkingPicker} from './PiThinkingPicker';
import { OfficeComposerState,OfficeComposerSeed } from './OfficeComposerState';
import { PiCopyApproval } from './PiCopyApproval';
import {PiPermissionApproval} from './PiPermissionApproval';
import {PiLearningReview} from './PiLearningReview';
import {PiQuestionCollection} from './PiQuestionCollection';
import {PiQuestionReview} from './PiQuestionReview';
import {PiPaperReview} from './PiPaperReview';
import {PiPracticeReview} from './PiPracticeReview';
import {PiDeliveryBundleCard} from './PiDeliveryBundleCard';
import { PiTextChangeCard } from './PiTextChangeCard';
import {PiOfficeArtifactCard} from './PiOfficeArtifactCard';
import { PiControlCards } from './PiControlCards';
import { PiSkillSettings } from './PiSkillSettings';
import { PiHomeSuggestions, isHomeConversation } from './PiHomeLayout';
import { workspaceNotifications } from './workspace-notifications';
import { PiWorkspaceShell } from './PiWorkspaceShell';
import { PiWorkspaceContext } from './PiWorkspaceContext';
import { PiWorkspaceFiles } from './PiWorkspaceFiles';
import { PiWorkbenchBridge } from './PiWorkbenchBridge';
import {usePiAttachments} from './usePiAttachments';
import { createPiSnapshotHydrator } from './pi-snapshot-hydrator';
import { createPiTextViewBuffer, mergePiViewSnapshot, piTextViewEvent } from './pi-text-view-buffer';
import {usePermissionMode} from './usePermissionMode';
import { useDesktopCommands, useDesktopNavigation } from '../desktop/DesktopFrame';
import './pi-education-workspace.css';

async function readPiSnapshot(target: string) {
  const current = await window.omniEdu?.getXiaozhiSnapshot(target);
  const settings = await window.omniEdu?.getXiaozhiSettings({ sessionId: target });
  if (!current) throw Error('snapshot_unavailable');
  return { current, settings };
}

export function PiEducationWorkspace({ onLeave, onSettings, visible = true }: { onLeave: () => void; onSettings: () => void; visible?: boolean }) {
  const navigation=useDesktopNavigation(),navigationRef=useRef(navigation);navigationRef.current=navigation;
  const active=useRef(false);
  const visibleRef=useRef(visible);visibleRef.current=visible;
  const sessionNavigation=useRef<ReturnType<typeof createPiSessionNavigation<typeof navigation.target>> | undefined>(undefined);
  if(!sessionNavigation.current)sessionNavigation.current=createPiSessionNavigation({
    target:()=>navigationRef.current.target,
    active:()=>active.current,
    navigate:sessionId=>navigationRef.current.navigate({view:'ai',sessionId}),
    open:target=>open(target,false),
  });
  useLayoutEffect(()=>{sessionNavigation.current!.observe(navigation.target);},[navigation.target]);
  const [workspace, setWorkspace] = useState<AiConversationWorkspace>({ folders: [], sessions: [], archivedFolders: [], archivedSessions: [] });
  const [id, setId] = useState('');
  const [snapshot, setSnapshot] = useState<XiaozhiWorkspaceSnapshot>();
  const attachments=usePiAttachments(id,visible,snapshot?.projection.turns.flatMap(turn=>turn.items)||[]);
  const [goalOpenSignal,setGoalOpenSignal]=useState<{token:number;sessionId:string}>();
  const [fileReveal,setFileReveal]=useState<{sessionId:string;id:string;path:string}>();
  const [models, setModels] = useState<XiaozhiSettingsView>(), [modelSelecting, setModelSelecting] = useState(false);
  const [returnHydrating,setReturnHydrating]=useState(false);
  const [loadingEarlier,setLoadingEarlier]=useState(false);
  const [eventSync,setEventSync]=useState<XiaozhiEventSynchronization>('ready'),[refreshFailed,markRefreshFailed]=useState(false);
  const refreshing=useRef(false),refreshFailure=useRef(false),snapshotRef=useRef(snapshot);
  useLayoutEffect(()=>{snapshotRef.current=snapshot;},[snapshot]);
  const snapshotBarrier=useRef<symbol | undefined>(undefined);
  const [snapshotPublishing,setSnapshotPublishing]=useState(false);
  function clearSnapshotBarrier(token?:symbol){if(snapshotBarrier.current===token){snapshotBarrier.current=undefined;setSnapshotPublishing(false);}}
  function setHydrating(value:boolean){refreshing.current=value;setReturnHydrating(value);}
  function setRefreshFailed(value:boolean){refreshFailure.current=value;markRefreshFailed(value);}
  const [hasEntered,setHasEntered]=useState(visible);
  useEffect(()=>{if(visible)setHasEntered(true);},[visible]);
  const modelLock = useRef(false);
  const [notice, setNotice] = useState('');
  const {permissionMode, setPermissionMode} = usePermissionMode(id, setNotice);
  const [skillsOpen, setSkillsOpen] = useState(false);
  const [compactBusy, setCompactBusy] = useState(false);
  const compactLock = useRef(false);
  const compactAttempt = useRef<{ sessionId: string; commandId: string } | undefined>(undefined);
  const idRef = useRef('');
  const opening=useRef<symbol | undefined>(undefined);
  const attempt = useRef<XiaozhiStartInput | undefined>(undefined);
  const queueAttempt=useRef<{sessionId:string;commandId:string;text:string;mode:'steer'|'followUp'}|undefined>(undefined);
  const sequences = useRef(new Map<string, number>());
  const loadingEarlierRef=useRef(false);
  const eventReceiver = useRef<ReturnType<typeof createEventReceiver> | undefined>(undefined);
  const viewBuffer = useRef<ReturnType<typeof createPiTextViewBuffer> | undefined>(undefined);
  if (!viewBuffer.current) viewBuffer.current = createPiTextViewBuffer({
    text: view => applyProjectedEvent(piTextViewEvent(view), view.throughSequence),
    immediate: event => applyProjectedEvent(event),
  });
  const hydration = useRef<ReturnType<typeof createPiSnapshotHydrator<Awaited<ReturnType<typeof readPiSnapshot>>>> | undefined>(undefined);
  if (!hydration.current) hydration.current = createPiSnapshotHydrator({
    read: readPiSnapshot,
    publish: ({ current, settings }) => {
      const token = hydration.current!.token();
      const revision = hydration.current!.revision();
      snapshotBarrier.current=token;setSnapshotPublishing(true);
      // Only authoritative replacement uses a synchronous commit boundary.
      // Consume queued text/history updates before proving page coverage, so
      // the proof and replacement use the same committed React state.
      flushSync(() => { viewBuffer.current!.flush(); setSnapshot(previous => previous); });
      if (!active.current || token !== hydration.current!.token() || current.projection.threadId !== idRef.current) return false;
      const previous = snapshotRef.current;
      const known = new Map((eventReceiver.current?.cursors() || []).map(cursor => [cursor.runId, cursor]));
      for (const turn of current.projection.turns) {
        const accepted = known.get(turn.id);
        if (!accepted) continue;
        const cursor = current.eventCursors?.find(value => value.runId === turn.id);
        if (!cursor || cursor.generation !== accepted.generation || cursor.sequence < accepted.sequence) return false;
      }
      if (!viewBuffer.current!.canReplace(current, previous?.projection)) return false;
      const retainedCursors = eventReceiver.current?.cursors() || [];
      const merged = mergePiViewSnapshot(previous, current, retainedCursors);
      flushSync(() => setSnapshot(merged));
      if (!active.current || token !== hydration.current!.token() || revision !== hydration.current!.revision() || snapshotRef.current !== merged) return false;
      viewBuffer.current!.acknowledge(current, previous?.projection);
      if (settings?.ok) setModels(settings.value);
      if (!current.eventPersistence && !current.projection.needsHydration) eventReceiver.current?.seed(current.eventCursors || [],true);
      for (const cursor of current.eventCursors || []) sequences.current.set(cursor.runId, Math.max(sequences.current.get(cursor.runId) || 0, cursor.sequence));
      if (current.eventPersistence === 'unavailable') setNotice(XIAOZHI_ERRORS.event_persistence);
      const turn = current.projection.turns.at(-1);
      if (turn && current.running) sequences.current.set(turn.id, Math.max(sequences.current.get(turn.id) || 0, current.projection.sourceSequence));
      setRefreshFailed(false);
      setNotice(value => value === '无法刷新本地会话，请重试。' ? '' : value);
      if (revision !== hydration.current!.revision() || token !== hydration.current!.token()) return false;
      clearSnapshotBarrier(token);
    },
    failed: () => { setRefreshFailed(true); clearSnapshotBarrier(hydration.current!.token()); setNotice('无法刷新本地会话，请重试。'); },
  });
  const syncBlocked=!snapshot||snapshotPublishing||returnHydrating||refreshFailed||eventSync!=='ready'||Boolean(snapshot.projection.needsHydration||snapshot.eventPersistence);
  function mutationsBlocked(){const view=snapshotRef.current;return !view||view.projection.threadId!==idRef.current||snapshotBarrier.current!==undefined||refreshing.current||refreshFailure.current||eventReceiver.current?.synchronization()!=='ready'||Boolean(view.projection.needsHydration||view.eventPersistence);}
  function requireSynchronized(){if(mutationsBlocked())throw Error('过程记录正在同步，请稍后再试。');}
  async function refreshCurrent(){
    if(refreshing.current)return;const target=idRef.current,token=hydration.current!.token();setHydrating(true);
    const failed=Boolean(snapshotRef.current?.eventPersistence)||eventReceiver.current?.synchronization()==='unavailable';
    try{
      const result=await window.omniEdu?.refreshXiaozhiRecords(target);
      if(!active.current||hydration.current!.token()!==token)return;
      await hydrate(target);
      if(!active.current||hydration.current!.token()!==token)return;
      if(!result?.ok)setNotice(result&&result.error==='busy'?'上一轮执行仍在结束，请稍后重新读取记录。':result?XIAOZHI_ERRORS[result.error]:'无法刷新本地会话，请重试。');
      else if(failed&&!snapshotRef.current?.eventPersistence)setNotice('已重新核对本地记录。已保存的成果会保留，请核对后继续任务。');
    }catch{if(active.current&&hydration.current!.token()===token)setRefreshFailed(true);}
    finally{if(active.current&&hydration.current!.token()===token)setHydrating(false);}
  }
  function applyProjectedEvent(event: XiaozhiAgentEvent, throughSequence = event.sequence) {
      setSnapshot(previous => {
        if (!previous || previous.projection.threadId !== event.sessionId) return previous;
        const turns = previous.projection.turns.slice();
        let index = turns.findIndex(turn => turn.id === event.runId);
        if (index < 0) {
          const pending = turns.at(-1)?.id === 'pending-send' ? turns.pop() : undefined;
          turns.push({ id: event.runId, status: 'running', items: pending?.items || [] }); index = turns.length - 1;
        }
        turns[index] = applyXiaozhiEvent(turns[index], event);
        const approvals = event.kind === 'approval' ? [...(previous.approvals || []).filter(item => item.id !== event.approval.id), event.approval] : previous.approvals;
        const changes = event.kind === 'change' ? [...(previous.changes || []).filter(item => item.id !== event.change.id), event.change] : previous.changes;
        const deliveries=event.kind==='delivery_bundle'?[...(previous.deliveries||[]).filter(item=>item.id!==event.delivery.id),event.delivery]:previous.deliveries;
        const officeArtifacts=event.kind==='office_artifact'?[...(previous.officeArtifacts||[]).filter(item=>item.id!==event.artifact.id),event.artifact]:previous.officeArtifacts;
        const learningReviews=event.kind==='learning_review'?[...(previous.learningReviews||[]).filter(item=>item.id!==event.review.id),event.review]:previous.learningReviews;
        const paperReviews=event.kind==='paper_review'?[...(previous.paperReviews||[]).filter(item=>item.id!==event.review.id),event.review]:previous.paperReviews;
        const practiceReviews=event.kind==='practice_review'?[...(previous.practiceReviews||[]).filter(item=>item.id!==event.review.id),event.review]:previous.practiceReviews;
        const questionCollections=event.kind==='question_collection'?[...(previous.questionCollections||[]).filter(item=>item.id!==event.review.id),event.review]:previous.questionCollections;
        const questionReviews=event.kind==='question_review'?[...(previous.questionReviews||[]).filter(item=>item.id!==event.review.id),event.review]:previous.questionReviews;
        const controls=event.kind === 'control' ? [...(previous.controls || []).filter(item=>item.id !== event.control.id),event.control] : previous.controls;
        const usage=event.kind==='usage'?[...(previous.usage || []).filter(item=>item.runId!==event.usage.runId),event.usage]:previous.usage;
        return { ...previous, approvals, changes, deliveries, officeArtifacts, learningReviews, questionCollections, questionReviews, practiceReviews, paperReviews, controls, usage, ...(event.kind==='goal'?{goal:event.goal}:{}),...(event.kind==='task'?{task:event.task,taskUnavailable:false,...(event.goal?{goal:event.goal}:{})}:{}), ...(event.kind === 'compaction' && !event.automatic ? { operation: 'compact' as const } : {}), running: event.kind === 'status' ? event.status === 'running' : previous.running,
          projection: { ...previous.projection, sourceSequence: throughSequence, turns } };
      });
  }
  const journalRunId = snapshot?.projection.turns.at(-1)?.id;
  useEffect(() => {
    if (!visible || !snapshot?.running || !id || !journalRunId) return;
    const timer = setInterval(() => eventReceiver.current?.poll(id, journalRunId), 1500);
    return () => clearInterval(timer);
  }, [visible, id, snapshot?.running, journalRunId]);
  const refreshList = async () => { const list = await window.omniEdu?.listAiConversations(); if (list) setWorkspace(list); };
  async function hydrate(target: string, fresh = true) {
    if(!active.current||idRef.current!==target)return;
    await hydration.current!.hydrate(target, fresh);
  }
  async function open(target: string,record=true) {
    if(!active.current)return;
    sessionNavigation.current!.invalidate();
    if(record&&visibleRef.current&&navigationRef.current.target.view==='ai'&&!navigationRef.current.navigate({view:'ai',sessionId:target}))return;
    viewBuffer.current!.clear();
    clearSnapshotBarrier(snapshotBarrier.current);
    hydration.current!.open(target);
    const token=hydration.current!.token();
    opening.current=token;
    loadingEarlierRef.current=false;setLoadingEarlier(false);
    idRef.current = target; snapshotRef.current=undefined;setId(target); setSnapshot(undefined); setModels(undefined); setNotice(''); sequences.current.clear();
    eventReceiver.current?.reset();
    setHydrating(false);setRefreshFailed(false);
    try{localStorage.setItem('xiaozhi.current-session.v1',target);}catch{/* Navigation remains usable without UI preference storage. */}
    attempt.current = undefined;
    queueAttempt.current=undefined;
    compactAttempt.current=undefined;
    try { await hydrate(target); } catch { if (active.current && hydration.current!.token() === token) setNotice('无法读取本地会话，请重试。'); }
    finally { if(opening.current===token)opening.current=undefined; }
    return active.current && hydration.current!.token()===token && !hydration.current!.hasFailed();
  }
  async function fresh(folderId: string | null = null, title = '新对话', reveal = false) {
    return sessionNavigation.current!.create(async()=>{
      const detail=await window.omniEdu?.createAiConversationSession({title:title.trim()||'新对话',folderId});
      return detail?.session.id;
    },async target=>{
      if(reveal)return sessionNavigation.current!.select(target);
      return open(target);
    },refreshList);
  }
  async function loadEarlier() {
    const current=snapshotRef.current,target=idRef.current;
    const before=current?.projection.turns[0]?.id;
    if(loadingEarlierRef.current||!current||!target||!before||!current.projection.hasMoreHistory)return;
    loadingEarlierRef.current=true;setLoadingEarlier(true);
    try{
      const page=await window.omniEdu?.getXiaozhiHistoryPage({sessionId:target,before,limit:40});
      if(!page||idRef.current!==target)return;
      eventReceiver.current?.seed(page.eventCursors);
      for(const cursor of page.eventCursors)sequences.current.set(cursor.runId,Math.max(sequences.current.get(cursor.runId)||0,cursor.sequence));
      setSnapshot(previous=>{
        if(!previous||previous.projection.threadId!==target)return previous;
        const existing=new Set(previous.projection.turns.map(turn=>turn.id));
        const earlier=page.projection.turns.filter(turn=>!existing.has(turn.id));
        const cursors=new Map((previous.eventCursors||[]).map(cursor=>[`${cursor.runId}:${cursor.generation}`,cursor]));
        for(const cursor of page.eventCursors)cursors.set(`${cursor.runId}:${cursor.generation}`,cursor);
        return {...previous,eventCursors:[...cursors.values()],legacyHistory:previous.legacyHistory||page.legacyHistory,
          projection:{...previous.projection,turns:[...earlier,...previous.projection.turns],hasMoreHistory:page.projection.hasMoreHistory}};
      });
    }catch{
      if(idRef.current===target)setNotice('加载较早的消息失败，请重试。');
      throw Error('history_page_failed');
    }finally{
      loadingEarlierRef.current=false;
      if(active.current)setLoadingEarlier(false);
    }
  }
  useDesktopCommands(command=>{if(visible&&command==='new-chat'&&idRef.current){void fresh().catch(()=>setNotice('无法创建本地对话，请重试。'));return true;}return false;},10);
  useEffect(()=>{
    viewBuffer.current!.flush();
    if(!visible){setSkillsOpen(false);return;}
    const target=idRef.current;if(!target)return;
    // Explicit open already owns the authoritative read when returning to AI.
    if(opening.current&&opening.current===hydration.current!.token())return;
    const token=hydration.current!.token();
    let live=true;setHydrating(true);
    void (async()=>{
      const list=await window.omniEdu?.listAiConversations();if(!live||!active.current||hydration.current!.token()!==token)return;
      if(list)setWorkspace(list);
      if(list&&!list.sessions.some(session=>session.id===target)){if(list.sessions[0])await open(list.sessions[0].id);else await fresh();}
      else await hydrate(target);
    })().catch(()=>{if(live&&active.current&&hydration.current!.token()===token){setRefreshFailed(true);setNotice('无法刷新本地会话，请重试。');}}).finally(()=>{if(live&&active.current&&hydration.current!.token()===token)setHydrating(false);});
    return()=>{live=false;};
  },[visible]);
  useEffect(()=>{if(visible&&id&&!returnHydrating)navigation.flush();},[id,visible,returnHydrating,navigation.flush]);
  useEffect(()=>{
    const target=navigation.target.sessionId;
    if(!target||target===idRef.current||!idRef.current)return;
    if(workspace.sessions.some(session=>session.id===target))void open(target,false);
    else{let live=true;void (async()=>{const list=await window.omniEdu?.listAiConversations();if(!live||!active.current||navigationRef.current.target.sessionId!==target)return;if(list)setWorkspace(list);if(list?.sessions.some(session=>session.id===target))await open(target,false);else{setNotice('该会话已不可用，已从窗口导航中移除。');navigation.reject(target);}})().catch(()=>{if(live)setNotice('无法读取本地会话，请重试。');});return()=>{live=false;};}
  },[navigation.target.sessionId,workspace.sessions]);
  useEffect(() => {
    if(!hasEntered)return;
    let live = true;active.current=true;
    void (async () => {
      const list = await window.omniEdu?.listAiConversations(); if (!live) return;
      if (list) setWorkspace(list);
      let remembered='';try{remembered=localStorage.getItem('xiaozhi.current-session.v1')||'';}catch{/* Fall back to current active list. */}
      const requested=navigationRef.current.target.sessionId;
      if(requested&&!list?.sessions.some(session=>session.id===requested))navigationRef.current.reject(requested);
      const first = list?.sessions.find(session=>session.id===(requested||remembered)) || list?.sessions[0]; if (first) await open(first.id); else await fresh();
    })().catch(() => { if (live) setNotice('无法加载本地对话。'); });
    const applyEvent = (event: XiaozhiAgentEvent) => {
      if (!live || event.sessionId !== idRef.current || event.sequence <= (sequences.current.get(event.runId) || 0)) return;
      hydration.current!.changed(); // In-flight older snapshots must re-read after the burst.
      sequences.current.set(event.runId, event.sequence);
      if (hydration.current!.needsRecovery()) void hydrate(event.sessionId, false).catch(() => undefined);
      viewBuffer.current!.accept(event);
      if (event.kind === 'status') {
        void refreshList();
        if (event.status !== 'running' && !hydration.current!.hasFailed()) void hydrate(event.sessionId).catch(() => undefined);
      }
    };
    const receiver = createEventReceiver({
      list: input => { if (!window.omniEdu) return Promise.reject(Error('configuration')); return window.omniEdu.listXiaozhiEvents(input); },
      apply: applyEvent,
      syncChanged: state=>{if(live)setEventSync(state);},
      unavailable: () => { if (live) { viewBuffer.current!.flush(); setNotice(XIAOZHI_ERRORS.event_persistence); if (!hydration.current!.hasFailed()) void hydrate(idRef.current).catch(()=>undefined); } },
      gapFailure: () => { if (live) { viewBuffer.current!.flush(); if (!hydration.current!.hasFailed()) void hydrate(idRef.current).catch(()=>undefined); } },
    });
    eventReceiver.current = receiver;
    const unsubscribe = window.omniEdu?.onXiaozhiEvent(event => { if (live && event.sessionId === idRef.current) receiver.accept(event); });
    return () => { viewBuffer.current!.flush(); viewBuffer.current!.clear(); live = false; active.current=false; hydration.current!.reset(); receiver.reset(); unsubscribe?.(); };
  }, [hasEntered]);
  async function send(prompt: string,presentation?:XiaozhiMessagePresentation,paperExportIntent?:PaperExportIntent) {
    requireSynchronized();
    if (!id || !window.omniEdu) throw new Error('configuration');
    const sourceTurn=[...(snapshot?.projection.turns||[])].reverse().find(t=>['failed','interrupted'].includes(t.status)&&t.task&&!t.task.goal&&continuationPrompt(t)===prompt);
    const continueTask=sourceTurn?.task?{taskId:sourceTurn.task.id,requirementsVersion:sourceTurn.task.requirementsVersion}:undefined;
    const issue=paperExportSendError(paperExportIntent,{running:snapshot?.running,attachments:attachments.hasAttachments,continuation:!!continueTask});
    if(issue){setNotice(issue);throw new Error(issue);}
    setNotice('');
    setSnapshot(previous => previous ? { ...previous, running: true, projection: { ...previous.projection,
      turns: [...previous.projection.turns, { id: 'pending-send', status: 'running', items: [{ id: 'pending-user', kind: 'message', role: 'user', text: publicMessageText(prompt,presentation) }] }] } } : previous);
    if (!attempt.current || attempt.current.sessionId !== id || attempt.current.prompt !== prompt || !samePaperExportIntent(attempt.current.paperExportIntent,paperExportIntent) || JSON.stringify(attempt.current.presentation)!==JSON.stringify(presentation)||JSON.stringify(attempt.current.continueTask)!==JSON.stringify(continueTask)) attempt.current = { sessionId: id, prompt, ...(paperExportIntent?{paperExportIntent:copyPaperExportIntent(paperExportIntent)}:{}), ...(continueTask?{continueTask}:{}), ...(presentation?{presentation}:{}), commandId: `xicmd_${crypto.randomUUID()}`,
      ...(attachments.selections.length?{attachments:attachments.selections}:{}) };
    let result;
    try{result=await window.omniEdu.startXiaozhi(attempt.current);}catch(error){await hydrate(id).catch(()=>undefined);throw error;}
    if (!result.ok) { attempt.current=undefined;setNotice(XIAOZHI_ERRORS[result.error]); await Promise.all([hydrate(id),attachments.refresh()]); throw new Error(result.error); }
    attempt.current = undefined;
    await Promise.all([hydrate(id), refreshList(),attachments.refresh()]).catch(() => setNotice('消息已接收，暂时无法刷新记录。'));
  }
  const projection = snapshot?.projection;
  const current = projection?.turns.at(-1);
  const compacting = snapshot?.running && snapshot.operation === 'compact';
  async function compact() {
    if (mutationsBlocked() || !id || !snapshot || snapshot.running || compactLock.current) return;
    compactLock.current = true; setCompactBusy(true); setNotice(''); const target = id;
    if (compactAttempt.current?.sessionId !== target) compactAttempt.current = { sessionId: target, commandId: `xicmd_${crypto.randomUUID()}` };
    try {
      const result = await window.omniEdu?.compactXiaozhi(compactAttempt.current);
      if (!result?.ok) setNotice(result ? XIAOZHI_ERRORS[result.error] : '压缩请求未送达，请重试。');
      else compactAttempt.current = undefined;
      await hydrate(target);
    } catch { if (idRef.current === target) setNotice('压缩请求未确认，请重试。'); }
    finally { compactLock.current = false; setCompactBusy(false); }
  }
  const history = (onSelected?: () => void) => <AiConversationSidebar codexStyle inline folders={workspace.folders} sessions={workspace.sessions} activeSessionId={id}
      onOpenSession={async target=>{if(await sessionNavigation.current!.select(target))onSelected?.();}}
      onNewSession={async folder=>{const result=await fresh(folder,'新对话',true);if(result?.activated)onSelected?.();}} onLeaveAi={onLeave}
      onCreateFolder={async name => { const list = await window.omniEdu?.createAiConversationFolder({ name }); if (list) setWorkspace(list); }}
      onMoveSession={async (session, folder) => { const list = await window.omniEdu?.moveAiConversationSession(session, folder); if (list) setWorkspace(list); }}
      onRename={async (target, value) => { const list = target.type === 'folder' ? await window.omniEdu?.renameAiConversationFolder(target.id, { name: value }) : await window.omniEdu?.renameAiConversationSession(target.id, { title: value }); if (list) setWorkspace(list); }}
      onArchive={async target => { const list = target.type === 'folder' ? await window.omniEdu?.archiveAiConversationFolder(target.id) : await window.omniEdu?.archiveAiConversationSession(target.id); if (list) setWorkspace(list); if (target.id === id) await fresh(); }} />;
  return <OfficeComposerState key={id || 'loading'} sessionId={id}><OfficeSynchronization blocked={syncBlocked} isBlocked={mutationsBlocked}><PiWorkbenchBridge data={{folders:workspace.folders,sessions:workspace.sessions,activeSessionId:id,blocked:syncBlocked||!id,
      history,onOpenSession:target=>sessionNavigation.current!.select(target),
      onNewSession:async(folderId,title)=>{requireSynchronized();const result=await fresh(folderId??null,title,true);if(!result)throw Error('对话创建失败，请重试。');return result.activated;},
      onCreateFolder:async name=>{requireSynchronized();const list=await window.omniEdu?.createAiConversationFolder({name});if(!list)throw Error('folder_failed');setWorkspace(list);}
    }}/><OfficeComposerSeed text={navigation.target.sessionId===id?navigation.target.draft:undefined} paperExportIntent={navigation.target.sessionId===id?navigation.target.paperExportIntent:undefined} onConsumed={()=>{if(navigation.target.sessionId===id&&navigation.target.draft!==undefined)navigation.consumeDraft(id,{text:navigation.target.draft,paperExportIntent:navigation.target.paperExportIntent});}}/><PiWorkspaceShell visible={visible} sessionKey={id} onNewChat={()=>void fresh(null)} title={workspace.sessions.find(session=>session.id===id)?.title||'新对话'}
    isEmpty={!projection || isHomeConversation(projection)} notifications={workspaceNotifications(snapshot)}
    fileRequest={fileReveal?.sessionId===id?fileReveal.id:undefined}
    onLeave={onLeave} onSettings={onSettings} onSkills={()=>{if(!mutationsBlocked())setSkillsOpen(true);}}
    files={close=><PiWorkspaceFiles key={`${id}:${snapshot?.workspace?.label||''}`} sessionId={id} changes={snapshot?.changes} officeArtifacts={snapshot?.officeArtifacts} reveal={fileReveal?.sessionId===id?fileReveal:undefined} onClose={close} onChoose={()=>void (async()=>{
      requireSynchronized();const target=id;const result=await window.omniEdu?.selectXiaozhiWorkspace(target);if(result&&!result.ok)setNotice(XIAOZHI_ERRORS[result.error]);else await hydrate(target);
    })().catch(()=>setNotice('无法选择教学工作目录，请重试。'))}/>}
    aside={<PiWorkspaceContext sessionId={id} snapshot={snapshot} compactBusy={compactBusy} compacting={Boolean(compacting)} onCompact={()=>void compact()} onRefresh={()=>hydrate(id)}
      goalControl={<PiGoalControl key={id} sessionId={id} goal={snapshot?.goal} task={snapshot?.task} running={Boolean(snapshot?.running)} disabled={!snapshot||!id||modelSelecting||returnHydrating||attachments.hasAttachments} onRefresh={()=>hydrate(id)} openSignal={goalOpenSignal}/>}/>}
    sidebar={history()}>
    <section className="work-panel ai-chat-surface" data-empty={isHomeConversation(projection)}>
      {snapshot?.legacyHistory && <p className="pi-history-note">旧对话保留供参考；小智从本轮开始使用新的上下文。</p>}
      {snapshot?.interruptedSend && <p className="pi-history-note" role="status">上次消息接收过程中中断。请重新发送，旧请求不会自动继续。</p>}
      {snapshot?.studentContext&&<p className="pi-history-note" data-testid="pi-student-selection">学习对话 · {snapshot.studentContext.label}{snapshot.studentContext.status==='active'?' · 仅使用必要的脱敏学习记录':' · 档案已归档或不可用，无法读取新记录'}</p>}
      {snapshot?.fileWritesEnabled===false&&<p role="status" className="pi-history-note" data-testid="pi-file-writes-paused">小智自动文件生成已暂停，已有文件与对话仍可打开。恢复生成需取消启动停写设置并重启。</p>}
      {notice && <p role="alert" className="pi-history-note">{notice}</p>}
      {snapshot?.taskUnavailable&&<p role="alert" className="pi-history-note">本轮要求记录暂时无法核对，请重新读取会话。</p>}
      {syncBlocked&&<OfficeSynchronizationNotice unavailable={eventSync==='unavailable'||refreshFailed||Boolean(snapshot?.eventPersistence)} refreshing={returnHydrating} onRefresh={()=>void refreshCurrent()}/>}
      <div className="ai-conversation-frame">{projection ? <PiConversationSurface homeHeadingOnly onConfigure={onSettings} visible={visible} projection={projection} onLoadEarlier={loadingEarlier?undefined:loadEarlier} renderAttachments={attachments.renderHistory} renderViewedImages={attachments.renderViewed} running={Boolean(snapshot?.running)} controls={snapshot?.controls} renderApprovals={turnId => snapshot?.approvals?.filter(item => item.runId === turnId).map(approval => approval.permission ? <PiPermissionApproval key={approval.id} approval={approval.permission} onRefresh={() => hydrate(id)}/> : <PiCopyApproval key={approval.id} approval={approval} onDecision={async (approvalId, decision) => {
        const target = id; const result = await window.omniEdu?.decideXiaozhi({ sessionId: target, approvalId, decision });
        if (!result?.ok) throw new Error('decision_failed'); await hydrate(target);
      }} />).concat((snapshot?.changes||[]).filter(item=>item.runId===turnId&&!(snapshot?.deliveries||[]).some(d=>d.files.some(f=>!f.carried&&f.draftId===item.id))).map(change=><PiTextChangeCard key={change.id} sessionId={id} change={change} running={Boolean(snapshot?.running)} onRefresh={()=>hydrate(id)} onOpen={path=>setFileReveal({sessionId:id,id:crypto.randomUUID(),path})}/>)).concat((snapshot?.officeArtifacts||[]).filter(item=>item.runId===turnId&&!(snapshot?.deliveries||[]).some(d=>d.files.some(f=>!f.carried&&f.draftId===item.id))).map(artifact=><PiOfficeArtifactCard key={artifact.id} sessionId={id} artifact={artifact} running={Boolean(snapshot?.running)} onRefresh={()=>hydrate(id)} onOpen={path=>setFileReveal({sessionId:id,id:crypto.randomUUID(),path})}/>)).concat((snapshot?.deliveries||[]).filter(item=>item.runId===turnId).map(delivery=><PiDeliveryBundleCard key={delivery.id} delivery={delivery} sessionId={id} running={Boolean(snapshot?.running)} onRefresh={()=>hydrate(id)} onOpen={path=>setFileReveal({sessionId:id,id:crypto.randomUUID(),path})}/>)).concat((snapshot?.learningReviews||[]).filter(item=>item.runId===turnId).map(review=><PiLearningReview key={review.id} sessionId={id} review={review} onRefresh={()=>hydrate(id)}/>)).concat((snapshot?.questionCollections||[]).filter(item=>item.runId===turnId).map(review=><PiQuestionCollection key={review.id} sessionId={id} review={review} onRefresh={()=>hydrate(id)}/>)).concat((snapshot?.questionReviews||[]).filter(item=>item.runId===turnId&&!item.collectionId).map(review=><PiQuestionReview key={review.id} sessionId={id} review={review} onRefresh={()=>hydrate(id)}/>)).concat((snapshot?.paperReviews||[]).filter(item=>item.runId===turnId).map(review=><PiPaperReview key={review.id} sessionId={id} review={review} running={Boolean(snapshot?.running)} onRefresh={()=>hydrate(id)}/>)).concat((snapshot?.practiceReviews||[]).filter(item=>item.runId===turnId).map(review=><PiPracticeReview key={review.id} sessionId={id} review={review} onRefresh={()=>hydrate(id)}/>)).concat(<PiControlCards key={`controls:${turnId}`} items={snapshot?.controls?.filter(item=>item.runId === turnId) || []} onAnswer={async(controlId,answer)=>{
        const target=id; const result=await window.omniEdu?.answerXiaozhi({sessionId:target,controlId,answer}); if(!result?.ok)throw new Error('answer_failed'); await hydrate(target);
      }} sessionId={id} onMutation={async input=>{
        const target=id; const result=await window.omniEdu?.mutateXiaozhiQueue(input); await hydrate(target);
        if (!result?.ok) throw new Error('queue_mutation_failed');
      }}/>) } /> : <p className="pi-history-note" role="status">正在读取本地对话…</p>}</div>
      <div className="edu-composer-viewport" data-testid="pi-composer-viewport"><OfficeComposer nativeAppearance visible={visible} sessionId={id || 'loading'} status={snapshot?.running ? current?.status || 'running' : current?.status}
        thinkingControl={<PiThinkingPicker key={id} view={models} scope="session" visible={visible} disabled={!snapshot||!id||snapshot.running||modelSelecting||syncBlocked} onChange={choice=>{
          if(mutationsBlocked()||modelLock.current||snapshot?.running||!models?.thinking?.session)return;
          modelLock.current=true;setModelSelecting(true);const target=id;
          void (async()=>{
            const result=await window.omniEdu?.saveXiaozhiThinking({schemaVersion:XIAOZHI_SETTINGS_SCHEMA,sessionId:target,version:models.thinking!.session!.version,choice});
            if(!active.current||idRef.current!==target)return;
            setNotice(result?.ok?'已保存思考配置，下一轮生效。':result?XIAOZHI_SETTINGS_ERRORS[result.error]:'思考配置没有保存，请重试。');
            await hydrate(target);
          })().catch(()=>{if(active.current&&idRef.current===target)setNotice('思考配置没有保存，请重试。');})
            .finally(()=>{modelLock.current=false;if(active.current)setModelSelecting(false);});
        }}/ >}
        showQuickStarts={false}
        taskSummary={<><PiGoalControl headless sessionId={id} goal={snapshot?.goal} task={snapshot?.task} running={Boolean(snapshot?.running)} disabled={!snapshot||!id||modelSelecting||returnHydrating||attachments.hasAttachments||syncBlocked} onRefresh={()=>hydrate(id)} openSignal={goalOpenSignal}/></>}
        skills={snapshot?.skills}
        disabled={!snapshot || !id || modelSelecting || Boolean(snapshot.studentContext&&snapshot.studentContext.status!=='active')} model={projection?.model || 'DeepSeek'} models={models?.models.map(item => ({ id: item.id, label: item.id })) || [{ id: projection?.model || 'DeepSeek', label: projection?.model || 'DeepSeek' }]}
        onModelChange={!models?.sessionModel || models.sessionModel.locked || models.locked ? undefined : model => {
          if (mutationsBlocked() || modelLock.current || snapshot?.running) return;
          modelLock.current = true; setModelSelecting(true); const target = id;
          void (async () => {
            const result = await window.omniEdu?.selectXiaozhiModel({ schemaVersion: XIAOZHI_SETTINGS_SCHEMA, sessionId: target, version: models.sessionModel!.version, model });
            if (!active.current || idRef.current !== target) return;
            if (!result?.ok) setNotice(result ? XIAOZHI_SETTINGS_ERRORS[result.error] : '模型没有切换，请重试。');
            await hydrate(target);
          })().catch(() => { if (active.current && idRef.current === target) setNotice('模型没有切换，请重试。'); })
            .finally(() => { modelLock.current = false; if (active.current) setModelSelecting(false); });
        }}
        onQueue={compacting ? undefined : async(text,mode)=>{
          requireSynchronized();
          const target=id; if(!queueAttempt.current || queueAttempt.current.sessionId !== target || queueAttempt.current.text !== text || queueAttempt.current.mode !== mode)queueAttempt.current={sessionId:target,text,mode,commandId:`xicmd_${crypto.randomUUID()}`};
          const result=await window.omniEdu?.queueXiaozhi(queueAttempt.current); if(!result?.ok){setNotice(result?XIAOZHI_ERRORS[result.error]:'补充未发送。');throw new Error('queue_failed');}queueAttempt.current=undefined;await hydrate(target);
        }}
        attachments={attachments.cards} hasAttachments={attachments.hasAttachments} sendBlocked={attachments.sendBlocked} attachDisabled={attachments.busy||Boolean(snapshot?.running)||syncBlocked} onAttach={()=>{if(!mutationsBlocked())void attachments.choose();}} onFilesSelected={files=>{if(!mutationsBlocked())void attachments.importFiles(files);}}
        onPermissions={onSettings} permissionMode={permissionMode} onPermissionModeChange={setPermissionMode}
        onNewChat={()=>void fresh(null)} onOpenGoal={()=>setGoalOpenSignal({token:Date.now(),sessionId:id})} onCompact={()=>void compact()} onSkills={()=>{if(!mutationsBlocked())setSkillsOpen(true);}}
        attachLabel="添加本地附件" permissionLabel={snapshot?.workspace ? '工作目录 · 写入需确认' : '教师资料 · 只读'} onWorkspace={() => { void (async () => {
          requireSynchronized();setNotice(''); const target = id; const result = await window.omniEdu?.selectXiaozhiWorkspace(target);
          if (result && !result.ok) setNotice(XIAOZHI_ERRORS[result.error]); else await hydrate(target);
        })().catch(() => setNotice('无法选择教学工作目录，请重试。')); }} onSubmit={send} onStop={async () => { viewBuffer.current!.flush(); const result = await window.omniEdu?.stopXiaozhi(id); if (!result?.ok) throw new Error('stop_failed'); }} />
      </div><PiHomeSuggestions visible={isHomeConversation(projection)} />
    </section>
    {attachments.modal}
    {skillsOpen && <PiSkillSettings running={Boolean(snapshot?.running)} onClose={() => setSkillsOpen(false)} onChanged={() => hydrate(id)} />}
  </PiWorkspaceShell></OfficeSynchronization></OfficeComposerState>;
}
