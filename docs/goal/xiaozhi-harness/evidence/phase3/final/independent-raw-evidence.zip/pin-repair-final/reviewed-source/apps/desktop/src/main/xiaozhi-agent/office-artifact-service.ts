import {PAPER_C2_OFFICE_SCHEMA} from '../../shared/paper-export';
import {isClassroomOfficeSchema,validClassroomOfficeFormat} from '../../shared/classroom-export';
import {TEACHING_LESSON_OFFICE_SCHEMA} from '../../shared/teaching-lesson-export';
import {assertFileWritesEnabled} from './file-write-policy';
import {applyPresentationEdit,validPresentationEditProposal} from '../../shared/xiaozhi-presentation-edit';
import fs from 'node:fs';
import {assertCurrentPermissionSignal} from './permissions/current';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import {removeOwnedFileStage,withOwnedFileStage} from './owned-file-stage';
import {withFileMutationQueue} from '@earendil-works/pi-coding-agent';
import {authorizedWorkspace,approvedFile,workspaceHash} from './workspace-authority';
import {fileVersion} from './workspace-files';
import {OFFICE_ARTIFACT_SCHEMA,officeRelativePath,validOfficeProposal,type OfficeArtifactDecision,type OfficeArtifactSource} from '../../shared/xiaozhi-office-artifacts';
import {validOfficeDraft,validOfficeDraftFormat,isPresentationDraft,isMathOfficeSchema,isPaperOfficeDraft,type OfficeDraft} from '../../shared/xiaozhi-office-draft';
import {isRichPaperOfficeSchema} from '../../shared/paper-export';
import {createOfficeArtifactState,officeSha,officeSummary,type PrivateOfficeArtifact} from './office-artifact-state';
type Ledger=ReturnType<typeof createOfficeArtifactState>;
const check=(signal?:AbortSignal)=>{if(signal?.aborted)throw new Error('cancelled');};
function file(root:string,relative:string){
 if(!officeRelativePath(relative))throw new Error('permission_denied');
 return approvedFile(root,relative);
}
function target(root:string,row:Pick<PrivateOfficeArtifact,'path'|'format'>){
 const value=file(root,row.path);
 if(!row.path.toLowerCase().endsWith('.'+row.format))throw new Error('invalid_input');
 const parent=fs.lstatSync(path.dirname(value));
 if(!parent.isDirectory()||parent.isSymbolicLink())throw new Error('permission_denied');
 return value;
}
function capture(root:string,relative:string,version?:string){
 const value=file(root,relative),stat=fs.lstatSync(value);
 if(!stat.isFile()||stat.isSymbolicLink()||stat.nlink!==1)throw new Error('permission_denied');
 if(stat.size>50*1048576)throw new Error('too_large');
 if(version&&fileVersion(stat)!==version)throw new Error('conflict');
 const handle=fs.openSync(value,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));
 try{
  const opened=fs.fstatSync(handle);if(!opened.isFile()||opened.nlink!==1||fileVersion(opened)!==fileVersion(stat))throw new Error('conflict');
  const bytes=fs.readFileSync(handle),post=fs.fstatSync(handle);
  if(bytes.length!==stat.size||fileVersion(post)!==fileVersion(stat)||fileVersion(fs.lstatSync(file(root,relative)))!==fileVersion(stat))throw new Error('conflict');
  return {version:fileVersion(stat),sha256:officeSha(bytes)};
 }finally{fs.closeSync(handle);}
}
function sourceVersions(root:string,row:PrivateOfficeArtifact){
 return row.sources.every(source=>{const v=capture(root,source.path,source.version);return v.sha256===source.sha256;});
}
function missing(root:string,row:Pick<PrivateOfficeArtifact,'path'|'format'>){return !fs.existsSync(target(root,row));}
/** Main application glue around original Pi mutation queue and existing Office generators. */
export function createOfficeArtifactService(options:{state:Ledger;dataRoot:string;workspace:(sessionId:string)=>Promise<string|null>;paperWorkspace?:(sessionId:string,hash?:string)=>Promise<string|null>;isCurrent:(sessionId:string,runId:string)=>boolean;
 validateClassroomDraft?:(sessionId:string,draft:OfficeDraft)=>Promise<void>;
 commitClassroomDraft?:(sessionId:string,draft:OfficeDraft,install:()=>void)=>Promise<void>;
 validateLessonDraft?:(sessionId:string,draft:OfficeDraft)=>Promise<void>;
 commitLessonDraft?:(sessionId:string,draft:OfficeDraft,install:()=>void)=>Promise<void>;
 validatePaperDraft?:(sessionId:string,draft:OfficeDraft)=>Promise<void>;
 commitPaperDraft?:(sessionId:string,draft:OfficeDraft,install:()=>void)=>Promise<void>;
  recoverPaperDraft?:<T>(sessionId:string,draft:OfficeDraft,assertCurrent:()=>void,action:(ledger:Ledger)=>Promise<T>,assertAuthority:()=>Promise<void>)=>Promise<T>;
 resolvePaperImages?:(sessionId:string,draft:OfficeDraft,signal?:AbortSignal)=>Promise<Map<string,Buffer>>;
 generate?: (format:PrivateOfficeArtifact['format'],draft:OfficeDraft,options:{dataRoot:string;signal?:AbortSignal;images?:ReadonlyMap<string,Buffer>})=>Promise<Buffer>;
 afterStage?:(stage:'prepared'|'intent'|'file'|'fact')=>Promise<void>;onState?:(summary:ReturnType<typeof officeSummary>)=>void}){
 const {state}=options;
 const validatePaper=async(sessionId:string,draft:OfficeDraft)=>{if(draft.schemaVersion===TEACHING_LESSON_OFFICE_SCHEMA){if(!options.validateLessonDraft||!options.commitLessonDraft)throw Error('permission_denied');await options.validateLessonDraft(sessionId,draft);}if(isClassroomOfficeSchema(draft.schemaVersion)){if(!options.validateClassroomDraft||!options.commitClassroomDraft)throw Error('permission_denied');await options.validateClassroomDraft(sessionId,draft);}if(isPaperOfficeDraft(draft)){if(!options.validatePaperDraft||!options.commitPaperDraft)throw new Error('permission_denied');await options.validatePaperDraft(sessionId,draft);}};
 const images=async(sessionId:string,draft:OfficeDraft,signal?:AbortSignal)=>{
  if(!isRichPaperOfficeSchema(draft.schemaVersion))return undefined;
  if(!options.resolvePaperImages)throw new Error('permission_denied');return options.resolvePaperImages(sessionId,draft,signal);
 };
 const notify=(row:PrivateOfficeArtifact)=>{try{options.onState?.(officeSummary(row));}catch{/* A UI lifetime cannot own file execution. */}};
 const current=(row:Pick<PrivateOfficeArtifact,'sessionId'|'runId'>,signal?:AbortSignal)=>{check(signal);if(!options.isCurrent(row.sessionId,row.runId))throw new Error('permission_denied');};
 async function authority(sessionId:string,row?:Pick<PrivateOfficeArtifact,'draft'>&Partial<Pick<PrivateOfficeArtifact,'sessionId'|'workspaceHash'>>){
  const raw=row&&(isPaperOfficeDraft(row.draft)||isClassroomOfficeSchema(row.draft.schemaVersion))&&options.paperWorkspace?await options.paperWorkspace(sessionId,row.workspaceHash):await options.workspace(sessionId);if(!raw)throw new Error('permission_denied');
  const root=authorizedWorkspace(raw,options.dataRoot);
  if(row&&(row.sessionId!==undefined&&row.sessionId!==sessionId||row.workspaceHash!==undefined&&row.workspaceHash!==workspaceHash(root)))throw new Error('permission_denied');return root;
 }
 async function owned(sessionId:string,id:string){const row=await state.get(id);if(!row||row.sessionId!==sessionId)throw new Error('permission_denied');return row;}
  async function recheck(row:PrivateOfficeArtifact,root:string,signal?:AbortSignal,checkPaper=true,assertCurrent=()=>current(row,signal)){
   assertCurrent();if(checkPaper){await validatePaper(row.sessionId,row.draft);assertCurrent();}
  if(row.parentArtifactId){
    const parent=await state.parent(row.parentArtifactId);assertCurrent();const source=row.sources.find(s=>s.kind==='parent_artifact');
   if(!parent||!source||parent.session_id!==row.sessionId||parent.content_hash!==source.sha256||parent.file_path!==file(root,source.path))throw new Error('conflict');
  }
   const active=await authority(row.sessionId,row);assertCurrent();
  if(root!==active)throw new Error('permission_denied');return active;
 }
 async function conflict(row:PrivateOfficeArtifact){return officeSummary(await state.transition(row,[row.state],'conflict'));}
 function compatible(root:string,row:PrivateOfficeArtifact){try{return missing(root,row)&&sourceVersions(root,row);}catch(error){if((error as Error).message==='permission_denied')throw error;return false;}}
 function install(root:string,row:PrivateOfficeArtifact,temporary:string,signal?:AbortSignal){
  assertCurrentPermissionSignal();
  assertFileWritesEnabled();
  if(!row.output||!row.outputHash)throw new Error('configuration');
  current(row,signal);
  if(workspaceHash(authorizedWorkspace(root,options.dataRoot))!==row.workspaceHash)throw new Error('permission_denied');
  if(!compatible(root,row))throw new Error('conflict');
  fs.linkSync(temporary,target(root,row));fs.unlinkSync(temporary);
 }
 function outputMatches(root:string,row:PrivateOfficeArtifact){
  const destination=target(root,row);
  if(destination!==row.resultPath||!row.output||!row.outputHash)throw new Error('configuration');
  if(!fs.existsSync(destination))return 'absent' as const;
  return capture(root,row.path).sha256===row.outputHash?'same' as const:'different' as const;
 }
 return {
  async preparePresentationEdit(sessionId:string,runId:string,raw:unknown,signal?:AbortSignal){
   current({sessionId,runId},signal);if(!validPresentationEditProposal(raw))throw Error('invalid_input');
   const parent=await state.byArtifact(sessionId,raw.parentArtifactId);current({sessionId,runId},signal);
   if(!parent)throw Error('permission_denied');
   if(parent.format!=='pptx'||!isPresentationDraft(parent.draft))throw Error('invalid_input');
   const root=await authority(sessionId,parent);current({sessionId,runId},signal);
   const captured=capture(root,parent.path,raw.presentationEdit.version);
   if(captured.sha256!==parent.outputHash)throw Error('conflict');
   const draft=applyPresentationEdit(parent.draft,raw.presentationEdit);
   if(isDeepStrictEqual(draft,parent.draft))return {unchanged:{schemaVersion:'xiaozhi.presentation-edit-result.v1' as const,success:true as const,outcome:'unchanged' as const,format:'pptx' as const,artifactId:raw.parentArtifactId,file:parent.path,version:captured.version,sha256:captured.sha256,draftHash:parent.draftHash,
    message:'所提局部修改与原内容一致，保留原成果；本次未创建草稿、新版本或新文件，无需再次确认。不要声称已生成目标文件，也不表示重新完成交付检查。'}};
   return {path:raw.path,format:'pptx' as const,parentArtifactId:raw.parentArtifactId,
    draft,sources:[{path:parent.path,version:captured.version}]};
  },
  async propose(sessionId:string,runId:string,callId:string,raw:unknown,signal?:AbortSignal){
   assertFileWritesEnabled();
   current({sessionId,runId},signal);if(!validOfficeProposal(raw)||!callId||callId.length>128)throw new Error('invalid_input');
   const input=JSON.parse(JSON.stringify(raw)) as typeof raw,root=await authority(sessionId,{draft:input.draft});current({sessionId,runId},signal);
   if(isPresentationDraft(input.draft)&&!isMathOfficeSchema(input.draft.schemaVersion)){const {presentationPageLayout}=await import('./presentation-layout');input.draft.sections.forEach(section=>presentationPageLayout(section));current({sessionId,runId},signal);}
   if(isClassroomOfficeSchema(input.draft.schemaVersion)&&(input.sources.length||input.parentArtifactId||!validClassroomOfficeFormat(input.draft.schemaVersion,input.format)))throw Error('invalid_input');
   if(isPaperOfficeDraft(input.draft)&&(input.sources.length||input.parentArtifactId||!['docx','pdf'].includes(input.format)))throw new Error('invalid_input');
   if(input.draft.schemaVersion===TEACHING_LESSON_OFFICE_SCHEMA&&(input.sources.length||input.parentArtifactId))throw Error('invalid_input');
   await validatePaper(sessionId,input.draft);current({sessionId,runId},signal);
   await images(sessionId,input.draft,signal);current({sessionId,runId},signal);
   const inputHash=officeSha(JSON.stringify(input)),existing=await state.call(sessionId,runId,callId);current({sessionId,runId},signal);
   if(existing){if(existing.inputHash!==inputHash||existing.workspaceHash!==workspaceHash(root))throw new Error('conflict');return officeSummary(existing);}
   if(!missing(root,input))throw new Error('conflict');
   const sources:OfficeArtifactSource[]=input.sources.map(s=>({kind:'workspace_file',sourceId:'',path:s.path,...capture(root,s.path,s.version)}));
   if(input.parentArtifactId){
    const parent=await state.parent(input.parentArtifactId);current({sessionId,runId},signal);
    if(!parent||parent.session_id!==sessionId)throw new Error('permission_denied');
    const relative=path.relative(root,String(parent.file_path)).replace(/\\/g,'/');
    if(relative===input.path)throw new Error('invalid_input');
    const captured=capture(root,relative);
    if(captured.sha256!==parent.content_hash||file(root,relative)!==String(parent.file_path))throw new Error('conflict');
    const existing=sources.findIndex(s=>s.path.toLowerCase()===relative.toLowerCase());
    const parentSource:OfficeArtifactSource={kind:'parent_artifact',sourceId:input.parentArtifactId,path:relative,...captured};
    // A reread parent is both the input and the previous artifact. Preserve its
    // captured version/hash in one lineage row rather than rejecting that task.
    if(existing>=0){
     if(sources[existing].version!==captured.version||sources[existing].sha256!==captured.sha256)throw new Error('conflict');
     sources[existing]=parentSource;
    }else sources.push(parentSource);
   }
   const rootNow=await authority(sessionId,{draft:input.draft});current({sessionId,runId},signal);if(rootNow!==root)throw new Error('permission_denied');
   const row=await state.create({sessionId,runId,callId,path:input.path,format:input.format,draft:input.draft,sources,parentArtifactId:input.parentArtifactId??null,inputHash,workspaceHash:workspaceHash(root)});
   try{await recheck(row,root,signal);}catch(error){await state.transition(row,['pending'],'interrupted');throw error;}
   return officeSummary(row);
  },
  async review(sessionId:string,id:string){
   const row=await owned(sessionId,id),root=await authority(sessionId,row);target(root,row);
   if(isRichPaperOfficeSchema(row.draft.schemaVersion))await validatePaper(sessionId,row.draft);
   const resolved=await images(sessionId,row.draft);await authority(sessionId,row);
   return {...officeSummary(row),draft:row.draft,sources:row.sources,parentArtifactId:row.parentArtifactId,...(resolved?{images:[...resolved].map(([assetId,bytes])=>({assetId,sha256:officeSha(bytes),dataUrl:'data:image/png;base64,'+bytes.toString('base64')}))}:{})};
  },
  async candidate(sessionId:string,id:string,signal?:AbortSignal){
   let row=await owned(sessionId,id);const root=await authority(sessionId,row);current(row,signal);await recheck(row,root,signal);
   if(row.state!=='pending')throw Error('conflict');
   if(!row.output){
    const generate=options.generate??(await import('./office-generator')).generateOfficeDocument;
    const resolved=await images(sessionId,row.draft,signal),bytes=await generate(row.format,row.draft,{dataRoot:options.dataRoot,signal,images:resolved});
    await recheck(row,root,signal);row=await state.cacheCandidate(row,bytes);
   }
   return{path:row.path,bytes:row.output!,version:row.draftHash,candidate:{kind:'office' as const,id:row.id,revision:row.revision}};
  },
  async revise(sessionId:string,id:string,revision:number,draft:unknown){
   if(!Number.isSafeInteger(revision)||revision<0||!validOfficeDraft(draft))throw new Error('invalid_input');
   const content=JSON.parse(JSON.stringify(draft)) as OfficeDraft,row=await owned(sessionId,id),root=await authority(sessionId,row);current(row);
   return withFileMutationQueue(target(root,row),async()=>{
    const latest=await owned(sessionId,id);await recheck(latest,root);
    if(!validOfficeDraftFormat(content.schemaVersion,latest.format))throw Error('invalid_input');
    if(isPresentationDraft(content)){if(latest.format!=='pptx')throw Error('invalid_input');const {presentationPageLayout}=await import('./presentation-layout');if(!isMathOfficeSchema(content.schemaVersion))content.sections.forEach(section=>presentationPageLayout(section));current(latest);}
    if(isClassroomOfficeSchema(latest.draft.schemaVersion)&&(content.schemaVersion!==latest.draft.schemaVersion||!('classroomSource'in content)||JSON.stringify(content.classroomSource)!==JSON.stringify('classroomSource'in latest.draft?latest.draft.classroomSource:undefined)))throw Error('conflict');
    if(!isClassroomOfficeSchema(latest.draft.schemaVersion)&&isClassroomOfficeSchema(content.schemaVersion))throw Error('permission_denied');
    if(latest.draft.schemaVersion===TEACHING_LESSON_OFFICE_SCHEMA&&(content.schemaVersion!==TEACHING_LESSON_OFFICE_SCHEMA||!isDeepStrictEqual(content.lessonSource,latest.draft.lessonSource)))throw Error('conflict');
    if(latest.draft.schemaVersion!==TEACHING_LESSON_OFFICE_SCHEMA&&content.schemaVersion===TEACHING_LESSON_OFFICE_SCHEMA)throw Error('permission_denied');
    if(isPaperOfficeDraft(latest.draft)&&(!isPaperOfficeDraft(content)||content.schemaVersion!==latest.draft.schemaVersion||JSON.stringify(content.paperSource)!==JSON.stringify(latest.draft.paperSource)))throw new Error('conflict');
    if(!isPaperOfficeDraft(latest.draft)&&isPaperOfficeDraft(content))throw new Error('permission_denied');
    await validatePaper(sessionId,content);current(latest);
    if(latest.revision!==revision||latest.state!=='pending')throw new Error('conflict');
    if(!compatible(root,latest))return conflict(latest);
    return officeSummary(await state.transition(latest,['pending'],'pending',{draft:content}));
   });
  },
  async decide(input:OfficeArtifactDecision,recoveryLease?:()=>void){
   if(input?.action==='approve')assertFileWritesEnabled();
   if(!input||input.schemaVersion!==OFFICE_ARTIFACT_SCHEMA||Object.keys(input).some(k=>!['schemaVersion','sessionId','draftId','revision','action','imagesReviewed'].includes(k))
    ||!Number.isSafeInteger(input.revision)||input.revision<0||!['approve','reject','verify'].includes(input.action)||(input.imagesReviewed!==undefined&&input.imagesReviewed!==true))throw new Error('invalid_input');
   const lease=input.action==='verify'?recoveryLease:undefined;lease?.();
   const row=await owned(input.sessionId,input.draftId);lease?.();
   const root=await authority(input.sessionId,row);lease?.();
   return withFileMutationQueue(target(root,row),async()=>{
    lease?.();const latest=await owned(input.sessionId,input.draftId);lease?.();
    const active=await authority(input.sessionId,latest);lease?.();
    if(root!==active)throw new Error('permission_denied');if(latest.revision!==input.revision)throw new Error('conflict');
    if(input.action==='verify'){
     if(latest.state!=='uncertain')throw new Error('conflict');
     if(latest.draft.schemaVersion===PAPER_C2_OFFICE_SCHEMA){
      // An idle recovery owns the host settings lease, not the historical run.
      // Publish through the source transaction's ledger, never the outer writer.
      if(!lease||!options.recoverPaperDraft)throw new Error('permission_denied');
      await recheck(latest,root,undefined,true,lease);lease();
      let verifiedOutcome:ReturnType<typeof outputMatches>|undefined;
      const assertAuthority=async()=>{
       await recheck(latest,root,undefined,false,lease);lease();
       if(verifiedOutcome!==undefined&&outputMatches(root,latest)!==verifiedOutcome)throw new Error('conflict');
      };
      const recovered=await options.recoverPaperDraft(latest.sessionId,latest.draft,lease,async ledger=>{
       await assertAuthority();lease();const outcome=verifiedOutcome=outputMatches(root,latest);lease();
       const result=await ledger.transition(latest,['uncertain'],outcome==='same'?'saved':outcome==='absent'?'interrupted':'conflict');lease();return result;
      },assertAuthority);return officeSummary(recovered);
     }
     if(latest.staging){removeOwnedFileStage(target(root,latest),latest.staging);await state.storeStage(latest,null);}
     const outcome=outputMatches(root,latest);
     return officeSummary(await state.transition(latest,['uncertain'],outcome==='same'?'saved':outcome==='absent'?'interrupted':'conflict'));
    }
    await recheck(latest,root,undefined,input.action!=='reject');if(latest.state!=='pending')throw new Error('conflict');
    if(input.action==='approve'&&isClassroomOfficeSchema(latest.draft.schemaVersion)){if(input.imagesReviewed!==true)throw Error('invalid_input');}
    else if(input.action==='approve'&&isRichPaperOfficeSchema(latest.draft.schemaVersion)&&latest.draft.sections.some(s=>s.figures?.length)){if(input.imagesReviewed!==true)throw new Error('invalid_input');await images(input.sessionId,latest.draft);current(latest);}
    else if(input.imagesReviewed!==undefined)throw new Error('invalid_input');
    if(input.action==='approve'&&!compatible(root,latest))return conflict(latest);
    return officeSummary(await state.transition(latest,['pending'],input.action==='approve'?'approved':'rejected',input.imagesReviewed?{imagesReviewed:true}:{}));
   });
  },
  async apply(sessionId:string,id:string,signal?:AbortSignal){
   assertFileWritesEnabled();
   const row=await owned(sessionId,id),root=await authority(sessionId,row);current(row,signal);
   return withFileMutationQueue(target(root,row),async()=>{
    let latest=await owned(sessionId,id);await recheck(latest,root,signal);
    if(latest.state!=='approved')throw new Error('conflict');if(!compatible(root,latest))return conflict(latest);
    latest=await state.transition(latest,['approved'],'generating');
    notify(latest);
    try{
     const generate=options.generate??(await import('./office-generator')).generateOfficeDocument;
     await recheck(latest,root,signal);
     const resolved=await images(sessionId,latest.draft,signal);await recheck(latest,root,signal);
     const bytes=latest.output??await generate(latest.format,latest.draft,{dataRoot:options.dataRoot,signal,images:resolved});
     await recheck(latest,root,signal);
     if(!compatible(root,latest))return conflict(latest);
     latest=await state.transition(latest,['generating'],'prepared',{output:bytes,resultPath:target(root,latest)});
     notify(latest);
     await options.afterStage?.('prepared');await recheck(latest,root,signal);
     latest=await state.transition(latest,['prepared'],'committing');
     notify(latest);
     await options.afterStage?.('intent');await recheck(latest,root,signal);
     await withOwnedFileStage(target(root,latest),latest.output!,stage=>state.storeStage(latest,stage),async temporary=>{
      if(isClassroomOfficeSchema(latest.draft.schemaVersion)){if(!options.commitClassroomDraft)throw Error('permission_denied');await options.commitClassroomDraft(sessionId,latest.draft,()=>install(root,latest,temporary,signal));}
      else if(latest.draft.schemaVersion===TEACHING_LESSON_OFFICE_SCHEMA){if(!options.commitLessonDraft)throw Error('permission_denied');await options.commitLessonDraft(sessionId,latest.draft,()=>install(root,latest,temporary,signal));}
      else if(isPaperOfficeDraft(latest.draft)){if(!options.commitPaperDraft)throw new Error('permission_denied');await options.commitPaperDraft(sessionId,latest.draft,()=>install(root,latest,temporary,signal));}
      else install(root,latest,temporary,signal);
     });
     await options.afterStage?.('file');
     // The file may already exist; cancellation must retain an uncertain effect,
     // rather than granting a late continuation permission to publish saved facts.
     current(latest,signal);
     if(outputMatches(root,latest)!=='same')throw new Error('conflict');
     const saved=await state.transition(latest,['committing'],'saved');notify(saved);await options.afterStage?.('fact');return officeSummary(saved);
    }catch(error){
     const pending=await state.get(id);
     if(pending&&['generating','prepared','committing'].includes(pending.state))await state.transition(pending,[pending.state],pending.state==='committing'?'uncertain':signal?.aborted||(error as Error).message==='cancelled'?'interrupted':(error as Error).message==='conflict'?'conflict':'failed');
     throw error;
    }
   });
  }
 };
}
