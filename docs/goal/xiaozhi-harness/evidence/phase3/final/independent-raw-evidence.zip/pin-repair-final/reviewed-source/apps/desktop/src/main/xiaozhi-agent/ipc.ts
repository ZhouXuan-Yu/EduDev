import {registerDeliveryCheckIpc} from './checks/api';
import {registerDiagnosticsIpc} from './diagnostics/api';
import {registerPermissionIpc} from './permissions/api';
import {registerEnvironmentIpc} from './environment/api';
import {createManagedTools} from '../managed-tools/service';
import {registerManagedToolIpc} from '../managed-tools/api';
import {registerScienceExportIpc} from './science-export-api';
import {registerTaskIpc} from './tasks/api';
import { registerMcpIpc } from './mcp-api';
import { registerDecisionIpc } from './decisions/api';
import {registerTeacherCandidateIpc} from '../education/teacher-candidate-api';
import {registerOriginalQuestionIpc} from '../education/original-question-api';
import {registerPaperIpc} from '../education/paper-api';
import {registerPaperBasketIpc} from '../education/paper-basket-api';
import {validPaperOutput} from '../../shared/paper-export';
import {registerPracticeReviewIpc} from '../education/practice-review-api';
import type { IpcMain, BrowserWindow } from 'electron';
import { app, dialog, safeStorage, shell } from 'electron';
import {registerWebIpc} from './web-api';
import {registerAttachmentIpc} from './attachment-api';
import fs from 'node:fs';
import path from 'node:path';
import type { OmniEduStore } from '../db';
import { createXiaozhiProductionHost } from './production-host';
import { registerSkillManagementIpc } from './skill-management-api';
import { registerWorkspaceFileIpc } from './workspace-file-api';
import { registerModelSettingsIpc } from './model-settings-api';
import { registerTextChangeIpc } from './text-change-api';
import {registerOfficeArtifactIpc} from './office-artifact-api';
import {registerLearningReviewIpc} from '../education/learning-review-api';
import {registerClassroomIpc} from '../education/classroom-api';
import {registerQuestionReviewIpc} from '../education/question-review-api';
import {registerQuestionContextIpc} from '../education/question-context-api';
import {registerStudentTrainingIpc} from '../education/student-training-api';
import type { RuntimeAuthority } from './runtime-authority';
import {isBackgroundAcceptance} from './runtime-authority';

export function registerXiaozhiIpc(options: { ipcMain: IpcMain; store: OmniEduStore; dataRoot: string; window: () => BrowserWindow | undefined; authority: RuntimeAuthority }) {
  const commitDelay = !app.isPackaged && process.env.OMNI_EDU_E2E_DIALOG_MODE === '1'
    ? Math.min(30000, Math.max(0, Number(process.env.OMNI_EDU_E2E_PI_COMPACT_COMMIT_DELAY_MS) || 0)) : 0;
  const testing = !app.isPackaged && process.env.OMNI_EDU_E2E_DIALOG_MODE === '1';
  const learningStop=process.env.OMNI_EDU_E2E_PI_LEARNING_CUT==='stop'&&isBackgroundAcceptance({packaged:app.isPackaged,env:process.env,dataRoot:options.dataRoot,profileRoot:app.getPath('userData'),repoRoot:process.env.OMNI_EDU_REPO_ROOT||''});let learningStopHeld=false;
  const textCut = testing ? process.env.OMNI_EDU_E2E_PI_TEXT_CUT_STAGE : undefined;
  const officeCut=testing&&isBackgroundAcceptance({packaged:app.isPackaged,env:process.env,dataRoot:options.dataRoot,profileRoot:app.getPath('userData'),repoRoot:process.env.OMNI_EDU_REPO_ROOT||''})?process.env.OMNI_EDU_E2E_PI_OFFICE_CUT_STAGE:undefined;
  const testWindow = testing ? Number(process.env.OMNI_EDU_E2E_PI_CONTEXT_WINDOW) : 0;
  const autoDelay = testing ? Math.min(30000, Math.max(0, Number(process.env.OMNI_EDU_E2E_PI_AUTO_COMMIT_DELAY_MS) || 0)) : 0;
  const queueDelay = testing ? Math.min(30000, Math.max(0, Number(process.env.OMNI_EDU_E2E_PI_QUEUE_DISPATCH_DELAY_MS) || 0)) : 0;
  const autoCompaction = testing && process.env.OMNI_EDU_E2E_PI_AUTO_COMPACTION !== undefined
    ? process.env.OMNI_EDU_E2E_PI_AUTO_COMPACTION === '1' : process.env.OMNI_EDU_PI_AUTO_COMPACTION !== '0';
  const managedTools=createManagedTools({root:path.join(options.dataRoot,'managed-tools'),...(testing&&isBackgroundAcceptance({packaged:app.isPackaged,env:process.env,dataRoot:options.dataRoot,profileRoot:app.getPath('userData'),repoRoot:process.env.OMNI_EDU_REPO_ROOT||''})&&process.env.OMNI_EDU_E2E_MANAGED_TOOLS_NO_BUILTIN==='1'?{bundledWasm:null}:{})});
  const host = createXiaozhiProductionHost({ ...options,managedTools, enabled: options.authority.mode === 'pi', autoCompaction,
    ...(testing&&process.env.OMNI_EDU_E2E_PI_MODEL_WAIT==='1'&&isBackgroundAcceptance({packaged:app.isPackaged,env:process.env,dataRoot:options.dataRoot,profileRoot:app.getPath('userData'),repoRoot:process.env.OMNI_EDU_REPO_ROOT||''})?{beforeModelDelivery:async()=>{
      const held=path.join(options.dataRoot,'.e2e-model-wait');
      if(fs.existsSync(held))return;
      fs.writeFileSync(held,'await-before-delivery');
      while(!fs.existsSync(path.join(options.dataRoot,'.e2e-model-release')))await new Promise(resolve=>setTimeout(resolve,50));
      fs.writeFileSync(path.join(options.dataRoot,'.e2e-model-returned'),'late-await-returned');
    }}:{}),
    ...(testing&&process.env.OMNI_EDU_E2E_PI_ORIGINAL_CUT==='1'&&isBackgroundAcceptance({packaged:app.isPackaged,env:process.env,dataRoot:options.dataRoot,profileRoot:app.getPath('userData'),repoRoot:process.env.OMNI_EDU_REPO_ROOT||''})?{afterOriginalReviewWrite:async()=>{fs.writeFileSync(path.join(options.dataRoot,'.e2e-original-uncommitted'),'uncommitted');await new Promise(resolve=>setTimeout(resolve,30000));}}:{}),
    ...(testing&&process.env.OMNI_EDU_E2E_PI_LEARNING_CUT==='1'?{afterLearningReviewWrite:async()=>{fs.writeFileSync(path.join(options.dataRoot,'.e2e-pi-learning-uncommitted'),'uncommitted');await new Promise(resolve=>setTimeout(resolve,30000));}}:{}),
    ...(learningStop?{afterLearningReviewWrite:async(isCurrent:()=>boolean)=>{if(learningStopHeld)return;learningStopHeld=true;fs.writeFileSync(path.join(options.dataRoot,'.e2e-pi-learning-uncommitted'),'uncommitted');const end=Date.now()+30000;while(isCurrent()&&Date.now()<end)await new Promise(resolve=>setTimeout(resolve,40));if(isCurrent())throw new Error('cancelled');}}:{}),
    ...(['prepared','intent','file','fact'].includes(officeCut||'')?{afterOfficeArtifactStage:async(stage:'prepared'|'intent'|'file'|'fact')=>{
      if(stage!==officeCut)return;fs.writeFileSync(path.join(options.dataRoot,`.e2e-pi-office-${stage}`),'durable-stage-reached');
      if(process.env.OMNI_EDU_E2E_PI_OFFICE_RELEASE==='1'){
        const deadline=Date.now()+30000;
        while(!fs.existsSync(path.join(options.dataRoot,'.e2e-pi-office-release'))&&Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,25));
        fs.writeFileSync(path.join(options.dataRoot,'.e2e-pi-office-returned'),'owned-cut-returned');
      }else await new Promise(resolve=>setTimeout(resolve,30000));
    }}:{}),
    ...(['intent','file','undo-intent','undo-file'].includes(textCut || '') ? { afterTextChangeStage: async (stage: 'intent' | 'file' | 'undo-intent' | 'undo-file') => {
      if (stage !== textCut) return;
      fs.writeFileSync(path.join(options.dataRoot, `.e2e-pi-text-${stage}`), 'durable-stage-reached');
      await new Promise(resolve => setTimeout(resolve, 30000));
    } } : {}),
    settingsCodec: { available: () => safeStorage.isEncryptionAvailable(), seal: key => safeStorage.encryptString(key).toString('base64'),
      open: sealed => safeStorage.decryptString(Buffer.from(sealed, 'base64')) },
    ...(queueDelay ? {afterInstructionDispatch:async (signal:AbortSignal)=>{
      fs.writeFileSync(path.join(options.dataRoot,'.e2e-pi-queue-dispatching'),'durable-dispatching');
      await new Promise<void>(resolve=>{const done=()=>{clearTimeout(timer);signal.removeEventListener('abort',done);resolve();};const timer=setTimeout(done,queueDelay);signal.addEventListener('abort',done,{once:true});if(signal.aborted)done();});
    }} : {}),
    ...(testing && process.env.OMNI_EDU_E2E_PI_AUTO_COMPACT_REJECT === '1' ? { beforeAutoCompactCommit: async () => { throw new Error('compaction_failed'); } } : {}),
    ...(Number.isSafeInteger(testWindow) && testWindow >= 32768 && testWindow <= 1048576 ? { testContextWindow: testWindow } : {}),
    ...(autoDelay ? { afterAutoCompactCommit: async () => { fs.writeFileSync(path.join(options.dataRoot, '.e2e-pi-auto-compaction-committed'), 'native-summary-committed'); await new Promise(resolve => setTimeout(resolve, autoDelay)); } } : {}),
    ...(commitDelay ? { afterCompactCommit: async () => {
    fs.writeFileSync(path.join(options.dataRoot, '.e2e-pi-compaction-committed'), 'native-summary-committed');
    await new Promise(resolve => setTimeout(resolve, commitDelay));
  } } : {}), emit: event => {
    const window = options.window(); if (window && !window.isDestroyed()) window.webContents.send('xiaozhi:event', event);
  } });
  const fromMain = (event: Electron.IpcMainInvokeEvent) => event.sender === options.window()?.webContents && event.senderFrame === event.sender.mainFrame;
  registerPermissionIpc({ipcMain: options.ipcMain, allowed: fromMain, permissions: host.permissions,
    resumeLegacy: input => host.resumeLegacyApproval(input)});
  registerEnvironmentIpc({ipcMain: options.ipcMain, allowed: fromMain, host});
  registerManagedToolIpc({ipcMain:options.ipcMain,allowed:fromMain,service:managedTools});
  registerAttachmentIpc({ipcMain:options.ipcMain,allowed:fromMain,attachments:host.attachments,choose:async()=>{
    const current=options.window();if(!current||current.isDestroyed())return;
    const result=await dialog.showOpenDialog(current,{title:'添加本地附件',properties:['openFile','multiSelections'],
      filters:[{name:'教学资料',extensions:['png','jpg','jpeg','gif','webp','txt','md','docx','pdf','xlsx','pptx']},{name:'所有文件',extensions:['*']}]});
    return result.canceled?undefined:result.filePaths;
  }});
  registerWebIpc({ipcMain:options.ipcMain,allowed:fromMain,host,preferences:()=>options.store.xiaozhiState.modelSettings.web(),open:url=>shell.openExternal(url)});
  registerMcpIpc({ ipcMain: options.ipcMain, allowed: fromMain, host });
  registerTaskIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerDecisionIpc({ ipcMain: options.ipcMain, allowed: fromMain, host });
  registerTeacherCandidateIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerModelSettingsIpc({ ipcMain: options.ipcMain, allowed: fromMain, host });
  registerTextChangeIpc({ ipcMain: options.ipcMain, allowed: fromMain, host });
  registerOfficeArtifactIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerLearningReviewIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerClassroomIpc({ipcMain:options.ipcMain,allowed:fromMain,state:options.store.xiaozhiState.classrooms,plans:options.store.xiaozhiState.classroomPlans});
  registerQuestionReviewIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerOriginalQuestionIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerPracticeReviewIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerPaperIpc({ipcMain:options.ipcMain,allowed:fromMain,host});
  registerPaperBasketIpc({ipcMain: options.ipcMain, allowed: fromMain, host});
  registerStudentTrainingIpc({ipcMain:options.ipcMain,allowed:fromMain,repository:options.store.learningReviews});
  registerQuestionContextIpc({ipcMain:options.ipcMain,allowed:fromMain,store:options.store});
  registerWorkspaceFileIpc({ipcMain:options.ipcMain,allowed:fromMain,resolve:host.resolveFileWorkspace});
  registerDeliveryCheckIpc({ipcMain:options.ipcMain,allowed:fromMain,service:host.deliveryChecks});
  registerDiagnosticsIpc({ipcMain:options.ipcMain,allowed:fromMain,store:options.store});
  registerScienceExportIpc({ipcMain:options.ipcMain,allowed:fromMain,resolve:host.resolveFileWorkspace});
  registerSkillManagementIpc({ ipcMain: options.ipcMain, allowed: fromMain, host, choose: async () => {
    const current = options.window(); if (!current || current.isDestroyed()) return;
    const result = await dialog.showOpenDialog(current, { title: '导入本地教育技能（选择包含 SKILL.md 的目录）', properties: ['openDirectory'] });
    return result.canceled ? undefined : result.filePaths[0];
  } });
  options.ipcMain.handle('xiaozhi:enabled', event => { if (!fromMain(event)) throw new Error('permission_denied'); return host.enabled; });
  options.ipcMain.handle('xiaozhi:snapshot', (event, id) => { if (!fromMain(event)) throw new Error('permission_denied'); return host.snapshot(id); });
  options.ipcMain.handle('xiaozhi:records-refresh',(event,id)=>fromMain(event)?host.refreshRecords(id):{ok:false,error:'permission_denied'});
  options.ipcMain.handle('xiaozhi:history-page', (event, input) => { if (!fromMain(event)) throw new Error('permission_denied'); return host.historyPage(input); });
  options.ipcMain.handle('xiaozhi:events', (event, input) => { if (!fromMain(event)) throw new Error('permission_denied'); return host.listEvents(input); });
  options.ipcMain.handle('xiaozhi:plan-history',(event,input)=>fromMain(event)?host.planHistory(input):{ok:false,error:'permission_denied'});
  options.ipcMain.handle('xiaozhi:goal-mutate',(event,input)=>fromMain(event)?host.mutateGoal(input):{ok:false,error:'permission_denied'});
  options.ipcMain.handle('xiaozhi:browser-show',(event,id)=>fromMain(event)?host.showBrowser(id):{ok:false,error:'permission_denied'});
  options.ipcMain.handle('xiaozhi:browser-capture-preview',(event,input)=>fromMain(event)?host.previewBrowserCapture(input):{ok:false,error:'permission_denied'});
  options.ipcMain.handle('xiaozhi:start', (event, input) => { if (!fromMain(event)) return { ok: false, error: 'configuration' }; return host.start(input); });
  options.ipcMain.handle('xiaozhi:stop', (event, id) => { if (!fromMain(event)) return { ok: false }; return host.stop(id); });
  options.ipcMain.handle('xiaozhi:decide', (event, input) => { if (!fromMain(event)) return { ok: false, error: 'permission_denied' }; return host.decide(input); });
  options.ipcMain.handle('xiaozhi:answer', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.answer(input); });
  options.ipcMain.handle('xiaozhi:queue', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.queue(input); });
  options.ipcMain.handle('xiaozhi:queue-mutate', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.mutateQueue(input); });
  options.ipcMain.handle('xiaozhi:budget', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.setBudget(input); });
  options.ipcMain.handle('xiaozhi:memory-catalog', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.memoryCatalog(input); });
  options.ipcMain.handle('xiaozhi:memory-scope', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.setMemoryScope(input); });
  options.ipcMain.handle('xiaozhi:memory-trace', (event,id) => { if (!fromMain(event)) throw new Error('permission_denied'); return host.memoryTrace(id); });
  options.ipcMain.handle('xiaozhi:compact', (event,input) => { if (!fromMain(event)) return {ok:false,error:'permission_denied'}; return host.compact(input); });
  options.ipcMain.handle('xiaozhi:workspace', (event, id) => {
    if (!fromMain(event)) return { ok: false, error: 'permission_denied' };
    return host.selectWorkspace(id, async () => {
      const current = options.window(); if (!current) return;
      const result = await dialog.showOpenDialog(current, { title: '选择本会话的教学工作目录', properties: ['openDirectory'] });
      return result.canceled ? undefined : result.filePaths[0];
    });
  });
  options.ipcMain.handle('xiaozhi:paper-output', (event,input) => {
    if(!fromMain(event))return {ok:false,error:'permission_denied'};
    if(!validPaperOutput(input))return {ok:false,error:'invalid_input'};
    return host.selectPaperOutput(input.sessionId,async()=>{
      const current=options.window();if(!current)return;
      const result=await dialog.showOpenDialog(current,{title:'选择试卷保存文件夹（仅保存已确认试卷）',properties:['openDirectory']});
      return result.canceled?undefined:result.filePaths[0];
    });
  });
  return host;
}
