import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';

const root = 'C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase3-production-hPdPoi';
const database = new DatabaseSync(path.join(root, 'data/app.db'), {readOnly: true});
try {
  const files = Object.fromEntries(['main-result.txt', 'legacy-result.txt', 'same-task.txt'].map(name =>
    [name, fs.readFileSync(path.join(root, 'workspace', name), 'utf8')]));
  assert.equal(files['main-result.txt'], 'owned-main');
  assert.equal(files['legacy-result.txt'], 'synthetic');
  assert.equal(files['same-task.txt'], 'synthetic');
  const effects = database.prepare("SELECT json_extract(event_json,'$.attempt.tool') AS tool, json_extract(event_json,'$.attempt.effect') AS effect, json_extract(event_json,'$.attempt.maxAttempts') AS maxAttempts FROM xiaozhi_event_journal WHERE json_extract(event_json,'$.kind')='tool_attempt' AND json_extract(event_json,'$.attempt.state')='failed'").all();
  const mcp = effects.filter(item => item.tool?.startsWith('mcp_'));
  assert(mcp.length > 0);
  assert(mcp.every(item => item.effect === 'unknown' && item.maxAttempts === 1));
  const grants = database.prepare("SELECT json_extract(document_json,'$.scope.kind') AS kind, revoked, count(*) AS count FROM xiaozhi_permission_grants_v1 GROUP BY kind,revoked").all();
  assert(grants.some(item => item.kind === 'mcp' && item.revoked === 1));
  const approvals = database.prepare("SELECT json_extract(payload_json,'$.state') AS state, count(*) AS count FROM ai_confirmation_items WHERE action_type='xiaozhi_permission_v2' GROUP BY state").all();
  assert(approvals.some(item => item.state === 'pending'));
  assert(approvals.some(item => item.state === 'approved'));
  const facts = {success: true, root, files, failedMcpEffects: mcp, grants, approvals,
    boundary: 'Independent read-only SQLite and actual file readback after the reviewer-owned Main/Pi suite'};
  fs.writeFileSync(new URL('./independent-main-readback.json', import.meta.url), JSON.stringify(facts, null, 2));
  console.log(JSON.stringify(facts));
} finally {
  database.close();
}
