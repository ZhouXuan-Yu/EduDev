$ErrorActionPreference = 'Stop'
$candidateRoot = $PSScriptRoot
$sourcePath = Join-Path $candidateRoot 'NativeSandbox.cs'
$referencePath = Join-Path $candidateRoot 'snapshot-v2\NativeSandbox.cs'
[Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.dll')) | Out-Null
[Reflection.Assembly]::LoadFrom((Join-Path $PSHOME 'Microsoft.CodeAnalysis.CSharp.dll')) | Out-Null
$original = [IO.File]::ReadAllText($referencePath)
$originalTree = [Microsoft.CodeAnalysis.CSharp.SyntaxFactory]::ParseCompilationUnit($original)
$normalized = [Microsoft.CodeAnalysis.SyntaxNodeExtensions]::NormalizeWhitespace[Microsoft.CodeAnalysis.CSharp.Syntax.CompilationUnitSyntax]($originalTree, '    ', "`r`n", $false).ToFullString() + "`r`n"
$tree = [Microsoft.CodeAnalysis.CSharp.SyntaxFactory]::ParseCompilationUnit($normalized)
$breaks = [Collections.Generic.Dictionary[int,int]]::new()
function Add-LineBreak([int]$position, [int]$indent) {
    if (!$breaks.ContainsKey($position) -or $indent -lt $breaks[$position]) {
        $breaks[$position] = $indent
    }
}
function Get-LineIndent([int]$position) {
    $start = $normalized.LastIndexOf("`n", [Math]::Max(0, $position - 1)) + 1
    $length = 0
    while ($start + $length -lt $normalized.Length -and $normalized[$start + $length] -eq ' ') {
        $length++
    }
    return $length
}
function Split-Arguments($list, [int]$indent) {
    Add-LineBreak $list.OpenParenToken.Span.End ($indent + 4)
    foreach ($argument in $list.Arguments) {
        Add-LineBreak $argument.Span.Start ($indent + 4)
    }
    Add-LineBreak $list.CloseParenToken.Span.Start $indent
}
foreach ($node in $tree.DescendantNodes()) {
    $kind = $node.GetType().Name
    $indent = Get-LineIndent $node.Span.Start
    if ($kind -eq 'BinaryExpressionSyntax' -and $node.OperatorToken.Text -in @('&&', '||') -and $node.Span.Length -gt 100) {
        $covered = $false
        foreach ($ancestor in $node.Ancestors()) {
            if ($ancestor.GetType().Name -eq 'BinaryExpressionSyntax' -and $ancestor.OperatorToken.Text -in @('&&', '||') -and $ancestor.Span.Length -gt 100) {
                $covered = $true
                break
            }
        }
        if ($covered) {
            continue
        }
        foreach ($part in $node.DescendantNodesAndSelf()) {
            if ($part.GetType().Name -eq 'BinaryExpressionSyntax' -and $part.OperatorToken.Text -in @('&&', '||')) {
                $nested = 0
                foreach ($ancestor in $part.Ancestors()) {
                    if ($ancestor.Span.Start -eq $node.Span.Start -and $ancestor.Span.Length -eq $node.Span.Length) {
                        break
                    }
                    if ($ancestor.GetType().Name -eq 'ParenthesizedExpressionSyntax') {
                        $nested++
                    }
                }
                Add-LineBreak $part.OperatorToken.Span.Start ($indent + 4 + (4 * $nested))
            }
        }
    }
    if ($kind -eq 'MethodDeclarationSyntax' -and $node.ParameterList.Parameters.Count -ge 4 -and $node.ParameterList.Span.Length -gt 90) {
        Add-LineBreak $node.ParameterList.OpenParenToken.Span.End ($indent + 4)
        foreach ($parameter in $node.ParameterList.Parameters) {
            Add-LineBreak $parameter.Span.Start ($indent + 4)
        }
        Add-LineBreak $node.ParameterList.CloseParenToken.Span.Start $indent
    }
    if ($kind -in @('InvocationExpressionSyntax', 'ObjectCreationExpressionSyntax') -and $node.ArgumentList -and $node.ArgumentList.Arguments.Count -ge 3 -and $node.Span.Length -gt 105) {
        Split-Arguments $node.ArgumentList $indent
    }
    if ($kind -eq 'InitializerExpressionSyntax' -and $node.Expressions.Count -ge 3 -and $node.Span.Length -gt 100) {
        Add-LineBreak $node.OpenBraceToken.Span.End ($indent + 4)
        foreach ($expression in $node.Expressions) {
            Add-LineBreak $expression.Span.Start ($indent + 4)
        }
        Add-LineBreak $node.CloseBraceToken.Span.Start $indent
    }
}
$builder = [Text.StringBuilder]::new($normalized)
foreach ($position in @($breaks.Keys | Sort-Object -Descending)) {
    $builder.Insert($position, "`r`n" + (' ' * $breaks[$position])) | Out-Null
}
$formatted = (($builder.ToString() -split "`r?`n" | ForEach-Object { $_.TrimEnd() }) -join "`r`n")
$formatted = $formatted.TrimEnd() + "`r`n"
$finalTree = [Microsoft.CodeAnalysis.CSharp.SyntaxFactory]::ParseCompilationUnit($formatted)
$equivalent = [Microsoft.CodeAnalysis.CSharp.SyntaxFactory]::AreEquivalent($originalTree, $finalTree, $false)
$beforeTokens = @($originalTree.DescendantTokens() | ForEach-Object { [string]$_.RawKind + ':' + $_.Text })
$afterTokens = @($finalTree.DescendantTokens() | ForEach-Object { [string]$_.RawKind + ':' + $_.Text })
$sameTokens = $beforeTokens.Count -eq $afterTokens.Count -and [string]::Join("`n", $beforeTokens) -ceq [string]::Join("`n", $afterTokens)
$errors = @($finalTree.GetDiagnostics() | Where-Object { $_.Severity.ToString() -eq 'Error' })
if (!$equivalent -or !$sameTokens -or $errors.Count -ne 0) {
    throw 'Formatting changed syntax or token identity'
}
[IO.File]::WriteAllText($sourcePath, $formatted, [Text.UTF8Encoding]::new($false))
$evidence = [ordered]@{
    formattedAt = (Get-Date -Format o)
    reference = $referencePath
    source = $sourcePath
    syntaxEquivalent = $equivalent
    tokensIdentical = $sameTokens
    tokenCount = $afterTokens.Count
    syntaxErrors = $errors.Count
    referenceLines = @($original -split "`r?`n").Count
    readableLines = @($formatted -split "`r?`n").Count
    sourceSha256 = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
}
$evidence | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $candidateRoot 'readability-equivalence.json')
$evidence | ConvertTo-Json -Depth 4
