using System;
namespace Xiaozhi.PermissionRuntime
{
    internal static class TrustProbe
    {
        internal static int Main(string[] args)
        {
            if (args.Length != 1)
            {
                return 2;
            }

            Console.WriteLine(Json.Encode(PlatformInfo.Inspect("powershell5", args[0])));
            return 0;
        }
    }
}
