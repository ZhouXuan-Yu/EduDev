import {spawn} from 'node:child_process';
import fs from 'node:fs';
const [helper,requestPath,outputPath,metaPath]=process.argv.slice(2);
const request=JSON.parse(fs.readFileSync(requestPath,'utf8'));
const output=fs.openSync(outputPath,'wx');
const child=spawn(helper,['--protocol-stdio'],{stdio:['pipe',output,'ignore'],windowsHide:true,detached:true});
fs.closeSync(output);
child.stdin.on('error',()=>{});
child.stdin.write(JSON.stringify(request)+'\n');
fs.writeFileSync(metaPath,JSON.stringify({hostPid:process.pid,helperPid:child.pid,executionId:request.executionId}));
const timer=setInterval(()=>{
  if(fs.existsSync(request.projectionRoot+'\\parent-exit-ready.txt'))process.exit(91);
},25);
setTimeout(()=>{clearInterval(timer);process.exit(92);},10000);
