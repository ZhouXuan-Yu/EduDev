$ErrorActionPreference = 'Stop'
$buildRoot = $PSScriptRoot
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$executables = @('C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe')
$pwsh = Get-Command pwsh -ErrorAction SilentlyContinue
if ($pwsh) { $executables += $pwsh.Source }
$runtimes = @($executables | Select-Object -Unique | ForEach-Object {
    [ordered]@{ path=[IO.Path]::GetFullPath($_); sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant(); fileVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo($_).FileVersion; required=($_ -eq $executables[0]) }
})
$source = @('namespace Xiaozhi.PermissionRuntime {', 'internal sealed class TrustedRuntime { internal string Path, Hash; internal TrustedRuntime(string path, string hash) { Path=path; Hash=hash; } }', 'internal static class TrustedRuntimes { internal static readonly TrustedRuntime[] Items = new TrustedRuntime[] {')
foreach($runtime in $runtimes) { $source += 'new TrustedRuntime(@"' + $runtime.path.Replace('"','""') + '", "' + $runtime.sha256 + '"),' }
$source += '}; } }'
$source | Set-Content -LiteralPath (Join-Path $buildRoot 'TrustedRuntimes.cs') -Encoding utf8
$output = Join-Path $buildRoot 'xiaozhi-sandbox.exe'
$arguments = @('/nologo','/target:exe','/platform:x64','/optimize+','/checked+','/warn:4',('/out:'+$output),(Join-Path $buildRoot 'NativeSandbox.cs'),(Join-Path $buildRoot 'TrustedRuntimes.cs'))
('"'+$compiler+'" '+(($arguments | ForEach-Object {'"'+$_+'"'}) -join ' ')) | Set-Content -LiteralPath (Join-Path $buildRoot 'build-command.txt')
& $compiler @arguments 2>&1 | Tee-Object -FilePath (Join-Path $buildRoot 'build.log')
if($LASTEXITCODE -ne 0) { throw "Compiler exit $LASTEXITCODE" }
$manifest = [ordered]@{
    schemaVersion=1; protocolVersion=1; maintenanceMode='--cleanup-owned'; profileNamePattern='XiaozhiSandbox.<execution UUID without hyphens>'; hostSpawn=[ordered]@{detached=$true;windowsHide=$true;stdio=@('pipe','pipe','pipe')}; privateIdentityPath='.runtime/.helper-state/identity.json'; helperFile='xiaozhi-sandbox.exe'; helperSha256=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash.ToLowerInvariant(); sourceSha256=(Get-FileHash -LiteralPath (Join-Path $buildRoot 'NativeSandbox.cs') -Algorithm SHA256).Hash.ToLowerInvariant(); pinsSourceSha256=(Get-FileHash -LiteralPath (Join-Path $buildRoot 'TrustedRuntimes.cs') -Algorithm SHA256).Hash.ToLowerInvariant(); helperBytes=(Get-Item -LiteralPath $output).Length; architecture='x64'; targetFramework='.NET Framework 4.x'; compilerPath=$compiler; compilerFileVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo($compiler).FileVersion; runtimes=$runtimes; invalidExecutionId='xiexec_00000000-0000-0000-0000-000000000000'; outputLimitError='output_limit'; buildTime=(Get-Date -Format o)
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $buildRoot 'sandbox-manifest.json') -Encoding utf8
$manifest | ConvertTo-Json -Depth 8
