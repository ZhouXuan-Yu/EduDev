$ErrorActionPreference='Stop'
$candidateRoot=$PSScriptRoot
$started=@()
$roots=@()
foreach($evidence in Get-ChildItem -LiteralPath $candidateRoot -Directory -Filter 'evidence-*'){
    foreach($file in Get-ChildItem -LiteralPath $evidence.FullName -File -Filter '*.stdout.ndjson'){
        foreach($line in Get-Content -LiteralPath $file.FullName){
            try{$frame=$line|ConvertFrom-Json -ErrorAction Stop}catch{continue}
            if($frame.type -eq 'started'){$started+=@{profileName=$frame.profileName;pid=$frame.pid;observedUntilUtc=$file.LastWriteTimeUtc.ToString('o')}}
        }
    }
    $summary=Join-Path $evidence.FullName 'summary.json'
    if(Test-Path -LiteralPath $summary){$roots+=@((Get-Content -LiteralPath $summary -Raw|ConvertFrom-Json).fixtureRoots)}
}
$started=@($started|Sort-Object -Property @{Expression={$_.profileName}},@{Expression={$_.pid}} -Unique)
$rows=@($started|ForEach-Object{$_|ConvertTo-Json -Compress}|& (Join-Path $candidateRoot 'inventory-evidence.exe')|ForEach-Object{$_|ConvertFrom-Json})
if($LASTEXITCODE -ne 0 -or $rows.Count -ne $started.Count){throw ('Incomplete profile inventory expected='+$started.Count+' actual='+$rows.Count+' exit='+$LASTEXITCODE)}
$sidSet=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach($row in $rows){$null=$sidSet.Add($row.sid)}
$remaining=@()
$scannedObjects=0
$skippedLinks=@()
foreach($fixture in @($roots|Sort-Object -Unique)){
    if([IO.Path]::GetDirectoryName($fixture) -ne [IO.Path]::GetTempPath().TrimEnd('\') -or [IO.Path]::GetFileName($fixture) -notmatch '^xiaozhi-permission-exec-[0-9a-f-]{36}$'){throw 'Out-of-owned-fixture inventory path'}
    $pending=[Collections.Generic.Queue[string]]::new();$pending.Enqueue($fixture)
    while($pending.Count -gt 0){
        $object=$pending.Dequeue()
        $item=Get-Item -LiteralPath $object -Force
        if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){$skippedLinks+=$object;continue}
        $scannedObjects++
        foreach($ace in (Get-Acl -LiteralPath $object).Access){
            $principal=$ace.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
            if($sidSet.Contains($principal)){$remaining+=@{path=$object;sid=$principal;rights=[string]$ace.FileSystemRights}}
        }
        if($item.PSIsContainer){foreach($child in Get-ChildItem -LiteralPath $object -Force){$pending.Enqueue($child.FullName)}}
    }
}
$report=[ordered]@{checkedAt=(Get-Date -Format o); observedProfileExecutions=$rows.Count; profileFoldersRemaining=@($rows|Where-Object profileFolderExists).Count; profileMappingsRemaining=@($rows|Where-Object profileMappingExists).Count; pidStillExists=@($rows|Where-Object pidExists); ownedPidsRemaining=@($rows|Where-Object {$_.pidExists -and !$_.pidReused}); ownedFixtureCount=@($roots|Sort-Object -Unique).Count; scannedObjects=$scannedObjects; skippedReparse=$skippedLinks; remainingOwnedAces=$remaining; executions=$rows}
$report|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $candidateRoot 'cleanup-inventory.json')
[pscustomobject]@{checkedAt=$report.checkedAt;observedProfileExecutions=$rows.Count;profileFoldersRemaining=$report.profileFoldersRemaining;profileMappingsRemaining=$report.profileMappingsRemaining;ownedFixtureCount=$report.ownedFixtureCount;scannedObjects=$scannedObjects;remainingAces=$remaining.Count;existingPids=$report.pidStillExists.Count;ownedPidsRemaining=$report.ownedPidsRemaining.Count}|Format-List
