import { spawn } from 'node:child_process';
import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse((await fs.readFile(path.join(root, 'sandbox-manifest.json'), 'utf8')).replace(/^\uFEFF/, ''));
const fixtureRoots = [];
const results = [];
const args = process.argv.slice(2);
const suiteName = args.includes('--quick') ? 'quick' : 'full';
const evidence = path.join(root, `evidence-${Date.now()}`);
await fs.mkdir(evidence);

async function fixture(command, overrides = {}, runtime = manifest.runtimes[0]) {
  const projectionRoot = path.join(os.tmpdir(), `xiaozhi-permission-exec-${crypto.randomUUID()}`);
  fixtureRoots.push(projectionRoot);
  await fs.mkdir(projectionRoot);
  const request = {
    schemaVersion: 1, type: 'start', executionId: `xiexec_${crypto.randomUUID()}`,
    owner: { sessionId: `aisession_${crypto.randomUUID()}`, taskId: 'synthetic-task', runId: 'synthetic-run', generation: 1 },
    grantHash: crypto.createHash('sha256').update('synthetic-grant').digest('hex'),
    executable: runtime.path, executableHash: runtime.sha256,
    projectionRoot, cwd: projectionRoot, command,
    env: { XIAOZHI_WORKSPACE: projectionRoot }, timeoutMs: 10000, maxOutputBytes: 1048576, maxProcesses: 16,
    ...overrides,
  };
  await fs.writeFile(path.join(projectionRoot, '.xiaozhi-projection.json'), JSON.stringify({ schemaVersion: 1, executionId: request.executionId, grantHash: request.grantHash, owner: request.owner }));
  return request;
}

async function execute(name, request, options = {}) {
  const child = spawn(options.helperPath ?? path.join(root, 'xiaozhi-sandbox.exe'), [options.mode ?? '--protocol-stdio'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, detached: true });
  const frames = [];
  let stdout = '', stderr = '', buffer = '', parseError;
  const began = performance.now();
  child.stdout.on('data', data => {
    stdout += data.toString('utf8'); buffer += data.toString('utf8');
    while (buffer.includes('\n')) {
      const position = buffer.indexOf('\n');
      const line = buffer.slice(0, position); buffer = buffer.slice(position + 1);
      try {
        const frame = JSON.parse(line); frames.push(frame);
        if (frame.type === 'started' && options.onStarted) options.onStarted(child, frame);
      } catch (error) { parseError = String(error); }
    }
  });
  child.stderr.on('data', data => { stderr += data.toString('utf8'); });
  child.stdin.on('error', () => {});
  const watchdog = setTimeout(() => child.kill(), 20000);
  const closed = new Promise((resolve, reject) => { child.on('error', reject); child.on('close', (code, signal) => resolve({ code, signal })); });
  child.stdin.write(options.raw ?? `${JSON.stringify(request)}\n`);
  if (options.afterWrite) options.afterWrite(child);
  const processExit = await closed;
  clearTimeout(watchdog);
  const result = frames.findLast(frame => frame.type === 'result');
  const streams = Object.fromEntries(['stdout', 'stderr'].map(stream => [stream, Buffer.concat(frames.filter(frame => frame.type === 'output' && frame.stream === stream).map(frame => Buffer.from(frame.data, 'base64'))).toString('utf8')]));
  const record = { name, durationMs: performance.now() - began, processExit, frames, streams, parseError, diagnostics: stderr };
  await fs.writeFile(path.join(evidence, `${name}.request.json`), JSON.stringify(request, null, 2));
  await fs.writeFile(path.join(evidence, `${name}.stdout.ndjson`), stdout);
  await fs.writeFile(path.join(evidence, `${name}.stderr.log`), stderr);
  await fs.writeFile(path.join(evidence, `${name}.result.json`), JSON.stringify(record, null, 2));
  return { record, result, streams, frames };
}

async function test(name, request, options, check) {
  try {
    const value = await execute(name, request, options);
    const failure = await check(value);
    results.push({ name, status: failure ? 'FAIL' : 'PASS', detail: failure || 'verified', durationMs: value.record.durationMs });
    console.log(`${results.at(-1).status} ${name} ${Math.round(value.record.durationMs)}ms ${failure || ''}`);
  } catch (error) {
    results.push({ name, status: 'FAIL', detail: error.stack }); console.log(`FAIL ${name} ${error}`);
  }
}
function clean(result) { return result?.cleanup?.jobActiveProcesses === 0 && result.cleanup.profileRemoved && result.cleanup.remainingOwnedAces === 0; }

for (const [index, runtime] of manifest.runtimes.entries()) {
  const request = await fixture(`$ErrorActionPreference='Stop'\n$n = 1..8 | Where-Object { $_ % 2 -eq 0 } | ForEach-Object { $_ * $_ }\n$sum=0; foreach($value in $n){$sum+=$value}\n[IO.File]::WriteAllText((Join-Path $env:XIAOZHI_WORKSPACE 'result.txt'), "教师中文 sum=$sum")\n[Console]::WriteLine("STDOUT 教师中文 sum=$sum")\n[Console]::Error.WriteLine('STDERR 错误通道')\nexit 37`, {}, runtime);
  await test(`complex-ps${index}`, request, {}, async ({result, streams}) => result?.state !== 'completed' || result.exitCode !== 37 || !clean(result) || !streams.stdout.includes('教师中文 sum=120') || !streams.stderr.includes('STDERR 错误通道') || !(await fs.readFile(path.join(request.projectionRoot,'result.txt'),'utf8')).includes('sum=120') ? JSON.stringify({result,streams}) : null);
}

if (suiteName === 'full') {
  const large = await fixture(`#${'界'.repeat(15000)}\n[Console]::WriteLine('LONG_SCRIPT_PASS'); exit 37`);
  await test('long-command', large, {}, ({result,streams}) => result?.exitCode !== 37 || !streams.stdout.includes('LONG_SCRIPT_PASS') || !clean(result) ? JSON.stringify({result,streams}) : null);
  const timeout = await fixture(`[Threading.Thread]::Sleep(30000)`, { timeoutMs: 1000 });
  await test('deadline', timeout, {}, ({result}) => result?.state !== 'timed_out' || !clean(result) ? JSON.stringify(result) : null);
  const cancel = await fixture(`[Threading.Thread]::Sleep(30000)`);
  await test('cancel', cancel, {onStarted(child) { setTimeout(() => child.stdin.write(`${JSON.stringify({schemaVersion:1,type:'cancel',executionId:cancel.executionId,reason:'revoked'})}\n`),100); }}, ({result}) => result?.state !== 'cancelled' || !clean(result) ? JSON.stringify(result) : null);
  const eof = await fixture(`[Threading.Thread]::Sleep(30000)`);
  await test('eof', eof, {onStarted(child) { child.stdin.end(); }}, ({result}) => result?.state !== 'cancelled' || !clean(result) ? JSON.stringify(result) : null);
  const output = await fixture(`for($i=0;$i -lt 10000;$i++){[Console]::WriteLine('012345678901234567890123456789012345678901234567890123456789')}`, { maxOutputBytes:1024 });
  await test('output-limit', output, {}, ({result,frames}) => !result?.truncated || !clean(result) || frames.filter(frame => frame.type === 'output').reduce((sum,frame)=>sum+Buffer.from(frame.data,'base64').length,0)>1024 ? JSON.stringify(result) : null);
  const wrongHash = await fixture(`'MUST_NOT_RUN'`, { executableHash:'0'.repeat(64) });
  await test('changed-runtime', wrongHash, {}, ({result,frames}) => result?.error !== 'executable_changed' || frames.some(frame=>frame.type==='started') || !clean(result) ? JSON.stringify(result) : null);
  const unknown = await fixture(`'MUST_NOT_RUN'`); unknown.unknownField = true;
  await test('unknown-start-field', unknown, {}, ({result,frames}) => result?.error !== 'invalid_protocol' || frames.some(frame=>frame.type==='started') || !clean(result) ? JSON.stringify(result) : null);
  const hardlink = await fixture(`'MUST_NOT_RUN'`);
  await fs.writeFile(path.join(evidence,'hardlink-canary.txt'),'SYNTHETIC_HARDLINK');
  await fs.link(path.join(evidence,'hardlink-canary.txt'),path.join(hardlink.projectionRoot,'hardlink.txt'));
  await test('hardlink-input', hardlink, {}, ({result,frames}) => result?.error !== 'invalid_projection' || frames.some(frame=>frame.type==='started') || !clean(result) ? JSON.stringify(result) : null);
  const junction = await fixture(`'MUST_NOT_RUN'`);
  await fs.symlink(evidence,path.join(junction.projectionRoot,'junction'),'junction');
  await test('junction-input', junction, {}, ({result,frames}) => result?.error !== 'invalid_projection' || frames.some(frame=>frame.type==='started') || !clean(result) ? JSON.stringify(result) : null);

  const canary = path.join(evidence, 'sibling-canary.txt');
  await fs.writeFile(canary,'SYNTHETIC_SIBLING_UNCHANGED');
  let connections = 0;
  const server = net.createServer(socket => { connections++; socket.end(); });
  await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
  const port = server.address().port;
  await new Promise((resolve,reject) => { const control=net.connect(port,'127.0.0.1',()=>{ control.end(); resolve(); }); control.on('error',reject); });
  await new Promise(resolve=>setTimeout(resolve,25));
  const controlConnections = connections; connections = 0;
  const confined = await fixture(`$ErrorActionPreference='Stop'\ntry{[IO.File]::ReadAllText('${canary}');[Console]::WriteLine('READ_LEAK')}catch{[Console]::WriteLine('READ_DENIED')}\ntry{[IO.File]::WriteAllText('${canary}','LEAK');[Console]::WriteLine('WRITE_LEAK')}catch{[Console]::WriteLine('WRITE_DENIED')}\n$c=New-Object Net.Sockets.TcpClient\ntry{$t=$c.ConnectAsync('127.0.0.1',${port});if(!$t.Wait(750)){throw 'timeout'};[Console]::WriteLine('NETWORK_LEAK')}catch{[Console]::WriteLine('NETWORK_DENIED')}finally{$c.Dispose()}\nexit 37`);
  await test('sibling-network-denial', confined, {}, async ({result,streams}) => result?.exitCode!==37 || !clean(result) || !streams.stdout.includes('READ_DENIED') || !streams.stdout.includes('WRITE_DENIED') || !streams.stdout.includes('NETWORK_DENIED') || streams.stdout.includes('_LEAK') || controlConnections!==1 || connections!==0 || (await fs.readFile(canary,'utf8'))!=='SYNTHETIC_SIBLING_UNCHANGED' ? JSON.stringify({result,streams,controlConnections,connections}) : null);
  await new Promise(resolve=>server.close(resolve));

  const childRun = await fixture('PLACEHOLDER');
  const childScript = `[IO.File]::WriteAllText('${path.join(childRun.projectionRoot,'child-ready.txt')}',[string]$PID);[Threading.Thread]::Sleep(30000)`;
  const childEncoded = Buffer.from(childScript,'utf16le').toString('base64');
  childRun.command=`$i=New-Object Diagnostics.ProcessStartInfo;$i.FileName='${manifest.runtimes[0].path}';$i.Arguments='-NoLogo -NoProfile -NonInteractive -EncodedCommand ${childEncoded}';$i.UseShellExecute=$false;$i.CreateNoWindow=$true;$p=[Diagnostics.Process]::Start($i);[Console]::WriteLine('CHILD_PID '+$p.Id);[Threading.Thread]::Sleep(30000)`;
  await test('cancel-child-job', childRun, {onStarted(child) {
    (async()=>{for(let i=0;i<100;i++){try{await fs.access(path.join(childRun.projectionRoot,'child-ready.txt'));break;}catch{await new Promise(resolve=>setTimeout(resolve,25));}} child.stdin.write(`${JSON.stringify({schemaVersion:1,type:'cancel',executionId:childRun.executionId,reason:'cancelled'})}\n`);})().catch(()=>{});
  }}, async({result,streams}) => {
    const pid=Number((await fs.readFile(path.join(childRun.projectionRoot,'child-ready.txt'),'utf8')).trim());
    let alive=true;try{process.kill(pid,0);}catch{alive=false;}
    return result?.state!=='cancelled'||!clean(result)||alive||!streams.stdout.includes('CHILD_PID')?JSON.stringify({result,streams,pid,alive}):null;
  });

  const duplicate = await fixture(`[Threading.Thread]::Sleep(30000)`);
  await test('duplicate-start', duplicate, {onStarted(child){child.stdin.write(`${JSON.stringify(duplicate)}\n`);}},({result})=>result?.error!=='invalid_protocol'||!clean(result)?JSON.stringify(result):null);
  const duplicateKeys = await fixture(`'MUST_NOT_RUN'`);
  await test('duplicate-json-key', duplicateKeys, {raw: JSON.stringify(duplicateKeys).replace('"schemaVersion":1','"schemaVersion":1,"schemaVersion":1')+'\n'},({result,frames})=>result?.error!=='invalid_protocol'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const forgedEnv = await fixture(`'MUST_NOT_RUN'`,{env:{API_KEY:'SYNTHETIC_FORBIDDEN'}});
  await test('forbidden-env', forgedEnv,{},({result,frames})=>result?.error!=='invalid_protocol'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const marker = await fixture(`'MUST_NOT_RUN'`);
  await fs.writeFile(path.join(marker.projectionRoot,'.xiaozhi-projection.json'),JSON.stringify({schemaVersion:1,executionId:marker.executionId,grantHash:'0'.repeat(64),owner:marker.owner}));
  await test('forged-marker', marker,{},({result,frames})=>result?.error!=='invalid_projection'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const boundary = await fixture(`'MUST_NOT_RUN'`,{timeoutMs:999});
  await test('invalid-timeout',boundary,{},({result})=>result?.error!=='invalid_protocol'?JSON.stringify(result):null);
  const secret = await fixture(`[Console]::WriteLine('PARENT_SECRET=' + [Environment]::GetEnvironmentVariable('XIAOZHI_SYNTHETIC_PARENT_SECRET'));[Console]::WriteLine('HOME=' + $env:USERPROFILE);[Console]::WriteLine('TEMP=' + $env:TEMP);exit 37`);
  process.env.XIAOZHI_SYNTHETIC_PARENT_SECRET='SYNTHETIC_SECRET_MUST_BE_ABSENT';
  await test('environment-filter',secret,{},({result,streams})=>result?.exitCode!==37||!clean(result)||streams.stdout.includes('SYNTHETIC_SECRET_MUST_BE_ABSENT')||!streams.stdout.includes(secret.projectionRoot)?JSON.stringify({result,streams}):null);
  delete process.env.XIAOZHI_SYNTHETIC_PARENT_SECRET;

  const parentExit = await fixture(`[IO.File]::WriteAllText((Join-Path $env:XIAOZHI_WORKSPACE 'parent-exit-ready.txt'),[string]$PID);[Threading.Thread]::Sleep(30000)`);
  const parentFixture = path.join(evidence,'parent-exit.request.json');
  await fs.writeFile(parentFixture,JSON.stringify(parentExit));
  const host = spawn(process.execPath,[path.join(root,'parent-host.mjs'),path.join(root,'xiaozhi-sandbox.exe'),parentFixture,path.join(evidence,'parent-exit.stdout.ndjson'),path.join(evidence,'parent-exit.host.json')],{stdio:['ignore','pipe','pipe'],windowsHide:true});
  const hostExit=await new Promise((resolve,reject)=>{host.on('error',reject);host.on('close',(code)=>resolve(code));});
  let parentFrames=[];
  for(let i=0;i<150;i++){
    try{parentFrames=(await fs.readFile(path.join(evidence,'parent-exit.stdout.ndjson'),'utf8')).trim().split('\n').map(line=>JSON.parse(line)); if(parentFrames.some(frame=>frame.type==='result'))break;}catch{}
    await new Promise(resolve=>setTimeout(resolve,25));
  }
  const parentResult=parentFrames.find(frame=>frame.type==='result');
  const parentStatus=hostExit===91&&parentResult?.state==='cancelled'&&clean(parentResult)?'PASS':'FAIL';
  results.push({name:'abnormal-parent-exit',status:parentStatus,detail:{hostExit,parentResult}});
  console.log(`${parentStatus} abnormal-parent-exit`);

  const privateState = await fixture(`$p=Join-Path $env:XIAOZHI_WORKSPACE '.runtime\\.helper-state\\identity.json';try{[IO.File]::ReadAllText($p);[Console]::WriteLine('PRIVATE_READ_LEAK')}catch{[Console]::WriteLine('PRIVATE_READ_DENIED')};try{[IO.File]::WriteAllText($p,'FORGED');[Console]::WriteLine('PRIVATE_WRITE_LEAK')}catch{[Console]::WriteLine('PRIVATE_WRITE_DENIED')};try{[IO.Directory]::Delete((Split-Path $p -Parent),$true);[Console]::WriteLine('PRIVATE_DELETE_LEAK')}catch{[Console]::WriteLine('PRIVATE_DELETE_DENIED')};exit 37`);
  await test('private-recovery-identity-protected',privateState,{},async({result,streams})=>{
    const identity=JSON.parse(await fs.readFile(path.join(privateState.projectionRoot,'.runtime','.helper-state','identity.json'),'utf8'));
    return result?.exitCode!==37||!clean(result)||streams.stdout.includes('_LEAK')||!streams.stdout.includes('PRIVATE_READ_DENIED')||!streams.stdout.includes('PRIVATE_WRITE_DENIED')||!streams.stdout.includes('PRIVATE_DELETE_DENIED')||identity.executionId!==privateState.executionId?JSON.stringify({result,streams,identity}):null;
  });

  const strong = await fixture(`[IO.File]::WriteAllText((Join-Path $env:XIAOZHI_WORKSPACE 'strong-ready.txt'),[string]$PID);[Threading.Thread]::Sleep(30000)`);
  let killedShell;
  const strongValue=await execute('strong-kill-helper',strong,{onStarted(child,frame){killedShell=frame.pid;(async()=>{for(let i=0;i<100;i++){try{await fs.access(path.join(strong.projectionRoot,'strong-ready.txt'));break;}catch{await new Promise(resolve=>setTimeout(resolve,25));}}child.kill('SIGKILL');})().catch(()=>{});}});
  let shellAlive=true;try{process.kill(killedShell,0);}catch{shellAlive=false;}
  const strongProfile=`XiaozhiSandbox.${strong.executionId.slice('xiexec_'.length).replaceAll('-','')}`;
  const strongProfileDir=path.join(process.env.LOCALAPPDATA,'Packages',strongProfile.toLowerCase(),'AC');
  let residualProfile=false;try{await fs.access(strongProfileDir);residualProfile=true;}catch{}
  results.push({name:'strong-kill-helper-job',status:!shellAlive&&!strongValue.result&&residualProfile?'PASS':'FAIL',detail:{shellAlive,residualProfile,killedShell}});
  console.log(`${results.at(-1).status} strong-kill-helper-job`);

  const recovery={...strong,command:"'cleanup-only placeholder'"};
  await test('cleanup-owned-after-strong-kill',recovery,{mode:'--cleanup-owned'},async({result,frames})=>{
    let profileExists=false;try{await fs.access(strongProfileDir);profileExists=true;}catch{}
    return result?.state!=='completed'||result.exitCode!==null||!clean(result)||frames.some(frame=>frame.type==='started'||frame.type==='output')||profileExists?JSON.stringify({result,profileExists}):null;
  });
  await test('cleanup-owned-idempotent',recovery,{mode:'--cleanup-owned'},({result,frames})=>result?.state!=='completed'||!clean(result)||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const wrongExecution={...recovery,executionId:`xiexec_${crypto.randomUUID()}`};
  await test('cleanup-owned-wrong-execution',wrongExecution,{mode:'--cleanup-owned'},({result})=>result?.error!=='invalid_projection'?JSON.stringify(result):null);
  const cloned=await fixture(`'MUST_NOT_RUN'`);
  const clonedRequest={...recovery,projectionRoot:cloned.projectionRoot,cwd:cloned.projectionRoot,env:{XIAOZHI_WORKSPACE:cloned.projectionRoot}};
  await fs.writeFile(path.join(cloned.projectionRoot,'.xiaozhi-projection.json'),JSON.stringify({schemaVersion:1,executionId:clonedRequest.executionId,grantHash:clonedRequest.grantHash,owner:clonedRequest.owner}));
  await test('cleanup-owned-cloned-marker-other-root',clonedRequest,{mode:'--cleanup-owned'},({result})=>result?.error!=='invalid_projection'?JSON.stringify(result):null);
  const tampered={...recovery,grantHash:'0'.repeat(64)};
  await test('cleanup-owned-tampered-marker',tampered,{mode:'--cleanup-owned'},({result})=>result?.error!=='invalid_projection'?JSON.stringify(result):null);

  const broken = await fixture(`while($true){[Console]::WriteLine('OUTPUT_AFTER_STDOUT_CLOSED');[Threading.Thread]::Sleep(50)}`);
  const brokenValue=await execute('broken-stdout',broken,{onStarted(child){child.stdout.destroy();}});
  results.push({name:'broken-stdout-bounded-exit',status:brokenValue.record.durationMs<5000?'PASS':'FAIL',detail:{durationMs:brokenValue.record.durationMs}});
  console.log(`${results.at(-1).status} broken-stdout-bounded-exit`);
  await test('cleanup-owned-after-broken-stdout',broken,{mode:'--cleanup-owned'},({result})=>result?.state!=='completed'||!clean(result)?JSON.stringify(result):null);

  const invalidCases = [
    ['schema-version',{schemaVersion:2}], ['output-underflow',{maxOutputBytes:1023}],
    ['output-overflow',{maxOutputBytes:4194305}], ['process-underflow',{maxProcesses:0}],
    ['process-overflow',{maxProcesses:65}], ['command-overflow',{command:'x'.repeat(16385)}],
    ['timeout-overflow',{timeoutMs:120001}], ['invalid-grant-hash',{grantHash:'A'.repeat(64)}],
  ];
  for(const [suffix,override] of invalidCases){
    const invalid=await fixture(`'MUST_NOT_RUN'`,override);
    await test(`range-${suffix}`,invalid,{},({result,frames})=>result?.error!=='invalid_protocol'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  }
  const outside=await fixture(`'MUST_NOT_RUN'`,{cwd:evidence});
  await test('outside-cwd',outside,{},({result,frames})=>result?.error!=='invalid_projection'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const outsideEnv=await fixture(`'MUST_NOT_RUN'`,{env:{XIAOZHI_WORKSPACE:evidence}});
  await test('outside-env-path',outsideEnv,{},({result,frames})=>result?.error!=='invalid_projection'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const malformed=await fixture(`'MUST_NOT_RUN'`);
  await test('invalid-utf8',malformed,{raw:Buffer.from([0xff,0x0a])},({result})=>result?.error!=='invalid_protocol'?JSON.stringify(result):null);
  await test('oversized-frame',malformed,{raw:' '.repeat(1048577)+'\n'},({result})=>result?.error!=='invalid_protocol'?JSON.stringify(result):null);
  const recoveryLink=await fixture(`'MUST_NOT_RUN'`);
  await fs.symlink(evidence,path.join(recoveryLink.projectionRoot,'reparse'),'junction');
  await test('cleanup-owned-reparse-rejected',recoveryLink,{mode:'--cleanup-owned'},({result,frames})=>result?.error!=='invalid_projection'||frames.some(frame=>frame.type==='started')?JSON.stringify(result):null);
  const recoveryExe={...recovery,executableHash:'0'.repeat(64)};
  await test('cleanup-owned-executable-identity-mismatch',recoveryExe,{mode:'--cleanup-owned'},({result})=>result?.error!=='invalid_projection'?JSON.stringify(result):null);
  const differentCancel=await fixture(`[Threading.Thread]::Sleep(250);[Console]::WriteLine('WRONG_CANCEL_IGNORED');exit 37`);
  await test('other-execution-cancel-ignored',differentCancel,{onStarted(child){child.stdin.write(JSON.stringify({schemaVersion:1,type:'cancel',executionId:`xiexec_${crypto.randomUUID()}`,reason:'revoked'})+'\n');}},({result,streams})=>result?.state!=='completed'||result.exitCode!==37||!streams.stdout.includes('WRONG_CANCEL_IGNORED')||!clean(result)?JSON.stringify({result,streams}):null);
  const repeated=await fixture(`[Threading.Thread]::Sleep(30000)`);
  await test('repeated-cancel-idempotent',repeated,{onStarted(child){const cancel=JSON.stringify({schemaVersion:1,type:'cancel',executionId:repeated.executionId,reason:'cancelled'})+'\n';child.stdin.write(cancel+cancel);}},({result,frames})=>result?.state!=='cancelled'||!clean(result)||frames.filter(frame=>frame.type==='result').length!==1?JSON.stringify(result):null);

  const processLimit=await fixture('PLACEHOLDER',{maxProcesses:2});
  const budgetChild=Buffer.from(`[IO.File]::WriteAllText('${processLimit.projectionRoot}\\process-budget-'+$PID+'.txt','ALLOWED');[Threading.Thread]::Sleep(3000)`,'utf16le').toString('base64');
  processLimit.command=`$children=@();for($index=0;$index -lt 4;$index++){try{$i=New-Object Diagnostics.ProcessStartInfo;$i.FileName='${manifest.runtimes[0].path}';$i.Arguments='-NoLogo -NoProfile -NonInteractive -EncodedCommand ${budgetChild}';$i.UseShellExecute=$false;$i.CreateNoWindow=$true;$children += [Diagnostics.Process]::Start($i);[Console]::WriteLine('CHILD_RETURNED')}catch{[Console]::WriteLine('PROCESS_BUDGET_DENIED')}};foreach($p in $children){$p.WaitForExit()};exit 37`;
  await test('process-budget-enforced',processLimit,{},async({result,streams})=>{
    const markers=(await fs.readdir(processLimit.projectionRoot)).filter(name=>name.startsWith('process-budget-')&&name.endsWith('.txt'));
    return !clean(result)||markers.length>1||!streams.stdout.includes('PROCESS_BUDGET_DENIED')?JSON.stringify({result,streams,markers}):null;
  });

  const variant=path.join(evidence,'runtime-hash-variant');await fs.mkdir(variant);
  const copiedRuntime=path.join(variant,'powershell.exe');await fs.copyFile(manifest.runtimes[0].path,copiedRuntime);
  const beforeHash=crypto.createHash('sha256').update(await fs.readFile(copiedRuntime)).digest('hex');
  const pinSource=path.join(variant,'TrustedRuntimes.cs');
  await fs.writeFile(pinSource,`namespace Xiaozhi.PermissionRuntime { internal sealed class TrustedRuntime { internal string Path,Hash;internal TrustedRuntime(string path,string hash){Path=path;Hash=hash;} } internal static class TrustedRuntimes { internal static readonly TrustedRuntime[] Items={new TrustedRuntime(@"${copiedRuntime}","${beforeHash}")}; } }`);
  const variantExe=path.join(variant,'hash-canary-helper.exe');
  const compileArgs=['/nologo','/target:exe','/platform:x64','/optimize+','/checked+',`/out:${variantExe}`,path.join(root,'NativeSandbox.cs'),pinSource];
  await fs.writeFile(path.join(variant,'compile-command.json'),JSON.stringify({compiler:manifest.compilerPath,args:compileArgs},null,2));
  const compiler=spawn(manifest.compilerPath,compileArgs,{windowsHide:true,stdio:['ignore','pipe','pipe']});let compileLog='';compiler.stdout.on('data',data=>compileLog+=data);compiler.stderr.on('data',data=>compileLog+=data);
  const compilerExit=await new Promise((resolve,reject)=>{compiler.on('error',reject);compiler.on('close',resolve);});await fs.writeFile(path.join(variant,'compile.log'),compileLog);if(compilerExit!==0)throw new Error('Variant compiler failed '+compileLog);
  await fs.appendFile(copiedRuntime,Buffer.from([0]));
  const actualRuntime=await fixture(`'MUST_NOT_RUN'`,{}, {path:copiedRuntime,sha256:beforeHash});
  await test('actual-runtime-byte-change',actualRuntime,{helperPath:variantExe},({result,frames})=>result?.error!=='executable_changed'||frames.some(frame=>frame.type==='started')||!clean(result)?JSON.stringify(result):null);
  for(const [name,command,expected] of [
    ['native-last-failure','cmd /c exit 13',1],
    ['nonterminating-last-error',"Write-Error 'SYNTHETIC_ERROR'",1],
    ['terminating-error',"throw 'SYNTHETIC_THROW'",1],
    ['native-failure-then-success',"cmd /c exit 13;[Console]::WriteLine('RECOVERED_SUCCESS')",0],
  ]){
    const semantic=await fixture(command);
    await test(`exit-semantics-${name}`,semantic,{},({result})=>result?.state!=='completed'||result.exitCode!==expected||!clean(result)?JSON.stringify(result):null);
  }
}
await fs.writeFile(path.join(evidence,'summary.json'), JSON.stringify({suite:suiteName,helperSha256:manifest.helperSha256,results,fixtureRoots},null,2));
console.log(`EVIDENCE ${evidence}`);
console.log(`SUMMARY ${results.filter(result=>result.status==='PASS').length}/${results.length}`);
process.exitCode = results.some(result=>result.status==='FAIL') ? 1 : 0;
