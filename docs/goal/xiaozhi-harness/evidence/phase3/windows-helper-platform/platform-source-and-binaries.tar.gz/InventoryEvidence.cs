using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Globalization;
using Microsoft.Win32;
namespace Xiaozhi.PermissionRuntime {
internal static class InventoryEvidence {
    internal static int Main() {
        string line;
        while((line=Console.ReadLine())!=null){
            Dictionary<string,object> item=Request.Object(Json.Parse(line));
            string profile=Request.Text(item,"profileName",100); int pid=Request.Number(item,"pid",1,int.MaxValue);
            if(!Regex.IsMatch(profile,"^XiaozhiSandbox\\.[0-9a-f]{32}$"))return 2;
            IntPtr sid; if(Native.DeriveAppContainerSidFromAppContainerName(profile,out sid)!=0)return 3;
            try {
                string sidText=new SecurityIdentifier(sid).Value;
                bool mapped;using(RegistryKey key=Registry.CurrentUser.OpenSubKey("Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\CurrentVersion\\AppContainer\\Mappings\\"+sidText))mapped=key!=null;
                bool alive=false;string name=null;string created=null;bool reused=false;
                IntPtr processHandle=Native.OpenProcess(0x100000,false,pid);
                if(processHandle!=IntPtr.Zero){try{alive=Native.WaitForSingleObject(processHandle,0)==258;}finally{Native.CloseHandle(processHandle);}}
                if(alive){try{using(Process process=Process.GetProcessById(pid)){name=process.ProcessName;DateTime began=process.StartTime.ToUniversalTime();created=began.ToString("o");DateTime observed=DateTime.Parse(Request.Text(item,"observedUntilUtc",100),CultureInfo.InvariantCulture,DateTimeStyles.RoundtripKind).ToUniversalTime();reused=began>observed.AddSeconds(1);}}catch{name="unavailable";}}
                Dictionary<string,object> record=new Dictionary<string,object>{{"profileName",profile},{"sid",sidText},{"pid",pid},{"pidExists",alive},{"pidReused",reused},{"currentProcessCreatedUtc",created},{"currentProcessName",name},{"profileFolderExists",Directory.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Packages",profile.ToLowerInvariant(),"AC"))},{"profileMappingExists",mapped}};
                Console.WriteLine(Json.Encode(record));
            }finally{Native.FreeSid(sid);}
        }
        return 0;
    }
}
}
