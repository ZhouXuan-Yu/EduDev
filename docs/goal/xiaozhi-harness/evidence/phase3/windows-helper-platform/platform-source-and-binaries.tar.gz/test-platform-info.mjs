import {spawn} from 'node:child_process';
import {promises as fs} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const evidence=path.join(root,`platform-evidence-${Date.now()}`);
await fs.mkdir(evidence);
const helper=path.join(root,'xiaozhi-sandbox.exe');
const manifest=JSON.parse((await fs.readFile(path.join(root,'sandbox-manifest.json'),'utf8')).replace(/^\uFEFF/,''));
const results=[];
async function run(file,args,env=process.env){
    const child=spawn(file,args,{windowsHide:true,detached:true,stdio:['ignore','pipe','pipe'],env});
    let stdout='',stderr='';
    child.stdout.on('data',data=>stdout+=data.toString('utf8'));
    child.stderr.on('data',data=>stderr+=data.toString('utf8'));
    const timeout=setTimeout(()=>child.kill(),10000);
    const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',resolve);});
    clearTimeout(timeout);
    return {code,stdout,stderr};
}
function add(name,pass,detail){results.push({name,status:pass?'PASS':'FAIL',detail});console.log(`${pass?'PASS':'FAIL'} ${name}`);}
const baseline=await run(helper,['--platform-info']);
await fs.writeFile(path.join(evidence,'platform-info.stdout.ndjson'),baseline.stdout);
await fs.writeFile(path.join(evidence,'platform-info.stderr.log'),baseline.stderr);
const info=JSON.parse(baseline.stdout);
add('platform-single-readonly-frame',baseline.code===0&&baseline.stderr===''&&baseline.stdout.trim().split('\n').length===1&&info.schemaVersion===1&&info.type==='platform_info'&&info.platform==='win32'&&info.runtimes.length===2,baseline);
for(const runtime of info.runtimes){
    const actual=crypto.createHash('sha256').update(await fs.readFile(runtime.path)).digest('hex');
    add(`actual-sha-${runtime.kind}`,actual===runtime.sha256,{actual,reported:runtime.sha256});
    add(`offline-microsoft-${runtime.kind}`,runtime.trust==='verified'&&['catalog','embedded'].includes(runtime.trustSource)&&runtime.publisher.startsWith('Microsoft'),runtime);
}
const poisoned={...process.env};
for(const key of Object.keys(poisoned))if(['systemroot','windir','path','temp','tmp','localappdata','userprofile'].includes(key.toLowerCase()))delete poisoned[key];
for(const key of ['SystemRoot','windir','PATH','TEMP','TMP','LOCALAPPDATA','USERPROFILE'])poisoned[key]=path.join(evidence,'FORGED-WINDOWS');
const spoofed=await run(helper,['--platform-info'],poisoned);
await fs.writeFile(path.join(evidence,'poisoned-env.stdout.ndjson'),spoofed.stdout);
add('forged-environment-does-not-select-tools',spoofed.code===0&&spoofed.stdout===baseline.stdout,{code:spoofed.code,stderr:spoofed.stderr});

const probe=path.join(evidence,'trust-probe.exe');
const compileArgs=['/nologo','/target:exe','/platform:x64','/optimize+','/checked+','/main:Xiaozhi.PermissionRuntime.TrustProbe',`/out:${probe}`,path.join(root,'NativeSandbox.cs'),path.join(root,'TrustedRuntimes.cs'),path.join(root,'TrustProbe.cs')];
const compiled=await run(manifest.compilerPath,compileArgs);
await fs.writeFile(path.join(evidence,'probe-build.json'),JSON.stringify({compiler:manifest.compilerPath,args:compileArgs,...compiled},null,2));
if(compiled.code!==0)throw new Error('Trust probe build failed '+compiled.stdout);
const systemPowerShell=info.runtimes.find(runtime=>runtime.kind==='powershell5');
const copy=path.join(evidence,'owned-powershell.exe');
await fs.copyFile(systemPowerShell.path,copy);
const pristine=await run(probe,[copy]);
const pristineInfo=JSON.parse(pristine.stdout);
add('owned-identical-bytes-catalog-verification',pristineInfo.sha256===systemPowerShell.sha256&&pristineInfo.trust==='verified'&&pristineInfo.trustSource==='catalog',pristineInfo);
await fs.appendFile(copy,Buffer.from([0x5a]));
const tampered=await run(probe,[copy]);
const tamperedInfo=JSON.parse(tampered.stdout);
add('mutated-actual-bytes-not-verified',tamperedInfo.sha256!==systemPowerShell.sha256&&tamperedInfo.trust!=='verified',tamperedInfo);
const plain=path.join(evidence,'unsigned.bin');await fs.writeFile(plain,'SYNTHETIC_UNSIGNED');
const unsigned=JSON.parse((await run(probe,[plain])).stdout);
add('unsigned-actual-bytes-not-verified',unsigned.trust!=='verified',unsigned);
const linked=path.join(evidence,'reparse');await fs.symlink(evidence,linked,'junction');
const linkedInfo=JSON.parse((await run(probe,[path.join(linked,'owned-powershell.exe')])).stdout);
add('reparse-path-rejected',linkedInfo.trust==='untrusted'&&linkedInfo.reason==='unsafe_path'&&linkedInfo.sha256===null,linkedInfo);
const missing=JSON.parse((await run(probe,[path.join(evidence,'missing.exe')])).stdout);
add('missing-runtime-unavailable',missing.trust==='unavailable'&&missing.sha256===null,missing);
const record={schemaVersion:1,helperSha256:manifest.helperSha256,results,platform:info,evidence};
await fs.writeFile(path.join(evidence,'summary.json'),JSON.stringify(record,null,2));
console.log(`EVIDENCE ${evidence}`);
console.log(`SUMMARY ${results.filter(result=>result.status==='PASS').length}/${results.length}`);
process.exitCode=results.some(result=>result.status==='FAIL')?1:0;
