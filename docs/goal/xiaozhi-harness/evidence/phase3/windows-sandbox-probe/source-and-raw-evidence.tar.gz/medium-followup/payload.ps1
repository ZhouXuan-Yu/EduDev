[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$ErrorActionPreference='Stop'
[Console]::WriteLine('MEDIUM_START ' + $PSVersionTable.PSVersion)
try { [IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\medium-followup\medium-workspace\created.txt','MEDIUM_CREATE_SUCCESS'); [Console]::WriteLine('CREATE_PASS') } catch { [Console]::WriteLine('CREATE_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\medium-followup\medium-workspace\existing.txt','MEDIUM_OVERWRITE_SUCCESS'); [Console]::WriteLine('OVERWRITE_PASS') } catch { [Console]::WriteLine('OVERWRITE_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::Move('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\medium-followup\medium-workspace\created.txt','C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\medium-followup\medium-workspace\renamed.txt'); [Console]::WriteLine('RENAME_PASS') } catch { [Console]::WriteLine('RENAME_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\medium-followup\sibling-canary.txt','LEAK'); [Console]::WriteLine('SIBLING_WRITE_LEAK') } catch { [Console]::WriteLine('SIBLING_WRITE_DENIED '+$_.Exception.GetType().FullName) }
[Console]::WriteLine('MEDIUM_END')
exit 41
