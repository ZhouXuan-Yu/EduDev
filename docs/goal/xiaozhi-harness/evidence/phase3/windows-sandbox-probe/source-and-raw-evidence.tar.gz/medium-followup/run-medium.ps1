$ErrorActionPreference='Stop'
$probeRoot=$PSScriptRoot
$workspace=Join-Path $probeRoot 'medium-workspace'
$canary=Join-Path $probeRoot 'sibling-canary.txt'
$profileName='XiaozhiMedium3314308a542041038fb20355f5e385dc'
$sid=[IntPtr]::Zero
$created=$false
$outcomes=[ordered]@{schemaVersion=1; started=(Get-Date -Format o); test='Explicit Medium MIC, exact AppContainer SID Modify DACL only'; sourceOriginalEvidenceUnchanged=$true}
New-Item -ItemType Directory -Path $workspace -Force | Out-Null
Start-Transcript -LiteralPath (Join-Path $probeRoot 'transcript.log') | Out-Null
try {
  Add-Type -Path (Join-Path (Split-Path $probeRoot -Parent) 'NativeProbe.cs')
  'ParentToken '+[NativeProbe]::ParentTokenSummary()
  Set-Content -LiteralPath (Join-Path $workspace 'existing.txt') -Value 'BEFORE' -NoNewline
  Set-Content -LiteralPath $canary -Value 'SYNTHETIC_MEDIUM_SIBLING' -NoNewline
  & icacls $workspace /setintegritylevel '(OI)(CI)M'
  if($LASTEXITCODE -ne 0){throw 'Explicit Medium integrity setup failed'}
  & icacls (Join-Path $workspace 'existing.txt') /setintegritylevel M
  if($LASTEXITCODE -ne 0){throw 'Explicit Medium file integrity setup failed'}
  & icacls $workspace | Set-Content -LiteralPath (Join-Path $probeRoot 'before-icacls.txt')
  & icacls (Join-Path $workspace 'existing.txt') | Add-Content -LiteralPath (Join-Path $probeRoot 'before-icacls.txt')
  Get-Content -LiteralPath (Join-Path $probeRoot 'before-icacls.txt')
  $hr=[NativeProbe]::CreateAppContainerProfile($profileName,$profileName,'Owned TEMP Medium MIC probe',[IntPtr]::Zero,0,[ref]$sid)
  'CreateProfile HRESULT='+$hr
  if($hr -ne 0){throw "Profile failed $hr"}
  $created=$true
  $sidText=[NativeProbe]::SidText($sid)
  $outcomes.sid=$sidText
  $profileFolder=[NativeProbe]::ProfileFolder($sidText)
  $acl=Get-Acl -LiteralPath $workspace
  $rule=[Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($sidText),'Modify','ContainerInherit,ObjectInherit','None','Allow')
  $acl.AddAccessRule($rule)
  Set-Acl -LiteralPath $workspace -AclObject $acl
  & icacls $workspace | Set-Content -LiteralPath (Join-Path $probeRoot 'granted-icacls.txt')
  Get-Content -LiteralPath (Join-Path $probeRoot 'granted-icacls.txt')
  $payload=@'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$ErrorActionPreference='Stop'
[Console]::WriteLine('MEDIUM_START ' + $PSVersionTable.PSVersion)
try { [IO.File]::WriteAllText('__WORKSPACE__\created.txt','MEDIUM_CREATE_SUCCESS'); [Console]::WriteLine('CREATE_PASS') } catch { [Console]::WriteLine('CREATE_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::WriteAllText('__WORKSPACE__\existing.txt','MEDIUM_OVERWRITE_SUCCESS'); [Console]::WriteLine('OVERWRITE_PASS') } catch { [Console]::WriteLine('OVERWRITE_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::Move('__WORKSPACE__\created.txt','__WORKSPACE__\renamed.txt'); [Console]::WriteLine('RENAME_PASS') } catch { [Console]::WriteLine('RENAME_FAIL '+$_.Exception.ToString()) }
try { [IO.File]::WriteAllText('__CANARY__','LEAK'); [Console]::WriteLine('SIBLING_WRITE_LEAK') } catch { [Console]::WriteLine('SIBLING_WRITE_DENIED '+$_.Exception.GetType().FullName) }
[Console]::WriteLine('MEDIUM_END')
exit 41
'@
  $payload=$payload.Replace('__WORKSPACE__',$workspace).Replace('__CANARY__',$canary)
  $payload | Set-Content -LiteralPath (Join-Path $probeRoot 'payload.ps1')
  $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($payload))
  $shell='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
  $outcomes.launch=[NativeProbe]::Launch($sid,$shell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encoded",$workspace,(Join-Path $probeRoot 'stdout.log'),15000,$false)
  $outcomes.launch
  Get-Content -LiteralPath (Join-Path $probeRoot 'stdout.log')
  $outcomes.existingReadback=Get-Content -LiteralPath (Join-Path $workspace 'existing.txt') -Raw
  $outcomes.createdAndRenamed=Test-Path -LiteralPath (Join-Path $workspace 'renamed.txt')
  $outcomes.canaryUnchanged=(Get-Content -LiteralPath $canary -Raw) -eq 'SYNTHETIC_MEDIUM_SIBLING'
  & icacls $workspace | Set-Content -LiteralPath (Join-Path $probeRoot 'after-icacls.txt')
  & icacls (Join-Path $workspace 'existing.txt') | Add-Content -LiteralPath (Join-Path $probeRoot 'after-icacls.txt')
  Get-Content -LiteralPath (Join-Path $probeRoot 'after-icacls.txt')
} catch { $outcomes.error=$_.Exception.ToString(); $_ | Format-List * -Force } finally {
  if($created){$outcomes.deleteProfileHr=[NativeProbe]::DeleteAppContainerProfile($profileName); $outcomes.profileFolderExists=Test-Path -LiteralPath $profileFolder; $outcomes.profileMappingExists=Test-Path -LiteralPath ('Registry::HKEY_CURRENT_USER\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Mappings\'+$sidText)}
  if($sid -ne [IntPtr]::Zero){
    $acl=Get-Acl -LiteralPath $workspace
    @($acl.Access | Where-Object {$_.IdentityReference.Value -eq $sidText}) | ForEach-Object {$acl.RemoveAccessRuleSpecific($_)}
    Set-Acl -LiteralPath $workspace -AclObject $acl
    $outcomes.remainingSidAces=@(@(Get-Item -LiteralPath $workspace)+@(Get-ChildItem -LiteralPath $workspace -Recurse) | ForEach-Object {(Get-Acl -LiteralPath $_.FullName).Access | Where-Object {$_.IdentityReference.Value -eq $sidText}}).Count
    [NativeProbe]::FreeSid($sid) | Out-Null
  }
  $outcomes.ended=Get-Date -Format o
  $outcomes | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $probeRoot 'results.json')
  $outcomes | ConvertTo-Json -Depth 5
  Stop-Transcript | Out-Null
}
