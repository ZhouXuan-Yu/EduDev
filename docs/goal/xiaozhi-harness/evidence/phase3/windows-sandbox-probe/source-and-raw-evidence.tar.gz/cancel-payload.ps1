$info = [Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$info.Arguments='-NoLogo -NoProfile -NonInteractive -EncodedCommand WwBJAE8ALgBGAGkAbABlAF0AOgA6AFcAcgBpAHQAZQBBAGwAbABUAGUAeAB0ACgAJwBDADoAXABVAHMAZQByAHMAXABaAGgAbwB1AFgAdQBhAG4AXABBAHAAcABEAGEAdABhAFwATABvAGMAYQBsAFwAVABlAG0AcABcAHgAaQBhAG8AegBoAGkALQB3AGkAbgBkAG8AdwBzAC0AcwBhAG4AZABiAG8AeAAtADMAMwAxADQAMwAwADgAYQA1ADQAMgAwADQAMQAwADMAOABmAGIAMgAwADMANQA1AGYANQBlADMAOAA1AGQAYwBcAHcAbwByAGsAcwBwAGEAYwBlAFwAYwBoAGkAbABkAC0AcwB0AGEAcgB0AGUAZAAuAHQAeAB0ACcALABbAHMAdAByAGkAbgBnAF0AJABQAEkARAApADsAIABbAFQAaAByAGUAYQBkAGkAbgBnAC4AVABoAHIAZQBhAGQAXQA6ADoAUwBsAGUAZQBwACgAMwAwADAAMAAwACkA'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$child=[Diagnostics.Process]::Start($info)
[IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\workspace\child-pid.txt',[string]$child.Id)
[Console]::WriteLine('CHILD_STARTED pid=' + $child.Id)
[Threading.Thread]::Sleep(30000)
