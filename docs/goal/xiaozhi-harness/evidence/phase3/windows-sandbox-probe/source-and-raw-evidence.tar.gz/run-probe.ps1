param([switch]$OnlyLpac)
$ErrorActionPreference = 'Stop'
$probeRoot = $PSScriptRoot
$profileName = 'XiaozhiProbe3314308a542041038fb20355f5e385dc'
$workspace = Join-Path $probeRoot 'workspace'
$canary = Join-Path $probeRoot 'outside-canary.txt'
$sid = [IntPtr]::Zero
$profileCreated = $false
$listener = $null
New-Item -ItemType Directory -Path $workspace -Force | Out-Null
Set-Content -LiteralPath $canary -Value 'SYNTHETIC_SIBLING_CANARY_3314308a' -NoNewline
Set-Content -LiteralPath (Join-Path $workspace 'input.txt') -Value '4,5,6' -NoNewline
Start-Transcript -LiteralPath (Join-Path $probeRoot 'run-transcript.log') -Append | Out-Null
try {
    'START ' + (Get-Date -Format o)
    $PSVersionTable | Format-List
    [Environment]::OSVersion.VersionString
    & dotnet --info
    Add-Type -Path (Join-Path $probeRoot 'NativeProbe.cs')
    'ParentToken ' + [NativeProbe]::ParentTokenSummary()
    $hr = [NativeProbe]::CreateAppContainerProfile($profileName,$profileName,'TEMP synthetic sandbox probe',[IntPtr]::Zero,0,[ref]$sid)
    'CreateAppContainerProfile HRESULT=' + $hr
    if ($hr -ne 0) { throw "Profile creation failed $hr" }
    $profileCreated = $true
    $sidText = [NativeProbe]::SidText($sid)
    'SID=' + $sidText
    $profileFolder = [NativeProbe]::ProfileFolder($sidText)
    'ProfileFolder=' + $profileFolder
    'ProfileFolderBeforeExists=' + (Test-Path -LiteralPath $profileFolder)
    $sidObject = [Security.Principal.SecurityIdentifier]::new($sidText)
    $acl = Get-Acl -LiteralPath $workspace
    $acl.Sddl | Set-Content -LiteralPath (Join-Path $probeRoot 'workspace-before.sddl')
    $rule = [Security.AccessControl.FileSystemAccessRule]::new($sidObject,'Modify','ContainerInherit,ObjectInherit','None','Allow')
    $acl.AddAccessRule($rule)
    Set-Acl -LiteralPath $workspace -AclObject $acl
    & icacls $workspace /setintegritylevel '(OI)(CI)L'
    if ($LASTEXITCODE -ne 0) { throw 'Owned fixture low integrity ACL failed' }
    (Get-Acl -LiteralPath $workspace).Sddl | Set-Content -LiteralPath (Join-Path $probeRoot 'workspace-granted.sddl')
    (Get-Acl -LiteralPath $canary).Sddl | Set-Content -LiteralPath (Join-Path $probeRoot 'outside-canary.sddl')
    if ($OnlyLpac) {
        'CORRECTED_LPAC_ATTRIBUTE=0x2000f OPT_OUT=1'
        $lpacShell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
        $lpacPayload = '[Console]::WriteLine("HELLO_TRUE_LPAC"); exit 23'
        $lpacEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($lpacPayload))
        [NativeProbe]::Launch($sid,$lpacShell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $lpacEncoded",$workspace,(Join-Path $probeRoot 'lpac-corrected-stdout.log'),15000,$true)
        Get-Content -LiteralPath (Join-Path $probeRoot 'lpac-corrected-stdout.log')
        return
    }
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
    $listener.Start()
    $port = $listener.LocalEndpoint.Port
    'loopbackPort=' + $port
    $control = [Net.Sockets.TcpClient]::new()
    $control.Connect('127.0.0.1',$port)
    'UnconfinedLoopbackControlConnected=' + $control.Connected
    $accepted = $listener.AcceptTcpClient()
    $accepted.Dispose()
    $control.Dispose()
    $shell = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
    $simple = '[Console]::WriteLine("HELLO_APP_CONTAINER"); exit 23'
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($simple))
    [NativeProbe]::Launch($sid,$shell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encoded",$workspace,(Join-Path $probeRoot 'basic-stdout.log'),15000,$false)
    Get-Content -LiteralPath (Join-Path $probeRoot 'basic-stdout.log')
    $script = @'
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::WriteLine('FULL_SCRIPT_START')
[Console]::WriteLine('POWERSHELL_VERSION ' + $PSVersionTable.PSVersion)
try {
  $numbers = ([IO.File]::ReadAllText('__WORKSPACE__\input.txt')).Split(',') | ForEach-Object { [int]$_ }
  $squares = @($numbers | Where-Object { $_ -ge 4 } | ForEach-Object { $_ * $_ })
  $sum = 0; foreach ($n in $squares) { $sum += $n }
  [IO.File]::WriteAllText('__WORKSPACE__\output.txt',"sum=$sum unicode=教师中文")
  [Console]::WriteLine('WORKSPACE_RW_PASS ' + [IO.File]::ReadAllText('__WORKSPACE__\output.txt'))
} catch { [Console]::WriteLine('WORKSPACE_RW_FAIL ' + $_.Exception.ToString()) }
try { [Console]::WriteLine('SIBLING_LEAK ' + [IO.File]::ReadAllText('__CANARY__')) } catch { [Console]::WriteLine('SIBLING_DENIED ' + $_.Exception.ToString()) }
try { [IO.File]::WriteAllText('__CANARY__','CORRUPTED'); [Console]::WriteLine('SIBLING_WRITE_LEAK') } catch { [Console]::WriteLine('SIBLING_WRITE_DENIED ' + $_.Exception.ToString()) }
try {
  $client = [Net.Sockets.TcpClient]::new()
  $task = $client.ConnectAsync('127.0.0.1',__PORT__)
  if (!$task.Wait(1500)) { throw 'socket timeout' }
  [Console]::WriteLine('DIRECT_SOCKET_CONNECTED')
} catch { [Console]::WriteLine('DIRECT_SOCKET_DENIED ' + $_.Exception.ToString()) } finally { if ($client) { $client.Dispose() } }
[Console]::WriteLine('FULL_SCRIPT_END')
exit 37
'@
    $script = $script.Replace('__WORKSPACE__',$workspace).Replace('__CANARY__',$canary).Replace('__PORT__',[string]$port)
    $script | Set-Content -LiteralPath (Join-Path $probeRoot 'synthetic-payload.ps1')
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($script))
    [NativeProbe]::Launch($sid,$shell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encoded",$workspace,(Join-Path $probeRoot 'full-stdout.log'),20000,$false)
    Get-Content -LiteralPath (Join-Path $probeRoot 'full-stdout.log')
    'ListenerPending=' + $listener.Pending()
    'CanaryUnchanged=' + ((Get-Content -LiteralPath $canary -Raw) -eq 'SYNTHETIC_SIBLING_CANARY_3314308a')
    'WorkspaceUnicodeReadback=' + (Get-Content -LiteralPath (Join-Path $workspace 'output.txt') -Raw)
    $childScript = "[IO.File]::WriteAllText('$workspace\child-started.txt',[string]`$PID); [Threading.Thread]::Sleep(30000)"
    $childEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($childScript))
    $cancelScript = @'
$info = [Diagnostics.ProcessStartInfo]::new()
$info.FileName='C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
$info.Arguments='-NoLogo -NoProfile -NonInteractive -EncodedCommand __CHILD__'
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$child=[Diagnostics.Process]::Start($info)
[IO.File]::WriteAllText('__WORKSPACE__\child-pid.txt',[string]$child.Id)
[Console]::WriteLine('CHILD_STARTED pid=' + $child.Id)
[Threading.Thread]::Sleep(30000)
'@
    $cancelScript = $cancelScript.Replace('__CHILD__',$childEncoded).Replace('__WORKSPACE__',$workspace)
    $cancelScript | Set-Content -LiteralPath (Join-Path $probeRoot 'cancel-payload.ps1')
    $cancelEncoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cancelScript))
    [NativeProbe]::Launch($sid,$shell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $cancelEncoded",$workspace,(Join-Path $probeRoot 'cancel-stdout.log'),2500,$false)
    Get-Content -LiteralPath (Join-Path $probeRoot 'cancel-stdout.log')
    $childPid = [int](Get-Content -LiteralPath (Join-Path $workspace 'child-pid.txt') -Raw)
    'ChildScriptStarted=' + (Test-Path -LiteralPath (Join-Path $workspace 'child-started.txt'))
    'ChildAliveAfterCancel=' + [bool](Get-Process -Id $childPid -ErrorAction SilentlyContinue)
    $shell7 = (Get-Command pwsh).Source
    'PowerShell7Path=' + $shell7
    [NativeProbe]::Launch($sid,$shell7,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encoded",$workspace,(Join-Path $probeRoot 'powershell7-stdout.log'),15000,$false)
    Get-Content -LiteralPath (Join-Path $probeRoot 'powershell7-stdout.log')
    'ListenerPendingAfterPowerShell7=' + $listener.Pending()
    'CanaryUnchangedAfterPowerShell7=' + ((Get-Content -LiteralPath $canary -Raw) -eq 'SYNTHETIC_SIBLING_CANARY_3314308a')
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($simple))
    [NativeProbe]::Launch($sid,$shell,"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand $encoded",$workspace,(Join-Path $probeRoot 'lpac-stdout.log'),15000,$true)
    Get-Content -LiteralPath (Join-Path $probeRoot 'lpac-stdout.log')
} catch {
    $_ | Format-List * -Force
    $_.ScriptStackTrace
} finally {
    if ($listener) { $listener.Stop(); 'ListenerStopped=True' }
    if ($profileCreated) {
        $cleanupHr = [NativeProbe]::DeleteAppContainerProfile($profileName)
        'DeleteAppContainerProfile HRESULT=' + $cleanupHr
        $secondHr = [NativeProbe]::DeleteAppContainerProfile($profileName)
        'DeleteAgain HRESULT=' + $secondHr
        'ProfileFolderAfterExists=' + (Test-Path -LiteralPath $profileFolder)
        $mappingPath = 'Registry::HKEY_CURRENT_USER\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Mappings\' + $sidText
        'ProfileMappingAfterExists=' + (Test-Path -LiteralPath $mappingPath)
    }
    if ($sid -ne [IntPtr]::Zero) {
        $cleanupAcl = Get-Acl -LiteralPath $workspace
        @($cleanupAcl.Access | Where-Object { $_.IdentityReference.Value -eq $sidText }) | ForEach-Object { $cleanupAcl.RemoveAccessRuleSpecific($_) }
        Set-Acl -LiteralPath $workspace -AclObject $cleanupAcl
        'RemainingOwnSidACE=' + @((Get-Acl -LiteralPath $workspace).Access | Where-Object { $_.IdentityReference.Value -eq $sidText }).Count
        $remaining = @(Get-ChildItem -LiteralPath $workspace -Recurse | ForEach-Object { (Get-Acl -LiteralPath $_.FullName).Access | Where-Object { $_.IdentityReference.Value -eq $sidText } }).Count
        'RemainingDescendantOwnSidACE=' + $remaining
        & icacls $workspace /setintegritylevel '(OI)(CI)M'
        (Get-Acl -LiteralPath $workspace).Sddl | Set-Content -LiteralPath (Join-Path $probeRoot 'workspace-cleaned.sddl')
        [NativeProbe]::FreeSid($sid) | Out-Null
    }
    'END ' + (Get-Date -Format o)
    Stop-Transcript | Out-Null
}
