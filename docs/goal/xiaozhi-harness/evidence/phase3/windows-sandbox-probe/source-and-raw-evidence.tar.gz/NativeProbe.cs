using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.ComponentModel;

public static class NativeProbe {
 [StructLayout(LayoutKind.Sequential)] struct SECURITY_ATTRIBUTES { public int nLength; public IntPtr lpSecurityDescriptor; public int bInheritHandle; }
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct STARTUPINFO { public int cb; public string lpReserved,lpDesktop,lpTitle; public int dwX,dwY,dwXSize,dwYSize,dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags; public short wShowWindow,cbReserved2; public IntPtr lpReserved2,hStdInput,hStdOutput,hStdError; }
 [StructLayout(LayoutKind.Sequential)] struct STARTUPINFOEX { public STARTUPINFO StartupInfo; public IntPtr lpAttributeList; }
 [StructLayout(LayoutKind.Sequential)] struct PROCESS_INFORMATION { public IntPtr hProcess,hThread; public int dwProcessId,dwThreadId; }
 [StructLayout(LayoutKind.Sequential)] struct SECURITY_CAPABILITIES { public IntPtr AppContainerSid,Capabilities; public int CapabilityCount,Reserved; }
 [StructLayout(LayoutKind.Sequential)] struct JOBOBJECT_BASIC_LIMIT_INFORMATION { public long PerProcessUserTimeLimit,PerJobUserTimeLimit; public uint LimitFlags; public UIntPtr MinimumWorkingSetSize,MaximumWorkingSetSize; public uint ActiveProcessLimit; public UIntPtr Affinity; public uint PriorityClass,SchedulingClass; }
 [StructLayout(LayoutKind.Sequential)] struct IO_COUNTERS { public ulong ReadOperationCount,WriteOperationCount,OtherOperationCount,ReadTransferCount,WriteTransferCount,OtherTransferCount; }
 [StructLayout(LayoutKind.Sequential)] struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION { public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation; public IO_COUNTERS IoInfo; public UIntPtr ProcessMemoryLimit,JobMemoryLimit,PeakProcessMemoryUsed,PeakJobMemoryUsed; }
 [StructLayout(LayoutKind.Sequential)] struct JOBOBJECT_BASIC_ACCOUNTING_INFORMATION { public long TotalUserTime,TotalKernelTime,ThisPeriodTotalUserTime,ThisPeriodTotalKernelTime; public uint TotalPageFaultCount,TotalProcesses,ActiveProcesses,TotalTerminatedProcesses; }
 [DllImport("userenv.dll",CharSet=CharSet.Unicode)] public static extern int CreateAppContainerProfile(string name,string display,string description,IntPtr capabilities,uint count,out IntPtr sid);
 [DllImport("userenv.dll",CharSet=CharSet.Unicode)] public static extern int DeleteAppContainerProfile(string name);
 [DllImport("userenv.dll",CharSet=CharSet.Unicode)] public static extern int DeriveAppContainerSidFromAppContainerName(string name,out IntPtr sid);
 [DllImport("userenv.dll",CharSet=CharSet.Unicode)] static extern int GetAppContainerFolderPath(string sid,out IntPtr path);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool ConvertSidToStringSid(IntPtr sid,out IntPtr str);
 [DllImport("advapi32.dll")] public static extern IntPtr FreeSid(IntPtr sid);
 [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr mem);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,int flags,ref IntPtr size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,IntPtr attribute,IntPtr value,IntPtr size,IntPtr prev,IntPtr ret);
 [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcess(string application,StringBuilder command,IntPtr processAttributes,IntPtr threadAttributes,bool inherit,uint flags,IntPtr environment,string directory,ref STARTUPINFOEX startup,out PROCESS_INFORMATION info);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateFile(string name,uint access,uint share,ref SECURITY_ATTRIBUTES attributes,uint creation,uint flags,IntPtr template);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr attributes,string name);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int infoClass,ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION info,int length);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job,IntPtr process);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool IsProcessInJob(IntPtr process,IntPtr job,out bool result);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateJobObject(IntPtr job,uint exit);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool QueryInformationJobObject(IntPtr job,int kind,out JOBOBJECT_BASIC_ACCOUNTING_INFORMATION info,int size,IntPtr required);
 [DllImport("kernel32.dll")] static extern uint ResumeThread(IntPtr thread);
 [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll")] static extern bool GetExitCodeProcess(IntPtr process,out uint exit);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr process,uint access,out IntPtr token);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr token,int kind,IntPtr data,int size,out int required);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateProcess(IntPtr process,uint exit);
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("advapi32.dll")] static extern bool IsTokenRestricted(IntPtr token);
 public static string SidText(IntPtr sid) { IntPtr str; if(!ConvertSidToStringSid(sid,out str)) throw new Win32Exception(); try{return Marshal.PtrToStringUni(str);}finally{LocalFree(str);} }
 public static string ProfileFolder(string sid) { IntPtr path; int hr=GetAppContainerFolderPath(sid,out path); if(hr!=0) throw new Exception("GetAppContainerFolderPath HRESULT="+hr); try{return Marshal.PtrToStringUni(path);}finally{Marshal.FreeCoTaskMem(path);} }
 public static string ParentTokenSummary() { return TokenSummary(GetCurrentProcess()); }
 static string TokenSummary(IntPtr process) {
  IntPtr token=IntPtr.Zero,data=IntPtr.Zero;
  try {
   Check(OpenProcessToken(process,8,out token),"Open summary token"); data=Marshal.AllocHGlobal(1024); int needed;
   Check(GetTokenInformation(token,29,data,1024,out needed),"Summary TokenIsAppContainer"); int app=Marshal.ReadInt32(data);
   Check(GetTokenInformation(token,25,data,1024,out needed),"Summary integrity"); string integrity=SidText(Marshal.ReadIntPtr(data));
   string appSid="none"; int count=0;
   if(app!=0) {
    Check(GetTokenInformation(token,31,data,1024,out needed),"Summary AppContainerSid"); appSid=SidText(Marshal.ReadIntPtr(data));
    Check(GetTokenInformation(token,30,data,1024,out needed),"Summary capabilities"); count=Marshal.ReadInt32(data);
   }
   string lowPrivilege="unavailable";
   if(GetTokenInformation(token,46,data,1024,out needed)) lowPrivilege=Marshal.ReadInt32(data).ToString();
   return "isAppContainer="+app+" restricted="+IsTokenRestricted(token)+" isLessPrivileged="+lowPrivilege+" integrity="+integrity+" appSid="+appSid+" capabilities="+count;
  } finally { if(token!=IntPtr.Zero) CloseHandle(token); if(data!=IntPtr.Zero) Marshal.FreeHGlobal(data); }
 }
 static void Check(bool result,string stage) { if(!result) throw new Win32Exception(Marshal.GetLastWin32Error(),stage); }
 public static string Launch(IntPtr sid,string shell,string arguments,string cwd,string log,int timeout,bool lpac) {
  IntPtr list=IntPtr.Zero,cap=IntPtr.Zero,handles=IntPtr.Zero,opt=IntPtr.Zero,env=IntPtr.Zero,job=IntPtr.Zero,token=IntPtr.Zero,tokenData=IntPtr.Zero;
  IntPtr output=IntPtr.Zero,input=IntPtr.Zero; PROCESS_INFORMATION pi=new PROCESS_INFORMATION();
  try {
   SECURITY_ATTRIBUTES sa=new SECURITY_ATTRIBUTES{nLength=Marshal.SizeOf(typeof(SECURITY_ATTRIBUTES)),bInheritHandle=1};
   output=CreateFile(log,0x40000000,3,ref sa,2,0x80,IntPtr.Zero); Check(output!=new IntPtr(-1),"Create output");
   input=CreateFile("NUL",0x80000000,3,ref sa,3,0x80,IntPtr.Zero); Check(input!=new IntPtr(-1),"Create stdin");
   IntPtr bytes=IntPtr.Zero; InitializeProcThreadAttributeList(IntPtr.Zero,lpac?3:2,0,ref bytes);
   list=Marshal.AllocHGlobal(bytes); Check(InitializeProcThreadAttributeList(list,lpac?3:2,0,ref bytes),"Initialize attributes");
   SECURITY_CAPABILITIES sc=new SECURITY_CAPABILITIES{AppContainerSid=sid}; cap=Marshal.AllocHGlobal(Marshal.SizeOf(sc)); Marshal.StructureToPtr(sc,cap,false);
   Check(UpdateProcThreadAttribute(list,0,new IntPtr(0x20009),cap,new IntPtr(Marshal.SizeOf(sc)),IntPtr.Zero,IntPtr.Zero),"AppContainer attribute");
   handles=Marshal.AllocHGlobal(IntPtr.Size*2); Marshal.WriteIntPtr(handles,output); Marshal.WriteIntPtr(handles,IntPtr.Size,input);
   Check(UpdateProcThreadAttribute(list,0,new IntPtr(0x20002),handles,new IntPtr(IntPtr.Size*2),IntPtr.Zero,IntPtr.Zero),"Handle list");
   if(lpac) { opt=Marshal.AllocHGlobal(4); Marshal.WriteInt32(opt,1); Check(UpdateProcThreadAttribute(list,0,new IntPtr(0x2000f),opt,new IntPtr(4),IntPtr.Zero,IntPtr.Zero),"LPAC AllApplicationPackagesPolicy attribute"); }
   job=CreateJobObject(IntPtr.Zero,null); Check(job!=IntPtr.Zero,"Create Job");
   JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits=new JOBOBJECT_EXTENDED_LIMIT_INFORMATION(); limits.BasicLimitInformation.LimitFlags=0x2000;
   Check(SetInformationJobObject(job,9,ref limits,Marshal.SizeOf(limits)),"Kill-on-close Job");
   string envText="APPDATA="+Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)+"\0LOCALAPPDATA="+Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)+"\0PATH=C:\\Windows\\System32;"+Path.GetDirectoryName(shell)+"\0SystemDrive=C:\0SystemRoot=C:\\Windows\0TEMP="+cwd+"\0TMP="+cwd+"\0USERPROFILE="+Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)+"\0windir=C:\\Windows\0\0";
   env=Marshal.StringToHGlobalUni(envText);
   STARTUPINFOEX si=new STARTUPINFOEX(); si.StartupInfo.cb=Marshal.SizeOf(si); si.StartupInfo.dwFlags=0x100; si.StartupInfo.hStdInput=input; si.StartupInfo.hStdOutput=output; si.StartupInfo.hStdError=output; si.lpAttributeList=list;
   Check(CreateProcess(shell,new StringBuilder("\""+shell+"\" "+arguments),IntPtr.Zero,IntPtr.Zero,true,0x80000|0x400|0x4|0x8000000,env,cwd,ref si,out pi),"CreateProcess AppContainer");
   Check(AssignProcessToJobObject(job,pi.hProcess),"Assign suspended process Job");
   Check(OpenProcessToken(pi.hProcess,8,out token),"Open token"); tokenData=Marshal.AllocHGlobal(4); int needed;
   Check(GetTokenInformation(token,29,tokenData,4,out needed),"TokenIsAppContainer"); int isAC=Marshal.ReadInt32(tokenData);
   bool inJob; Check(IsProcessInJob(pi.hProcess,job,out inJob),"IsProcessInJob");
   string tokenSummary=TokenSummary(pi.hProcess);
   ResumeThread(pi.hThread); uint wait=WaitForSingleObject(pi.hProcess,(uint)timeout); bool timedOut=wait==258;
   JOBOBJECT_BASIC_ACCOUNTING_INFORMATION before; Check(QueryInformationJobObject(job,1,out before,Marshal.SizeOf(typeof(JOBOBJECT_BASIC_ACCOUNTING_INFORMATION)),IntPtr.Zero),"Job accounting before cancel");
   if(timedOut || before.ActiveProcesses>0) { Check(TerminateJobObject(job,timedOut?124u:125u),"Cancel or drain owned job"); WaitForSingleObject(pi.hProcess,5000); }
   JOBOBJECT_BASIC_ACCOUNTING_INFORMATION after; Check(QueryInformationJobObject(job,1,out after,Marshal.SizeOf(typeof(JOBOBJECT_BASIC_ACCOUNTING_INFORMATION)),IntPtr.Zero),"Job accounting after cancel");
   for(int retry=0;after.ActiveProcesses>0 && retry<100;retry++) { System.Threading.Thread.Sleep(50); Check(QueryInformationJobObject(job,1,out after,Marshal.SizeOf(typeof(JOBOBJECT_BASIC_ACCOUNTING_INFORMATION)),IntPtr.Zero),"Job drain"); }
   uint exit; GetExitCodeProcess(pi.hProcess,out exit);
   return "pid="+pi.dwProcessId+" appContainer="+isAC+" lpac="+lpac+" job="+inJob+" timedOut="+timedOut+" exit="+exit+" jobTotalProcesses="+before.TotalProcesses+" jobActiveBefore="+before.ActiveProcesses+" jobActiveAfter="+after.ActiveProcesses+" token=["+tokenSummary+"]";
  } finally {
   if(job!=IntPtr.Zero) CloseHandle(job);
   if(pi.hProcess!=IntPtr.Zero) { TerminateProcess(pi.hProcess,125); CloseHandle(pi.hProcess); }
   if(pi.hThread!=IntPtr.Zero) CloseHandle(pi.hThread);
   if(token!=IntPtr.Zero) CloseHandle(token);
   if(output!=IntPtr.Zero && output!=new IntPtr(-1)) CloseHandle(output);
   if(input!=IntPtr.Zero && input!=new IntPtr(-1)) CloseHandle(input);
   if(list!=IntPtr.Zero) { DeleteProcThreadAttributeList(list); Marshal.FreeHGlobal(list); }
   foreach(IntPtr ptr in new[]{cap,handles,opt,env,tokenData}) if(ptr!=IntPtr.Zero) Marshal.FreeHGlobal(ptr);
  }
 }
}
