$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::WriteLine('FULL_SCRIPT_START')
[Console]::WriteLine('POWERSHELL_VERSION ' + $PSVersionTable.PSVersion)
try {
  $numbers = ([IO.File]::ReadAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\workspace\input.txt')).Split(',') | ForEach-Object { [int]$_ }
  $squares = @($numbers | Where-Object { $_ -ge 4 } | ForEach-Object { $_ * $_ })
  $sum = 0; foreach ($n in $squares) { $sum += $n }
  [IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\workspace\output.txt',"sum=$sum unicode=教师中文")
  [Console]::WriteLine('WORKSPACE_RW_PASS ' + [IO.File]::ReadAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\workspace\output.txt'))
} catch { [Console]::WriteLine('WORKSPACE_RW_FAIL ' + $_.Exception.ToString()) }
try { [Console]::WriteLine('SIBLING_LEAK ' + [IO.File]::ReadAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\outside-canary.txt')) } catch { [Console]::WriteLine('SIBLING_DENIED ' + $_.Exception.ToString()) }
try { [IO.File]::WriteAllText('C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-windows-sandbox-3314308a542041038fb20355f5e385dc\outside-canary.txt','CORRUPTED'); [Console]::WriteLine('SIBLING_WRITE_LEAK') } catch { [Console]::WriteLine('SIBLING_WRITE_DENIED ' + $_.Exception.ToString()) }
try {
  $client = [Net.Sockets.TcpClient]::new()
  $task = $client.ConnectAsync('127.0.0.1',59427)
  if (!$task.Wait(1500)) { throw 'socket timeout' }
  [Console]::WriteLine('DIRECT_SOCKET_CONNECTED')
} catch { [Console]::WriteLine('DIRECT_SOCKET_DENIED ' + $_.Exception.ToString()) } finally { if ($client) { $client.Dispose() } }
[Console]::WriteLine('FULL_SCRIPT_END')
exit 37
