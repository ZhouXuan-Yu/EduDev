import 'file:///D:/WorkProject/EduProject-harness/apps/desktop/scripts/office-agent/register-source.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {pathToFileURL} from 'node:url';

const repo = 'D:/WorkProject/EduProject-harness';
const load = file => import(pathToFileURL(path.join(repo, 'apps/desktop/src/main/xiaozhi-agent', file)).href);
const {serializeStateWrites} = await load('serialized-state-sql.ts');
const {createSkillGovernanceState} = await load('skills/state.ts');
const {createSkillGovernance} = await load('skills/service.ts');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaozhi-gate4-sql-fallback-'));
const database = new DatabaseSync(path.join(root, 'authority.sqlite'));
const checks = [];
const report = {success: false, root, checks,
  boundary: 'Actual SQLite, original old-shape Sql wrapper and actual governance view. Managed package APIs are unused in these metadata-only transaction probes.'};
const deferred = () => {
  let resolve;
  const promise = new Promise(done => {resolve = done;});
  return {promise, resolve};
};
async function check(name, action) {
  try {await action(); checks.push({name, pass: true});}
  catch (error) {checks.push({name, pass: false, error: error.stack});}
}
const raw = {
  run: async (query, args = []) => database.prepare(query).run(...args),
  change: async (query, args = []) => Number(database.prepare(query).run(...args).changes),
  all: async (query, args = []) => database.prepare(query).all(...args),
};
const sql = serializeStateWrites(raw);
try {
  await sql.run('CREATE TABLE facts(id TEXT PRIMARY KEY,value TEXT)');
  await check('Old-shape transaction uses callback work for nested module operations and serializes competing writers', async () => {
    const order = [];
    async function nested(work, id) {await work.run('INSERT INTO facts VALUES(?,?)', [id, 'committed']);}
    await Promise.all(['one', 'two'].map(id => sql.transaction(async work => {
      order.push(id + ':begin'); await nested(work, id);
      await new Promise(resolve => setTimeout(resolve, 5)); order.push(id + ':end');
    })));
    assert.deepEqual(order, ['one:begin', 'one:end', 'two:begin', 'two:end']);
  });
  await check('Thrown transaction rolls back and the next queued write remains usable', async () => {
    await assert.rejects(sql.transaction(async work => {
      await work.run("UPDATE facts SET value='lost'"); throw Error('owned_rollback');
    }), /owned_rollback/);
    await sql.run('INSERT INTO facts VALUES(?,?)', ['after', 'committed']);
    assert.equal((await sql.all("SELECT * FROM facts WHERE value='committed'")).length, 3);
  });
  await check('Native transaction remains the preferred adapter', async () => {
    let delegated = 0;
    const native = serializeStateWrites({...raw, transaction: async action => {delegated++; return action(raw);}});
    await native.transaction(work => work.all('SELECT * FROM facts'));
    assert.equal(delegated, 1);
  });
  const state = createSkillGovernanceState(sql);
  await state.migrate();
  await sql.run('CREATE TABLE users(id TEXT,display_name TEXT,role TEXT,status TEXT)');
  await sql.run("INSERT INTO users VALUES('user-owned','Owned teacher','owner','active')");
  const service = createSkillGovernance({state, managed: {}, sanitize: async text => text,
    dependency: async () => true, current: async () => true});
  await check('External governance view cannot observe a half-written Skill that later rolls back', async () => {
    const entered = deferred(), release = deferred();
    const writing = state.transaction(async work => {
      await state.save('skills', {id: 'skill_owned_pending', name: 'owned-pending', legacyName: 'owned-pending',
        title: 'Owned pending', scope: 'personal', ownerId: 'user-owned', activeVersion: null, autoActivate: null,
        enabled: true, archived: false, revision: 1}, 0, work);
      entered.resolve(); await release.promise; throw Error('owned_rollback');
    });
    const finished = writing.catch(error => {assert.equal(error.message, 'owned_rollback');});
    await entered.promise;
    let settled = false, observed;
    const reading = service.view().then(view => {settled = true; observed = view;});
    await new Promise(resolve => setTimeout(resolve, 30));
    const readBeforeRelease = settled;
    release.resolve(); await finished; await reading;
    report.businessRead = {readBeforeRelease, visibleIds: observed.skills.map(skill => skill.id),
      afterRollbackIds: (await service.view()).skills.map(skill => skill.id)};
    assert(!observed.skills.some(skill => skill.id === 'skill_owned_pending'), 'governance view exposed rolled-back Skill');
  });
  report.success = checks.every(item => item.pass);
} finally {
  database.close();
  fs.writeFileSync(path.join(root, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
  if (!report.success) process.exitCode = 1;
}
