const privateReads = new Set(['office_read_text', 'office_read_document', 'office_read_attachment', 'office_read_material',
  'education_read_material_page', 'education_read_question', 'search_teacher_knowledge', 'education_search_materials']);
/** Bounded in-memory source excerpts. Raw teacher text is never persisted as Skill metadata. */
export function captureSkillPrivateContext(target: Set<string>, tool: string, result: unknown) {
  if (!privateReads.has(tool) || target.size >= 256) return;
  let remaining = 65536;
  function visit(value: unknown, depth: number) {
    if (depth > 8 || remaining <= 0 || target.size >= 256) return;
    if (typeof value === 'string') {
      remaining -= value.length;
      try { visit(JSON.parse(value), depth + 1); return; } catch { /* Plain text source. */ }
      for (const paragraph of value.split(/\r?\n/)) {
        const clean = paragraph.trim();
        if (clean.length >= 32 && target.size < 256) target.add(clean.slice(0, 4096));
      }
    } else if (Array.isArray(value)) {
      for (const item of value.slice(0, 128)) visit(item, depth + 1);
    } else if (value && typeof value === 'object') {
      for (const [key, item] of Object.entries(value).slice(0, 128)) {
        if (!/^(?:path|id|sha256|hash|version|url|sourceId|fileId)$/.test(key)) visit(item, depth + 1);
      }
    }
  }
  visit(result, 0);
}
