import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
const repo='D:/WorkProject/EduProject-harness';
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const base=JSON.parse(fs.readFileSync(path.join(repo,'docs/goal/xiaozhi-harness/evidence/phase4/final/verification-after-runtime.json')));
const stat=relative=>{if(!fs.existsSync(path.join(repo,relative)))return {path:relative,missing:true,size:null,sha256:null};const b=fs.readFileSync(path.join(repo,relative));return {path:relative,size:b.length,sha256:hash(b)};};
function tree(relative){return fs.readdirSync(path.join(repo,relative),{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en')).flatMap(e=>e.isDirectory()?tree(relative+'/'+e.name):[stat(relative+'/'+e.name)]);}
const runRoot=process.argv[2]||fs.mkdtempSync(path.join(os.tmpdir(),'xiaozhi-phase4-integration-20261117-'));
const stage=process.argv[3]||'before-build';
const governed=base.checks.map(e=>stat(e.path));
const sourceTree=tree('apps/desktop/src');
const outputs=tree('apps/desktop/out');
const helper='apps/desktop/src/main/xiaozhi-agent/permissions/windows/generated/xiaozhi-sandbox.exe';
const sandboxManifest='apps/desktop/src/main/xiaozhi-agent/permissions/windows/generated/sandbox-manifest.json';
const nativeManifest='apps/desktop/src/main/xiaozhi-agent/capabilities/generated/native-stat-manifest.json';
const native=JSON.parse(fs.readFileSync(path.join(repo,nativeManifest)));
const artifacts=[helper,sandboxManifest,nativeManifest,'apps/desktop/src/main/xiaozhi-agent/capabilities/generated/'+native.file,'apps/desktop/src/main/xiaozhi-agent/permissions/windows/NativeSandbox.cs','apps/desktop/src/main/xiaozhi-agent/permissions/windows/PlatformInfo.cs','apps/desktop/src/main/xiaozhi-agent/permissions/windows/TrustedRuntimes.cs'].map(stat);
const acceptedDelta=governed.flatMap((entry,i)=>entry.sha256===base.checks[i].expected&&entry.size===base.checks[i].expectedSize?[]:[{...entry,acceptedSha256:base.checks[i].expected,acceptedSize:base.checks[i].expectedSize}]);
const snapshot={createdAt:new Date().toISOString(),stage,governed,governedListHash:hash(JSON.stringify(governed)),sourceTree,sourceTreeListHash:hash(JSON.stringify(sourceTree)),outputs,outListHash:hash(JSON.stringify(outputs)),artifacts,acceptedDelta};
fs.writeFileSync(path.join(runRoot,stage+'.json'),JSON.stringify(snapshot,null,2)+'\n');
console.log(JSON.stringify({runRoot,stage,governed:governed.length,sourceTree:sourceTree.length,outputs:outputs.length,acceptedDelta,artifacts}));

