import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
const output = path.dirname(new URL(import.meta.url).pathname.slice(1));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const roots = {
  production: 'C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase4-production-6elOkc',
  ui: 'C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase4-ui-HSMUnQ',
};
const results = {};
for (const [name, root] of Object.entries(roots)) {
  const data = path.join(root, 'data');
  const db = new DatabaseSync(path.join(data, 'app.db'), {readOnly:true});
  try {
    const list = table => db.prepare(`SELECT * FROM ${table}`).all().map(row => {
      assert.equal(hash(row.payload_json), row.payload_hash);
      return JSON.parse(row.payload_json);
    });
    const skills = list('xiaozhi_skill_governance_v1');
    const versions = list('xiaozhi_skill_versions_v1');
    const reviews = list('xiaozhi_skill_reviews_v1');
    const snapshots = list('xiaozhi_skill_run_snapshots_v1');
    let files = 0;
    for (const version of versions) {
      assert.equal(hash(JSON.stringify(version.package.files)), version.sha256);
      for (const file of version.package.files) {
        const bytes = fs.readFileSync(path.join(data, 'xiaozhi-pi', 'skills', version.package.directory, file.relativePath));
        assert.equal(hash(bytes), file.sha256);
        files++;
      }
    }
    if (name === 'production') {
      const privateExcerpt = fs.readFileSync(path.join(root, 'workspace/private.txt'), 'utf8').slice(9300, 9364);
      const blocked = skills.filter(skill => /^private-(?:copy|history-next|history-cold)$/.test(skill.name));
      assert.equal(blocked.length, 3);
      for (const skill of blocked) {
        const version = versions.find(item => item.skillId === skill.id);
        assert.equal(version.state, 'draft');
        assert(version.validation.checks.some(check => check.reasons.includes('private_source_excerpt')));
        assert(!JSON.stringify(version).includes(privateExcerpt));
      }
      for (const version of versions) {
        for (const file of version.package.files) {
          assert(!fs.readFileSync(path.join(data, 'xiaozhi-pi', 'skills', version.package.directory, file.relativePath), 'utf8').includes(privateExcerpt));
        }
      }
      const workflow = skills.find(skill => skill.name === 'phase4-workflow' && skill.scope === 'personal');
      assert.equal(workflow.activeVersion, '1.0.0');
      assert.deepEqual(versions.filter(version => version.skillId === workflow.id).map(item => item.version).sort(), ['1.0.0', '2.0.0']);
      const team = skills.find(skill => skill.scope === 'team');
      assert(team && reviews.some(review => review.skillId === team.id && review.status === 'approved'));
      const ownDirs = versions.filter(version => version.skillId === workflow.id).map(item => item.package.directory);
      assert(versions.filter(version => version.skillId === team.id).every(item => !ownDirs.includes(item.package.directory)));
      const generations = snapshots.filter(snapshot => snapshot.selected.some(item => item.skillId === workflow.id)).map(snapshot => ({taskId:snapshot.owner.taskId, generation:snapshot.owner.generation, version:snapshot.selected.find(item => item.skillId === workflow.id).version}));
      assert(generations.some(item => item.generation === 2 && item.version === '1.0.0'));
      assert(generations.some(item => item.generation === 3 && item.version === '2.0.0'));
      assert.equal(db.prepare("SELECT count(*) AS n FROM xiaozhi_permission_audit_v1 WHERE kind='sandbox_execution_prepared'").get().n, 0);
      assert(!fs.existsSync(path.join(root, 'workspace/must-not-write.txt')));
      results[name] = {skillCount:skills.length, versionCount:versions.length, verifiedFiles:files, blockedHistoryDrafts:blocked.map(item => item.name), runSnapshotCount:snapshots.length, workflowGenerations:generations, approvedIndependentTeamCopy:true, sandboxExecutionPrepared:0, unexpectedFile:false};
    } else {
      const workflow = skills.find(skill => skill.name === 'ui-workflow');
      assert.equal(workflow.activeVersion, '1.0.0');
      assert.equal(versions.find(item => item.skillId === workflow.id && item.version === '2.0.0').state, 'withdrawn');
      const team = skills.find(skill => skill.scope === 'team');
      assert.equal(team.activeVersion, '2.0.0');
      assert(reviews.filter(review => review.skillId === team.id).every(review => review.status === 'approved'));
      const blocked = skills.find(skill => skill.name === 'ui-private-blocked');
      assert.equal(versions.find(item => item.skillId === blocked.id).state, 'draft');
      assert(!JSON.stringify(versions).includes('13800138000'));
      assert.equal(db.prepare('SELECT count(*) AS n FROM ai_agent_runs').get().n, 0);
      results[name] = {skillCount:skills.length, versionCount:versions.length, verifiedFiles:files, personalActive:workflow.activeVersion, secondPersonalState:'withdrawn', teamActive:team.activeVersion, approvedReviewCount:reviews.length, sensitiveMetadataPresent:false, coldRunCount:0};
    }
  } finally {db.close();}
}
fs.writeFileSync(path.join(output,'post-runtime-readback.json'), JSON.stringify({success:true, readOnly:true, results},null,2));
console.log(JSON.stringify({success:true,readOnly:true,results}));
