# P5-10 parent-kill package recovery leaf

The fixed two crash groups passed2/2 in the first concentrated run. Only phase5-extension-recovery-parent.mjs and phase5-extension-recovery-worker.mjs were added, plus owned TEMP evidence. Existing package manager/extension/resource/lifecycle/production sources were not modified. No core repair was needed for these two recovery outcomes.

## Command and identity

From D:/WorkProject/EduProject-harness/apps/desktop run node scripts/xiaozhi-agent/phase5-extension-recovery-parent.mjs.

The command exited0 with2PASS,0FAIL,0skipped. Final report is C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-extension-recovery-U9ncxY/report.json. SOURCE_MANIFEST.json and report.sources record both scripts and the exact package/state/Permission source hashes. Both scripts passed node --check. There were no earlier failed runs for this leaf. Baseline HEAD is7a93b4baa38f15566c442c69c2d495113757a13b plus concurrent owner WIP.

## Actual setup and boundaries

Each case runs in a separate owned root. The old selected1.0.0 package is copied from the prior actual native18 fixture's owned.format.esm-mjs record. Its exact binding files are verified after copying, and the original actual health/selection facts are transferred into original Extension state. Fresh original scoped grants cover the new owned paths. A new local2.0.0 directory is imported through the actual package manager, and its precise original preparation request receives explicit task-scoped approval.

The worker calls the real package manager and original Permission/Sql services. The only boundary instrumentation is its public Sql.transaction dependency. It never changes production logic, imports an external entry, or substitutes an exception for process termination. Parent uses fork's exact child object and child.kill('SIGKILL'), then awaits the actual close event. Worker environments contain only required Windows/TEMP variables. Node and the fixed official LICENSE are reused from verified local caches. PublicFetch is a local verified-license reader and cannot fetch other URLs.

## Cut1

The transaction seam awaited the original SQLite binding-intent COMMIT before suspending the worker, while package-manager was still awaiting save and had not called stage-to-final rename. Parent's separate read-only connection observed phase preparing at revision4 with the exact binding. The final directory was absent, and one real stage's complete file hashes matched the committed binding.

Parent accepted the kill and observed exit code null/signal SIGKILL. Reopened services performed only list/state/grant/file reads, with phase preparing revision4, final absent and the same stage/file identities. No fetch or preparation occurred automatically. Old selected version1.0.0 and all11 Grant records matched their setup checksums.

A fresh Run/generation explicitly retried through the original scopes/CAS. The manager safely rebuilt from the immutable quarantine and reached prepared. Its only fetcher call read the exact fixed official license from local verified cache. No unknown entry or external effect was executed. The old selected state and11 grants remained byte-identical. The final file manifest matched the resulting binding.

The original orphan stage remained after retry, with the same name and exact hashes. The test records this residual and does not claim automatic orphan cleanup. The source package manager does not remove that orphan in this path. This residual is available for core's cleanup/accounting decision and remains inside the owned test root.

## Cut2

The original package-manager stage-to-final rename completed before the prepared-state transaction was held. The held transaction had written prepared inside its own connection but had not committed. Complete actual final-file hashes matched binding intent and no stage remained. Parent's independent connection still read committed preparing revision4 and observed the actual rollback-journal file.

Parent accepted the kill and observed exit code null/signal SIGKILL. SQLite/service reconstruction retained committed preparing revision4, the complete final directory, old selected1.0.0 and identical11 Grant records. Recovery first performed read-only package/state/grant inspection, with no automatic execution or fetch. SQLite's ordinary rollback-journal recovery is part of reopening the real database, rather than an application-level preparation replay.

After that inspection, the parent deliberately changed an owned final payload. A new Run's explicit retry returned source_changed, performed zero fetches, preserved old selection/grants and recorded failed package state. Parent restored the exact original payload bytes and checked their hash. A subsequent explicit Run verified the actual final file manifest and reconciled to prepared with zero fetcher calls and no orphan stages. Old selection/grants again matched the baseline.

## Recorded invariants

Both cases preserved the old selection hash d69beb055c4d6c7a6f383c8cb9da439d0cf63db05ad252035e2ff82659044170. Grant hashes are case-specific and fully recorded in setup/checkpoint/reopen/retry. Their exact values remain stable within each case. Both reopened the original database at revision4 preparing. Both ended prepared after explicit retry and original PermissionEngine active0. Every mode reports native terminal count0 and no external-entry execution marker.

The report includes original committed records, the worker checkpoint, independent committed-state read before kill, actual worker exit status, read-only reconstructed facts, drift-failure details and final retry facts. Physical filesystem presence and content hashes accompany each state.

## Exact limitations and rollback

This verifies two real package-manager worker kills and SQLite/filesystem recovery on this Windows machine. It does not exercise power loss, storage-device failure, Electron app restart, runtime/helper parent death, active guest/native revocation, real provider functionality, Pi/Task Journal effect integration or teacher UI. Source external packages were never loaded in main or a guest during this leaf. There was no helper, real external network, model or key operation, and paid calls remain0. No native window was requested or occupied.

The first case retains one90MB-class owned stage after successful retry. Cleanup of that residual was not implemented or asserted by this test. Existing historical evidence is retained. Root/core retain whole P5-10/Gate5 acceptance authority.

Removing these two additive test entrypoints from a runner rolls back this leaf. Owned report/stages/final packages are available for readback. Existing teacher data, production sources and previously frozen artifacts remain untouched. No commit/push or main out build was performed.
