const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const output=__dirname,env={...process.env};delete env.NODE_OPTIONS;delete env.ELECTRON_RUN_AS_NODE;
const log=fs.createWriteStream(path.join(output,'worker.log'));
const child=spawn(require('electron'),[path.join(output,'bootstrap.cjs'),output],{cwd:'D:/WorkProject/EduProject-harness/apps/desktop',env,windowsHide:true,stdio:['ignore','pipe','pipe']});
child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});const timer=setTimeout(()=>child.kill(),240000);
child.on('error',e=>{console.error(e);process.exitCode=1;});child.on('exit',(code,signal)=>{clearTimeout(timer);log.end(()=>{fs.writeFileSync(path.join(output,'process-result.json'),JSON.stringify({code,signal}));console.log(JSON.stringify({code,signal,output}));});});
