import {useEffect, useRef, useState} from 'react';
import {Button, Input, Label, TextField} from '@heroui/react';
import {ACQUISITION_ERRORS, type AcquisitionApiResult, type AcquisitionMutation,
  type AcquisitionPhase, type AcquisitionView, type DiscoverySource} from '../../../shared/xiaozhi-acquisition';
import {DisclosureCard} from '../ui/DisclosureCard';
import {SettingsSection} from './hana-settings/SettingsSection';
import {SettingsRow} from './hana-settings/SettingsRow';
import {SettingsStack} from './hana-settings/SettingsPrimitives';

type Mode = 'discovery' | 'installed' | 'environment';
type Lifecycle = {sessionId: string; active: boolean; request: number};
const sources: Record<DiscoverySource, string> = {
  official_mcp: '官方 MCP 目录', github: 'GitHub', community: '社区目录', reviewed: '已审核目录',
};
const phases: Record<AcquisitionPhase, string> = {
  discovered: '已发现候选', quarantined: '隔离待审查', resolving: '正在核对来源与依赖',
  needs_approval: '等待授权', downloading: '正在下载', verifying: '正在验证', registering: '正在登记能力',
  ready: '已就绪', failed: '准备失败', cancelled: '已取消', interrupted: '准备已中断', revoked: '已撤销',
};
const artifactStates = {verifying: '验证中', ready: '已就绪', revoked: '已撤销', failed: '验证失败'};
const sourceStates = {online: '在线', cached: '离线缓存', unavailable: '来源不可用'};
const cancellable = new Set<AcquisitionPhase>(['resolving', 'needs_approval', 'downloading', 'verifying', 'registering']);
const retryable = new Set<AcquisitionPhase>(['failed', 'cancelled', 'interrupted']);
const message = (code: string) => ACQUISITION_ERRORS[code] || ACQUISITION_ERRORS.acquisition_failed;

async function bounded<T>(work: Promise<T> | undefined): Promise<T | undefined> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([Promise.resolve(work), new Promise<never>((_resolve, reject) => {
      timer = setTimeout(() => reject(Error('unavailable')), 10000);
    })]);
  } finally {clearTimeout(timer);}
}

/** Main projections remain authoritative; the renderer retains only the currently selected session view. */
export function PiAcquisitionSettings({sessionId = '', mode = 'discovery'}: {sessionId?: string; mode?: Mode}) {
  const [received, setReceived] = useState<{sessionId: string; value: AcquisitionView}>();
  const view = received?.sessionId === sessionId ? received.value : undefined;
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [readNotice, setReadNotice] = useState('');
  const [loading, setLoading] = useState(Boolean(sessionId));
  const [pending, setPending] = useState<'search' | 'mutation' | null>(null);
  const [preparingId, setPreparingId] = useState<string>();
  const section = useRef<HTMLDivElement>(null);
  const selectedSession = useRef(sessionId);
  selectedSession.current = sessionId;
  const lifecycle = useRef<Lifecycle>({sessionId, active: false, request: 0});
  const reading = useRef<symbol | undefined>(undefined);
  const acting = useRef<symbol | undefined>(undefined);
  const preparing = useRef<symbol | undefined>(undefined);

  function current(owner: Lifecycle, revision?: number) {
    return owner.active && lifecycle.current === owner && selectedSession.current === owner.sessionId
      && (revision === undefined || owner.request === revision);
  }
  async function accept(work: () => Promise<AcquisitionApiResult<AcquisitionView> | undefined> | undefined, owner: Lifecycle, kind: 'read' | 'action' = 'read') {
    const revision = ++owner.request;
    const reportError = kind === 'read' ? setReadNotice : setNotice;
    try {
      const result = await bounded(work());
      if (!current(owner, revision)) return;
      if (!result?.ok) {reportError(message(result?.error || 'unavailable')); return;}
      if (result.value.context && result.value.context.sessionId !== owner.sessionId) {
        reportError(message('permission_denied')); return;
      }
      setReceived({sessionId: owner.sessionId, value: result.value}); setReadNotice('');
      if (kind === 'action') setNotice('');
    } catch {
      if (current(owner, revision)) reportError(message('unavailable'));
    } finally {if (current(owner, revision)) setLoading(false);}
  }
  async function refresh() {
    const owner = lifecycle.current;
    if (!owner.sessionId || !current(owner) || reading.current || acting.current) return;
    const token = Symbol('acquisition-read'); reading.current = token;
    let dispatched = false;
    try {
      await accept(() => {
        const work = window.omniEdu?.getXiaozhiAcquisition(owner.sessionId);
        dispatched = true;
        // A renderer deadline cannot cancel IPC. Keep its single-flight lease until it really settles.
        return Promise.resolve(work).finally(() => {if (reading.current === token) reading.current = undefined;});
      }, owner);
    } finally {if (!dispatched && reading.current === token) reading.current = undefined;}
  }
  useEffect(() => {
    const owner: Lifecycle = {sessionId, active: true, request: 0};
    lifecycle.current = owner; reading.current = undefined; acting.current = undefined; preparing.current = undefined;
    setReceived(undefined); setQuery(''); setNotice(''); setReadNotice(''); setPending(null); setPreparingId(undefined); setLoading(Boolean(sessionId));
    let timer: ReturnType<typeof setTimeout> | undefined;
    let inView = typeof IntersectionObserver === 'undefined';
    let polling = false;
    const visible = () => inView && document.visibilityState === 'visible';
    async function poll() {
      if (!current(owner) || !visible() || polling || !sessionId) return;
      polling = true;
      try {await refresh();}
      finally {
        polling = false;
        if (current(owner) && visible()) timer = setTimeout(() => void poll(), 1200);
      }
    }
    function visibilityChanged() {
      clearTimeout(timer);
      if (visible()) void poll();
    }
    const observer = typeof IntersectionObserver === 'undefined' ? undefined : new IntersectionObserver(entries => {
      inView = entries.some(entry => entry.isIntersecting && entry.intersectionRatio > 0); visibilityChanged();
    });
    if (section.current) observer?.observe(section.current);
    document.addEventListener('visibilitychange', visibilityChanged);
    if (inView) void poll();
    return () => {
      owner.active = false; owner.request++; clearTimeout(timer); observer?.disconnect();
      document.removeEventListener('visibilitychange', visibilityChanged);
    };
  }, [sessionId]);

  async function search() {
    const owner = lifecycle.current;
    if (!owner.sessionId || !query.trim() || acting.current || !current(owner)) return;
    const token = Symbol('acquisition-search'); acting.current = token; setPending('search'); setNotice('');
    try {await accept(() => window.omniEdu?.searchXiaozhiAcquisition({sessionId: owner.sessionId, query: query.trim()}), owner, 'action');}
    finally {if (acting.current === token) {acting.current = undefined; if (current(owner)) setPending(null);}}
  }
  async function mutate(input: AcquisitionMutation) {
    const owner = lifecycle.current;
    if (acting.current || !current(owner) || input.sessionId !== owner.sessionId) return;
    if (input.action === 'prepare') {
      if (!view?.context) {setNotice(message('task_required')); return;}
      if (preparing.current) return;
      const token = Symbol('acquisition-prepare'); preparing.current = token;
      owner.request++; setPreparingId(input.candidateId); setNotice('');
      try {
        // The main API waits for the pipeline. Read polling and safe controls stay available.
        const result = await window.omniEdu?.mutateXiaozhiAcquisition(input);
        if (!current(owner)) return;
        if (!result?.ok) {setNotice(message(result?.error || 'unavailable')); return;}
        if (result.value.context && result.value.context.sessionId !== owner.sessionId) {
          setNotice(message('permission_denied')); return;
        }
        owner.request++; setReceived({sessionId: owner.sessionId, value: result.value}); setReadNotice(''); setLoading(false);
      } catch {if (current(owner)) setNotice(message('unavailable'));}
      finally {
        if (preparing.current === token) {preparing.current = undefined; if (current(owner)) setPreparingId(undefined);}
      }
      return;
    }
    const token = Symbol('acquisition-mutation'); acting.current = token; setPending('mutation'); setNotice('');
    try {await accept(() => window.omniEdu?.mutateXiaozhiAcquisition(input), owner, 'action');}
    finally {if (acting.current === token) {acting.current = undefined; if (current(owner)) setPending(null);}}
  }

  const title = mode === 'discovery' ? '发现与准备外部能力' : mode === 'installed' ? '受管外部能力' : '外部能力诊断';
  const operations = view?.operations || [];
  return <div ref={section} data-testid={`pi-acquisition-${mode}`} data-session-id={sessionId}>
    <SettingsSection title={title} surface="plain"><SettingsStack gap="sm">
      {!sessionId ? <p role="status" data-testid="pi-acquisition-task-required">{message('task_required')}</p> : <>
        {mode === 'discovery' && <>
          <form data-testid="pi-acquisition-search-form" onSubmit={event => {event.preventDefault(); void search();}}>
            <TextField value={query} onChange={setQuery} isDisabled={pending !== null}>
              <Label>搜索公开能力目录</Label><Input data-testid="pi-acquisition-query" maxLength={200}/>
            </TextField>
            <Button size="sm" type="submit" data-testid="pi-acquisition-search" isDisabled={pending !== null || !query.trim()}>搜索</Button>
          </form>
          {!view?.context && !loading && <p role="status" data-testid="pi-acquisition-task-required">{message('task_required')} 返回当前小智对话，启动需要该能力的任务后再准备。</p>}
          {view?.sourceStatus?.map(source => <p key={source.source} data-testid={`pi-acquisition-source-${source.source}`}>
            {sources[source.source]} · {sourceStates[source.status]}{source.error ? ` · ${message(source.error)}` : ''}
          </p>)}
        </>}
        {loading && <p role="status">正在读取能力状态…</p>}
        {mode === 'discovery' && view && !view.candidates.length && <p data-testid="pi-acquisition-empty">没有可展示的候选，可搜索其他关键词。</p>}
        {mode === 'discovery' && view?.candidates.map(candidate => {
          const latest = operations.filter(operation => operation.candidateId === candidate.id)
            .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))[0];
          const installed = view.artifacts.find(artifact => artifact.id === latest?.artifactId);
          return <div key={candidate.id} data-testid={`pi-acquisition-candidate-${candidate.id}`}>
            <SettingsRow label={candidate.name} hint={candidate.description} control={<Button size="sm"
              data-testid={`pi-acquisition-prepare-${candidate.id}`}
              isDisabled={pending !== null || Boolean(preparingId) || !view.context || Boolean(latest && cancellable.has(latest.phase)) || installed?.status === 'ready'}
              onPress={() => void mutate({action: 'prepare', sessionId, candidateId: candidate.id})}>
              {latest && retryable.has(latest.phase) ? '重试准备' : latest?.phase === 'quarantined' ? '重新核查' : '准备能力'}
            </Button>}/>
            <p>版本 {candidate.version || '待核查'} · {sources[candidate.source]} · 许可证 {installed?.license || '待核查'}</p>
            <DisclosureCard title={<>来源与连接详情</>}>
              <p>{candidate.repository || candidate.packageName || candidate.externalId}</p>
              <p>{candidate.transport === 'stdio' ? '本地 stdio' : candidate.transport === 'http' ? '远程 HTTP' : '连接方式待核查'}</p>
              <p>来源标识 {candidate.sourceHash}</p>
            </DisclosureCard>
          </div>;
        })}
        {operations.map(operation => <div key={operation.id} data-testid={`pi-acquisition-operation-${operation.id}`} data-phase={operation.phase}>
          <p role="status">{view?.candidates.find(candidate => candidate.id === operation.candidateId)?.name || '能力准备'} · {phases[operation.phase]}</p>
          {operation.error && <p role="status">{message(operation.error)}</p>}
          {cancellable.has(operation.phase) && <Button size="sm" variant="ghost" data-testid={`pi-acquisition-cancel-${operation.id}`}
            isDisabled={pending !== null} onPress={() => void mutate({action: 'cancel', sessionId, operationId: operation.id, revision: operation.revision})}>取消准备</Button>}
        </div>)}
        {mode !== 'discovery' && view && !view.artifacts.length && <p data-testid="pi-acquisition-installed-empty">尚无受管外部能力安装记录。</p>}
        {mode !== 'discovery' && view?.artifacts.map(artifact => <div key={artifact.id} data-testid={`pi-acquisition-artifact-${artifact.id}`} data-status={artifact.status}>
          <SettingsRow label={`${artifact.name} · ${artifact.version}`} hint={`运行状态 · ${artifactStates[artifact.status]}`} control={
            <Button size="sm" variant="ghost" data-testid={`pi-acquisition-revoke-${artifact.id}`} isDisabled={pending !== null || artifact.status === 'revoked'}
              onPress={() => void mutate({action: 'revoke', sessionId, artifactId: artifact.id, revision: artifact.revision})}>撤销能力</Button>}/>
          <p>{sources[artifact.source as DiscoverySource] || artifact.source} · 许可证 {artifact.license} · 已保存 {artifact.installedBytes.toLocaleString()} 字节</p>
          <DisclosureCard title={<>安装记录详情</>}>
            <p>有效期 {new Date(artifact.expiresAt).toLocaleString()}</p>
            {artifact.schemaHash && <p>工具目录标识 {artifact.schemaHash}</p>}
          </DisclosureCard>
        </div>)}
        {pending && <p role="status">{pending === 'search' ? '正在检索来源…' : '正在更新能力状态…'}</p>}
        {preparingId && <p role="status">正在准备能力，进度以当前操作记录为准。</p>}
        {(notice || readNotice) && <p role="alert" data-testid={`pi-acquisition-notice-${mode}`}>{notice || readNotice}</p>}
        <Button size="sm" variant="ghost" data-testid={`pi-acquisition-refresh-${mode}`} isDisabled={pending !== null} onPress={() => void refresh()}>刷新能力状态</Button>
      </>}
    </SettingsStack></SettingsSection>
  </div>;
}
