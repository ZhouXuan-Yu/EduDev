# Phase5 Acquisition UI窄交付合同

2026-11-17，实施前冻结。主源码只写PiMcpSettings/PiManagedTools/PiEnvironmentSettings、邻接专属PiAcquisitionSettings组件及PiSettingsWorkspace两处sessionId传参。测试仅新增phase5-acquisition-renderer-smoke.mjs。shared/preload/main/中央runner/Goal/out保持由原owner维护。

教师结果为现有高级工具页搜索候选、核对来源/版本/许可证，当前活动Task可prepare，idle可search/view，已有操作可cancel、已保存artifact可revoke。安装记录按实际status区分验证中、ready、failed/revoked。失败/取消/中断提供重试，quarantined/source_requires_review如实显示。

复用SettingsSection/Row/Stack、DisclosureCard及现有HeroUI控件，保持Composer与原MCP running/busy门禁。MCP区域提供发现候选与操作，Managed区域展示受管安装记录，Environment渐进披露外部能力状态。

所有新数据仅来自get/search/mutate三Acquisition typed preload API。显式sessionId绑定当前UI消费者，context由main返回。null显示ACQUISITION_ERRORS.task_required并引导返回当前小智任务。取消/撤销独立于原MCP配置锁。

可见/前台期间最多一个有界read请求，完成后1200ms再轮询，隐藏/卸载停止新轮询。session epoch+请求版本阻断旧响应，mutation/search使旧read失效。网络异常使用ACQUISITION_ERRORS并提供刷新，保留已读事实。

专属Node组件测试覆盖实际React/HeroUI、桥接三API的合成返回、搜索/prepare/取消/重试/撤销、null context、状态与来源/许可、session切换/卸载、可见轮询、原MCP busy控件。组件测试不替代Electron或真实provider。

本轮不build、不启Electron、不读取真实key、不调用模型。交付组件测试与无输出typecheck证据、源码SHA/testId、边界及本轮可回滚文件清单，实际双尺寸UI由root集成门禁验证。
