import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {JSDOM} from 'jsdom';

const output = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaozhi-phase5-acquisition-renderer-'));
const desktop = path.resolve(import.meta.dirname, '../..');
const report = {success: false, output, checks: [], boundary: 'Actual React/HeroUI settings mounted in JSDOM with synthetic typed bridge responses. No Electron, build output, provider or real data.'};
let root, dom;
const channels = new Set();
const NativeMessageChannel = globalThis.MessageChannel;
const delay = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
const deferred = () => {let resolve; const promise = new Promise(done => {resolve = done;}); return {promise, resolve};};
const actor = sessionId => ({sessionId, taskId: 'xitask_fixture', runId: 'run_fixture', generation: 1});
const candidate = {id: 'candidate_fixture', source: 'github', externalId: 'fixture/repository', name: '合成候选',
  description: '合成组件测试', version: '1.2.3', repository: 'https://example.test/fixture', packageName: 'fixture-package',
  transport: 'stdio', sourceHash: 'a'.repeat(64), fetchedAt: '2026-11-17T00:00:00Z', expiresAt: '2026-12-17T00:00:00Z'};
const artifact = {id: 'artifact_fixture', name: '合成安装记录', version: '1.2.3', source: 'reviewed', license: 'MIT', revision: 4,
  status: 'verifying', schemaHash: null, installedBytes: 12345, expiresAt: '2026-12-17T00:00:00Z'};
const operation = {id: 'operation_fixture', candidateId: candidate.id, revision: 3, phase: 'downloading', error: null,
  artifactId: artifact.id, updatedAt: '2026-11-17T00:00:00Z'};
const view = (sessionId = 'session_A', patch = {}) => ({schemaVersion: 'xiaozhi.acquisition.v1', context: actor(sessionId),
  candidates: [candidate], operations: [], artifacts: [], sourceStatus: [{source: 'github', status: 'cached'}], ...patch});
const ok = value => ({ok: true, value});
let React, act, createRoot, PiAcquisitionSettings, PiMcpSettings, PiEnvironmentSettings;
let visible = true;
const intersections = new Set();

async function settle(action = async () => {}) {await act(async () => {await action(); await delay(5);});}
async function mount(component, props) {
  await settle(async () => {root?.unmount(); document.body.innerHTML = '<div id="root"></div>'; root = createRoot(document.getElementById('root')); root.render(React.createElement(component, props));});
}
function element(id) {return document.querySelector(`[data-testid="${id}"]`);}
async function click(id) {const target = element(id); assert(target, 'missing control ' + id); await settle(async () => {target.click();});}
async function text(id, value) {
  await settle(async () => {
    const target = element(id);
    Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(target, value);
    target.dispatchEvent(new window.Event('input', {bubbles: true}));
  });
}
async function check(name, action) {
  try {await action(); report.checks.push({name, pass: true});}
  catch (error) {report.checks.push({name, pass: false, error: error.stack});}
  console.log(JSON.stringify(report.checks.at(-1)));
}

try {
  const entry = path.join(output, 'entry.tsx');
  fs.writeFileSync(entry, `export {default as React,act} from 'react';export {createRoot} from 'react-dom/client';
export {PiAcquisitionSettings} from ${JSON.stringify(path.join(desktop, 'src/renderer/components/office/PiAcquisitionSettings.tsx'))};
export {PiMcpSettings} from ${JSON.stringify(path.join(desktop, 'src/renderer/components/office/PiMcpSettings.tsx'))};
export {PiEnvironmentSettings} from ${JSON.stringify(path.join(desktop, 'src/renderer/components/office/PiEnvironmentSettings.tsx'))};`);
  const bundle = path.join(output, 'components.cjs');
  await build({entryPoints: [entry], outfile: bundle, bundle: true, platform: 'node', format: 'cjs', target: 'node24',
    nodePaths: [path.join(desktop, 'node_modules')], loader: {'.css': 'empty'}, jsx: 'automatic', logLevel: 'silent'});
  dom = new JSDOM('<html><body></body></html>', {url: 'http://localhost/', pretendToBeVisual: true});
  for (const name of ['window', 'document', 'Element', 'Node', 'Document', 'DocumentFragment', 'ShadowRoot',
    'NodeFilter', 'MutationObserver', 'Event', 'MouseEvent', 'KeyboardEvent', 'CustomEvent', 'PointerEvent',
    ...Object.getOwnPropertyNames(dom.window).filter(name => /^(HTML|SVG).*Element$/.test(name))]) {
    if (dom.window[name]) globalThis[name] = dom.window[name];
  }
  if (NativeMessageChannel) globalThis.MessageChannel = class extends NativeMessageChannel {
    constructor() {super(); channels.add(this);}
  };
  Object.defineProperty(globalThis, 'navigator', {configurable: true, value: dom.window.navigator});
  globalThis.IS_REACT_ACT_ENVIRONMENT = true;
  globalThis.requestAnimationFrame = callback => setTimeout(() => callback(performance.now()), 16);
  globalThis.cancelAnimationFrame = clearTimeout;
  globalThis.CSS = dom.window.CSS || {escape: value => String(value).replace(/[^A-Za-z0-9_-]/g, '\\$&')};
  window.HTMLElement.prototype.scrollIntoView = function() {};
  window.matchMedia = () => ({matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}});
  globalThis.ResizeObserver = class {observe() {} unobserve() {} disconnect() {}};
  globalThis.IntersectionObserver = class {
    constructor(callback) {this.callback = callback; intersections.add(this);}
    observe(target) {this.target = target; this.callback([{target, isIntersecting: visible, intersectionRatio: visible ? 1 : 0}]);}
    disconnect() {intersections.delete(this);}
  };
  Object.defineProperty(document, 'visibilityState', {configurable: true, get: () => visible ? 'visible' : 'hidden'});
  ({React, act, createRoot, PiAcquisitionSettings, PiMcpSettings, PiEnvironmentSettings} = createRequire(import.meta.url)(bundle));

  await check('Missing session has task guidance and performs no inferred-owner query', async () => {
    let reads = 0; window.omniEdu = {getXiaozhiAcquisition: async () => {reads++; return ok(view());}};
    await mount(PiAcquisitionSettings, {mode: 'discovery'});
    assert.equal(reads, 0); assert(document.body.textContent.includes('请在小智当前任务中准备所需能力'));
  });
  await check('Idle discovery remains searchable while null context disables preparation and exposes source state', async () => {
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view('session_A', {context: null}))};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    assert(element('pi-acquisition-prepare-candidate_fixture').disabled);
    assert(!element('pi-acquisition-query').disabled);
    assert(document.body.textContent.includes('GitHub')); assert(document.body.textContent.includes('离线缓存'));
    assert(document.body.textContent.includes('1.2.3')); assert(document.body.textContent.includes('许可证'));
  });
  await check('Real search form calls only typed search with its current session and query', async () => {
    let query;
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view()), searchXiaozhiAcquisition: async input => {
      query = input; return ok(view('session_A', {candidates: [{...candidate, name: '检索返回候选'}]}));}};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await text('pi-acquisition-query', 'local fixture');
    await settle(async () => element('pi-acquisition-search-form').dispatchEvent(new window.Event('submit', {bubbles: true, cancelable: true})));
    assert.deepEqual(query, {sessionId: 'session_A', query: 'local fixture'});
    assert(document.body.textContent.includes('检索返回候选'));
  });
  await check('Prepare uses main context and quarantine/source_requires_review stays distinct from readiness', async () => {
    const calls = [];
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view()), mutateXiaozhiAcquisition: async input => {
      calls.push(input); return ok(view('session_A', {operations: [{...operation, phase: 'quarantined', error: 'source_requires_review', artifactId: null}]}));}};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await click('pi-acquisition-prepare-candidate_fixture');
    assert.deepEqual(calls, [{action: 'prepare', sessionId: 'session_A', candidateId: candidate.id}]);
    assert(document.body.textContent.includes('隔离待审查')); assert(document.body.textContent.includes('此候选需要来源与权限审查'));
    assert(!document.body.textContent.includes('已就绪'));
  });
  await check('Active cancellation sends the precise operation revision and a cancelled candidate can retry', async () => {
    const calls = [];
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view('session_A', {operations: [operation]})), mutateXiaozhiAcquisition: async input => {
      calls.push(input); return ok(view('session_A', {operations: [{...operation, phase: 'cancelled'}]}));}};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await click('pi-acquisition-cancel-operation_fixture');
    assert.deepEqual(calls[0], {action: 'cancel', sessionId: 'session_A', operationId: operation.id, revision: 3});
    assert(document.body.textContent.includes('已取消')); assert(!element('pi-acquisition-prepare-candidate_fixture').disabled);
  });
  await check('An awaited prepare pipeline continues polling real progress and allows cancellation before its API resolves', async () => {
    const preparing = deferred(); let started = false; let cancelled = false;
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view('session_A', {operations: started ? [{...operation, phase: cancelled ? 'cancelled' : 'downloading'}] : []})),
      mutateXiaozhiAcquisition: input => {
        if (input.action === 'prepare') {started = true; return preparing.promise;}
        cancelled = true;
        const result = ok(view('session_A', {operations: [{...operation, phase: 'cancelled'}]}));
        preparing.resolve(result); return Promise.resolve(result);
      }};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await click('pi-acquisition-prepare-candidate_fixture');
    await settle(async () => delay(1300));
    assert(document.body.textContent.includes('正在下载')); assert(!element('pi-acquisition-cancel-operation_fixture').disabled);
    await click('pi-acquisition-cancel-operation_fixture'); assert(cancelled); assert(document.body.textContent.includes('已取消'));
  });
  await check('Installed records show license/version and verifying is distinct from ready; revoke is idle-safe', async () => {
    let mutation;
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view('session_A', {context: null, artifacts: [artifact]})),
      mutateXiaozhiAcquisition: async input => {mutation = input; return ok(view('session_A', {context: null, artifacts: [{...artifact, status: 'revoked'}]}));}};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'installed'});
    assert(document.body.textContent.includes('MIT')); assert(document.body.textContent.includes('验证中'));
    assert(!document.body.textContent.includes('已就绪'));
    await click('pi-acquisition-revoke-artifact_fixture');
    assert.deepEqual(mutation, {action: 'revoke', sessionId: 'session_A', artifactId: artifact.id, revision: 4});
    assert(document.body.textContent.includes('已撤销'));
  });
  await check('Typed failures retain current facts and expose retry with ACQUISITION_ERRORS', async () => {
    window.omniEdu = {getXiaozhiAcquisition: async () => ok(view()), mutateXiaozhiAcquisition: async () => ({ok: false, error: 'checksum_mismatch'})};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await click('pi-acquisition-prepare-candidate_fixture');
    assert(document.body.textContent.includes('下载内容与固定完整性记录不一致'));
    assert(element('pi-acquisition-prepare-candidate_fixture')); assert(!element('pi-acquisition-prepare-candidate_fixture').disabled);
    window.omniEdu = {getXiaozhiAcquisition: async () => ({ok: false, error: 'unavailable'})};
    await mount(PiAcquisitionSettings, {sessionId: 'session_B', mode: 'discovery'});
    assert(document.body.textContent.includes('当前能力管理尚不可用'));
    assert(!document.body.textContent.includes('请在小智当前任务中准备所需能力'));
  });
  await check('Late old-session reads and unmounted operations cannot replace the new session view', async () => {
    const old = deferred();
    window.omniEdu = {getXiaozhiAcquisition: id => id === 'session_A' ? old.promise : Promise.resolve(ok(view('session_B', {candidates: [{...candidate, name: 'B会话候选'}]})))};
    await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
    await settle(async () => root.render(React.createElement(PiAcquisitionSettings, {sessionId: 'session_B', mode: 'discovery'})));
    await settle(async () => old.resolve(ok(view('session_A', {candidates: [{...candidate, name: 'A过期候选'}]}))));
    assert(document.body.textContent.includes('B会话候选')); assert(!document.body.textContent.includes('A过期候选'));
    const pending = deferred(); window.omniEdu.mutateXiaozhiAcquisition = () => pending.promise;
    await click('pi-acquisition-prepare-candidate_fixture');
    await mount(PiAcquisitionSettings, {sessionId: 'session_C', mode: 'installed'});
    await settle(async () => pending.resolve(ok(view('session_B', {artifacts: [{...artifact, name: '已卸载组件过期结果'}]}))));
    assert(!document.body.textContent.includes('已卸载组件过期结果'));
  });
  await check('Visible polling remains single-flight and stops starting reads when hidden', async () => {
    let reads = 0; const pending = deferred();
    window.omniEdu = {getXiaozhiAcquisition: () => {reads++; return pending.promise;}};
    const nativeTimeout = globalThis.setTimeout;
    globalThis.setTimeout = (callback, milliseconds, ...args) => nativeTimeout(callback, milliseconds === 10000 ? 20 : milliseconds, ...args);
    try {
      await mount(PiAcquisitionSettings, {sessionId: 'session_A', mode: 'discovery'});
      await settle(async () => delay(1300)); assert.equal(reads, 1);
      assert(document.body.textContent.includes('当前能力管理尚不可用'));
      visible = false;
      await settle(async () => document.dispatchEvent(new window.Event('visibilitychange')));
      await settle(async () => pending.resolve(ok(view())));
      await settle(async () => delay(1300)); assert.equal(reads, 1);
      visible = true; await settle(async () => document.dispatchEvent(new window.Event('visibilitychange')));
      assert.equal(reads, 2);
    } finally {globalThis.setTimeout = nativeTimeout; visible = true;}
  });
  await check('Original MCP configuration stays busy-locked while acquisition cancel remains available', async () => {
    window.omniEdu = {getXiaozhiMcpCatalog: async () => ({ok: true, value: {revision: 1, servers: []}}),
      getXiaozhiAcquisition: async () => ok(view('session_A', {operations: [operation]})),
      mutateXiaozhiAcquisition: async () => ok(view('session_A', {operations: [{...operation, phase: 'cancelled'}]}))};
    await mount(PiMcpSettings, {running: true, sessionId: 'session_A'});
    assert(element('pi-mcp-name').disabled); assert(element('pi-mcp-refresh').disabled);
    assert(!element('pi-acquisition-cancel-operation_fixture').disabled);
    await click('pi-acquisition-cancel-operation_fixture'); assert(document.body.textContent.includes('已取消'));
  });
  await check('Environment async repair and diagnosis stay attached to the selected session', async () => {
    const old = deferred();
    const environment = id => ({platform: {os: id, arch: 'x64', node: '24'}, checks: [{id: 'workspace_text', status: 'needs_configuration', label: '配置', detail: id}]});
    window.omniEdu = {getXiaozhiEnvironment: id => id === 'session_A' ? old.promise : Promise.resolve(ok(environment(id))),
      getXiaozhiAcquisition: async id => ok(view(id))};
    await mount(PiEnvironmentSettings, {sessionId: 'session_A'});
    await settle(async () => root.render(React.createElement(PiEnvironmentSettings, {sessionId: 'session_B'})));
    await settle(async () => old.resolve(ok(environment('A过期环境'))));
    assert(document.body.textContent.includes('session_B')); assert(!document.body.textContent.includes('A过期环境'));
  });
  report.success = report.checks.length === 12 && report.checks.every(item => item.pass);
} catch (error) {report.error = error.stack;}
finally {
  if (root && act) await settle(async () => root.unmount());
  dom?.window.close();
  for (const channel of channels) {channel.port1.close(); channel.port2.close();}
  globalThis.MessageChannel = NativeMessageChannel;
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({success: report.success, passed: report.checks.filter(item => item.pass).length, total: report.checks.length, output, error: report.error}));
  if (!report.success) process.exitCode = 1;
}
