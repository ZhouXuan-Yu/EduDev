// src/main/xiaozhi-agent/permissions/windows/launcher.ts
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// gate5:private-helper-channel
var spawn = (...args) => globalThis.__gate5PrivateSpawn(...args);

// src/main/xiaozhi-agent/permissions/windows/launcher.ts
import { StringDecoder } from "node:string_decoder";

// src/main/xiaozhi-agent/permissions/resources.ts
import { createHash } from "node:crypto";

// src/main/ai-harness/vendor/openhanako-tool-input-snapshot.ts
var MAX_INPUT_STRING_LENGTH = 2 * 1024 * 1024;

// src/main/xiaozhi-agent/permissions/validation.ts
var plain = (value) => !!value && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
var exact = (value, names) => Object.keys(value).length === names.length && names.every((name) => Object.prototype.hasOwnProperty.call(value, name));
var text = (value) => typeof value === "string" && value.length > 0 && value.length <= 4096 && !/[\x00-\x1f]/u.test(value);
var hash = (value) => typeof value === "string" && /^[a-f0-9]{64}$/u.test(value);

// src/main/xiaozhi-agent/permissions/resources.ts
var digest = (value) => createHash("sha256").update(value).digest("hex");

// src/main/xiaozhi-agent/permissions/windows/generated/sandbox-manifest.json
var sandbox_manifest_default = {
  schemaVersion: 1,
  protocolVersion: 1,
  maintenanceMode: "--cleanup-owned",
  profileNamePattern: "XiaozhiSandbox.<execution UUID without hyphens>",
  hostSpawn: {
    detached: true,
    windowsHide: true,
    stdio: [
      "pipe",
      "pipe",
      "pipe"
    ]
  },
  privateIdentityPath: ".runtime/.helper-state/identity.json",
  helperFile: "xiaozhi-sandbox.exe",
  helperSha256: "915a468e8747b93db77f3fb2c7424e43405ccd7ba973cad029af8b510ef5cf0f",
  sourceSha256: "df2da64900a0c71d9447de79a7a0d11ff0ed137e0f90843b0631063c7782f2cf",
  pinsSourceSha256: "dd5d906eb27868382cbf9cd28c6ac335eaec96faf16beb30612707721d230926",
  helperBytes: 52736,
  architecture: "x64",
  targetFramework: ".NET Framework 4.x",
  compilerPath: "C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe",
  compilerFileVersion: "4.8.9221.0 built by: NET481REL1LAST_25H2",
  runtimes: [
    {
      path: "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
      sha256: "60c9b29843624dd8af6b6a7b26147753be6aeef65098b9a503cc50850afe410f",
      fileVersion: "10.0.26100.8875 (WinBuild.160101.0800)",
      required: true
    },
    {
      path: "C:\\Program Files\\WindowsApps\\OpenAI.CodexPrimaryRuntime.v26-1110-778-0_26.1110.778.0_x64__3k8sg7r9htsxt\\dependencies\\native\\powershell\\pwsh.exe",
      sha256: "2a6769a3330dc1084d0154bfde7d164ab750ca7f700f313f9d417c1be78b2233",
      fileVersion: "7.6.9.500",
      required: false
    }
  ],
  invalidExecutionId: "xiexec_00000000-0000-0000-0000-000000000000",
  outputLimitError: "output_limit",
  buildTime: "2026-11-17T11:34:28.755Z",
  sourceFiles: [
    {
      file: "NativeSandbox.cs",
      sha256: "b2ad83b7cd6ee8722f7e69685f0c7ddae39b55fc8aaf4d6b248da857e977d278"
    },
    {
      file: "PlatformInfo.cs",
      sha256: "8198cebea1d7d5bf4aca3b9b303221f1c2572e3152ade20038a595a831747b5b"
    },
    {
      file: "SessionOptions.cs",
      sha256: "7a56f5aa85b27d5ac66631fdb9b3096cdf43e0852bd87781d9127a6e4f08abe5"
    },
    {
      file: "SessionInput.cs",
      sha256: "44328304d3c045509e2d00af106ad4fca1e708bbe11ea30cbde2a98f6da0789a"
    },
    {
      file: "SessionPackage.cs",
      sha256: "bb5553c17fa4f91a3a36960e535d1635eda3b23b50ffa0c29ca95805dc3d7c66"
    },
    {
      file: "JobLimits.cs",
      sha256: "0cbc9152724cc0fe3d8ab50b40b9738c14c1bd2afb20ffd8a464f9a1b12fa5d2"
    }
  ],
  adapterFiles: [
    {
      file: "windows/launcher.ts",
      sha256: "b91ef8ec4a3fbba92cc683c39a3dda1e7ca7d0a90c62b8f46c32a37ab31babff"
    },
    {
      file: "windows/projection.ts",
      sha256: "bfb4e95b5cd162a384e562f80ba4e4f9887006f92f1da68ad7698c019cc1a341"
    },
    {
      file: "windows/operations.ts",
      sha256: "83d7d3b0c56b82bbcc6fe72ac97afd277a243a48d67e7c7db09db316eae14a55"
    },
    {
      file: "windows/broker.ts",
      sha256: "325ca3793170164331ec309ea778588f4eb5d6c62d1220069c4f991cd87eecc0"
    },
    {
      file: "windows/runtime.ts",
      sha256: "6a12065c427132abe38e9574f25283e08007d4313a60ab3601c0bbd2f6eb8f1b"
    },
    {
      file: "current.ts",
      sha256: "1986398b01a7c9746033c9f2688692c6ac14108a10924635dea8d2c93f6278b4"
    },
    {
      file: "engine.ts",
      sha256: "6af562e915a0fabd10443db029f6b5c5aca51413ab29725e4c17e1aa1e6b47bf"
    },
    {
      file: "resources.ts",
      sha256: "087721c94e09b3d0944e3339497964d5f210ed9d9c098a985eedb47d213264b4"
    },
    {
      file: "summary.ts",
      sha256: "b1cb22a47125db5d24970e93e225e82ec6103fd50516fc32dd5f6aa1c1b36f6f"
    },
    {
      file: "tool-runtime.ts",
      sha256: "0876747ba1f917d7cccf65d4fc0e53ad358a59180a831159d0fa72c5ee8e2853"
    },
    {
      file: "../tools/terminal.ts",
      sha256: "acab0103579d1dd8aa41cab0960ba10fd8e14f19f82f06d391cc06eb1df73a8d"
    }
  ],
  adapterSourceSha256: "203924029d8af00a07e73adfd4637b15b3203d34f3737ec373bb2857bc858d3b",
  sessionProtocolVersion: 1,
  jobResourceProtocolVersion: 1
};

// src/main/xiaozhi-agent/permissions/windows/launcher.ts
var builtinSandboxManifest = sandbox_manifest_default;
function builtinPermissionDirectory() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [path.join(here, "permission-runtime"), path.join(here, "generated"), path.resolve("src/main/xiaozhi-agent/permissions/windows/generated")];
  const found = candidates.find((directory) => fs.existsSync(path.join(directory, sandbox_manifest_default.helperFile)));
  if (!found) throw Error("unsupported_constraint");
  return found;
}
function verifySandboxBinary(manifest, directory) {
  if (process.platform !== "win32" || process.arch !== manifest.architecture || manifest.schemaVersion !== 1 || manifest.protocolVersion !== 1 || manifest.helperFile !== "xiaozhi-sandbox.exe" || !hash(manifest.helperSha256)) throw Error("unsupported_constraint");
  const filename = path.join(directory, manifest.helperFile);
  const stat = fs.lstatSync(filename);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size !== manifest.helperBytes || stat.size > 1048576 || digest(fs.readFileSync(filename)) !== manifest.helperSha256) throw Error("source_changed");
  return filename;
}
async function inspectPermissionPlatform() {
  const executable = verifySandboxBinary(sandbox_manifest_default, builtinPermissionDirectory());
  const output = await new Promise((resolve, reject) => {
    const child = spawn(executable, ["--platform-info"], {
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
      env: Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(?:TEMP|TMP|USERPROFILE|LOCALAPPDATA|APPDATA)$/iu.test(name)))
    });
    const chunks = [];
    let size = 0, stderr = 0;
    const deadline = setTimeout(() => child.kill(), 1e4);
    child.stdout.on("data", (bytes) => {
      size += bytes.length;
      if (size > 65536) child.kill();
      else chunks.push(bytes);
    });
    child.stderr.on("data", (bytes) => {
      stderr += bytes.length;
      if (stderr > 8192) child.kill();
    });
    child.once("error", (error) => {
      clearTimeout(deadline);
      reject(error);
    });
    child.once("close", (code) => {
      clearTimeout(deadline);
      code === 0 && size <= 65536 && stderr <= 8192 ? resolve(Buffer.concat(chunks).toString("utf8")) : reject(Error("unsupported_constraint"));
    });
  });
  const raw = JSON.parse(output);
  if (!plain(raw) || !exact(raw, ["schemaVersion", "type", "platform", "architecture", "windowsDirectory", "runtimes"]) || raw.schemaVersion !== 1 || raw.type !== "platform_info" || raw.platform !== "win32" || raw.architecture !== "x64" || !text(raw.windowsDirectory) || !path.isAbsolute(raw.windowsDirectory) || !Array.isArray(raw.runtimes) || raw.runtimes.length !== 2) throw Error("invalid_protocol");
  const seen = /* @__PURE__ */ new Set();
  for (const entry of raw.runtimes) {
    if (!plain(entry) || !exact(entry, ["kind", "path", "sha256", "fileVersion", "trust", "trustSource", "publisher", "reason"]) || !["powershell5", "framework_csc"].includes(String(entry.kind)) || seen.has(entry.kind) || !text(entry.path) || entry.sha256 !== null && !hash(entry.sha256) || entry.fileVersion !== null && !text(entry.fileVersion) || !["verified", "unavailable", "untrusted"].includes(String(entry.trust)) || !["embedded", "catalog", "none"].includes(String(entry.trustSource)) || entry.publisher !== null && !text(entry.publisher) || entry.reason !== null && !text(entry.reason)) throw Error("invalid_protocol");
    seen.add(entry.kind);
    const expected = entry.kind === "powershell5" ? path.join(raw.windowsDirectory, "System32/WindowsPowerShell/v1.0/powershell.exe") : path.join(raw.windowsDirectory, "Microsoft.NET/Framework64/v4.0.30319/csc.exe");
    if (path.resolve(entry.path).toLowerCase() !== path.resolve(expected).toLowerCase()) throw Error("invalid_protocol");
  }
  return raw;
}
function validResult(raw, executionId) {
  if (!plain(raw)) return false;
  const keys = ["schemaVersion", "type", "executionId", "state", "exitCode", "truncated", "durationMs", "cleanup"];
  if (raw.error !== void 0) keys.push("error");
  return exact(raw, keys) && raw.schemaVersion === 1 && raw.type === "result" && raw.executionId === executionId && ["completed", "cancelled", "timed_out", "failed"].includes(String(raw.state)) && (raw.exitCode === null || Number.isInteger(raw.exitCode)) && typeof raw.truncated === "boolean" && typeof raw.durationMs === "number" && Number.isFinite(raw.durationMs) && raw.durationMs >= 0 && plain(raw.cleanup) && exact(raw.cleanup, ["jobActiveProcesses", "profileRemoved", "remainingOwnedAces"]) && Number.isSafeInteger(raw.cleanup.jobActiveProcesses) && typeof raw.cleanup.profileRemoved === "boolean" && Number.isSafeInteger(raw.cleanup.remainingOwnedAces) && (raw.error === void 0 || text(raw.error));
}
async function runNativeSandbox(options) {
  const executable = verifySandboxBinary(options.manifest, options.directory);
  if (options.start.session && options.manifest.sessionProtocolVersion !== 1) throw Error("unsupported_constraint");
  options.signal.throwIfAborted();
  const child = spawn(executable, [options.cleanupOnly ? "--cleanup-owned" : "--protocol-stdio"], {
    detached: true,
    windowsHide: true,
    stdio: ["pipe", "pipe", "pipe"],
    env: Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(?:SystemRoot|windir|TEMP|TMP|USERPROFILE|LOCALAPPDATA|APPDATA|SystemDrive)$/iu.test(name)))
  });
  const decoders = { stdout: new StringDecoder("utf8"), stderr: new StringDecoder("utf8") };
  const protocol = new StringDecoder("utf8");
  let pending = "", outputBytes = 0, stderrBytes = 0;
  let started = false, result, failure;
  let inputSequence = 0, acknowledgedSequence = 0, inputBytes = 0, inputClosed = false;
  const acknowledgements = /* @__PURE__ */ new Map();
  const sendControl = (frame) => {
    if (child.stdin.destroyed || !child.stdin.writable) throw Error("input_closed");
    child.stdin.write(JSON.stringify({ schemaVersion: 1, executionId: options.start.executionId, ...frame }) + "\n");
  };
  if (options.start.session) options.onSession?.({
    write(bytes) {
      options.signal.throwIfAborted();
      if (!started || result || failure || inputClosed) return Promise.reject(Error("input_closed"));
      if (!bytes.length || bytes.length > 16384 || acknowledgements.size >= 4 || inputBytes + bytes.length > options.start.session.maxInputBytes) return Promise.reject(Error("input_limit"));
      inputBytes += bytes.length;
      const sequence = ++inputSequence;
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          acknowledgements.delete(sequence);
          reject(Error("input_timeout"));
          fail();
        }, 3e4);
        acknowledgements.set(sequence, { resolve, reject, timer });
        try {
          sendControl({ type: "input", sequence, data: bytes.toString("base64") });
        } catch (error) {
          clearTimeout(timer);
          acknowledgements.delete(sequence);
          reject(error);
          fail();
        }
      });
    },
    close() {
      if (inputClosed) return;
      inputClosed = true;
      if (!result && !failure) sendControl({ type: "input_close" });
    }
  });
  const cancel = () => {
    if (!child.stdin.destroyed) child.stdin.write(JSON.stringify({
      schemaVersion: 1,
      type: "cancel",
      executionId: options.start.executionId,
      reason: options.signal.reason === "revoked" ? "revoked" : options.signal.reason === "timeout" ? "timeout" : "cancelled"
    }) + "\n");
  };
  const fail = () => {
    failure ||= Error("invalid_protocol");
    cancel();
    child.stdin.end();
  };
  options.signal.addEventListener("abort", cancel, { once: true });
  const deadline = setTimeout(() => {
    failure ||= Error("timeout");
    cancel();
    child.stdin.end();
  }, options.start.timeoutMs + 15e3);
  deadline.unref();
  child.stdin.on("error", () => {
  });
  child.stderr.on("data", (bytes) => {
    stderrBytes += bytes.length;
    if (stderrBytes > 8192) fail();
  });
  child.stdout.on("data", (bytes) => {
    try {
      pending += protocol.write(bytes);
      let newline = pending.indexOf("\n");
      while (newline >= 0) {
        const frame = JSON.parse(pending.slice(0, newline));
        pending = pending.slice(newline + 1);
        if (!plain(frame) || frame.schemaVersion !== 1 || frame.executionId !== options.start.executionId || result) return fail();
        if (frame.type === "started") {
          if (started || options.cleanupOnly || !exact(frame, ["schemaVersion", "type", "executionId", "pid", "tokenIsAppContainer", "jobAssigned", "profileName", "projectionRoot"]) || !Number.isInteger(frame.pid) || frame.tokenIsAppContainer !== true || frame.jobAssigned !== true || frame.projectionRoot !== options.start.projectionRoot || frame.profileName !== "XiaozhiSandbox." + options.start.executionId.slice(7).replaceAll("-", "")) return fail();
          started = true;
          options.onStarted?.(Number(frame.pid), child.pid);
        } else if (frame.type === "output") {
          if (!started || !exact(frame, ["schemaVersion", "type", "executionId", "stream", "data"]) || !["stdout", "stderr"].includes(String(frame.stream)) || typeof frame.data !== "string" || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(frame.data)) return fail();
          const chunk = Buffer.from(frame.data, "base64");
          outputBytes += chunk.length;
          if (chunk.length > 16384 || outputBytes > options.start.maxOutputBytes) return fail();
          options.onBytes?.(frame.stream, chunk);
          const decoded = decoders[frame.stream].write(chunk);
          if (decoded) options.onData?.(Buffer.from(decoded));
        } else if (frame.type === "input_ack") {
          if (!options.start.session || !started || !exact(frame, ["schemaVersion", "type", "executionId", "sequence"]) || frame.sequence !== acknowledgedSequence + 1) return fail();
          const pendingAck = acknowledgements.get(Number(frame.sequence));
          if (!pendingAck) return fail();
          acknowledgedSequence++;
          clearTimeout(pendingAck.timer);
          acknowledgements.delete(acknowledgedSequence);
          pendingAck.resolve();
        } else if (frame.type === "result" && validResult(frame, options.start.executionId)) {
          result = frame;
          options.onResult?.(frame);
        } else return fail();
        newline = pending.indexOf("\n");
      }
      if (Buffer.byteLength(pending) > 65536) fail();
    } catch {
      fail();
    }
  });
  try {
    const code = await new Promise((resolve, reject) => {
      child.once("error", reject);
      child.once("close", resolve);
      child.stdin.write(JSON.stringify(options.start) + "\n");
      if (options.signal.aborted) cancel();
    });
    if (failure) throw failure;
    if (pending.trim() || !result || result.cleanup.jobActiveProcesses !== 0 || !result.cleanup.profileRemoved || result.cleanup.remainingOwnedAces !== 0 || code !== (result.state === "failed" ? 1 : 0) || !options.cleanupOnly && result.state === "completed" && !started) throw Error("cleanup_failed");
    for (const decoder of Object.values(decoders)) {
      const tail = decoder.end();
      if (tail) options.onData?.(Buffer.from(tail));
    }
    return { result, helperHash: options.manifest.helperSha256, outputBytes, started };
  } finally {
    for (const pendingAck of acknowledgements.values()) {
      clearTimeout(pendingAck.timer);
      pendingAck.reject(Error("input_closed"));
    }
    acknowledgements.clear();
    clearTimeout(deadline);
    options.signal.removeEventListener("abort", cancel);
    child.stdin.end();
  }
}
export {
  builtinPermissionDirectory,
  builtinSandboxManifest,
  inspectPermissionPlatform,
  runNativeSandbox,
  verifySandboxBinary
};
