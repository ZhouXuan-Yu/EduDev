import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
const review = 'C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-gate5-independent-20261117';
const cwd = 'D:/WorkProject/EduProject-harness/apps/desktop';
const scripts = [
 ['governance','phase5-governance-smoke.mjs',11],
 ['extension-protocol','phase5-extension-protocol-smoke.mjs',16],
 ['acquisition-lifecycle','phase5-acquisition-lifecycle-smoke.mjs',14],
 ['renderer','phase5-acquisition-renderer-smoke.mjs',33],
 ['extension-native','phase5-extension-native-smoke.mjs',21],
 ['extension-package','phase5-extension-package-smoke.mjs',18],
 ['recovery','phase5-extension-recovery-parent.mjs',2],
 ['production','phase5-production-smoke.mjs',5],
 ['mcp-lifecycle','phase5-mcp-lifecycle-smoke.mjs',11],
 ['extension-host','phase5-extension-host-smoke.mjs',6],
 ['ui','phase5-ui-smoke.mjs',8]
];
const results=[];
for(const [name,file,expected] of scripts) {
 const command=['scripts/xiaozhi-agent/'+file];
 const started=Date.now();
 const log=path.join(review,name+'.log');
 const stream=fs.createWriteStream(log,{flags:'wx'});
 let output='';
 const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;delete env.NODE_OPTIONS;
 if(name==='production')env.PHASE5_RESUME_ROOT='C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-production-grcqce';
 const child=spawn(process.execPath,command,{cwd,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 for(const pipe of [child.stdout,child.stderr])pipe.on('data',bytes=>{stream.write(bytes);output+=bytes.toString('utf8');});
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve);});
 await new Promise(resolve=>stream.end(resolve));
 const lines=output.trim().split(/\r?\n/);let summary;
 for(const line of lines.reverse()){try{const value=JSON.parse(line);if(value&&typeof value==='object'&&'success'in value){summary=value;break;}}catch{}}
 const item={name,command:'node '+command.join(' '),cwd,code,expected,summary,elapsedMs:Date.now()-started,log};
 item.pass=code===0&&summary?.success===true;
 results.push(item);
 fs.writeFileSync(path.join(review,'runs.json'),JSON.stringify({results,paidCalls:0},null,2));
 console.log(JSON.stringify(item));
 if(!item.pass){process.exitCode=1;break;}
}