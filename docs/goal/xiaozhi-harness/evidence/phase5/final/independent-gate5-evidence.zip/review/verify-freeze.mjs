import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const workspace = 'D:/WorkProject/EduProject-harness';
const evidence = path.join(workspace, 'docs/goal/xiaozhi-harness/evidence/phase5/implementation-writer-20261117');
const review = path.dirname(new URL(import.meta.url).pathname.replace(/^\/(?:([A-Za-z]:)\/)/, '$1/'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const frozen = JSON.parse(fs.readFileSync(path.join(evidence, 'FINAL_FREEZE.json'), 'utf8'));
const result = {phase: process.argv[2] || 'before', createdAt: new Date().toISOString(), freezeSha256: sha(fs.readFileSync(path.join(evidence,'FINAL_FREEZE.json'))), groups: {}, differences: []};
for (const [name, group] of Object.entries(frozen)) {
  if (!group || !Array.isArray(group.files)) continue;
  const actual = [];
  for (const item of group.files) {
    const filename = path.isAbsolute(item.file) ? item.file : path.join(workspace,item.file);
    let bytes;
    try {bytes=fs.readFileSync(filename);} catch(error) {result.differences.push({group:name,file:item.file,error:error.code});continue;}
    const current = {...item,bytes:bytes.length,sha256:sha(bytes)};
    actual.push(current);
    if(current.bytes!==item.bytes||current.sha256!==item.sha256) result.differences.push({group:name,file:item.file,expected:item,actual:current});
  }
  result.groups[name] = {count:actual.length,expectedCount:group.count,listHash:sha(JSON.stringify(actual)),expectedListHash:group.listHash};
}
result.pass = result.freezeSha256 === 'ac07f17cf9485722052836955602f3efd90888ef88196d627f9f52017286f126' && result.differences.length === 0;
fs.writeFileSync(path.join(review,'identity-'+result.phase+'.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
if(!result.pass)process.exitCode=1;