# Gate5 independent review plan

Reviewer phase5_final_gate_review. Target D:/WorkProject/EduProject-harness. Production read-only, no Git, no npm installation, no build or out writes, no real provider. Await final freeze and runtime release before execution.

Contract PHASE_5_IMPLEMENTATION sections 1-11, P5-01 through P5-12. Preserve H01-H31 and existing 89 criteria. Scope includes T5.0-T5.5, Marketplace/MCP/Extension, H23 governance, acquisition-specific recovery. Phase6 checkpoint/PTY and Phase7/Terra full page and Phase8/provider/packaging remain under their own contracts.

Read-only preflight has inspected acquisition source/state/npm install/public fetch, Extension host/service/registry/package-manager anchors, core governance, controlled transport/service, JobLimits/SessionInput and production host composition. Entire repo graph is zero-node. Extension-domain graph symbol lookup succeeded. No confirmed P0/P1 finding from these reads. This preflight is a moving source candidate review and provides no accepted freeze.

## Fixed execution matrix after freeze

| P5 item | Existing criteria | Planned evidence |
|---|---|---|
| P5-01 | M-01, M-07 | lifecycle 14 source normalization/cache, exact ref/lock |
| P5-02 | M-02/03/04, A-P0-03 | lifecycle 14 plus genuine public package production 5 |
| P5-03 | H23, P-01/02/05, A-P0-02/08/09 | governance 11, production 5, original runtime tests |
| P5-04 | A-P0-03/05, M-05 | stdio 5, same-mode Extension malformed/limits/cancel, helper input coverage to map |
| P5-05 | A-P0-03/06/07 | Extension native/package, credentials, recovery, original helper boundaries |
| P5-06 | A-P0-03/06 | resources 10, source unsupported_constraint paths, API unsupported coverage to map |
| P5-07 | P-03, A-P0-09 | production 5 plus lifecycle 14 |
| P5-08 | M-05/06, A-P0-05/08 | MCP lifecycle 11 plus governance 11 |
| P5-09 | M-08, A-P0-06/07 | protocol 16, native 21, package 18, host 6 |
| P5-10 | T-05/06/07/12/13 scoped | lifecycle 14, actual kill recovery 2, package 18 |
| P5-11 | M-07/09, A-P0-07 | lifecycle 14, MCP 11, Extension native/host |
| P5-12 | relevant UI criteria | UI8 and renderer33, exact two-size/restart scoped evidence |

Expected independent commands from apps/desktop are node scripts/xiaozhi-agent/phase5-{acquisition-lifecycle,governance,stdio,extension-protocol,extension-native,extension-package,resources-native,production,mcp-lifecycle,extension-host,ui}-smoke.mjs, node scripts/xiaozhi-agent/phase5-extension-recovery-parent.mjs, node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs. These commands bundle isolated test harnesses to TEMP or test-results and do not build production out. Runtime tests execute serially. Root supplies final approved command subset and freeze, existing build/components/smoke evidence, helper/native/dependency manifests and readback roots.

## Open evidence mapping

Final source/helper/generated manifest/out/dependency identities and post-freeze zero-drift verification pending. Final build/smoke/component logs and UI8 pending. Helper input ack/backpressure/initialize hang coverage needs exact existing assertion mapping. OS API unsupported handling coverage needs source/runtime distinction. Prior manager source times and all original FAIL reports retained as historical evidence. The root audit reports 29 advisories low8/moderate13/high8/critical0, same as Gate4, Phase8 reachability scope.
