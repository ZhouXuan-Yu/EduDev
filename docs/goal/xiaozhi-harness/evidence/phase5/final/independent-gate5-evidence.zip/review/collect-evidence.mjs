import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const review='C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-gate5-independent-20261117';
const repo='D:/WorkProject/EduProject-harness';const desktop=path.join(repo,'apps/desktop');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const runs=JSON.parse(fs.readFileSync(path.join(review,'runs.json'),'utf8')).results;
const records=[];const directories=new Set([review]);const executions=new Set();const cleanups=new Map();
function visit(value){if(!value||typeof value!=='object')return;
 if(typeof value.executionId==='string')executions.add(value.executionId);
 if(value.cleanup&&Object.hasOwn(value.cleanup,'jobActiveProcesses'))cleanups.set(value.executionId||sha(JSON.stringify(value)),{executionId:value.executionId,...value.cleanup});
 for(const child of Object.values(value))if(child&&typeof child==='object')visit(child);
}
for(const run of runs){
 const s=run.summary;let file;
 for(const p of [s.output&&path.join(s.output,'report.json'),s.root&&path.join(s.root,'report.json'),s.root&&path.join(s.root,'evidence/report.json')].filter(Boolean))if(fs.existsSync(p)){file=p;break;}
 if(!file)throw Error('missing_report_'+run.name);
 const bytes=fs.readFileSync(file);const report=JSON.parse(bytes);const cases=report.checks||report.cases;
 if(run.code!==0||report.success!==true||cases.length!==run.expected||!cases.every(item=>item.pass))throw Error('run_count_mismatch_'+run.name);
 for(const d of [s.root,s.output,report.root,report.output])if(d)directories.add(d);
 visit(report);records.push({...run,report:file,reportSha256:sha(bytes),passed:cases.length,paidCalls:report.paidCalls||0});
}
const negativePath='C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-stdio-OGs0TO/evidence/report.json';
const negative=JSON.parse(fs.readFileSync(negativePath,'utf8'));
if(!negative.success||negative.checks.length!==5||!negative.checks.every(item=>item.pass))throw Error('negative_probe_failed');
visit(negative);directories.add(negative.root);directories.add(negative.output);
for(const entry of fs.readdirSync(process.env.TEMP,{withFileTypes:true})){
 if(!entry.isDirectory()||!entry.name.startsWith('xiaozhi-permission-exec-'))continue;
 const directory=path.join(process.env.TEMP,entry.name);const marker=path.join(directory,'.xiaozhi-projection.json');
 try{const projection=JSON.parse(fs.readFileSync(marker,'utf8'));if(executions.has(projection.executionId))directories.add(directory);}catch{}
}
const coreFile=path.join(desktop,'src/main/xiaozhi-agent/capabilities/generated/core-tool-manifest.json');
const core=JSON.parse(fs.readFileSync(coreFile,'utf8'));
const actualCore=core.sources.map(item=>({file:item.file,sha256:sha(fs.readFileSync(path.join(desktop,item.file)))}));
const coreResult={sources:core.sources.length,sourceHash:sha(JSON.stringify(actualCore)),expected:core.sourceHash,differences:actualCore.filter((item,index)=>item.sha256!==core.sources[index].sha256)};
coreResult.pass=coreResult.sourceHash===coreResult.expected&&coreResult.differences.length===0;
const summary={decision:'PENDING_FINAL_INVENTORY',records,negativeProbe:{file:negativePath,sha256:sha(fs.readFileSync(negativePath)),passed:5,exitCode:0},independentlyPassed:records.reduce((n,r)=>n+r.passed,0)+5,paidCalls:0,core:coreResult,nativeCleanups:[...cleanups.values()]};
summary.cleanupFailures=summary.nativeCleanups.filter(item=>item.jobActiveProcesses!==0||item.profileRemoved!==true||item.remainingOwnedAces!==0);
fs.writeFileSync(path.join(review,'owned-runtime-directories.json'),JSON.stringify([...directories],null,2));
fs.writeFileSync(path.join(review,'summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({independentlyPassed:summary.independentlyPassed,runSets:records.length,core:coreResult,nativeCleanupCount:cleanups.size,cleanupFailures:summary.cleanupFailures.length,ownedDirectories:directories.size}));