import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {build} from 'file:///D:/WorkProject/EduProject-harness/apps/desktop/node_modules/esbuild/lib/main.js';
import {McpClient} from 'file:///D:/WorkProject/EduProject-harness/apps/desktop/node_modules/@earendil-works/pi-mcp/dist/index.js';
import {DatabaseSync} from 'node:sqlite';

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaozhi-phase5-stdio-'));
const output = path.join(root, 'evidence'); fs.mkdirSync(output);
await build({stdin: {contents: `export {createControlledStdioTransport} from './src/main/xiaozhi-agent/mcp-controlled-transport.ts';
export {createPermissionRuntimeManager} from './src/main/xiaozhi-agent/permissions/windows/runtime.ts';
export {createPermissionStore} from './src/main/xiaozhi-agent/permissions/store.ts';
export {createPermissionEngine} from './src/main/xiaozhi-agent/permissions/engine.ts';
export {permissionHash} from './src/main/xiaozhi-agent/permissions/validation.ts';
export {createControlledMcpService} from './src/main/xiaozhi-agent/mcp-controlled-service.ts';
export {createMcpRuntime} from './src/main/xiaozhi-agent/mcp-runtime.ts';
export {createMcpPermissionContext} from './src/main/xiaozhi-agent/permissions/mcp.ts';
export {createPermissionService} from './src/main/xiaozhi-agent/permissions/service.ts';
export {filesystemScope, digest} from './src/main/xiaozhi-agent/permissions/resources.ts';`, resolveDir: process.cwd(), loader: 'ts'}, outfile: path.join(output, 'transport.mjs'),
  bundle: true, platform: 'node', format: 'esm', packages: 'external', target: 'node24', plugins: [{name: 'fixed-sdk-resolution', setup(builder) {builder.onResolve({filter: /^@earendil-works\/pi-mcp$/}, () => ({path: 'file:///D:/WorkProject/EduProject-harness/apps/desktop/node_modules/@earendil-works/pi-mcp/dist/index.js', external: true}));}}]});
const {createControlledStdioTransport, createPermissionRuntimeManager, createPermissionStore, createPermissionEngine, permissionHash,
  createControlledMcpService, createMcpRuntime, createMcpPermissionContext, createPermissionService, filesystemScope, digest} = await import(pathToFileURL(path.join(output, 'transport.mjs')).href);
const db = new DatabaseSync(path.join(root, 'authority.sqlite'));
db.exec('CREATE TABLE ai_confirmation_items(id TEXT PRIMARY KEY,run_id TEXT,session_id TEXT,action_type TEXT,status TEXT,title TEXT,description TEXT,preview_md TEXT,payload_json TEXT,created_at TEXT,updated_at TEXT)');
db.exec('CREATE TABLE app_settings(key TEXT PRIMARY KEY,value_json TEXT,updated_at TEXT)');
const sql = {all: async (query, values = []) => db.prepare(query).all(...values),
  run: async (query, values = []) => {db.prepare(query).run(...values);},
  change: async (query, values = []) => Number(db.prepare(query).run(...values).changes)};
sql.transaction = async action => {
  db.exec('BEGIN IMMEDIATE');
  try {const result = await action(sql); db.exec('COMMIT'); return result;}
  catch (error) {db.exec('ROLLBACK'); throw error;}
};
const store = createPermissionStore(sql); await store.migrate();
const owner = {sessionId: 'aisession_' + randomUUID(), taskId: 'xitask_' + 'a'.repeat(64), runId: 'run_stdio_recipe', generation: 1};
const manager = createPermissionRuntimeManager({root: path.join(root, 'runtime'), store});
const recipe = manager.recipe();
await store.issue(owner.sessionId, [recipe], {kind: 'teacher', reference: 'owned-phase5-runtime-recipe'});
const engine = createPermissionEngine({store, current: () => true});
const request = {schemaVersion: 2, owner, requirementsVersion: 1, callId: 'runtime_recipe', action: 'environment_repair', inputDigest: permissionHash(recipe),
  purpose: '合成stdio测试固定源码受控运行时', scopes: [recipe], files: [], provider: null, classification: 'redacted', expiresAt: new Date(Date.now() + 300000).toISOString()};
let selected, runtime;
const checks = [], receipts = [];
const report = {success: false, root, output, checks, receipts, paidCalls: 0,
  boundary: 'Independent Gate5 fixed negative probes. Actual production AppContainer/Job and public Pi initialize cancellation plus pipe backpressure cancellation. All fixtures owned TEMP, no paid provider, no production out writes. Private ACK contract negatives use an explicitly mocked main-helper control channel.'};
function projection(script) {
  const executionId = 'xiexec_' + randomUUID();
  const owner = {sessionId: 'aisession_' + randomUUID(), taskId: 'xitask_fixture', runId: 'run_stdio', generation: 1};
  const directory = path.join(os.tmpdir(), 'xiaozhi-permission-exec-' + randomUUID());
  fs.mkdirSync(directory);
  fs.writeFileSync(path.join(directory, '.xiaozhi-projection.json'), JSON.stringify({schemaVersion: 1, executionId, grantHash: 'a'.repeat(64), owner}));
  fs.writeFileSync(path.join(directory, 'server.ps1'), '\ufeff' + script);
  return {executionId, owner, directory, stderr: []};
}
function transport(fixture, signal, overrides = {}) {
  return createControlledStdioTransport({runtime: selected, signal,
    assert: async () => signal.throwIfAborted(), onStderr: bytes => fixture.stderr.push(bytes.toString('utf8')), receipt: async result => {receipts.push(result);}, cleanup: async () => {},
    start: {schemaVersion: 1, type: 'start', executionId: fixture.executionId, owner: fixture.owner, grantHash: 'a'.repeat(64),
      executable: runtime.path, executableHash: runtime.sha256, projectionRoot: fixture.directory, cwd: fixture.directory,
      command: '', env: {XIAOZHI_WORKSPACE: fixture.directory}, timeoutMs: 300000, maxOutputBytes: 4194304, maxProcesses: 8,
      session: {schemaVersion: 1, mode: 'stdio', arguments: '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + path.join(fixture.directory, 'server.ps1') + '"',
        maxInputBytes: 8388608, memoryBytes: 536870912, cpuRate: 5000, userTimeMs: 0, environment: {}, ...overrides}}});
}
async function until(predicate, timeoutMs = 12000) {
  const deadline = Date.now() + timeoutMs;
  while (!predicate()) {
    if (Date.now() >= deadline) throw Error('probe_setup_deadline');
    await new Promise(resolve => setTimeout(resolve, 25));
  }
}
async function bounded(promise, timeoutMs = 12000) {
  let timer;
  try {return await Promise.race([promise, new Promise((_, reject) => {timer = setTimeout(() => reject(Error('probe_cancel_deadline')), timeoutMs);})]);}
  finally {clearTimeout(timer);}
}
function clean(receipt) {
  assert(receipt);
  assert.equal(receipt.cleanup.jobActiveProcesses, 0);
  assert.equal(receipt.cleanup.profileRemoved, true);
  assert.equal(receipt.cleanup.remainingOwnedAces, 0);
}
async function check(name, action) {
  const started = performance.now();
  const record = {name, pass: false}; checks.push(record);
  try {await action(record); record.pass = true; record.durationMs = performance.now() - started; console.log('PASS ' + name);}
  catch (error) {record.durationMs = performance.now() - started; record.error = error.stack; throw error;}
  finally {fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));}
}
try {
  selected = (await engine.run(request, new AbortController().signal, context => manager.prepare({request, ...context}, recipe.sha256))).runtime;
  runtime = await manager.systemRuntime();
  assert.equal(selected.manifest.runtimes.find(item => item.required).sha256, runtime.sha256);
  report.helperHash = selected.manifest.helperSha256;
  report.runtime = {directory: selected.directory, helper: selected.manifest, systemRuntime: runtime};
  await check('Actual stdio initialize remains pending after the guest consumes initialize and parent cancellation settles it with exact cleanup', async record => {
    const fixture = projection(String.raw`
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
$line = [Console]::ReadLine()
$request = $line | ConvertFrom-Json
if ($request.method -ne 'initialize') { exit 7 }
[Console]::Error.WriteLine('GATE5_INITIALIZE_PENDING')
Start-Sleep -Seconds 300
`);
    const controller = new AbortController();
    const connection = transport(fixture, controller.signal);
    const client = new McpClient({name: 'gate5-independent', version: '1.0.0', requestTimeoutMs: 60000});
    let settled = false;
    const pending = client.connect(connection).then(() => {settled = true; return {status: 'fulfilled'};}, error => {settled = true; return {status: 'rejected', code: error.message};});
    try {
      await until(() => fixture.stderr.join('').includes('GATE5_INITIALIZE_PENDING'));
      await new Promise(resolve => setTimeout(resolve, 500));
      assert.equal(settled, false);
      record.initializeConsumedByGuest = true;
      const started = performance.now();
      controller.abort('cancelled');
      const outcome = await bounded(pending);
      await bounded(client.close());
      record.cancelToSettledMs = performance.now() - started;
      record.outcome = outcome;
      assert.equal(outcome.status, 'rejected');
      assert(record.cancelToSettledMs < 12000);
      clean(receipts.at(-1)); assert.equal(receipts.at(-1).executionId, fixture.executionId);
      assert.equal(receipts.at(-1).state, 'cancelled');
      record.receipt = receipts.at(-1);
    } finally {controller.abort('cancelled'); await bounded(client.close());}
  });
  await check('Actual unread stdin pipe backpressure leaves a large send pending and control-channel cancellation terminates the Job and pending send', async record => {
    const fixture = projection("[Console]::Error.WriteLine('GATE5_NOT_READING_STDIN'); Start-Sleep -Seconds 300");
    const controller = new AbortController();
    const connection = transport(fixture, controller.signal);
    try {
      await connection.start();
      await until(() => fixture.stderr.join('').includes('GATE5_NOT_READING_STDIN'));
      let settled = false;
      const message = {jsonrpc: '2.0', id: 1, method: 'tools/call', params: {name: 'owned', arguments: {text: 'x'.repeat(220000)}}};
      record.inputBytes = Buffer.byteLength(JSON.stringify(message) + '\n');
      const pending = connection.send(message).then(() => {settled = true; return {status: 'fulfilled'};}, error => {settled = true; return {status: 'rejected', code: error.message};});
      await new Promise(resolve => setTimeout(resolve, 750));
      assert.equal(settled, false);
      record.pendingAfter750ms = true;
      const started = performance.now();
      controller.abort('cancelled');
      const [outcome] = await bounded(Promise.all([pending, connection.close()]));
      record.cancelToSettledMs = performance.now() - started;
      record.outcome = outcome;
      assert.equal(outcome.status, 'rejected');
      assert(record.cancelToSettledMs < 12000);
      clean(receipts.at(-1)); assert.equal(receipts.at(-1).executionId, fixture.executionId);
      assert.equal(receipts.at(-1).state, 'cancelled');
      record.receipt = receipts.at(-1);
    } finally {controller.abort('cancelled'); await bounded(connection.close());}
  });
  const {EventEmitter} = await import('node:events');
  const launcherFile = path.join(output, 'launcher-contract.mjs');
  await build({entryPoints: ['src/main/xiaozhi-agent/permissions/windows/launcher.ts'], outfile: launcherFile,
    bundle: true, platform: 'node', format: 'esm', target: 'node24', plugins: [{name: 'private-helper-channel-mock', setup(builder) {
      builder.onResolve({filter: /^node:child_process$/}, () => ({path: 'private-helper-channel', namespace: 'gate5'}));
      builder.onLoad({filter: /.*/, namespace: 'gate5'}, () => ({contents: 'export const spawn=(...args)=>globalThis.__gate5PrivateSpawn(...args);', loader: 'js'}));
    }}]});
  const {runNativeSandbox} = await import(pathToFileURL(launcherFile).href);
  for (const fault of ['wrong_sequence', 'wrong_identity', 'extra_field']) {
    await check('Private main-helper ACK contract rejects ' + fault + ' and settles the pending write', async record => {
      const fixture = projection('Start-Sleep -Seconds 300');
      const controller = new AbortController();
      const start = {schemaVersion: 1, type: 'start', executionId: fixture.executionId, owner: fixture.owner,
        grantHash: 'a'.repeat(64), executable: runtime.path, executableHash: runtime.sha256, projectionRoot: fixture.directory,
        cwd: fixture.directory, command: '', env: {XIAOZHI_WORKSPACE: fixture.directory}, timeoutMs: 300000,
        maxOutputBytes: 4194304, maxProcesses: 8,
        session: {schemaVersion: 1, mode: 'stdio', arguments: '', maxInputBytes: 8388608, memoryBytes: 536870912, cpuRate: 5000, userTimeMs: 0, environment: {}}};
      let input;
      let writeResult;
      let mockedSpawnCalls = 0;
      globalThis.__gate5PrivateSpawn = (executable, args) => {
        mockedSpawnCalls++;
        assert.equal(executable, path.join(selected.directory, selected.manifest.helperFile));
        assert.deepEqual(args, ['--protocol-stdio']);
        const child = new EventEmitter(); child.pid = 987654;
        child.stdout = new EventEmitter(); child.stderr = new EventEmitter();
        child.stdin = new EventEmitter(); child.stdin.destroyed = false; child.stdin.writable = true;
        let terminal = false;
        const emit = frame => child.stdout.emit('data', Buffer.from(JSON.stringify(frame) + '\n'));
        const cancel = () => {
          if (terminal) return; terminal = true;
          setImmediate(() => {
            emit({schemaVersion: 1, type: 'result', executionId: fixture.executionId, state: 'cancelled', exitCode: null,
              truncated: false, durationMs: 1, cleanup: {jobActiveProcesses: 0, profileRemoved: true, remainingOwnedAces: 0}});
            child.emit('close', 0);
          });
        };
        child.stdin.end = () => {child.stdin.writable = false; cancel();};
        child.stdin.write = bytes => {
          for (const line of String(bytes).trim().split('\n')) {
            const frame = JSON.parse(line);
            if (frame.type === 'start') setImmediate(() => emit({schemaVersion: 1, type: 'started', executionId: fixture.executionId,
              pid: 987653, tokenIsAppContainer: true, jobAssigned: true,
              profileName: 'XiaozhiSandbox.' + fixture.executionId.slice(7).replaceAll('-', ''), projectionRoot: fixture.directory}));
            else if (frame.type === 'input') setImmediate(() => {
              const ack = {schemaVersion: 1, type: 'input_ack', executionId: fixture.executionId, sequence: frame.sequence};
              if (fault === 'wrong_sequence') ack.sequence++;
              if (fault === 'wrong_identity') ack.executionId = 'xiexec_' + randomUUID();
              if (fault === 'extra_field') ack.untrusted = true;
              emit(ack);
            });
            else if (frame.type === 'cancel') cancel();
          }
          return true;
        };
        return child;
      };
      try {
        const running = runNativeSandbox({manifest: selected.manifest, directory: selected.directory, start, signal: controller.signal,
          onSession: channel => {input = channel;}, onStarted: () => {
            writeResult = input.write(Buffer.from('owned')).then(() => ({status: 'fulfilled'}), error => ({status: 'rejected', code: error.message}));
          }});
        await assert.rejects(bounded(running), /invalid_protocol/);
        record.writeResult = await bounded(writeResult);
        assert.equal(record.writeResult.status, 'rejected');
        assert.equal(mockedSpawnCalls, 1);
        record.boundary = 'Explicit fake helper control frames. No native process or guest-origin ACK is claimed.';
      } finally {delete globalThis.__gate5PrivateSpawn; controller.abort();}
    });
  }
  report.success = true;
} catch (error) {report.error = error.stack; process.exitCode = 1; console.error(error);}
finally {
  db.close();
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({success: report.success, passed: checks.filter(item => item.pass).length, total: checks.length, output, root, error: report.error}));
}