import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
const review='C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase5-gate5-independent-20261117';
const base='D:/WorkProject/EduProject-harness/apps/desktop';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const files=['@earendil-works/pi-mcp','@earendil-works/pi-coding-agent','@earendil-works/pi-agent-core','typebox','esbuild','electron','sqlite3','semver','tar'].map(name=>'node_modules/'+name+'/package.json');
files.push(...['@earendil-works/pi-mcp/dist/index.js','@earendil-works/pi-mcp/dist/client.js','@earendil-works/pi-mcp/dist/transports/stdio.js','@earendil-works/pi-coding-agent/dist/index.js','@earendil-works/pi-agent-core/dist/index.js','electron/dist/electron.exe','sqlite3/build/Release/node_sqlite3.node','esbuild/lib/main.js','@esbuild/win32-x64/esbuild.exe','semver/index.js','tar/dist/esm/index.js'].map(name=>'node_modules/'+name));
const entries=files.map(file=>{const bytes=fs.readFileSync(path.join(base,file));let version;
if(file.endsWith('package.json'))version=JSON.parse(bytes).version;
return {file:'apps/desktop/'+file,bytes:bytes.length,sha256:sha(bytes),...(version?{version}:{})};});
const name=process.argv[2]||'before';
const result={name,entries};
if(name==='after') {const before=JSON.parse(fs.readFileSync(path.join(review,'dependencies-before.json'),'utf8'));result.differences=entries.filter((entry,index)=>JSON.stringify(entry)!==JSON.stringify(before.entries[index]));}
fs.writeFileSync(path.join(review,'dependencies-'+name+'.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({name,count:entries.length,differences:result.differences}));