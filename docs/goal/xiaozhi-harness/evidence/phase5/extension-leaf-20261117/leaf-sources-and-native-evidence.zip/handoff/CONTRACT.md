# Extension leaf delivery contract

Scope covers isolated external Extension lifecycle for Phase5 T5.4. Pi remains the only runtime and Task/Journal/Permission remain existing authorities. Main receives a reviewed immutable package binding from acquisition. This leaf writes only extensions/**, phase5-extension-* scripts, and this TEMP directory.

Supported hooks are context.transform and event.observe, RPC schemaVersion 1. Context hook receives and returns bounded JSON context. Event hook receives bounded public event data and returns an acknowledgement. No automatic Pi hook registration occurs here. Core owns host/shared/preload/UI integration.

Install and each run hold an independent Extension Scope lease in the original Permission Engine. The controlled MCP transport separately requests original filesystem/process/dependency scopes. No external code import/eval/require occurs in main. Package and Node bytes are reverified by existing binding before launch in AppContainer. Host filesystem/network/process/secret/arbitrary IPC requests explicitly return unsupported. Log records accept a fixed code enum and have no guest text.

Lifecycle metadata uses existing Sql transaction/CAS and app_settings namespace. Immutable versions reference acquisition-owned artifact bytes, existing active stays on failed health/install, enable/select/rollback require a fresh healthy run, disable/revoke abort active sessions and wait for cleanup. Revoked versions cannot reactivate. Source changes for the same version reject. Restart preserves metadata and creates no process until explicit open. No new Task or journal authority.

Tests cover normal hooks/Unicode, exact schema/ID/rate/size limits, health mismatch, unsupported hook/host calls, no Extension authorization, timeout/cancel, disable/revoke/owner changes, version selection/rollback, stale CAS, persistent readback and original helper Job/profile/ACE cleanup. Native fixtures additionally attempt outside file reads and socket access inside the real AppContainer. Node is copied from D:/Node/node.exe to owned TEMP and exact SHA verified. No real key/model/provider request.

Rollback disables extensions and closes sessions, then core can stop invoking createExtensionService. Metadata namespace is additive. No package deletion or original user data mutation occurs.

Product UI and full host integration, actual public third-party Extension compatibility, tool registration/context mutation in live Pi, secret consumption and asar/platform migration remain core/Gate5 integration boundaries. This leaf verifies its actual service and real Windows isolation.
