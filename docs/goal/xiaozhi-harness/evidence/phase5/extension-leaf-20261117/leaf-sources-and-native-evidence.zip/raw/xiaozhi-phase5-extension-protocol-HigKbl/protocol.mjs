// src/main/xiaozhi-agent/extensions/rpc.ts
import { randomUUID } from "node:crypto";

// src/main/ai-harness/vendor/openhanako-tool-input-snapshot.ts
var MAX_INPUT_STRING_LENGTH = 2 * 1024 * 1024;

// src/main/xiaozhi-agent/permissions/validation.ts
var plain = (value) => !!value && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
var exact = (value, names) => Object.keys(value).length === names.length && names.every((name) => Object.prototype.hasOwnProperty.call(value, name));

// src/main/xiaozhi-agent/extensions/types.ts
var EXTENSION_HOOKS = ["context.transform", "event.observe"];

// src/main/xiaozhi-agent/extensions/validation.ts
var EXTENSION_MAX_BYTES = 65536;
function boundedJson(value) {
  let nodes = 0;
  const visit = (item, depth) => {
    if (++nodes > 4096 || depth > 16) return false;
    if (item === null || typeof item === "boolean") return true;
    if (typeof item === "number") return Number.isFinite(item);
    if (typeof item === "string") return item.length <= 32768;
    if (Array.isArray(item)) return item.length <= 256 && item.every((child) => visit(child, depth + 1));
    return plain(item) && Object.keys(item).length <= 128 && Object.entries(item).every(([key, child]) => key.length <= 128 && !["__proto__", "constructor", "prototype"].includes(key) && visit(child, depth + 1));
  };
  return visit(value, 0) && Buffer.byteLength(JSON.stringify(value)) <= EXTENSION_MAX_BYTES;
}
function validManifest(value) {
  if (!plain(value) || !exact(value, ["schemaVersion", "extensionId", "version", "source", "sourceHash", "license", "licenseHash", "artifactId", "hooks"])) return false;
  return value.schemaVersion === 1 && typeof value.extensionId === "string" && /^[a-z][a-z0-9_.-]{0,79}$/u.test(value.extensionId) && typeof value.version === "string" && /^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9.-]+)?$/u.test(value.version) && typeof value.source === "string" && value.source.length <= 2048 && validSource(value.source) && typeof value.sourceHash === "string" && /^[a-f0-9]{64}$/u.test(value.sourceHash) && typeof value.licenseHash === "string" && /^[a-f0-9]{64}$/u.test(value.licenseHash) && typeof value.artifactId === "string" && /^[a-f0-9]{64}$/u.test(value.artifactId) && typeof value.license === "string" && /^[A-Za-z0-9 .+()-]{1,100}$/u.test(value.license) && value.license.trim() === value.license && Array.isArray(value.hooks) && value.hooks.length > 0 && value.hooks.length <= EXTENSION_HOOKS.length && new Set(value.hooks).size === value.hooks.length && value.hooks.every((hook) => EXTENSION_HOOKS.includes(hook));
}
function validSource(value) {
  try {
    const source = new URL(value);
    return source.protocol === "https:" && !source.username && !source.password && !source.hash;
  } catch {
    return false;
  }
}
function validView(value) {
  return plain(value) && exact(value, ["schemaVersion", "extensionId", "revision", "enabled", "activeVersion", "versions"]) && value.schemaVersion === 1 && typeof value.extensionId === "string" && /^[a-z][a-z0-9_.-]{0,79}$/u.test(value.extensionId) && typeof value.revision === "number" && Number.isSafeInteger(value.revision) && value.revision >= 0 && typeof value.enabled === "boolean" && Array.isArray(value.versions) && value.versions.length <= 64 && new Set(value.versions.map((item) => item?.manifest?.version)).size === value.versions.length && value.versions.every((item) => plain(item) && exact(item, ["manifest", "healthAt", "revokedAt"]) && validManifest(item.manifest) && item.manifest.extensionId === value.extensionId && typeof item.healthAt === "string" && Number.isFinite(Date.parse(item.healthAt)) && (item.revokedAt === null || typeof item.revokedAt === "string" && Number.isFinite(Date.parse(item.revokedAt)))) && (value.activeVersion === null || value.versions.some((item) => item.manifest.version === value.activeVersion && item.revokedAt === null)) && (!value.enabled || value.activeVersion !== null);
}

// src/main/xiaozhi-agent/extensions/rpc.ts
var logCodes = ["started", "health_ready", "hook_started", "hook_completed", "hook_failed", "stopping"];
function createExtensionRpc(transport, options) {
  const pending = /* @__PURE__ */ new Map();
  const entries = [];
  const unsubscribers = [];
  let closing;
  let stopped = false;
  let failure = "extension_closed";
  let windowStart = Date.now(), sent = 0, received = 0;
  const count = (direction) => {
    if (Date.now() - windowStart >= 1e3) {
      windowStart = Date.now();
      sent = 0;
      received = 0;
    }
    if (direction === "send" ? ++sent > 32 : ++received > 64) throw Error("extension_rate_limit");
  };
  const settle = () => {
    stopped = true;
    for (const item of pending.values()) item.reject(Error(failure));
    pending.clear();
  };
  const close = (code = "extension_closed") => {
    if (!closing) {
      failure = code;
      settle();
      closing = transport.close().finally(() => {
        options.signal.removeEventListener("abort", onAbort);
        for (const unsubscribe of unsubscribers) unsubscribe();
      });
    }
    return closing;
  };
  const onAbort = () => {
    void close("extension_cancelled").catch(() => void 0);
  };
  const fail = (code) => {
    void close(code).catch(() => void 0);
  };
  unsubscribers.push(transport.onMessage((message) => {
    try {
      count("receive");
      if (!boundedJson(message)) throw Error("extension_message_limit");
      const value = message;
      if (value.jsonrpc !== "2.0") throw Error("extension_protocol");
      if ("method" in value) {
        if ("id" in value) {
          if (!exact(value, ["jsonrpc", "id", "method", "params"]) || typeof value.method !== "string" || typeof value.id !== "string" && typeof value.id !== "number") throw Error("extension_protocol");
          void transport.send({
            jsonrpc: "2.0",
            id: value.id,
            error: { code: -32601, message: "unsupported_host_method" }
          }).catch(() => fail("extension_protocol"));
          return;
        }
        const params = value.params;
        if (!exact(value, ["jsonrpc", "method", "params"]) || value.method !== "extensions/log" || !plain(params) || !exact(params, ["schemaVersion", "level", "code"]) || params.schemaVersion !== 1 || !["info", "warn", "error"].includes(String(params.level)) || typeof params.code !== "string" || !logCodes.includes(params.code)) throw Error("extension_protocol");
        entries.push({ schemaVersion: 1, level: params.level, code: params.code, at: (/* @__PURE__ */ new Date()).toISOString() });
        if (entries.length > 64) entries.shift();
        return;
      }
      if (!exact(value, ["jsonrpc", "id", "error" in value ? "error" : "result"])) throw Error("extension_protocol");
      if ("error" in value && (!plain(value.error) || !exact(value.error, ["code", "message"]) || !Number.isSafeInteger(value.error.code) || typeof value.error.message !== "string")) throw Error("extension_protocol");
      if (typeof value.id !== "string" || !pending.has(value.id)) throw Error("extension_response_id");
      const item = pending.get(value.id);
      if ("error" in value) item.reject(Error("extension_guest_error"));
      else item.resolve(value.result);
      pending.delete(value.id);
    } catch (error) {
      fail(error instanceof Error ? error.message : "extension_protocol");
    }
  }));
  unsubscribers.push(transport.onError(() => fail("extension_transport")));
  unsubscribers.push(transport.onClose(() => {
    settle();
  }));
  options.signal.addEventListener("abort", onAbort, { once: true });
  return {
    async start() {
      options.signal.throwIfAborted();
      try {
        await transport.start();
      } catch (error) {
        await close("extension_start_failed");
        throw error;
      }
    },
    async request(method, params, signal) {
      if (stopped) throw Error(failure);
      if (!boundedJson(params)) throw Error("extension_message_limit");
      await options.assert();
      if (stopped) throw Error(failure);
      if (pending.size >= 4) throw Error("extension_busy");
      count("send");
      if (signal?.aborted) {
        await close("extension_cancelled");
        throw Error("extension_cancelled");
      }
      const id = "extension_" + randomUUID();
      let resolve, reject;
      const result = new Promise((success, failed) => {
        resolve = success;
        reject = failed;
      });
      pending.set(id, { resolve, reject });
      const cancel = () => fail("extension_cancelled");
      signal?.addEventListener("abort", cancel, { once: true });
      if (signal?.aborted) cancel();
      const timer = setTimeout(() => fail("extension_timeout"), options.timeoutMs);
      timer.unref();
      const settled = result.then((value) => ({ value }), (error) => ({ error }));
      try {
        await transport.send({ jsonrpc: "2.0", id, method, params });
        const outcome = await settled;
        if ("error" in outcome) throw outcome.error;
        await options.assert();
        return outcome.value;
      } catch (error) {
        await close(error instanceof Error && /^extension_[a-z_]+$/u.test(error.message) ? error.message : "extension_transport");
        throw error;
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", cancel);
        pending.delete(id);
      }
    },
    logs: () => structuredClone(entries),
    close: () => close()
  };
}
export {
  boundedJson,
  createExtensionRpc,
  validManifest,
  validView
};
