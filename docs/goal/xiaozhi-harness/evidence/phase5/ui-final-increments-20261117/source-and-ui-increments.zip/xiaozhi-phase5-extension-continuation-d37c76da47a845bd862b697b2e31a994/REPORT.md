# Phase5 Extension continuation repair

## Result and reproduced user-path defects

PASS for the bounded component repair. Two new deferred-bridge groups first reproduced both reported lifecycle gaps. After prepare returned permission_pending and main projection stayed needs_approval, an externally granted permission left the retry control disabled and an idle cancel control visible. When package phase advanced to prepared but the local prepare promise still awaited install/select health, cancellation disappeared. The original before-report.json preserves both actual observations and 0/2 failures.

PiExtensionSettings changes exactly two expressions. Cancellation availability now follows the artifact's locally pending preparingId or projected preparing phase. needs_approval labels its available prepare action as retry. Existing pending/task/revoked gates still apply. A completed needs_approval attempt therefore offers retry with the current artifact revision and task context. A locally pending attempt keeps cancellation reachable across package-phase changes. The UI continues to send main's exact artifact revision. Main remains the authority for the package, approval, health and cancellation facts.

## Actual commands and evidence

Working directory D:/WorkProject/EduProject-harness/apps/desktop.

- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs --extension-continuation-only
- Before repair exit 1 with 0/2. Original C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-uOCAnz/report.json is retained as before-report.json and before.log.
- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs
- After repair exit 0 with 30/30. Original C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-cQdU4z/report.json is retained as after-report.json and after.log.
- git diff --check -- followed by the nine frozen source paths returned 0. Exact output is in diff-check.log.

The existing28 groups run with the new two groups. The prior needs_approval assertion was updated to require a retry action and absence of idle cancellation, matching the released lifecycle. All picker waits longer than 10 seconds, prepare ordering, session/unmount and MCP Secret groups still pass in the same run. The first new group preserves phase needs_approval across an external permission flag change, then sends retry revision4 and accepts the returned prepared state. The second projects phase prepared while prepare remains pending, cancels revision6, and checks that the late earlier prepare response cannot overwrite cancelled.

Before observations are [{"case":"returned_needs_approval_after_grant","phase":"needs_approval","retryDisabled":true,"retryLabel":"准备扩展","cancelVisible":true},{"case":"prepared_while_health_pending","phase":"prepared","cancelVisible":false}].

After observations are [{"case":"returned_needs_approval_after_grant","phase":"needs_approval","retryDisabled":false,"retryLabel":"重试准备","cancelVisible":false},{"case":"prepared_while_health_pending","phase":"prepared","cancelVisible":true,"cancelDisabled":false}].

## Source freeze and rollback

Only PiExtensionSettings.tsx and the dedicated component test changed from the previous28 candidate. The other seven source SHA256 values remain identical. The full nine-file source snapshot and hashes are in freeze.json and source-snapshot. previous-freeze.json preserves the28 candidate. PiExtensionSettings-before.tsx and component-test-before.mjs preserve the two exact starting files. No shared, main, preload, out, schema, dependency or data migration changed.

Changed source SHA256 values follow.

- apps/desktop/src/renderer/components/office/PiExtensionSettings.tsx = 6a1083e2a7e08a8edda7a0d3faed01f61a636f554d77529942dbc6abef1adacb
- apps/desktop/scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs = a1a71678a39920df41da4371291c82682594cc3173518d1b796a617a5c0e65dc

Rollback restores the two before files into their original paths. Preserve the preceding Extension, picker-wait, MCP Secret and collaborator work.

## Verification boundary

NOT_RUN for full-source TypeScript checking, build, actual Electron UI, native picker, real Scope grants, isolated package install/select health, persisted readback/restart, models/providers, keyboard/viewport and performance comparison. This suite mounts actual React/HeroUI components in JSDOM using synthetic deferred typed bridge responses. Core/root own the final integrated gates. The external permission flag in the fixture simulates the released main behavior that a grant leaves the package phase unchanged. The renderer adds no new permission or business revision source.
