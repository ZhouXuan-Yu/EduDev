# Phase5 Extension UI delivery

## Result and bounded implementation

PASS for component delivery. The managed-tools settings entry now includes PiExtensionSettings. The optional extensions field is compatible with views created before this field. Main remains the authority for all projected artifacts, preparation phases, selection revisions, enabled/active/revoked state and errors.

The original acquisition session/request lifecycle was extracted into adjacent usePiAcquisition. Both settings components reuse visible foreground polling, a real single-flight read lease, bounded read/short-control waiting, long prepare IPC with polling and safe controls, task context checks, and the fixed later-action precedence. Search text remains local to PiAcquisitionSettings. The original 20 checks continue passing after extraction.

Extension import sends only action and sessionId to the main picker. Prepare/cancel send artifactId and artifact revision. Select/disable/revoke send extensionId, version and selectionRevision. Core confirmed these exact semantics. Prepare/select require main context. Import/cancel/disable/revoke can be used idle. A prepared but disabled version retains retry-prepare to handle the released approval boundary. Selecting any prepared existing version supplies update or rollback through the real extension_select action. Revoked versions remain visibly revoked and unavailable for selection.

The UI shows local import, unknown trust, license, real phase and current enabled/version state. Source SHA, directory fingerprint and declared hooks are behind the existing DisclosureCard. The supported-hook explanation names context.transform and event.observe. The component uses returned main errors through ACQUISITION_ERRORS. Source trust remains unknown.

## Actual commands and results

Working directory D:/WorkProject/EduProject-harness/apps/desktop.

- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs --extension-only
- Initial expected red exit 1 with 0/7. Raw original report C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-7tMVJH\report.json is copied as before-report.json. Raw before.log is retained.
- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs
- First full run exit 0 with 27/27 at C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-AvIg8n\report.json. This remains as first-27-pass-report.json and first-27-pass.log. Source review then added two optional-view null guards.
- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs
- Final full run exit 0 with 27/27 at C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-8J3Un6\report.json. This matches frozen final sources and remains as final-report.json and final.log.
- git diff --check -- followed by the nine frozen paths returned 0. Exact output is in diff-check.log.

Seven Extension regression groups run through the actual PiManagedTools parent entry. They cover legacy optional-field compatibility and idle picker payload, unknown local metadata and both hooks, long prepare polling and idle revision-correct cancellation, pending cancel conflict precedence over an old prepare, selecting a previously prepared older version plus idle disable/revoke with selectionRevision, permission/retry failures, and old-session/unmount response fencing. Deferred synthetic bridges drive exact payload assertions and actual React/HeroUI controls in JSDOM.

The prior ordering failure 0/2 and repair 14/14, followed by Secret 0/6 and 20/20, remain preserved in their earlier directories. previous-freeze.json records the accepted Secret candidate. This directory also retains the exact three starting source files for this increment.

## Sources and stable controls

This increment changes PiManagedTools.tsx, PiAcquisitionSettings.tsx and the dedicated phase5-acquisition-renderer-smoke.mjs, and adds PiExtensionSettings.tsx plus usePiAcquisition.ts. Nine-file SHA256 freeze and full snapshots are in freeze.json and source-snapshot. PiMcpSettings, PiMcpCredential, PiEnvironmentSettings and PiSettingsWorkspace retain their prior source SHA256 values. No dependencies or migrations were introduced.

- pi-extensions identifies the Extension section.
- pi-extension-import and pi-extension-refresh identify global actions.
- pi-extension-<artifactId> exposes data-phase for the projected artifact.
- pi-extension-prepare/cancel/select/disable/revoke-<artifactId> identify actual controls.
- pi-extension-details-<artifactId> is the progressive source/hook information disclosure.
- pi-extension-empty and pi-extension-notice identify empty and mapped-error states.

## Unverified boundaries

NOT_RUN for full-source TypeScript check, build, Electron page interaction, actual OS folder picker, package installation, long-lived isolated processes, persisted readback/restart, real permission grants, real models or provider requests, keyboard/viewport layout and performance before/after. These belong to the coordinated integration and actual UI gates. The local test bridge uses synthetic data. Core's separately reported Host or package tests remain separate evidence.

Selection rollback uses the existing prepared-version selection API. The UI offers available versions based on returned state. It creates no secondary Task, install, permission or extension state source. The hook retains only the selected-session view and renderer-observed request ordering.

## Rollback

Restore PiAcquisitionSettings-before.tsx, PiManagedTools-before.tsx and component-test-before.mjs into their original paths, then remove only PiExtensionSettings.tsx and usePiAcquisition.ts added by this increment. Preserve the prior MCP Secret delivery and all collaborator changes. SQLite/shared/main/preload/out require no rollback for this renderer increment.
