# Phase5 native picker result wait repair

## Reproduced defect and minimal repair

PASS for the bounded repair and component regression. The original extension_import shared the 10-second bounded accept path. The delayed actual bridge result showed that success, main picker cancellation and typed import error all produced an early unavailable notice and released the renderer mutation lock. A subsequently returned quarantined artifact remained absent. All three raw observations are preserved in before-report.json.

Only extension_import now passes waitForActualResult to the existing accept helper. Its mutation lock remains held until the actual main result settles. Existing session/request guards, typed error mapping and successful-view acceptance apply to that returned result. Main picker cancellation returns a successful unchanged view. The UI consumes that result. Read and short-control deadlines retain their existing behavior. The long prepare branch retains its existing pipeline waiting and visible polling/cancellation.

## Actual commands and observations

Working directory D:/WorkProject/EduProject-harness/apps/desktop.

- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs --picker-wait-only
- Before repair exit 1 with 0/1. Original C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-baj8C7/report.json is preserved as before-report.json with before.log.
- node scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs
- After repair exit 0 with 28/28. Original C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase5-acquisition-renderer-u2B9Pf/report.json is preserved as after-report.json with after.log.
- git diff --check -- followed by the nine frozen UI/test paths returned 0. Exact output is in diff-check.log.

The new single regression group uses actual renderer 10-second deadline timers and Node performance.now monotonic elapsed time. Success, cancellation and typed failure each remain pending for more than 10 seconds. It checks the disabled import control, one bridge mutation, absence of a premature notice, lock release after actual completion, and the actual returned artifact or mapped error. It also checks old-session success and post-unmount typed failure fencing. All original27 checks run in the same final suite.

Before observations are [{"outcome":"success","elapsedMs":10182.781,"locked":false,"notice":"当前能力管理尚不可用。","calls":1,"finalLocked":false,"finalNotice":"当前能力管理尚不可用。","imported":false},{"outcome":"cancel","elapsedMs":10167.5459,"locked":false,"notice":"当前能力管理尚不可用。","calls":1,"finalLocked":false,"finalNotice":"当前能力管理尚不可用。","imported":false},{"outcome":"error","elapsedMs":10169.995199999998,"locked":false,"notice":"当前能力管理尚不可用。","calls":1,"finalLocked":false,"finalNotice":"当前能力管理尚不可用。","imported":false},{"sessionSafe":true,"unmountSafe":true}].

After observations are [{"outcome":"success","elapsedMs":10174.831,"locked":true,"notice":"","calls":1,"finalLocked":false,"finalNotice":"","imported":true},{"outcome":"cancel","elapsedMs":10173.321399999997,"locked":true,"notice":"","calls":1,"finalLocked":false,"finalNotice":"","imported":false},{"outcome":"error","elapsedMs":10179.612700000005,"locked":true,"notice":"","calls":1,"finalLocked":false,"finalNotice":"扩展包不符合导入合同。","imported":false},{"sessionSafe":true,"unmountSafe":true}].

## Source freeze and scope

Only usePiAcquisition.ts and the dedicated phase5-acquisition-renderer-smoke.mjs changed from the previous27 candidate. Complete SHA256 values for all nine delivery files are in freeze.json with source-snapshot copies. previous-freeze.json preserves the previous candidate. usePiAcquisition-before.ts and component-test-before.mjs preserve the two exact starting files.

Changed source SHA256 values follow.

- apps/desktop/src/renderer/components/office/usePiAcquisition.ts = f5ed63504f596e78d0a7b21a6fd61ac9b34c43b37f9c1a306374375ac2d18d01
- apps/desktop/scripts/xiaozhi-agent/phase5-acquisition-renderer-smoke.mjs = 998cb952ed98e56553b573b7849832245e1421a3c0d9a869efb2c96a45d28177

No business revision, data migration or dependency was added. The renderer continues to retain only observed request order and the returned main view.

## Unverified boundaries and rollback

NOT_RUN for actual native picker, static package import, full-source TypeScript checking, build, Electron interaction, persisted readback, package execution, models/providers, viewport/keyboard behavior or performance comparison. The deferred typed bridge and actual React/HeroUI components in JSDOM establish this renderer timing regression. Core/root retain the integrated real-path gates.

Rollback restores only usePiAcquisition-before.ts and component-test-before.mjs into their original paths. Preserve the existing Extension, MCP Secret, other UI delivery and collaborator changes. No main/shared/preload/out rollback is required for this renderer change.
