# Fixed four Host recovery chains

2026-11-18. Only phase6-recovery-host-parent.mjs/worker.ts and owned TEMP. Script preparation and Node syntax checks precede an explicit core runtime window and refreshed core manifest.

One Electron/OmniEduStore/Host sample first answers through loopback Pi, then selects the already-selected model through the public versioned API. A new Task uses the actual foreground exec_command to create one owned workspace file. Its next model HTTP request waits after the tool response. The parent independently reads active Task, committed Effect and exact artifact hash before real SIGKILL.

Four cases restore one immutable golden snapshot at the same explicitly owned activeRoot. This preserves persisted absolute references without modifying business ledgers. Every case keeps independent before/after copies and file manifests. The cases are available JSONL normal resume, exact missing JSONL rebuild, legal header.id-only change rebuild, and native-binding INSERT trigger rollback followed by explicit retry. Cold runs require zero model POSTs and zero observed Node child-process entry calls, with unchanged business artifact. The failed-trigger case records actual failed and retry Run counts separately.

All keys and model responses are synthetic. Electron net.fetch accepts only the official model origin and redirects it to this fixture's loopback server. Source fixes belong to core. Original failures remain immutable evidence. This leaf never edits production or invokes the core manifest builder.
