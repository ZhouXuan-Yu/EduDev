# Independent Gate6 audit contract

Status PREFREEZE_READONLY. Production/source/preload/dependency/out writes 0. Build, Electron, native, and test executions 0. Runtime awaits root release. Baseline HEAD 0f753e572cbdfa20eaaf130a0f7b23d32e8ac2b8 plus Phase6 WIP.

## Frozen acceptance scope

The original T-01 through T-14, H-16, Phase6 T6.1 through T6.6 and existing PTY/background contract apply. The original 89-item project matrix remains unchanged. This review can establish ACCEPTED_SCOPED_PHASE6 after final source/output/runtime identity and evidence inspection. Phase7 actual page acceptance and Phase8 overall acceptance remain separately owned stages.

## Independent source traces

- Task checkpoint and crash recovery use original tasks/task-state, events/journal and publisher transaction lane. startup-recovery settles prior Task before retiring old owner. Checkpoint references persisted original Task, Effect, snapshots, approvals and remaining budget.
- Side-effect Tool admission routes through effects/journal Intent before execution, binds execution, and resolves only through actual readback. effects/state verifies owner/generation/Task authority and optimistic revision.
- Network broker receipts use effects/network and owned durable receipt files. Unknown receipt failure preserves state, explicit recheck reads receipt without HTTP replay.
- terminal/service -> lifecycle -> original permission engine runJob/openPermissionLease -> projection -> controlled-backend -> same native helper. Original Run completion releases controller to teacher. Job-specific authority persists only for admitted Job lifetime.
- terminal/input reserves command Intent and sequence in original Sql transaction, checks controller/lease before dispatch, persists exact helper ACK, and returns prior command facts for duplicate ID. Input/output cursor changes remain separate from business/controller/lease CAS.
- typed preload and allowed main IPC route teacher actions. Renderer supplies IDs and CAS fields, main derives all execution authority.
- Task coordinator beforeCompletion invokes terminalService.closeTask before independent result recheck and original teacher review checkpoint. This seam requires actual final-source teacher-review evidence.

## Evidence reuse and affected checks

1. Match final source, compiled output, helper recipe/artifact and dependency identities. Compare later test end identities. Any source change requires bounded impacted evidence review.
2. Reuse source-matched state8, ConPTY native9+protocol12, terminalUI9, Hostterminal9, Provider12, inspector13, network8+actualHTTP7, workflowHost5, TaskRecoveryUI10. Preserve failures and retain each suite's actual source identity and proof boundary.
3. Independently examine and, after release, run the needed final-source RecoveryHost H1-H4 consolidated checks. Same Task/new Run/generation, two cold openings, unchanged artifact, no model/process/business replay. H04 explicitly permits original refreshRecords plus retry and records two Runs.
4. Independently check Job parent Electron SIGKILL and second cold launch, exact ACK durable/Effect commit failure reconciliation, duplicate command send count zero, and original reviewTask completion -> closeTask cleanup. These are in-progress fixed negative cases.
5. Review genuine renderer integration at 1366x768 and 1920x1080 for terminal input/stop/resize and existing Task planning/recovery/approval actions. Real paid-model quality remains Phase8.
6. Inspect root centralized build, renderer components, relevant legacy/module regressions and git diff --check evidence. Avoid rerunning every source-matched leaf suite.
7. Keep paid requests 0. All model/network fixtures in this stage use owned loopback and synthetic workspace.

## Preliminary observations

No confirmed P0/P1 at this prefreeze point. Candidate bounded-history issue sent to root. terminal/job-state:list orders oldest first LIMIT256. All service list consumers can omit a newer live Job after 256 historical Jobs in one session. Global entries16 still caps launch inventory. This is a source-only observation pending owner decision, with no new fixed acceptance requirement.

## Required final report fields

ID, PASS/FAIL/BLOCKED/NOT_TESTED, exact source/output/runtime, command and exit code, expected/actual, SQLite/file proof, original failure references, paid request count, owned PID/profile/ACE/Job inventory, evidence limits, unresolved findings and rollback reference. Acceptance remains NOT_TESTED until authorized final-source verification finishes.

## Authorized pure Sql original counterexample

Root released only the prepared pure Sql counterexample. Command D:/Node/node.exe job-list-boundary.mjs --original executed against exact saved original job-state SHA8543fb68904d3ef5e7dcfca819e54c7d70230887dbc1957aac401e46aac3659c. JLIST01 FAIL, exit1, rows257 with 256 completed and one running, list length256 omitted liveId. Evidence original-ErzjzS/report.json. First fixture attempt original-vmCcIF/report.json failed before assertions because its referenced Effect table had not been created. The owned fixture was corrected to create and seed the FK target table. Both original reports remain. No Electron/native/helper/build/model/production state writes occurred. Candidate green and all actual runtime checks await release.
