# Persisted ACK product-entry trace

Read-only follow-up. No source/test/runtime change. Original 7sHl0t four PASS and low-level explicit reconciler proof remain intact.

- readXiaozhiTerminal -> terminal/service.ts50-55 -> input.readAck157-159 only returns derived ACK. It does not transition unknown Effect.
- duplicate write -> input.ts91-94 returns original Effect ACK without another physical send or Effect settlement.
- Teacher reviewTask -> tasks/coordinator.ts138-144 -> original beforeCompletion -> terminal/service.ts102-107 closeTask. pendingCompletion rejects unresolved Job-bound Effects. No Effect reconciler call exists on this path.
- refreshRecords only repairs failed event-journal persistence and Task state. It does not reconcile Job input Effects.
- Existing user continuation is a real reconciliation entry. production-host.ts1843-1848 recognizes taskResume/explicit continueTask or continuation text when Task is not active, then calls original effectReconciler.recheck before new Run/model execution. effects/reconcile.ts28-31 validates durable acknowledged_input_sequence before rejecting a live Job, then recheck65-86 transitions unknown to reconciled using original recovery authority. tasks/coordinator.ts65-86 permits explicit same-Task continuation from review_required, paused or interrupted.

The existing Host.start({...continueTask:{taskId,requirementsVersion},prompt:...}) path can replace the low-level exported call using a synthetic answer with no tools. That path necessarily starts a new Run/model request. It must record the added loopback model POST and cannot claim zero new model requests. A direct Teacher read/duplicate zero-model path currently does not reconcile the Effect. Runtime validation of this follow-up is pending core/root direction.
