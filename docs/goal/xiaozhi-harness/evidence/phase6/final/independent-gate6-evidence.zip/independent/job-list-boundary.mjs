import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {randomUUID, createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {registerHooks} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';

const desktop = 'D:/WorkProject/EduProject-harness/apps/desktop';
const audit = path.dirname(fileURLToPath(import.meta.url));
const original = process.argv.includes('--original');
const source = path.join(desktop, 'src/main/xiaozhi-agent/terminal/job-state.ts');
const snapshot = path.join(audit, 'job-state-original.ts');
await import(pathToFileURL(path.join(desktop, 'scripts/office-agent/register-source.mjs')).href);
registerHooks({resolve(specifier, context, next) {
  const mapped = context.parentURL === pathToFileURL(snapshot).href && specifier.startsWith('.')
    ? {...context, parentURL: pathToFileURL(source).href} : context;
  return next(specifier, mapped);
}});
const importedSource = original ? snapshot : source;
const {createTerminalJobState} = await import(pathToFileURL(importedSource).href);
const stamp = new Date().toISOString();
const digest = value => createHash('sha256').update(value).digest('hex');
const sessionId = 'aisession_' + randomUUID();
const taskId = 'task_' + randomUUID();
const owner = {sessionId, taskId, runId: 'run_' + randomUUID(), generation: 1};
const report = {success: false, original, source: importedSource,
  sha256: digest(fs.readFileSync(importedSource)), paidCalls: 0, checks: [],
  boundary: 'Pure original Job Sql list with owned synthetic SQLite. No Electron, helper, PTY, model, projection, production data or user-flow acceptance.'};
const runRoot = fs.mkdtempSync(path.join(audit, original ? 'original-' : 'candidate-'));
const db = new DatabaseSync(path.join(runRoot, 'owned.sqlite'));
const sql = {
  all: async (query, values = []) => db.prepare(query).all(...values),
  run: async (query, values = []) => db.prepare(query).run(...values),
  change: async (query, values = []) => Number(db.prepare(query).run(...values).changes),
  async transaction(action) {
    db.exec('BEGIN IMMEDIATE');
    try {const result = await action(sql); db.exec('COMMIT'); return result;}
    catch (error) {db.exec('ROLLBACK'); throw error;}
  },
};
const jobs = createTerminalJobState(sql);
async function check(id, action) {
  try {await action(); report.checks.push({id, pass: true});}
  catch (error) {report.checks.push({id, pass: false, error: String(error.stack || error)});}
}
try {
  db.exec('CREATE TABLE xiaozhi_effects_v1(effect_id TEXT PRIMARY KEY)');
  await jobs.migrate();
  const insert = db.prepare(`INSERT INTO xiaozhi_jobs_v1(job_id,session_id,task_id,origin_run_id,call_id,effect_id,
    revision,controller_revision,lease_revision,state,document_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  function seed(state, ordinal, alternateTask = taskId) {
    const jobId = 'term_' + randomUUID();
    const identity = {...owner, taskId: alternateTask};
    const callId = 'call_' + randomUUID();
    const createdAt = new Date(Date.UTC(2026, 0, 1, 0, 0, ordinal)).toISOString();
    const request = {schemaVersion: 2, owner: identity, requirementsVersion: 1, callId, action: 'exec_command',
      inputDigest: digest('owned-input'), purpose: 'Owned Sql regression',
      scopes: [{kind: 'filesystem', root: runRoot, identity: digest('owned-root'), actions: ['read','write']}],
      files: [], provider: null, classification: 'public', expiresAt: new Date(Date.now()+3600000).toISOString()};
    const doc = {schemaVersion: 1, jobId, sessionId, taskId: alternateTask, revision: 1, controllerRevision: 1, leaseRevision: 1,
      origin: identity, callId, effectId: 'effect_' + ordinal, contract: {}, controller: {kind:'teacher'}, request, decision: {},
      runtime: {version:'synthetic',directory:runRoot,helperHash:digest('no-helper')},
      projection: {executionId:'xiexec_'+randomUUID(),root:runRoot,cwd:runRoot,originalRoot:runRoot},
      command:'synthetic',cwd:runRoot,state,tty:true,background:true,createdAt,updatedAt:stamp,expiresAt:request.expiresAt,
      inputClosed:state==='completed',cleanup:state==='completed'?'complete':'pending',committed:[],projectionState:'pending'};
    db.prepare('INSERT INTO xiaozhi_effects_v1(effect_id) VALUES(?)').run(doc.effectId);
    insert.run(jobId,sessionId,alternateTask,identity.runId,callId,doc.effectId,1,1,1,state,JSON.stringify(doc),createdAt,stamp);
    return jobId;
  }
  for(let i=0;i<256;i++)seed('completed',i);
  const liveId=seed('running',256);
  await check('JLIST01',async()=>{
    const list=await jobs.list(sessionId);
    report.presentationIds=list.map(record=>record.document.jobId);
    assert(list.some(record=>record.document.jobId===liveId),'New live Job must survive bounded presentation listing after 256 historical Jobs');
  });
  if (!original) {
    await check('JLIST02', async () => {
      const active = await jobs.active(sessionId);
      assert.deepEqual(active.map(record => record.document.jobId), [liveId]);
    });
    const otherTask = 'task_' + randomUUID();
    for(let i=257;i<513;i++)seed('completed',i,otherTask);
    await check('JLIST03', async () => {
      const filtered = await jobs.list(sessionId,taskId);
      assert.equal(filtered.length,256);
      assert(filtered.every(record=>record.document.taskId===taskId));
      assert(filtered.some(record=>record.document.jobId===liveId));
    });
    await check('JLIST04', async () => {
      assert.deepEqual(await jobs.active(sessionId,otherTask),[]);
      assert.deepEqual((await jobs.active(sessionId,taskId)).map(record=>record.document.jobId),[liveId]);
    });
    await check('JLIST05', async () => {
      assert.deepEqual(await jobs.active('aisession_'+randomUUID()),[]);
    });
    await check('JLIST06', async () => {
      const syntheticLive = [];
      for(let i=513;i<769;i++)syntheticLive.push(seed('running',i));
      const active = await jobs.active(sessionId,taskId);
      assert.equal(active.length,257);
      assert(active.some(record=>record.document.jobId===liveId));
      assert(syntheticLive.every(id=>active.some(record=>record.document.jobId===id)));
      report.authorityQueryBoundary='257 synthetic live rows test unbounded Sql inventory. Product admission caps and actual PTY launch are outside this pure Sql fixture.';
    });
  }
  report.rows=Number(db.prepare('SELECT count(*) AS n FROM xiaozhi_jobs_v1').get().n);
  report.liveId=liveId;
  report.success=report.checks.length>0&&report.checks.every(check=>check.pass);
} catch(error) {report.error=String(error.stack||error);}
finally {
  report.finalSourceSha256=digest(fs.readFileSync(importedSource));
  report.sourceDrift=report.finalSourceSha256!==report.sha256;
  report.success=report.success&&!report.sourceDrift;
  db.close();
  fs.writeFileSync(path.join(runRoot,'report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({root:runRoot,success:report.success,checks:report.checks.map(({id,pass})=>({id,pass}))}));
  process.exitCode=report.success?0:1;
}



