import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const repo='D:/WorkProject/EduProject-harness';
const desktop=path.join(repo,'apps/desktop');
const owned=path.dirname(fileURLToPath(import.meta.url));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const freezePath=path.join(repo,'evidence/phase6/implementation-final-20261118/freeze.json');
const freeze=JSON.parse(fs.readFileSync(freezePath,'utf8'));
const report={time:new Date().toISOString(),freezeSha256:sha(fs.readFileSync(freezePath)),groups:{},dependencies:[],differences:[]};
for(const group of ['production','tests','verificationScripts','outputs']){
 const rows=freeze[group];const checked=rows.map(row=>{
  const filename=path.join(repo,row.path);
  try {const stat=fs.lstatSync(filename),hash=sha(fs.readFileSync(filename));
   if(!stat.isFile()||stat.size!==row.bytes||hash!==row.sha256)report.differences.push({group,...row,actualBytes:stat.size,actualHash:hash});
   return {path:row.path,bytes:stat.size,sha256:hash};
  }catch(error){report.differences.push({group,path:row.path,error:String(error)});return {path:row.path,missing:true};}
 });report.groups[group]={count:checked.length,listHash:sha(JSON.stringify(checked)),files:checked};
}
const outFiles=[];
function walk(directory){for(const entry of fs.readdirSync(directory,{withFileTypes:true})){const file=path.join(directory,entry.name);if(entry.isDirectory())walk(file);else outFiles.push(path.relative(repo,file).replaceAll('\\','/'));}}
walk(path.join(desktop,'out'));
const expected=new Set(freeze.outputs.map(row=>row.path.replaceAll('\\','/')));
report.extraOutputs=outFiles.filter(file=>!expected.has(file));
const pkg=JSON.parse(fs.readFileSync(path.join(desktop,'package.json'),'utf8'));
for(const name of Object.keys({...pkg.dependencies,...pkg.devDependencies}).sort()){
 const file=path.join(desktop,'node_modules',name,'package.json');
 try{const bytes=fs.readFileSync(file),value=JSON.parse(bytes);report.dependencies.push({name,version:value.version,file,sha256:sha(bytes)});}
 catch(error){report.dependencies.push({name,error:String(error)});}
}
const installedLock=path.join(desktop,'node_modules/.package-lock.json');
if(fs.existsSync(installedLock))report.installedLock={file:installedLock,sha256:sha(fs.readFileSync(installedLock))};
report.success=report.freezeSha256==='31b80e2afff5831b39d9ce0d4ad6e59e53dfd4c5da492ee964eb5b637d9a6c85'&&!report.differences.length&&!report.extraOutputs.length;
const phase=process.argv[2]||'before';const target=path.join(owned,'final-identities-'+phase+'.json');
fs.writeFileSync(target,JSON.stringify(report,null,2));
console.log(JSON.stringify({file:target,success:report.success,freezeSha256:report.freezeSha256,counts:Object.fromEntries(Object.entries(report.groups).map(([key,value])=>[key,value.count])),dependencies:report.dependencies.length,differences:report.differences,extraOutputs:report.extraOutputs}));
process.exitCode=report.success?0:1;
