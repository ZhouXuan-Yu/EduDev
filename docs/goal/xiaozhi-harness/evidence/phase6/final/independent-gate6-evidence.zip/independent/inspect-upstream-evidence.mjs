import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const repo='D:/WorkProject/EduProject-harness',desktop=path.join(repo,'apps/desktop');
const directory=path.join(repo,'evidence/phase6/implementation-final-20261118');
const owned=path.dirname(fileURLToPath(import.meta.url));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const runs=read(path.join(directory,'RUNS.json'));
const references=read(path.join(directory,'LEAF_REFERENCES.json'));
const resolve=file=>path.isAbsolute(file)?file:file.startsWith('apps/')?path.join(repo,file):file.startsWith('src/')||file.startsWith('scripts/')||file.startsWith('package')?path.join(desktop,file):path.join(desktop,'src/main/xiaozhi-agent',file);
function identities(rows){return rows.map(row=>{const filename=resolve(row.file||row.path);let actual;try{actual=sha(fs.readFileSync(filename));}catch{}return{...row,actualSha256:actual,matches:actual===(row.sha256||row.hash)};});}
const report={time:new Date().toISOString(),runRecords:[],references:[],sourceReuse:[]};
for(const record of runs){
 const log=path.join(directory,'logs',record.log);
 const found={log:record.log,logMatches:sha(fs.readFileSync(log))===record.sha256};
 if(record.report){found.report=record.report.file;found.reportMatches=sha(fs.readFileSync(record.report.file))===record.report.sha256;
  if(record.summary?.success===true){const value=read(record.report.file);const rows=value.sources||value.sourcesBefore||[];
   report.sourceReuse.push({log:record.log,file:record.report.file,success:value.success,checks:value.checks?.length||record.summary.passed||record.summary.checks,sourceCount:rows.length,sourceComparisons:identities(rows)});}}
 report.runRecords.push(found);
}
for(const reference of references){const actual=sha(fs.readFileSync(reference.file));report.references.push({...reference,matches:actual===reference.sha256});
 if(reference.file.endsWith('report.json')){const value=read(reference.file);const rows=value.sources||[];report.sourceReuse.push({file:reference.file,success:value.success,checks:value.checks?.length,sourceCount:rows.length,sourceComparisons:identities(rows)});}}
const workflow=read('C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-workflow-host-evidence-mYVR7A/identity.json');
report.workflowManifestComparisons=identities(workflow.manifest.sources);
report.success=report.runRecords.every(row=>row.logMatches&&row.reportMatches!==false)&&report.references.every(row=>row.matches);
fs.writeFileSync(path.join(owned,'upstream-evidence-inspection.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({success:report.success,runRecords:report.runRecords.length,references:report.references.length,reuse:report.sourceReuse.map(row=>({log:row.log,file:row.file,checks:row.checks,sourceCount:row.sourceCount,changed:row.sourceComparisons.filter(item=>!item.matches).map(item=>item.file)})),workflowChanged:report.workflowManifestComparisons.filter(row=>!row.matches).map(row=>row.file)}));
process.exitCode=report.success?0:1;
