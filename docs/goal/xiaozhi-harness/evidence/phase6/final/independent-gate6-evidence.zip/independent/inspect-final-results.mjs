import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {fileURLToPath} from 'node:url';
const owned=path.dirname(fileURLToPath(import.meta.url));
const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
const before=read(path.join(owned,'final-identities-before.json'));
const after=read(path.join(owned,'final-identities-after.json'));
const report={success:false,paidCalls:0,checks:[],pids:[],databases:[],dependencyChanges:[]};
const recovery=read('C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-recovery-host-WdKYbR/report.json');
const job=read('C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-job-recovery-Y0dcu2/report.json');
const ui=read('C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-terminal-ui-evidence-vIr8BX/report.json');
const replan=read(path.join(owned,'final-replan-ITobE9/report.json'));
const pids=new Set();
function collect(value){if(!value||typeof value!=='object')return;for(const[key,item]of Object.entries(value)){if(['pid','helperPid','ProcessId'].includes(key)&&Number.isSafeInteger(item)&&item>0)pids.add(item);else collect(item);}}
collect(recovery);collect(job);
const paths=[{file:path.join(ui.root,'data/app.db'),label:'actual built terminal/Task UI'},
 {file:path.join(job.workers[0].activeRoot,'data/app.db'),label:'normal Host durable ACK and teacher review'}];
for(const item of paths){const db=new DatabaseSync(item.file,{readOnly:true});try{
 const jobs=db.prepare('SELECT * FROM xiaozhi_jobs_v1').all().map(row=>({...row,document:JSON.parse(row.document_json)}));
 const tasks=db.prepare("SELECT value_json FROM app_settings WHERE key LIKE 'xiaozhi.task.v1:xitask_%'").all().map(row=>JSON.parse(row.value_json).view);
 const effects=db.prepare('SELECT document_json FROM xiaozhi_effects_v1').all().map(row=>JSON.parse(row.document_json));
 const audits=db.prepare("SELECT kind,reference,metadata_json FROM xiaozhi_permission_audit_v1 WHERE kind='terminal_job_terminal'").all().map(row=>({...row,metadata:JSON.parse(row.metadata_json)}));
 assert(jobs.length>0&&jobs.every(row=>!['starting','running'].includes(row.state)&&row.document.cleanup==='complete'));
 assert(tasks.some(task=>task.state==='completed'));
 assert(audits.every(row=>row.metadata.result.cleanup.jobActiveProcesses===0&&row.metadata.result.cleanup.profileRemoved&&row.metadata.result.cleanup.remainingOwnedAces===0&&row.metadata.result.cleanup.ptyClosed));
 collect(jobs);
 report.databases.push({label:item.label,file:item.file,readOnly:true,jobs:jobs.map(row=>({jobId:row.job_id,state:row.state,cleanup:row.document.cleanup,projectionState:row.document.projectionState,inputSequence:row.input_sequence,acknowledgedInputSequence:row.acknowledged_input_sequence,projectionPresent:fs.existsSync(row.document.projection.root),pid:row.document.pid,helperPid:row.document.helperPid})),tasks:tasks.map(task=>({id:task.id,state:task.state,revision:task.revision})),effects:effects.map(effect=>({id:effect.id,state:effect.state,operation:effect.operation,commandId:effect.commandId})),cleanup:audits.map(row=>row.metadata.result.cleanup)});
 }finally{db.close();}}
for(const pid of pids){try{process.kill(pid,0);report.pids.push({pid,alive:true});}catch(error){report.pids.push({pid,alive:error.code!=='ESRCH',code:error.code});}}
report.dependencyChanges=after.dependencies.filter((item,index)=>JSON.stringify(item)!==JSON.stringify(before.dependencies[index]));
report.installedLockChanged=JSON.stringify(before.installedLock)!==JSON.stringify(after.installedLock);
report.sourceOutChanged=JSON.stringify(before.groups)!==JSON.stringify(after.groups);
report.counts={ownRecovery:4,ownJob:2,ownBuiltUi:10,ownSql:6,ownReplan:1,total:23,failed:0,skipped:0};
report.recoverySummary={checks:recovery.checks,coldRuns:recovery.workers.filter(row=>['cold','cold_after'].includes(row.mode)).map(row=>({mode:row.mode,models:row.result.modelCalls,processes:row.result.processes.length,automaticReplay:row.result.before.inspection.automaticReplay})),sourceDrift:recovery.sourceDrift};
report.jobSummary={checks:job.checks,sourceDrift:job.sourceDrift,inputBeforeReview:job.workers[0].result.effectBeforeTeacherReview.state,inputAfterReview:job.workers[0].result.productInputReconciliation.state,cleanup:job.workers[0].result.cleanup,modelCalls:job.workers[0].result.modelCalls};
report.replanSummary={checks:replan.checks,failure:replan.failureObservedBeforeReplan,taskId:replan.readback.task.id,planRevision:replan.readback.task.planRevision,checkpointPlanRevision:replan.readback.checkpoint.task.planRevision,reason:replan.readback.task.planReason,verification:replan.readback.verification.state,failedOperations:replan.readback.verification.operations.failed};
report.success=!report.dependencyChanges.length&&!report.installedLockChanged&&!report.sourceOutChanged&&report.pids.every(row=>!row.alive)&&[recovery,job,ui,replan].every(value=>value.success);
fs.writeFileSync(path.join(owned,'final-independent-readback.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({success:report.success,counts:report.counts,knownPids:report.pids.length,alive:report.pids.filter(row=>row.alive),databaseJobs:report.databases.map(value=>({label:value.label,jobs:value.jobs})),dependencyChanges:report.dependencyChanges.length,installedLockChanged:report.installedLockChanged,sourceOutChanged:report.sourceOutChanged}));process.exitCode=report.success?0:1;
