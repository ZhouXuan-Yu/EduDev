import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {net} from 'electron';
import {OmniEduStore} from '../../src/main/db';
import {createXiaozhiProductionHost} from '../../src/main/xiaozhi-agent/production-host';
import {createTaskState} from '../../src/main/xiaozhi-agent/tasks/task-state';

const output = process.argv[2], root = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaozhi-phase6-workflow-host-'));
const dataRoot = path.join(root, 'data'), workspace = path.join(root, 'workspace'); fs.mkdirSync(workspace);
fs.writeFileSync(path.join(workspace, 'reference.txt'), 'OWNED_WORKFLOW_REFERENCE The teacher can inspect the existing outline.');
process.env.DEEPSEEK_API_KEY = 'synthetic-phase6-loopback'; process.env.DEEPSEEK_MODEL = 'deepseek-flash';
type Tool = {name: string; input: Record<string, unknown>};
let scenario: Tool[] = [], requests: Record<string, unknown>[] = [];
const report = {success: false, root, output, paidCalls: 0, modelCalls: 0, checks: [] as {name: string; pass: boolean; durationMs: number}[], error: undefined as string | undefined};
const server = http.createServer(async (request, response) => {
  try {
    if (request.url === '/v1/models') {response.writeHead(200, {'content-type': 'application/json'}); response.end(JSON.stringify({object: 'list', data: [{id: 'deepseek-flash', context_window: 1048576, max_output_tokens: 32768, input_modalities: ['text']}]})); return;}
    assert.equal(request.url, '/v1/chat/completions'); let body = '';
    for await (const bytes of request) body += bytes.toString('utf8');
    requests.push(JSON.parse(body)); report.modelCalls++;
    const tool=scenario.shift();
    if(tool?.name==='update_task_plan'&&tool.input.expectedRevision===1){
      const failed=await store.xiaozhiState.sql.all("SELECT run_id,call_id,tool,phase,success FROM xiaozhi_tool_receipts WHERE tool='office_read_text' AND success=0 ORDER BY rowid DESC LIMIT 1");
      assert.equal(failed.length,1,'actual committed failure required before model emits changed plan');
      (report as any).failureObservedBeforeReplan=failed[0];
      tool.input.reason='Actual failed read '+String(failed[0].call_id)+' of missing-after-failure.txt, use existing reference';
    }
    const base={id:'phase6-workflow',object:'chat.completion.chunk',created:1,model:'deepseek-flash'};
    const delta = tool ? {role: 'assistant', tool_calls: [{index: 0, id: 'call_' + randomUUID().replaceAll('-', ''), type: 'function', function: {name: tool.name, arguments: JSON.stringify(tool.input)}}]}
      : {role: 'assistant', content: '已保留实际任务状态，按现有授权完成可核对的步骤。'};
    response.writeHead(200, {'content-type': 'text/event-stream'});
    response.write('data: ' + JSON.stringify({...base, choices: [{index: 0, delta, finish_reason: null}]}) + '\n\n');
    response.write('data: ' + JSON.stringify({...base, choices: [{index: 0, delta: {}, finish_reason: tool ? 'tool_calls' : 'stop'}], usage: {prompt_tokens: 100, completion_tokens: 30, total_tokens: 130}}) + '\n\n');
    response.end('data: [DONE]\n\n');
  } catch (error) {console.error(error); response.writeHead(500); response.end();}
});
const originalFetch = net.fetch;
const store = new OmniEduStore(dataRoot);
let host: ReturnType<typeof createXiaozhiProductionHost> | undefined;
const events: unknown[] = [];
const makeHost = () => createXiaozhiProductionHost({store, dataRoot, enabled: true, emit: event => events.push(event)});
async function check(name: string, action: () => Promise<void>) {const started = performance.now(); await action(); report.checks.push({name, pass: true, durationMs: performance.now() - started}); fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2)); console.log('PASS ' + name);}
async function session(fullAccess: boolean) {
  const id = (await store.createAiConversationSession({title: 'Phase6实际规划与审批', folderId: null})).session.id;
  await store.xiaozhiState.setWorkspace(id, workspace, '合成教学目录');
  const view = await host!.permissions.view(id);
  if (fullAccess) await host!.permissions.setMode({sessionId: id, revision: view.profile.revision, mode: 'fullAccess'});
  return id;
}
async function snapshot(sessionId: string) {const result = await host!.taskSnapshot({sessionId}); assert(result.ok, JSON.stringify(result)); assert(result.value.task); return result.value;}
async function run(sessionId: string, tools: Tool[], resume = false) {
  scenario = tools; const current = resume ? (await snapshot(sessionId)).task! : undefined;
  const started = current ? await host!.start({sessionId, continueTask: {taskId: current.id, requirementsVersion: current.requirementsVersion},
      prompt: '继续刚才的任务，尊重教师拒绝并选择仍可完成的替代步骤。', commandId: 'xicmd_' + randomUUID()})
    : await host!.start({sessionId, commandId: 'xicmd_' + randomUUID(), prompt: '这是独立新任务。核对合成教学目录中的任务和授权事实。'});
  assert(started.ok, JSON.stringify(started)); await host!.waitForRun(sessionId, started.runId);
  return {runId: started.runId, snapshot: await snapshot(sessionId)};
}
const plan = (planningLevel: number, capabilityRequirements: unknown[] = []) => ({name: 'update_task_plan', input: {schemaVersion: 'xiaozhi.task-plan.v3', expectedRevision: 0, requirementsVersion: 1,
  reason: 'Persist the actual task complexity and dependencies', planningLevel, capabilityRequirements,
  steps: [{id: 'teaching_output', text: 'Prepare the synthetic teaching note', dependsOn: [], reported: 'pending', kind: 'saved_text', target: 'planned-output.txt'},
    {id: 'teacher_check', text: 'Teacher checks the result', dependsOn: ['teaching_output'], reported: 'pending', kind: 'human'}]}});
try {
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve)); const address = server.address(); assert(address && typeof address !== 'string');
  net.fetch = async (input, init) => {const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url); assert.equal(url.origin, 'https://api.deepseek.com'); return fetch(`http://127.0.0.1:${address.port}${url.pathname}`, init);};
  await store.init(); host = makeHost();
  await check('PL04 actual failed read changes the same Task plan and immutable checkpoint', async () => {
    const id=await session(true);
    const revised=plan(2);
    revised.input.expectedRevision=1;
    revised.input.reason='Replan after actual missing file read';
    revised.input.steps[0].text='Use the existing outline after the failed missing file read';
    const completed=await run(id,[plan(2),{name:'office_read_text',input:{path:'missing-after-failure.txt'}},revised,
      {name:'office_read_text',input:{path:'reference.txt'}}]);
    const task=completed.snapshot.task!;
    assert.equal(task.planRevision,2);
    assert(task.planReason.includes('Actual failed read'));
    assert.equal(task.steps[0].text,revised.input.steps[0].text);
    const failure=(report as any).failureObservedBeforeReplan;
    assert(failure&&failure.success===0&&failure.phase==='settled');
    assert.equal(failure.run_id,completed.runId);
    const checkpoint=await createTaskState(store.xiaozhiState.sql,{sanitize:async text=>text}).checkpoint(task.id);
    assert(checkpoint);assert.equal(checkpoint.task.id,task.id);assert.equal(checkpoint.task.planRevision,2);
    assert.equal(checkpoint.task.planReason,task.planReason);
    assert.deepEqual(checkpoint.task.steps,task.steps);
    const rows=await store.xiaozhiState.sql.all('SELECT call_id,tool,phase,success FROM xiaozhi_tool_receipts WHERE run_id=? ORDER BY start_sequence',[completed.runId]);
    assert.equal(rows.filter(row=>row.tool==='update_task_plan'&&row.success===1).length,2);
    assert(rows.some(row=>row.tool==='office_read_text'&&row.success===1));
    const bodies=JSON.stringify(requests);
    assert(bodies.includes('missing-after-failure.txt'));
    assert(bodies.includes('OWNED_WORKFLOW_REFERENCE'));
    assert.equal(fs.existsSync(path.join(workspace,'planned-output.txt')),false);
    const message=(await store.getAiConversationSession(id)).messages.find(row=>row.role==='assistant'&&row.metadata.agentRunId===completed.runId);
    assert(message);assert(!['verified','needs_human'].includes(String(message.metadata.verification?.state)));
    (report as any).readback={task,checkpoint,receipts:rows,runId:completed.runId,verification:message.metadata.verification};
  });
  report.success = true;
} catch (error) {report.error = error instanceof Error ? error.stack : String(error); console.error(error); process.exitCode = 1;}
finally {
  await host?.close(); await store.close(); net.fetch = originalFetch;
  await new Promise<void>(resolve => server.close(() => resolve()));
  fs.writeFileSync(path.join(output, 'model-requests.json'), JSON.stringify(requests, null, 2));
  fs.writeFileSync(path.join(output, 'events.json'), JSON.stringify(events, null, 2));
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({success: report.success, root, output, checks: report.checks.length, error: report.error}));
}
