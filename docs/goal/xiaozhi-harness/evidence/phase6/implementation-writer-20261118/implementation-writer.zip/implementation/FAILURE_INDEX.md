# Phase6 implementation side historical failures

All original reports remain at their recorded paths. Later scoped passes retain their own identities and boundaries.

| Group | Original evidence under the owned Windows TEMP directory | Resolution evidence |
| --- | --- | --- |
| Startup Task recovery | xiaozhi-phase6-startup-recovery-ygRgLn | EqzjET final foundation replay |
| State fixture row prototypes | xiaozhi-phase6-state-GnI46J | dcaa9y and WEG1QZ, original eight cases |
| ConPTY first native matrix | xiaozhi-phase6-conpty-native-cM5QpM, 4/9 | 7JWAoT, 9/9 |
| ConPTY owned cwd | xiaozhi-phase6-conpty-native-pAgbJb, 8/9 | Shell-local PSDrive, olkrDe and 7JWAoT |
| ConPTY Ctrl+C | xiaozhi-phase6-conpty-native-Zl2YFU | TEMP detached A/B oVTckh, production olkrDe and 7JWAoT |
| Terminal UI callback ordering | xiaozhi-phase6-terminal-renderer-QWDKtB, root probe | dcuOWb, root vdBsV8, final saB5Dn |
| Inspector ModelState/header identity | xiaozhi-phase6-recovery-inspection-VxNNYQ, 12/13 | KBPwag and wsc04L, 13/13 |
| Workflow | XjEWI4, 29WEdi, umaXML, vUTVlt, jQwJwN, Z8MzzP, RRPDEl | mYVR7A. Original reports distinguish two product defects from fixture expectations |
| Foreground fixture runtime recipe | Vrlkex, 130EHY | c0zTOq, original nine cases |
| Recovery Host directory identity | xiaozhi-phase6-recovery-host-KMvCOe and its diagnostic child directory | In-place golden restore preserves original directory identity, G4Zut1 H01 |
| Recovery Host lazy new-session file | xiaozhi-phase6-recovery-host-G4Zut1 H02 | Native metadata materialization, same-root revalidation-8168a507-07be-4f94-85bc-13858a75c849 H02/H03 |
| Recovery Host persistence failure | G4Zut1/revalidation-8168a507-07be-4f94-85bc-13858a75c849 H04 | Original visible persistence gate and refreshRecords, revalidation-9567c5cf-aa34-482a-8b5d-986b8d62b095 H04 |
| Network fixture | xiaozhi-phase6-network-effects-hRb0kg | Final OUC0fU, eight cases |
| Network complete receipt before SQL commit | xiaozhi-phase6-network-effects-o2EjXl, 7/8 | ZmF0fw and OUC0fU, exact receipt reconciliation with one HTTP request |
| Job OS inventory fixture | xiaozhi-phase6-job-recovery-Hhb6AJ | .NET ACL inventory, all original product evidence retained |
| Job parent-death OS residue | xiaozhi-phase6-job-recovery-PKD50T | Original protected cleanup-only reaper, legacy lweCEr and fresh 7sHl0t |
| Job recovered creation Effect | xiaozhi-phase6-job-recovery-kaCbEm | Atomic interrupted Job and unknown Effect recovery, lweCEr |
| Teacher Task completion | xiaozhi-phase6-job-recovery-YEG884 | Original Task human criteria reach final verification, 6KVB0j and 7sHl0t |
| Persisted ACK product entry | Original 7sHl0t used an exported reconciler directly for one local proof | CfKkwa replaces that test shortcut with the original Host Teacher review action, 2/2 |
| Task recovery renderer fixtures | xiaozhi-phase6-task-recovery-renderer-RJRXQN, 2/10 | dEg20n and Foduk4, 10/10 |
| Actual UI locator fixture | xiaozhi-phase6-terminal-ui-evidence-PZvR2i, 0 checks | Visible TerminalJobs navigation |
| Actual UI expanded-panel navigation | xiaozhi-phase6-terminal-ui-evidence-YCRtBk, 2 checks | Collapse the terminal panel before opening Task review |
| Actual UI synthetic tool schema | xiaozhi-phase6-terminal-ui-evidence-fLPVHG, 6 checks | Remove unsupported write_stdin yield_time_ms from the synthetic response |
| Actual UI shell ordering | xiaozhi-phase6-terminal-ui-evidence-YPMbvr, 5 checks | Await the actual new PowerShell prompt after Ctrl+C |
| Actual UI weak visibility assertion | xiaozhi-phase6-terminal-ui-evidence-CknqNL, 9/9 with viewport-bounds checks | Screenshot review found composer occlusion. Final test adds elementFromPoint pointer reachability and the production panel joins the original scroll area with its domain CSS root |
| Actual UI checkbox hit target | xiaozhi-phase6-terminal-ui-evidence-fTBJQA and xiaozhi-phase6-terminal-ui-evidence-65G9ZQ, eight checks | Click the original visible HeroUI Checkbox.Control and assert its native input is checked, final lNILQx 10/10 |

Leaf handoffs contain complete commands, original source manifests and nested failure paths. They remain in the owned TEMP directories named xiaozhi-phase6-conpty-candidate, xiaozhi-phase6-state-leaf, xiaozhi-phase6-recovery-host-leaf, xiaozhi-phase6-network-effects-handoff-dfd7d7bceb48407bbafbbb4e6d477a28 and xiaozhi-phase6-job-recovery-leaf. RUNS.json records exact report paths and hashes for the concentrated final writer runs.
