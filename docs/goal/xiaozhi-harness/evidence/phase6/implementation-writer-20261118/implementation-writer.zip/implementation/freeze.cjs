const fs=require('fs'),path=require('path'),crypto=require('crypto'),cp=require('child_process');
const repo='D:/WorkProject/EduProject-harness';
const desktop=path.join(repo,'apps/desktop');
const evidence=process.argv[2];
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function walk(directory){return fs.readdirSync(directory,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(path.join(directory,entry.name)):entry.isFile()?[path.join(directory,entry.name)]:[]);}
function entries(files){return [...new Set(files)].sort().map(file=>{const bytes=fs.readFileSync(file);return {path:path.relative(repo,file).replaceAll('\\','/'),bytes:bytes.length,sha256:hash(bytes)};});}
const production=entries([...walk(path.join(desktop,'src')),...['package.json','package-lock.json','electron.vite.config.ts','tsconfig.json','electron-builder.cjs'].map(name=>path.join(desktop,name)).filter(fs.existsSync),...walk(path.join(desktop,'scripts')).filter(file=>/[/\\](build-[^/\\]+|sync-pi-package-capabilities)\.mjs$/.test(file))]);
const tests=entries(walk(path.join(desktop,'scripts/xiaozhi-agent')).filter(file=>/[/\\]phase6-/.test(file)));
const verificationScripts=entries(walk(path.join(desktop,'scripts')).filter(file=>!path.basename(file).startsWith('phase8-')));
const outputs=entries(walk(path.join(desktop,'out')));
const core=JSON.parse(fs.readFileSync(path.join(desktop,'src/main/xiaozhi-agent/capabilities/generated/core-tool-manifest.json'),'utf8'));
const result={createdAt:new Date().toISOString(),kind:'implementation-side Phase6 final candidate',repo,head:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),production,productionListHash:hash(JSON.stringify(production)),tests,testListHash:hash(JSON.stringify(tests)),verificationScripts,verificationScriptListHash:hash(JSON.stringify(verificationScripts)),outputs,outListHash:hash(JSON.stringify(outputs)),coreSourceHash:core.sourceHash,excluded:'Independent Phase8 preparation scripts and root Goal status/evidence files are outside these production and Phase6 test identities.'};
fs.writeFileSync(path.join(evidence,'freeze.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({production:production.length,productionListHash:result.productionListHash,tests:tests.length,testListHash:result.testListHash,outputs:outputs.length,outListHash:result.outListHash,coreSourceHash:result.coreSourceHash,freezeHash:hash(fs.readFileSync(path.join(evidence,'freeze.json')))}));
