# Phase6 state foundation fixed contract

2026-11-18. Authorized writes are phase6-state-* scripts and owned TEMP. Production/shared/preload/build/Electron/native/Job/provider/budget/Git remain with core/root.

The fixture reuses register-source, actual Node SQLite, original TaskCoordinator/TaskState/EventPublisher/Journal and EffectState. Every positive effect starts from original coordinator.start, real Task plan/admission, ToolStart, admitted receipt and recordToolContract. The trusted synthetic ToolContract is stored through the actual admitted-receipt API. Effect run authority is derived from that actual owner. Owned file readback checks exact bytes. This test is state-foundation evidence.

The fixed set contains eight checks.

1. Real child SIGKILL after Intent commit, before executing. Reopen twice, retain unknown and zero automatic effects.
2. Real child SIGKILL after Executing plus execution binding commits. Reopen twice, retain unknown and zero automatic effects.
3. Real owned file success before Effect commit, then child SIGKILL. Reopen twice, reconcile from exact readback with one original physical effect.
4. Effect/receipt ToolEnd commit and Task checkpoint commit, then child SIGKILL. Reopen twice, preserve committed proof and one original physical effect.
5. Inject an outbox INSERT failure during original Journal.recover. Effect, Task/history/checkpoint, journal/outbox and owner all roll back. Retry through the original recovery API succeeds without business IO.
6. Inject outbox failure during original Task checkpoint. Private Task, immutable history/checkpoint, journal/outbox all roll back. An explicit retry through the original API succeeds.
7. Same-key/same-digest retry is idempotent. Same-key changed digest is refused. Concurrent Effect CAS transitions produce one winner.
8. Old Run and cross-Task authority are refused with no persisted mutation. Original Task CAS remains fenced.

Each crash worker reports its boundary only after actual SQLite commit and any required owned file write. Parent reads the committed DB while the child is paused, then kills the real process and records exit status. Read-only initial reopening preserves raw facts. Recovery and a second cold reopening record logical snapshots, checkpoint references, owner generation and effect counts. Reports retain first failures and exact source hashes. In-scope failures are given to core for source repair and the same fixed set is rerun.
