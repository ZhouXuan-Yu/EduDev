# Provider resume fixed test contract

2026-11-18. Only new phase6-provider-resume-* scripts and owned TEMP. Production, frozen ConPTY/state/policy leaves, build/out, Electron/native, external network, keys/models/budget and Git remain outside this leaf.

Original Phase2 contract suite passed 10/10 at xiaozhi-capability-phase2-contract-YY7TQN. New tests reuse actual Sql/Registry/Resolver/Snapshot/Runtime and original coordinator create/resume. The existing frozen state fixture is imported unchanged. Availability, authorization and adapter execution counters are explicit metadata test seams. They do not prove real Provider I/O, Permission approvals or Pi product paths.

Fixed twelve checks cover retained old version with a newer current version, revocation, missing executable, denied authorization, missing Required guarantees, persisted executing Effect, persisted unknown Effect, readback reconciliation followed by compatible fallback and Optional disclosure, foreign Task/old owner, stale Registry revision, Snapshot insert rollback and an Effect entering between resolver and persist.

Persisted safety follows the current Host predicate for the same capability and local_write/external_effect in intent/executing/unknown. Safety cases bind the real office_create_text admission/receipt Effect to its own capability and use clearly synthetic metadata provider declarations for that capability. Reconciliation uses a real owned file proof. Every boundary snapshot and source hash is retained, and the first failure will be preserved before any owner fix.
