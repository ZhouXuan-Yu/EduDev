# Phase6 terminal renderer delivery contract

Root released terminal/**, its local stylesheet, phase6-terminal-renderer-* tests and only the two existing parent terminal entries. Reuse old xterm6/fit0.11 UI structure and current HeroUI controls. Core owns shared DTO/preload/API/dependencies/build/runtime.

Consume exact TerminalJobView and three expected revisions. Read cursor/reset/hasMore stays independent. Teacher controls derive only from main. Stream real output into xterm, retain readonly legacy output, and use main-provided legacy terminal.jobId for exact inline lookup. List management stays in the original conversation terminal entry.

Serialize UTF8 input chunks within inputMaxBytes and16KiB, bounded unsent queue, exact command IDs and ACK matching. Unknown ACK or missing RPC response pauses the queue. Read with that exact commandId, clear only matching acknowledged proof or confirmed monotonic acknowledgement for an already-known sequence with main controls restored. Never retransmit unknown input. Preserve safe EOF/close, ordered Ctrl+C and coalesced resize. Fence session/job/unmount and stale revisions. Handle loading, empty, mapped errors, expiry/revoke/stale control, reset/truncation and cleanup notice.

Dedicated React/HeroUI/JSDOM typed-bridge tests use an explicit xterm adapter fixture and own node_modules. They prove protocols, not real xterm keyboard/viewport/ConPTY behavior. Real Electron two-size keyboard/stdin/resize/EOF/stop and backend persistence/lease/Task/Run gates remain core/root NOT_RUN until integrated. No real providers, keys or actual Goal budget are used. Rollback restores only the two before-parent files and removes the newly added terminal subtree/test, preserving collaborator changes.
