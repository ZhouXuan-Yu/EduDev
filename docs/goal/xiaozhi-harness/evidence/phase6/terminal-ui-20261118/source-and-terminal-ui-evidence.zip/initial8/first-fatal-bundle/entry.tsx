export {default as React,act} from 'react';export {createRoot} from 'react-dom/client';
export {TerminalConsole} from "D:\\WorkProject\\EduProject-harness\\apps\\desktop\\src\\renderer\\components\\office\\terminal\\TerminalConsole.tsx";
export {TerminalJobs} from "D:\\WorkProject\\EduProject-harness\\apps\\desktop\\src\\renderer\\components\\office\\terminal\\TerminalJobs.tsx";
export {splitInput} from "D:\\WorkProject\\EduProject-harness\\apps\\desktop\\src\\renderer\\components\\office\\terminal\\terminalState.ts";