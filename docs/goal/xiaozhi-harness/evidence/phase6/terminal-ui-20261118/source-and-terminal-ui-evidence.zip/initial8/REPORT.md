# Phase6 terminal UI leaf delivery

## Result and actual entry points

PASS for the component and owned-source checks. NOT_RUN for the integrated Electron/native/helper and product gates. Source baseline was0f753e572cbdfa20eaaf130a0f7b23d32e8ac2b8. Root released terminal/**, the dedicated smoke and only the existing two parent terminal entries. Current existing Composer/Pi and other page content/styles remain outside this leaf.

OfficeConversation mounts TerminalJobs at the original old-WIP conversation slot. AgentPublicTool replaces only its existing terminal-rendering block with TerminalConsole. The existing OfficeToolEvidence call stays intact. Legacy TerminalOutput without jobId stays readonly. The additive main terminal.jobId provides exact inline read identity. Session/Job lookup uses that ID and current session. No command/cwd inference is used.

The renderer reuses the old xterm/fit structure and local neutral stylesheet. Actual dependencies are @xterm/xterm6.0.0 and @xterm/addon-fit0.11.0 installed by core in this tree. Their package hashes are recorded. Package/lock editing remained core-owned. Six terminal TS/TSX files, one local stylesheet, two narrow parent edits and the dedicated script make ten frozen files.

## Implemented protocol behavior

List loading/empty/failure/retry states and foreground polling consume the actual typed API. The selected console uses same-session/same-Job reads/events and rejects mismatched Task identity. Output sinceSequence/reset/hasMore is independent from business, controller and lease revisions. Output buffers and xterm pending frames are bounded, xterm writes drain by callback, snapshots avoid clipped UTF16 low-surrogate starts, and delayed renderer initialization flushes its existing output queue. Stale output never revives an already-terminal process or replaces newer controls.

All mutations construct fresh xicmd_UUID IDs and all three expected revisions from the latest returned Job view. Main controls exclusively determine write/eof/resize/closeInput/close/takeControl availability. Foreground model state is absent from the enabling logic. Main therefore supports its authorized teacher-idle controls without another model request.

Input uses UTF8-safe chunks bounded by min(inputMaxBytes,16384), a bounded unsent queue and one real in-flight ACK. Adjacent raw keys coalesce before dispatch. Ctrl+C is an ordered ETX write. EOF invokes the additive sendEofXiaozhiTerminal API through the same ordered exact-ACK queue. The separately labeled 关闭输入通道 action calls closeInputXiaozhiTerminal and displays that this may end the terminal. End terminal calls the separate close API. Resize coalesces the latest geometry and retains pending dimensions across other operations. Stop can reach main while an older resize is pending.

Unknown ACK or missing RPC response pauses the queue and preserves its exact commandId and known sequence. Read includes that commandId. Matching acknowledged readback clears uncertainty, and core-confirmed monotonic ACK proof can clear a previously known sequence after main restores write controls. Unknown bytes are never retransmitted. The fixture checks both known-sequence unknown and no-response/no-sequence cases, including ignored late replies. Session/Job/unmount and control/lease changes fence stale work. A control-generation change stops unsent bytes with a visible notice. Main-derived expiry/revoke/source/error/cleanup notices remain visible.

## Actual commands and retained evidence

Cwd D:/WorkProject/EduProject-harness/apps/desktop.

- node scripts/xiaozhi-agent/phase6-terminal-renderer-smoke.mjs
- Expected preimplementation missing-component setup failure exit1,0/0 at TEMP/xiaozhi-phase6-terminal-renderer-as144F/report.json. tdd-red-report.json and tdd-red.log retain it.
- Initial integrated fixture run exited1 after two checks because the fixture omitted resizeXiaozhiTerminal and the timer dispatch threw synchronously. It produced no final JSON. first-fatal.log and first-fatal-bundle preserve the actual compiled bundle/entry from TEMP/xiaozhi-phase6-terminal-renderer-Y2ZwY0. The renderer dispatch now enters a caught Promise boundary, and the fixture supplies the required typed resize method.
- The next candidate passed8/8 at TEMP/xiaozhi-phase6-terminal-renderer-rcQ4dj/report.json. Later8/8 candidates T5ZjLb and r5ROkL remain separately copied.
- Final concentrated suite passed8/8 exit0 at TEMP/xiaozhi-phase6-terminal-renderer-ccRKe0/report.json. final-report.json and final.log retain the result matching the frozen source.
- An owned-source TypeScript createProgram check ran with the repo tsconfig options/noEmit and the eight owned TS/TSX roots plus repo declaration files. It returned zero owned diagnostics and zero dependency-graph diagnostics. owned-types.json records exact roots and scope. The inline Node command resolved this tree's typescript package, used getPreEmitDiagnostics and performed no emit. This is scoped source evidence. Core retains the whole-tree command.
- git diff --check across the ten delivery paths returned 0. diff-check.log and parent-entry.diff retain exact output and the two parent-consumer edits.

Eight protocol groups cover list/owner/load/failure, legacy/exact Job identity/main controls, output cursor/ANSI/Unicode/reset/stale terminal state, serialized UTF8 ACK payloads, known/unknown-sequence reconciliation, session/unmount/controller/lease fencing, separate Ctrl+C/EOF/channel-close/resize/take-control/stop actions, and expiry/source/cleanup notices. Actual React/HeroUI runs in JSDOM with an explicit xterm adapter fixture. DOM input is exercised through its controlled field and bridge. The xterm fixture's data/resize/write methods test adapter protocols. It does not claim native keyboard or actual xterm canvas behavior.

## Stable controls

terminal-jobs / terminal-jobs-toggle / terminal-jobs-refresh provide background management. terminal-select-<jobId> selects the exact Job. agent-terminal-output and agent-terminal-status preserve original evidence anchors. terminal-viewport, terminal-plain-output and terminal-input identify display/input. terminal-send, terminal-interrupt, terminal-eof, terminal-input-close, terminal-take-control, terminal-close and terminal-refresh identify real actions. terminal-unknown-input and terminal-error identify uncertainty and mapped failure feedback.

## Unverified boundaries

NOT_RUN for whole-tree build/out, actual Electron/native/ConPTY, real helper ownership/leases, persistent Effect/Job/Task/Run or restart readback, real stdin ACK/backpressure/cancellation, Windows EOF/ReadLine, actual xterm keyboard/ANSI/Unicode/resize,1366×768 and1920×1080 reachability, original user path through built parents, real permissions/revocation/expiry and performance comparison. Core/root own the integrated user-path gates and fresh Gate6 acceptance. No real provider/key or actual Goal budget was accessed. No main/shared/preload/package/lock or other UI page was edited by this leaf.

## Source freeze and rollback

freeze.json and source-snapshot contain complete SHA256 values for all ten owned files. The current shared/preload contracts are recorded as read-only references, including main's additive jobId, exact commandId readback and EOF API. They remain core authority.

- apps/desktop/src/renderer/components/office/terminal/TerminalConsole.tsx = 6474f31af5c295f292e279a550351915823477b2e65f9f00aeb04a146397451e
- apps/desktop/src/renderer/components/office/terminal/TerminalJobs.tsx = 3bbdd64ec8d15ce44c5f3cd2a9c82635c427b6e139b5806b9dba87ca739e09b4
- apps/desktop/src/renderer/components/office/terminal/TerminalViewport.tsx = 4ee43d08a51c49522f3e69ae50c6e7a09573643d061b85491b42377a4ccccec7
- apps/desktop/src/renderer/components/office/terminal/terminal.module.css = 77e8fb54c3819a93cfd9e7e621dee806a6a2013c2e93ab2d0861b1847cbc4b41
- apps/desktop/src/renderer/components/office/terminal/terminalState.ts = 4c2dc55c9931772f5136235c47cd31f883424419c3df4bcd30864f618ebc4cfd
- apps/desktop/src/renderer/components/office/terminal/useTerminalJobs.ts = 689626d131d4904112e578ddf6c4acdc0da32a5d860b5cb1ef72f2682e5c249f
- apps/desktop/src/renderer/components/office/terminal/useTerminalSession.ts = 09c585d90d1afa5c2e40cb3f2fbb268f6819a4cd9eaf893113fdf56bea550180
- apps/desktop/src/renderer/components/office/OfficeConversation.tsx = 9e4a9e555313defee2cc292c5921ea981d7cb70a34824f7cff56880f27faf0da
- apps/desktop/src/renderer/components/office/AgentPublicTool.tsx = 4df81b0f2f4e449dfa6f27fdb963f07c7579b3f891e49e5cb73fa8cb9409b43b
- apps/desktop/scripts/xiaozhi-agent/phase6-terminal-renderer-smoke.mjs = 94956b3b4b3209aa09701c1ea1320500da96f50ee6b7cf3251ad004d9c8e6709

Rollback restores the two parent-before files at this directory and removes only the new terminal subtree plus phase6-terminal-renderer-smoke.mjs. Preserve current core and other collaborator changes. SQLite/shared/helper/dependency rollback stays with core and is outside this UI-only rollback.

## Final frozen-source typecheck replay

The exact replay command is node C:\Users\ZhouXuan\AppData\Local\Temp\xiaozhi-phase6-terminal-ui-ef4cc55a1e64481a979496e892be1e15\owned-typecheck.cjs with cwd D:/WorkProject/EduProject-harness/apps/desktop. It returned exit0 with zero owned and zero dependency-graph diagnostics after the ten-file freeze. owned-types-final.json records this final source check, and the CJS file preserves its complete implementation. No source or build output changed during this check.
