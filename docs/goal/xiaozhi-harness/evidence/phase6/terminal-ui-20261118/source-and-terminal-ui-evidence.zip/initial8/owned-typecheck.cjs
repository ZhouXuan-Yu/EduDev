const fs=require('node:fs'),path=require('node:path');
const ts=require('node:module').createRequire(path.join(process.cwd(),'package.json'))('typescript');
const desktop=process.cwd(), directory=path.join(desktop,'src/renderer/components/office/terminal');
const owned=fs.readdirSync(directory).filter(name=>/\.tsx?$/.test(name)).map(name=>path.join(directory,name));
owned.push(path.join(desktop,'src/renderer/components/office/OfficeConversation.tsx'),path.join(desktop,'src/renderer/components/office/AgentPublicTool.tsx'));
const parsed=ts.parseJsonConfigFileContent(ts.readConfigFile(path.join(desktop,'tsconfig.json'),ts.sys.readFile).config,ts.sys,desktop);
const program=ts.createProgram([...owned,...parsed.fileNames.filter(file=>file.endsWith('.d.ts'))],{...parsed.options,noEmit:true});
const all=ts.getPreEmitDiagnostics(program), names=new Set(owned.map(file=>path.resolve(file).toLowerCase()));
const relevant=all.filter(item=>!item.file||names.has(path.resolve(item.file.fileName).toLowerCase()));
const result={status:relevant.length?'FAIL':'PASS',scope:'Eight owned TS/TSX roots and declaration/dependency graph. No emit/build, no whole-tree claim.',ownedFiles:owned,
ownedDiagnostics:relevant.map(item=>({file:item.file?.fileName,code:item.code,message:ts.flattenDiagnosticMessageText(item.messageText,'\n')})),otherDependencyDiagnosticCount:all.length-relevant.length};
fs.writeFileSync(path.join(process.env.TEMP,'xiaozhi-phase6-terminal-ui-ef4cc55a1e64481a979496e892be1e15','owned-types-final.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result));if(relevant.length)process.exitCode=1;
