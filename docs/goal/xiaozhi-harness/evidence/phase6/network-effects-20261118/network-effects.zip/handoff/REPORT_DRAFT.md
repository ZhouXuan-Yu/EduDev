# Network Effects fixed foundation suite

This draft records the bounded test-only leaf while core owns its source correction. Fixed groups N01 through N08 use the original state-foundation fixture and real SQLite Task, Journal, receipt and Effect APIs. PermissionEngine current-owner validation delegates to original TaskState.validateCurrent using the original three-field TaskOwner and exact Task ID. Real task-scoped network and egress grants authorize only the owned literal 127.0.0.1 server. Request and response bodies in these artifacts are synthetic fixture strings.

## Preserved initial results

The first fixture attempt produced 0/8 with 0 HTTP because its adapter passed a four-field PermissionOwner into the original three-field TaskOwner validator. hRb0kg/report.json and first-run.log preserve that result. The adapter was corrected to project the typed sessionId/runId/generation fields. No product guard was bypassed.

The corrected first product run produced 7/8, exit 1, source identity changes 0 and exactly 7 HTTP requests. Its raw report is TEMP/xiaozhi-phase6-network-effects-o2EjXl/report.json and owner-shape-corrected.log captures stdout/stderr. first-product-failure-report.json and first-product-failure-sources retain the report and all eleven exact tested source snapshots.

N05 failed. A child made one actual POST and wrote a complete network receipt file containing status 201 and the exact response body. The test paused inside the original Sql update boundary before the network Effect committed, independently read its real SQLite state as executing revision 2 with null outcome, then SIGKILLed the child. The cold original Journal recovery changed it to unknown revision 3 with empty proofs and an outcome digest derived from the missing tool result. An explicit same-Task new Run and a different admitted parent reached the normal NetworkBroker/Engine APIs. NetworkEffects.start compared the Journal placeholder digest with the full response receipt digest and returned side_effect_unknown. The route still received exactly one HTTP request. Core received precise source anchors and owns the repair.

Other fixed groups passed. Same Task/requirements/digest POSTs, including a distinct valid parent receipt, reused one exact cached response. Real GET with a fixed child call reused one response. An explicit IdempotencyKey with a changed body failed before a second request. Response loss remained unknown and refused both new-call and same-Task new-Run replay. Cancellation and actual Scope revocation after delivery preserved unknown. Renewed Scope grants allowed authorization but still could not replay unknown. A different valid Task could not borrow another Task's parent receipt, and a stale owner produced zero HTTP.

The transport evidence records one POST each on N01, N03, N04, N05, N06 and N07, one GET on N02 and zero requests on N08. Routes N01, N02, N03 and N05 completed responses. N04 dropped the connection and N06/N07 were interrupted by cancellation/revocation. The owned server closed and the actual crash child exited on SIGKILL.

## Acceptance boundary

These are network/effect service foundation tests with synthetic sanitizer input and an explicit review-equivalent test Scope grant. They exercise the actual main APIs and SQLite ownership rules. They do not execute Pi or an AgentLoop, actual teacher review UI, Host IPC, product recovery UI, public HTTPS/TLS/provider access, native helper/PTY, build/out, package installation, real key/configuration or paid-budget state. Whole-app restart and real model acceptance remain NOT_RUN. There is no product performance or security-completion claim.

Only the two new phase6-network-effects scripts are written by this leaf. The original inspector3, terminal UI10, Phase8 scripts and all production sources remain outside this leaf's write scope. Core may independently change the specific production bug after receiving this preserved failure.
