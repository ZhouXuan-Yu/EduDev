using System;
using System.Runtime.InteropServices;

namespace Xiaozhi.PermissionRuntime
{
    // TEMP candidate. Startup, AppContainer, Job and authorization remain core-owned.
    internal static class ConPtyNative
    {
        internal const int PseudoConsoleAttribute = 0x20016;

        [StructLayout(LayoutKind.Sequential)]
        internal struct Coord
        {
            internal short X;
            internal short Y;
        }

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern int CreatePseudoConsole(
            Coord size, IntPtr input, IntPtr output, uint flags, out IntPtr console);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern int ResizePseudoConsole(IntPtr console, Coord size);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern void ClosePseudoConsole(IntPtr console);

        internal static Coord Size(int cols, int rows)
        {
            if (cols < 1 || cols > short.MaxValue || rows < 1 || rows > short.MaxValue)
                throw new ArgumentOutOfRangeException("cols/rows");
            return new Coord { X = (short)cols, Y = (short)rows };
        }

        internal static void CheckResult(int result)
        {
            if (result < 0)
                Marshal.ThrowExceptionForHR(result);
        }
    }
}
