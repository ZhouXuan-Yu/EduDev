# Phase6 ConPTY leaf candidate

2026-11-17. Baseline 0f753e572cbdfa20eaaf130a0f7b23d32e8ac2b8. TEMP preparation only. Production implementation awaits core seam freeze and root production RELEASE. Compile, native/runtime and paid-model execution counts are zero.

## Source evidence

The archived compatibility zip SHA256 is bba56b2419037287b9106d62b463ee016231b6cdfc66ddd9a0bba79eac3ab9a1. Entry ConPtyProbe-v4.cs has 125100 bytes and historical SHA256 e7114e41b1ff79ce33101c28e9e5d2f2d45de6bcfeaaf6a5a4c94dcd6bd29a93. Only its dedicated ConPtyProbe class was extracted to ConPtyProbe-v4-dedicated.cs.txt, SHA256 2bd2570209cc10c1557f920f23e124378784d3c151168d7e79355cd4059f5345. Existing giant helper implementation is excluded from this extraction.

Codebase-memory list_projects still reports the Harness root with zero nodes, and its targeted Runner/SessionInput/runNativeSandbox query returns project not found or not indexed. Current-source statements below use bounded file reads. Old WIP graph also omits its untracked terminal modules, so their actual files were read.

## Minimum core seam

1. SessionOptions adds mode pty with validated cols/rows and the original arguments, input, output, process, memory, CPU and lifetime budgets. Stdio wire compatibility remains core-owned.
2. Runner creates ConPtySession before StartupInfoEx. SECURITY_CAPABILITIES and PSEUDOCONSOLE attributes use the same two-entry list. PSEUDOCONSOLE receives Handle directly with IntPtr.Size. STARTF_USESTDHANDLES is set with Input/Output/Error all zero. CreateProcess uses inheritHandles false and EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT | CREATE_SUSPENDED. Core retains executable pin, owned projection, JobLimits, token checks and ResumeThread ordering.
3. Original SessionInput keeps its 16KiB frames, monotonic sequence, four-entry queue and budget. Its writer synchronously calls WriteInput. It sends input_ack only after the whole byte chunk has been written. A completed input queue closes the PTY input writer after queued chunks drain. Resize uses an independent exact controlId and resize_ack, without consuming input sequence. ETX remains ordinary ordered UTF8 input.
4. Runner forwards PTY raw bytes through its existing bounded output accounting as stream pty. No UTF8 decoding occurs in C#. Its existing output sink owns the framing and total output limit. Byte callbacks start draining before ResumeThread.
5. Cleanup first terminates the original Job and verifies active zero. Input writer completion and PTY close happen while the PTY reader continues draining. Core includes reader-ended and HPCON-closed checks in final cleanup success. A close deadline failure must remain a cleanup failure. Profile/ACE, process handles and lease completion remain core-owned.
6. Launcher adds writeSequenced({sequence,bytes}), resize({controlId,cols,rows}), and the pty output branch. Its returned promise still resolves only after verified result plus helper child-close. Core updates source lists, recipe hashes and ptyProtocolVersion together.

## Proposed ConPtySession API

```csharp
internal static ConPtySession Create(int cols, int rows,
    Action<byte[]> onBytes, Action<Exception> onFailure);
internal IntPtr Handle { get; }
internal void WriteInput(byte[] bytes);
internal void Resize(int cols, int rows);
internal void CloseInput();
internal void Close();
public void Dispose();
```

The instance owns HPCON and both local pipe endpoints. Child-facing pipe endpoints close immediately after CreatePseudoConsole succeeds. Its reader continuously forwards bounded raw chunks. Input writes use the existing core writer thread. Resize and close serialize HPCON access. Close is idempotent, tracks one close operation, keeps the reader alive during ClosePseudoConsole, and waits for both console close and reader completion. Failure preserves the actual HRESULT/Win32 error for core classification. The leaf creates no process or Job, reads no SQLite, and acquires no Scope.

The v4 probe places ClosePseudoConsole on a dedicated thread with a five-second join and then waits three seconds for the reader. Production candidate must additionally retain close-in-progress state across repeated close and report failed joins. Releasing a handle still in use by a blocked reader or writer requires a defined cancellation/ownership path. This detail is pending the core lifecycle seam and will be resolved in the implementation before native testing.

## Proposed TypeScript backend seam

```ts
type ControlledTerminalPort = {
  writeSequenced(input: {sequence: number; bytes: Buffer}): Promise<{sequence: number}>;
  resize(input: {controlId: string; cols: number; rows: number}): Promise<void>;
  close(): void;
};
type LaunchCallbacks = {
  onStarted(pid: number, helperPid: number): void;
  onBytes(stream: 'stdout' | 'stderr' | 'pty', bytes: Buffer): void;
  onSession(input: ControlledTerminalPort): void;
};
// LaunchResult is the original runNativeSandbox awaited return type.
createControlledTerminalBackend({
  launch: (callbacks: LaunchCallbacks) => Promise<LaunchResult>,
  controller: AbortController,
  onData: (text: string) => void,
});
```

Return handle follows PHASE_6_IMPLEMENTATION section 4 with ready, write, resize, closeInput, cancel and closed. It uses StringDecoder to preserve UTF8 split across chunks, flushes once after the launcher settles, and never retains an unbounded transcript. It delegates input sequence and resize ACK validation to the launcher. Core persists Intent before each handle call and records ACK afterwards. Cancellation delegates to the injected controller. The launch callback is invoked once with the already-admitted immutable launch spec captured by core.

## Old WIP handle compatibility

Old pty-backend.spawnTerminal returns synchronous write/resize plus close and reports ready pid only. session-manager.write calls resize/write without awaiting either. Integration must await the new backend acknowledgements. The existing cursor/reset/32KiB display/64-chunk history and async output flush are reusable. Old worker finish has ending-once, flush, exit callback and disconnect handling. Core manager must use closed after verified helper cleanup as its final lifecycle boundary. The WIP fork, pty.spawn and taskkill implementations remain historical source references.

## Fixed native test scope for later RELEASE

- Real AppContainer PS5 console, Read-Host, variable/cwd persistence, repeated input, ANSI/Unicode split boundaries, actual resize, ETX followed by continued shell use, EOF and natural exit 0/nonzero.
- Ordered ACK and four-frame backpressure through the original launcher, blocked input/output cancellation, timeout, repeated close and initialization failure.
- Parent/transport death and precise Job/helper/shell/ConHost/reader/HPCON/profile/ACE cleanup evidence, using only owned fixtures and coordinated runtime windows.
- Budget and Grant/controller behavior uses core original services. End-to-end Task/Effect/Job persistence, UI, model and provider acceptance remains with core/root and Gate6.

All new native cases are NOT_RUN. The archived v4 two-case PASS is historical compatibility evidence only.
