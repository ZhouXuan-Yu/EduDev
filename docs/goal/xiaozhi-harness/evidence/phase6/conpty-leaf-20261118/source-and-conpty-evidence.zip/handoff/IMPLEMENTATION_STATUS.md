# Phase6 ConPTY leaf status

Production RELEASE received 2026-11-17. Only the authorized three new main files and phase6-conpty scripts were written. Core owns the original helper launch, protocol, runtime, build, Scope, Task, Effect and Job services.

## Current source and API

ConPtyNative is independent PInvoke. ConPtySession implements the frozen Create/Handle/StartReading/WriteInput/Resize/CloseInput/Close/Dispose API. It owns HPCON and its pipes, a continuous 16KiB output drain and one bounded close thread. Input uses the original core queue writer and ACK. Synchronous cancellation targets only the leaf's pinned writer-thread handle. The TS backend implements the actual controlled-types.ts signature, invokes one injected admitted launch, forwards raw Buffer data, preserves the original write sequence/resize control IDs and waits for the original verified child-close cleanup promise.

## Commands and evidence

- TEMP library compilation succeeded with Framework64 csc.exe /nologo /target:library /platform:x64 and the two absolute Windows source paths. Output is ConPty-leaf.dll under this owned TEMP directory. An initial command using relative slash-separated source arguments failed CS1504. It executed no native code. Resolve-Path absolute Windows paths corrected the invocation.
- A strict TypeScript noEmit program rooted at terminal/controlled-backend.ts reported zero diagnostics including its imported source dependencies.
- From D:/WorkProject/EduProject-harness/apps/desktop, D:/Node/node.exe scripts/xiaozhi-agent/phase6-conpty-protocol-smoke.mjs passed 12/12. Evidence is C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-conpty-protocol-qf65Vm/report.json. These are injected-launch protocol fixtures.
- The first real native run used D:/Node/node.exe scripts/xiaozhi-agent/phase6-conpty-native-smoke.mjs and finished 4/9. Original report and raw VT files remain under C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-conpty-native-cM5QpM/evidence. Seven real PTY sessions started, with Job0/profile removed/ACE0/ptyClosed true. The invalid-size request created no shell.

## Original failures and bounded fixes

P02 demonstrated real Read-Host hello-42, persistent variable42 and actual resize96x32, then its expected emoji was encoded as question marks by the PS5 default console encoding. PowerShell also selected C:\ initially. The revised fixture explicitly initializes UTF8 and its owned cwd. Core was notified to initialize these in the actual shell entry. Original VT remains available.

P04 exposed actual Windows console EOF behavior. Closing the ConPTY input pipe terminated the console with signed status -1073741510, equivalent to 0xC000013A. Its application ReadLine loop did not produce EOF_DONE. The initial exit0 expectation was inaccurate. The revised fixed case records actual terminal status and whether the application loop completed. It continues to require verified complete cleanup.

P06/P07 were masked by the original Engine.run final authority assertion after expected controller cancellation. The revised fixture preserves the underlying action error and records the original authority terminal error, accepting it only for explicitly expected cancelled sessions with actual cleanup receipts. P02's underlying failure is now preserved before cleanup cancellation can mask it.

P09 is a reported core seam defect. The helper rejects illegal size before Session is assigned, so its no-PTY cleanup result lacks ptyClosed. The launcher currently requires ptyClosed for all requested PTYs and reports cleanup_failed. Core owns the fix. The old report and owned invalid request projection remain preserved.

## Remaining work

The same nine native cases will be rerun after core's P09 correction and a renewed exclusive runtime window. No scope expansion is planned. Four-frame cancellation does not claim that all frames reached an OS-blocked write. Host/Task/Effect/Job background supervision, parent death recovery, Node/Python, renderer and provider acceptance remain with core/root and Gate6. Model and real-key access are zero.

## Second fixed native run

The same command completed 8/9 under C:/Users/ZhouXuan/AppData/Local/Temp/xiaozhi-phase6-conpty-native-pAgbJb/evidence/report.json. The first 4/9 report remains intact. This run directly uses core terminalShellArguments and terminalEofBytes. Typed Windows Ctrl+Z+Enter produced actual EOF_DONE, applicationReadLoopCompleted true and exit0. Physical input-pipe hangup remains the separate original observation with 0xC000013A.

Core corrected the invalid-size launcher cleanup predicate. P09 now reports failed/invalid_protocol with no shell and complete no-PTY cleanup. The actual four-frame cancellation had two ACKs pending after 100ms, then all four promises settled with complete cleanup. Seven started PTYs again reported ptyClosed true, Job0/profile removed/ACE0. Exact known helper/shell PID inventories for each run found alive[]. Independent ConHost PID inventory was not collected.

Only P02 remains failed. Production terminalShellArguments reaches Set-Location for the owned projection but PowerShell returns UnauthorizedAccessException and stays at C:\. The failure is before the remaining Unicode/Ctrl+C continuation assertions. Its original VT and precise owned root are in the second report. Core holds the Projection/launch/shell-startup fix and has the counterexample. Leaf production C#/backend source remains unchanged. No third native run will start before that owner fix and a coordinated window.

RUNTIME_RELEASED was sent to core and root immediately after each real run.
