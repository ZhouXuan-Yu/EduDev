# Fixed Job recovery contract

Root-confirmed final semantics, SOURCE_DONE.

- J01 preserves the real parent SIGKILL boundary inventory, including residual profile/ACE facts. Before Host creation, cold original SQLite recovery marks the Job interrupted and cleanup needs_check. Original Host reaper then uses one validated cleanup-only helper, dispatches no guest, removes exact SID/profile and retains original directory identities plus all projection file bytes. Job cleanup becomes complete while projectionState remains needs_check and parent Effect remains unknown.

- J02 has two bounded variants. TEMP-only controlled-backend instrumentation awaits real native input_ack then throws once before jobs.acknowledge. Assert marker once, unknown ACK/Effect, new command blocked, exact duplicate zero resend and zero new LLM, then real close cleanup. Separate normal bundle preserves real database ACK, rejects only committed job_input Effect with a narrow trigger, uses exact command read/duplicate, explicitly invokes original Effect reconciler based on ACK proof while Job is live, then continues within original Scope.

- J03 uses actual Task snapshot candidate and canAccept, original Teacher reviewTask input and same Task, then original closeTask cleanup. No fabricated candidate or early close.

Production and all frozen prior leaves remain core/root-owned. Two named scripts and owned TEMP evidence are the full leaf write boundary. Worker lease 180 seconds and watchdog 210 seconds. Native runtime is core-exclusive and released.