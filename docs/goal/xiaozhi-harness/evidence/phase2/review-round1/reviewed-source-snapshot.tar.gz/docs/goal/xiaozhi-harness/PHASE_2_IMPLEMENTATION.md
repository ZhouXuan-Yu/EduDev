# Phase 2 实施合同

2026-11-12，基线 `ab59604cf9937818ed387def21e737ade12264df`。Gate1 已 ACCEPTED。总控已释放 Phase2 生产写入，范围为 T2.1–T2.4，随后交独立 Gate2。当前 Goal 编号采用 Phase0–8。

## 教师可见结果与真实接缝

Pi 同一任务可通过稳定能力入口发现、解析并调用已验证的本地文件元信息 Provider。新能力在工具之间的安全点激活，当前 Task、Run、Pi Session 和既有成果延续。执行记录关联 Provider、软件版本、Contract 版本及 Registry Revision，撤销和当前工作区授权实时生效。

现有链路为 `production-host.execute → createPiXiaozhiSession → customTools → createToolExecutionBoundary → beforeDelivery → admitClassroomOrTaskTool / taskRuntime.admit → eventJournal.admitTool → Tool.execute`。Phase1 的 Registry/Resolver 和两个真实 Native 元信息实现已通过主进程试点。Phase2 将其纳入同一 Pi 调用链。

关键源码接缝为 `xiaozhi-agent/tools/execution-bound.ts`、`tools/manifest.ts`、`tasks/plan-runtime.ts`、`tasks/tool-envelope.ts`、`events/publisher.ts`、`events/journal.ts`、`pi-session.ts` 和 `production-host.ts`。`publisher.persist` 已提供同一 Journal owner 围栏和写队列，可复用来持久化 Provider Snapshot。

## Pi 1.0.2 核验

锁定 `@earendil-works/pi-coding-agent` 1.0.2。`dist/core/agent-session.d.ts:412` 的公开 `setActiveToolsByName` 只激活已注册工具，变更在下一 Agent turn 生效。`agent-session.js:1084` 对应实现通过既有工具 registry 组装 loadout。当前 Session 的 `customTools` 在创建时提供，任意新增 Definition 的热注册属于内部机制。

本阶段采用预注册、稳定 Schema 的 Bootstrap/Dispatcher，Provider 在主进程 Registry 内动态解析。同 Session 中的 Provider 激活无需修改 Tool Definition。Session 重建与续接专项继续核对同一 Task/Run 所有权和 SQLite 快照，公开 API 证据随测试归档。

## 交付切片

### T2.1 统一 Provider 合同

在 capabilities 领域新增共享主进程执行合同及严格校验，覆盖输入、结果、错误、取消、幂等、副作用、provenance。可信上下文由宿主闭包构建，关联 Task、Run、generation、callId、Snapshot、当前授权引用和预算。辅助只读调用允许空 stepId，沿原 Task admission 的 safe_read 规则执行。

Native Adapter 继续调用原 Hana `office_file_stat` 与 `createWorkspaceFiles.stat`。Provider identity、软件版本和 source hash 与实际可用实现绑定，数据规范化后执行 Contract 校验。read-only 试点使用原 Execution Boundary 的 safe_read 资源和取消策略。

### T2.2 稳定入口与执行边界

新增有限的 `capability_inspect`、`capability_resolve`、`capability_execute` 内置入口。核心业务 Tool 保持原名称、Schema 和具体实现。三个入口通过既有 customTools、Manifest、Task admission、Journal admission 和 Execution Boundary 装配。

当前 `capability_execute` 的支持范围为已验证 safe_read Native Adapter，副作用级别由主进程 Adapter 决定。任何后续写入 Adapter 的接入须有独立的效应分类和已有业务准入映射。模型输入只包含需求/业务参数，Task/Run/Grant/Snapshot 授权由宿主构造和读回。

### T2.3 Task/Run Provider Snapshot

新增版本化 Snapshot 类型和本地 SQLite 附属表，记录 snapshotId、taskId、sessionId、runId、generation、registryRevision、Provider ID/软件版本/Contract 版本/source hash、需求、创建时间和证据引用。通过现有 Sql/transaction/serialized writer 和 publisher owner 围栏保存，Task 与 Journal 继续使用原事实来源。

Registry 增量增加不可变 Provider 版本记录，兼容 Phase1 单一当前记录并回填旧 Manifest/Binding 元数据。当前指针与历史版本分离。相同软件版本的来源或 Contract 声明变化执行失败关闭，可信内建包的软件身份随实际代码 digest 区分。Capability Definition 的发布版本仍保持不可变，显式 Contract 升级与多版本共存需要保留旧 Definition/Binding/Task 引用的可信迁移机制。

### T2.4 安全刷新

刷新发生在当前任务的能力解析/执行安全点。所需能力由缺失转为已验证可用时创建新 Snapshot。无关 Provider 的 Registry 变化保持当前选择及 Snapshot。普通 Provider 升级保留当前 Run 已选软件版本和 source hash，新 Run 可选择当前版本。

每次执行重读全局/版本撤销、当前健康和实际 scope。历史 Snapshot 仅作选择事实。旧代码 artifact 可用时使用其精确 identity，旧实现不可用时返回可诊断结果，再在安全点选择满足剩余需求的兼容 Provider。活动有副作用调用的锁和原 Execution Boundary 结束前保持原选择。

## 计划修改文件与迁移

- 新增 capabilities 领域的 Provider 执行合同、Snapshot Store、Dispatcher、任务级 Runtime，按领域职责拆分。
- 扩展 `capabilities/registry.ts` 的历史版本保存和查询，调整 Native Adapter 与 Resolver 的版本核验。
- 对 `session-state.ts`、`production-host.ts`、`pi-session.ts`、`tools/manifest.ts`、`education-tool-catalog.ts` 作薄接线。Task envelope/admission 如需调整，仅覆盖新增稳定入口的实际 effect。
- 新增 Phase2 真实 SQLite/Provider/Boundary 专项及真实 Pi+loopback SSE+生产 host 专项。
- Schema/Tool Schema/Skill 正文/凭据继续由原模块持有，Registry 和 Snapshot 保存元数据及引用。

## 验收矩阵

覆盖 P-01–P-05、R-01–R-06 和 Gate2 的当前阶段接缝。

1. 两个真实 Native Provider 经 `capability_execute`、原 Execution Boundary、Task/Journal admission 成功完成，同一 Task 的 auxiliary read 可直接执行。
2. 无效输入、失效 Run/generation、伪造 Snapshot/Provider ID、来源不符、Required/Conditional 缺口、越权路径及撤销被阻止。
3. 统一结果/错误/取消/副作用/provenance 严格校验，重复 callId 幂等，失败输出安全且可追溯。
4. 与当前任务有关的新 Provider 在同 Pi Session 后续安全点可用，Task/上下文/成果保持。
5. 无关 Provider 变化保持 Snapshot，普通升级保持当前 Run 的旧 version；撤销立即覆盖旧 Snapshot，新的 Run 可选择已验证新版本。
6. 实际旧 Phase1 SQLite 副本与新数据库迁移、冷启 Snapshot readback、版本不可变、CAS/并发、失败回滚通过。
7. 锁定 Pi API 的真实本地 SSE 集成、停止、重启与旧 Run 拒绝通过，真实付费请求保持 0。
8. 运行 build、renderer-components、原能力32项、原工具14项、Task/SQLite 与相关 Pi 边界回归，记录精确命令/通过数/失败/跳过/范围。报告前后耗时、Schema 请求负担及主进程影响。

## 恢复与回滚

迁移采用新增表和幂等回填，保留 Phase1 当前 Registry 文档与原 Task/Run/Journal。失败事务保持原 revision 和旧 Snapshot。回滚 Phase2 接线可恢复 Phase1 路径，新增历史版本/Snapshot 表保留供后续兼容读取。真实教师文件与已确认成果沿原事实来源保存。

Phase0 F01–F04 的权限、审批和恢复修复仍按 Phase3/6 的边界实施。页面与最终系统验收按 Phase7/8 实施。Gate2 通过后由总控继续下一阶段。
