import type {ToolDefinition} from '@earendil-works/pi-coding-agent';
import {createToolCatalog} from './vendor/hana/quality/core/tool-catalog';
import {ANSWER_QUALITY_PROMPT} from './answer-quality';
import {scienceResourceChoices} from '../../shared/science-resources';

// Local question search/read form the core knowledge path, like material search/read.
// Pin definitions already granted by the host. Complex delivery schemas load for file tasks.
const PINNED=new Set(['education_compute','prepare_education_tool','ask_teacher','read','read_education_memory','read_session_process','read_teacher_request','office_list_attachments','office_read_attachment','office_list_materials','education_search_materials','office_read_material','education_search_questions','education_read_question','office_list_files','office_read_text','search_teacher_knowledge','office_web_search','office_web_fetch','update_plan','update_task_plan','report_goal_progress','exec_command']);
PINNED.add('capability_inspect');
PINNED.add('capability_resolve');
PINNED.add('capability_execute');
const FILE_DELIVERY_TOOLS = ['education_check_delivery', 'education_create_report', 'office_create_text',
  'office_edit_text', 'office_create_document', 'office_deliver_files'];
const FILE_DELIVERY_REQUEST = /pptx?|powerpoint|docx?|pdf|xlsx?|excel|html|svg|课件|讲义|教案|学案|备课包|演示|报告|文档|表格|导出|保存|写入|修改文件|创建文件|生成文件|制作文件|create.*file|write.*file|export|save/i;
export const TOOL_DISCOVERY_NAME='find_education_tools';
/** Keep identity fingerprints unchanged; only the provider-facing assembly is scoped. */
export function createEducationToolCatalog(prompt:string,definitions:readonly ToolDefinition[]) {
  const catalog=createToolCatalog(),loaded=new Set<string>();
  const deferred=definitions.length>24;
  const rules=new Map<string,string[]>(),common:string[]=[];
  for(const line of prompt.split('\n')){
    const owners=definitions.filter(d=>new RegExp(`(?<![a-zA-Z0-9_])${d.name}(?![a-zA-Z0-9_])`).test(line));
    // Only move complete domain lines. General authority/privacy rules stay global.
    if(owners.length&&line.length>100){for(const owner of owners)rules.set(owner.name,[...(rules.get(owner.name)||[]),line]);}
    else common.push(line);
  }
  for(const def of definitions)catalog.registerSource(def.name,[{name:def.name,description:def.description,serverId:'education',origin:'builtin',schemaRef:()=>def.parameters}]);
  const description=(def:ToolDefinition)=>[def.description,...(rules.get(def.name)||[])].join('\n');
  function reset(query:string){
    loaded.clear();
    for(const def of definitions)if(!deferred||PINNED.has(def.name))loaded.add(def.name);
    const needsFiles = FILE_DELIVERY_REQUEST.test(query) || FILE_DELIVERY_TOOLS.some(name => query.includes(name));
    // Office schemas are large. Load the complete existing delivery path when
    // the task needs it, while ordinary questions retain discovery and readers.
    if (deferred && needsFiles) {
      for (const name of FILE_DELIVERY_TOOLS) {
        if (definitions.some(definition => definition.name === name)) loaded.add(name);
      }
    }
    // Hana BM25 adds task-relevant tools without an extra model request.
    if(deferred)for(const hit of catalog.search(query,{limit:6})){
      if(needsFiles || !FILE_DELIVERY_TOOLS.includes(hit.name))loaded.add(hit.name);
    }
  }
  reset('');
  const tool:ToolDefinition={name:TOOL_DISCOVERY_NAME,label:'查找可用能力',description:'按教师任务查找当前已授权工具，加载参数及领域说明；需要的能力未列出时先查找。不会执行任务或增加权限。query可用中文或精确工具名。',
    parameters:{type:'object',properties:{query:{type:'string',minLength:1,maxLength:160}},required:['query'],additionalProperties:false} as ToolDefinition['parameters'],
    execute:async(_id,args,signal)=>{
      signal?.throwIfAborted();
      if(!args||typeof args!=='object'||Array.isArray(args)||Object.keys(args).join(',')!=='query'||typeof (args as {query?:unknown}).query!=='string')throw Error('invalid_input');
      const query=(args as {query:string}).query.trim();if(!query||query.length>160)throw Error('invalid_input');
      const hits=catalog.search(query,{limit:6});
      for(const hit of hits)loaded.add(hit.name);
      const resources=/资源|许可|仿真|科学|浮力|Anatomy|PhET|science|licen[cs]e|resource/i.test(query)?scienceResourceChoices(definitions.map(d=>d.name)):undefined;
      return {content:[{type:'text',text:JSON.stringify({tools:hits.map(hit=>{const def=definitions.find(d=>d.name===hit.name)!;return{name:def.name,description:description(def),parameters:def.parameters};}),...(resources?.length?{scienceResources:resources}:{}),note:'仅加载说明；执行仍须通过宿主授权与确认。资源条目不增加许可或文件权限。'})}],details:{success:true,data:{count:hits.length}}};
    }};
  return {tool,reset,description,
    exposed:(name:string)=>name===TOOL_DISCOVERY_NAME||loaded.has(name),
    prompt:[...common,ANSWER_QUALITY_PROMPT,deferred?'可通过 find_education_tools 查找尚未加载的教育、文件制作及外部服务工具。目录摘要只是能力说明，不表示已执行或有资料。\n'+catalog.manifest(1800).text:''].filter(Boolean).join('\n'),
    deferred,
  };
}
