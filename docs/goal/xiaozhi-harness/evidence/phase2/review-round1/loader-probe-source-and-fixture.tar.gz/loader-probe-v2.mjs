import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const desktop='D:/WorkProject/EduProject-harness/apps/desktop';
await import(pathToFileURL(desktop+'/scripts/office-agent/register-source.mjs'));
const {loadNativeStatExecutable,currentNativeStatArtifact}=await import(pathToFileURL(desktop+'/src/main/xiaozhi-agent/capabilities/native-stat-executable.ts'));
const ownRoot=path.dirname(fileURLToPath(import.meta.url));
const source=path.join(desktop,'src/main/xiaozhi-agent/capabilities/generated',currentNativeStatArtifact.file);
const trustedRequire=createRequire(desktop+'/package.json');
const observations=[];
const plain=path.join(ownRoot,'plain-case','capability-artifacts');fs.mkdirSync(plain,{recursive:true});fs.copyFileSync(source,path.join(plain,currentNativeStatArtifact.file));
const artifactRequire=createRequire(path.join(plain,currentNativeStatArtifact.file));
let plainError=null;try{loadNativeStatExecutable('hana',currentNativeStatArtifact,plain);}catch(error){plainError={code:error.code,message:error.message};}
const resolution={};for(const name of ['ipaddr.js','undici']){try{resolution[name]=artifactRequire.resolve(name);}catch(error){resolution[name]=error.code;}}
observations.push({name:'Current-machine repository-external artifact baseline',plainError,resolution,meaning:'Current machine has ancestor/global modules. Missing dependency on a clean machine remains unverified.'});
globalThis.__gate2BenignDependencyMarker=[];
const controlled=path.join(ownRoot,'controlled-case','capability-artifacts');fs.mkdirSync(controlled,{recursive:true});fs.copyFileSync(source,path.join(controlled,currentNativeStatArtifact.file));
for(const name of ['ipaddr.js','undici']){
 const folder=path.join(ownRoot,'controlled-case','node_modules',name);fs.mkdirSync(folder,{recursive:true});
 fs.writeFileSync(path.join(folder,'package.json'),JSON.stringify({name,main:'index.cjs'}));
 fs.writeFileSync(path.join(folder,'index.cjs'),'globalThis.__gate2BenignDependencyMarker.push('+JSON.stringify('owned-temp-proxy:'+name)+');\nmodule.exports = require('+JSON.stringify(trustedRequire.resolve(name))+');\n');
}
const loaded=loadNativeStatExecutable('hana',currentNativeStatArtifact,controlled);
assert.equal(loaded.hash,currentNativeStatArtifact.sha256);assert.deepEqual(globalThis.__gate2BenignDependencyMarker,['owned-temp-proxy:ipaddr.js','owned-temp-proxy:undici']);
observations.push({name:'Same verified bundle resolves own TEMP data-root dependency proxies',hash:loaded.hash,markers:globalThis.__gate2BenignDependencyMarker,resolution:Object.fromEntries(['ipaddr.js','undici'].map(name=>[name,createRequire(path.join(controlled,currentNativeStatArtifact.file)).resolve(name)]))});
const report={success:true,observations,loaderSha256:createHash('sha256').update(fs.readFileSync(path.join(desktop,'src/main/xiaozhi-agent/capabilities/native-stat-executable.ts'))).digest('hex'),scope:'Frozen source loader and current real bundle. Only owned TEMP benign global markers forwarding trusted package implementations. No out/build/model/user material access.',earlierFailedAssumption:'Two initial runs asserted MODULE_NOT_FOUND and failed because this machine resolves C:/Users/ZhouXuan/node_modules. Original loader-probe.mjs preserved.'};
fs.writeFileSync(path.join(ownRoot,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({success:true,output:ownRoot,observations},null,2));
