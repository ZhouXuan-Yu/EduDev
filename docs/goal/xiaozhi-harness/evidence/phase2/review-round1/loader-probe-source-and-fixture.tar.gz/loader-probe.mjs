import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const desktop='D:/WorkProject/EduProject-harness/apps/desktop';
await import(pathToFileURL(desktop+'/scripts/office-agent/register-source.mjs'));
const {loadNativeStatExecutable,currentNativeStatArtifact}=await import(pathToFileURL(desktop+'/src/main/xiaozhi-agent/capabilities/native-stat-executable.ts'));
const ownRoot=path.dirname(fileURLToPath(import.meta.url));
const retained=path.join(ownRoot,'data','capability-artifacts');fs.mkdirSync(retained,{recursive:true});
const source=path.join(desktop,'src/main/xiaozhi-agent/capabilities/generated',currentNativeStatArtifact.file);
fs.copyFileSync(source,path.join(retained,currentNativeStatArtifact.file));
const require=createRequire(desktop+'/package.json');
const observations=[];
let missing;
try{loadNativeStatExecutable('hana',currentNativeStatArtifact,retained);}catch(error){missing={code:error.code,message:error.message};}
assert(missing);assert.equal(missing.code,'MODULE_NOT_FOUND');observations.push({name:'Outside-repository retained directory without node_modules',actual:missing});
globalThis.__gate2BenignDependencyMarker=[];
for(const name of ['ipaddr.js','undici']){
 const folder=path.join(ownRoot,'data','node_modules',name);fs.mkdirSync(folder,{recursive:true});
 fs.writeFileSync(path.join(folder,'package.json'),JSON.stringify({name,main:'index.cjs'}));
 const trustedEntry=require.resolve(name);
 fs.writeFileSync(path.join(folder,'index.cjs'),'globalThis.__gate2BenignDependencyMarker.push('+JSON.stringify('owned-temp-proxy:'+name)+');\nmodule.exports = require('+JSON.stringify(trustedEntry)+');\n');
}
const loaded=loadNativeStatExecutable('hana',currentNativeStatArtifact,retained);
assert.equal(loaded.hash,currentNativeStatArtifact.sha256);assert.deepEqual(globalThis.__gate2BenignDependencyMarker,['owned-temp-proxy:ipaddr.js','owned-temp-proxy:undici']);
observations.push({name:'Same verified bundle resolves own TEMP data-root dependency proxies',hash:loaded.hash,markers:globalThis.__gate2BenignDependencyMarker});
fs.writeFileSync(path.join(ownRoot,'report.json'),JSON.stringify({success:true,observations,scope:'Frozen source loader and current real artifact. Only owned TEMP benign global markers and trusted module forwarding. No out/build/model/user data access.'},null,2));
console.log(JSON.stringify({success:true,output:ownRoot,observations},null,2));
