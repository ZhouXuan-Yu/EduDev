import {randomUUID} from 'node:crypto';
import type {Sql} from '../session-state';
import type {JournalOwner} from '../events/journal';
import {createTaskState} from '../tasks/task-state';
import {validTaskOwner} from '../../../shared/xiaozhi-task';
import type {ProviderSnapshot} from './provider-contract';
import {protocolHash, snapshotProtocolInput, validCapabilityRequirement, validCapabilityResolution} from './validation';

const table = 'xiaozhi_capability_snapshots_v1';
export function validProviderSnapshot(value: unknown): value is ProviderSnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const snapshot = value as ProviderSnapshot;
  if (Object.keys(snapshot).sort().join(',') !== 'capabilityId,createdAt,evidenceRefs,generation,providerHash,registryRevision,requirement,runId,schema,selection,sessionId,snapshotId,taskId') return false;
  if (snapshot.schema !== 'xiaozhi.capability-snapshot.v1' || !/^xicap_[a-f0-9-]{36}$/u.test(snapshot.snapshotId) || !/^xitask_[a-f0-9]{64}$/u.test(snapshot.taskId) || !validTaskOwner({sessionId:snapshot.sessionId,runId:snapshot.runId,generation:snapshot.generation})) return false;
  if (!validCapabilityRequirement(snapshot.requirement) || snapshot.capabilityId !== snapshot.requirement.capabilityId || !snapshot.selection || snapshot.selection.contractVersion !== snapshot.requirement.contractVersion) return false;
  if (!/^[a-f0-9]{64}$/u.test(snapshot.providerHash) || !Number.isFinite(Date.parse(snapshot.createdAt)) || !Array.isArray(snapshot.evidenceRefs) || snapshot.evidenceRefs.length > 128 || snapshot.evidenceRefs.some(reference => typeof reference !== 'string' || reference.length > 512)) return false;
  return validCapabilityResolution({capabilityId:snapshot.capabilityId,status:snapshot.selection.level === 'full' ? 'resolved' : 'partial',selectedProviders:[snapshot.selection],alternatives:[],acceptedLimitations:snapshot.selection.limitations,excludedProviders:[],blockedReasons:[],registryRevision:snapshot.registryRevision});
}
export function createProviderSnapshotStore(sql: Sql) {
  async function assertCurrent(work: Sql, owner: JournalOwner, taskId: string) {
    const state = createTaskState(work,{sanitize:async () => {throw Error('invalid_input');}});
    const task = await state.latest(owner.sessionId);
    if (!task || task.id !== taskId || task.state !== 'active' || task.binding?.runId !== owner.runId || task.binding.generation !== owner.generation) throw Error('permission_denied');
    await state.validateCurrent(owner,task.id,task.revision);
  }
  function decode(row: Record<string,unknown>): ProviderSnapshot {
    try {
      const snapshot: unknown = JSON.parse(String(row.snapshot_json));
      if (!validProviderSnapshot(snapshot) || protocolHash(snapshot) !== row.snapshot_hash) throw Error();
      return snapshot;
    } catch { throw Error('capability_snapshot_corrupt'); }
  }
  return {
    async migrate() {
      await sql.run(`CREATE TABLE IF NOT EXISTS ${table}(snapshot_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,session_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,capability_id TEXT NOT NULL,snapshot_json TEXT NOT NULL,snapshot_hash TEXT NOT NULL,created_at TEXT NOT NULL)`);
      await sql.run(`CREATE INDEX IF NOT EXISTS xiaozhi_capability_snapshot_owner ON ${table}(task_id,run_id,generation,capability_id)`);
    },
    async current(owner: JournalOwner,taskId: string,capabilityId: string) {
      await assertCurrent(sql,owner,taskId);
      const row = (await sql.all(`SELECT snapshot_json,snapshot_hash FROM ${table} WHERE task_id=? AND session_id=? AND run_id=? AND generation=? AND capability_id=? ORDER BY rowid DESC LIMIT 1`,[taskId,owner.sessionId,owner.runId,owner.generation,capabilityId]))[0];
      return row ? decode(row) : null;
    },
    async save(owner: JournalOwner, taskId: string, value: Omit<ProviderSnapshot,'schema'|'snapshotId'|'taskId'|'sessionId'|'runId'|'generation'|'createdAt'>) {
      const input = snapshotProtocolInput(value) as typeof value;
      const snapshot: ProviderSnapshot = {...structuredClone(input),schema:'xiaozhi.capability-snapshot.v1',snapshotId:'xicap_'+randomUUID(),taskId,sessionId:owner.sessionId,runId:owner.runId,generation:owner.generation,createdAt:new Date().toISOString()};
      if (!validProviderSnapshot(snapshot) || !sql.transaction) throw Error('capability_invalid_snapshot');
      return sql.transaction(async work => {
        await assertCurrent(work,owner,taskId);
        const revision = (await work.all('SELECT revision FROM xiaozhi_capability_registry_v1 WHERE id=1'))[0];
        if (Number(revision?.revision) !== snapshot.registryRevision) throw Error('source_changed');
        await work.run(`INSERT INTO ${table}(snapshot_id,task_id,session_id,run_id,generation,capability_id,snapshot_json,snapshot_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?)`,[snapshot.snapshotId,taskId,owner.sessionId,owner.runId,owner.generation,snapshot.capabilityId,JSON.stringify(snapshot),protocolHash(snapshot),snapshot.createdAt]);
        return snapshot;
      });
    },
    async history(taskId: string) {
      if (!/^xitask_[a-f0-9]{64}$/u.test(taskId)) throw Error('invalid_input');
      return (await sql.all(`SELECT snapshot_json,snapshot_hash FROM ${table} WHERE task_id=? ORDER BY rowid`,[taskId])).map(decode);
    },
  };
}
export type ProviderSnapshotStore = ReturnType<typeof createProviderSnapshotStore>;
