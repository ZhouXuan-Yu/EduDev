# Phase8 逐HTTP计量辅助交付

状态 **FROZEN_FOR_ROOT_REVIEW**，2026-11-17。实施者 /root/phase4_resume_independent，沿当前Sol模型。辅助专项最终PASS 12/12，exit0，真实模型调用0。

## 范围与文件

本轮仅新增5个 `apps/desktop/scripts/xiaozhi-agent/phase8-*.mjs` 并在 `docs/goal/xiaozhi-harness/PHASE_8_REAL_MODEL_ACCEPTANCE_PLAN.md`增加合同及实施检查点。源码逐文件bytes/SHA256与快照见本目录 `freeze.json`、`source-snapshot/`。生产、Phase5、其他Goal文件、out无本轮修改，commit与真实网络模型调用为0。

- ledger模块使用Node内置SQLite，原子预留、不可提升/重置的limit与导入量、单调全局序号、状态事件及后续Run关联。
- counting-proxy模块固定127.0.0.1 listener、单POST route、预配置HTTPS完整目标、Authorization透传和header白名单。预留及dispatch两次SQLite提交均在构造HTTP request之前。自动代理重试0，所有redirect拒绝，超额上游前429。
- CLI提供serve/status/bind-run，serve配置与精确示例在计划检查点。status/bind-run的missing路径失败关闭，CLI不接受fixtureHttp或key配置。两worktree传入同一绝对SQLite路径。
- smoke与worker为合成测试基础设施。HTTP fixture模式在模块中显式开放给127.0.0.1，CLI继续要求HTTPS。

原单Run生产预算、业务Task与Effect沿原系统。此辅助数据库仅承担跨worktree验收用量。实际全Goal共享DB路径、核对后的initialUsed、正式provider endpoint及UI/SDK baseURL路由仍由后续验收接线冻结。

## 精确命令与结果

cwd为 `D:/WorkProject/EduProject-harness/apps/desktop`。

```powershell
node scripts/xiaozhi-agent/phase8-budget-smoke.mjs
```

测试先行的red为缺模块预期失败，exit1、0用例，原report在 `%TEMP%/xiaozhi-phase8-budget-R4Q7AU/report.json`。首次完整实现集中运行10/10 exit0，原report在 `%TEMP%/xiaozhi-phase8-budget-KMaDKs/report.json`。补齐CLI状态与16MiB慢消费者的当前冻结候选最终12/12 exit0，原report在 `%TEMP%/xiaozhi-phase8-budget-vuZ0fX/report.json`。上述全部报告与三份原始日志已复制本目录，原件保留。

5份mjs逐个 `node --check <absolute-file>` 均exit0。仓根定向 `git diff --check -- apps/desktop/scripts/xiaozhi-agent/phase8-* docs/goal/xiaozhi-harness/PHASE_8_REAL_MODEL_ACCEPTANCE_PLAN.md` exit0。

实际环境为Node v24.12.0、SQLite 3.50.4，见 `environment.log`。无需新增包。

## 已执行覆盖

1. cap3/initialUsed1，后续仅能预留2份；重开额度仍耗尽，改cap或导入量拒绝，201上限拒绝，错误终态转换拒绝。WAL/FULL实际读回。
2. unknown extra、秘密样式label、越界round及不安全evidenceRef拒绝，零预留；runtime Run空位绑定一次，重复同值幂等，异值冲突并保留绑定event。
3. 8个真实Node进程同一WAL文件同时请求96次，cap37/initialUsed3恰好预留34，序号唯一，used37。子进程退出已等待。
4. reserved及dispatching后分别SIGKILL，重开保留两份消耗，状态未完成且余额0。
5. 真HTTP fixture逐块SSE流在结束前可读，2次SDK式POST重试分别计数；上游始终仅收到/fixed，Authorization只转向该固定endpoint，extra header未透传。503原样传回并记录http_error。
6. 307零跟随，第二origin命中0；挂起请求timeout记录timed_out并关上游socket；首响应前socket断开记录failed。
7. 16MiB慢消费者实际暂停后恢复，共16,777,263 bytes逐字节计量，上游256次drain且结束晚于消费者恢复。
8. CLI独立进程读取同DB及绑定Run，missing status文件未被创建。
9. 客户端中止SSE记录client_cancelled，上游socket收束；上游截断SSE记录failed，额度均保留。
10. oversized Content-Length预拒绝无消耗；9个并发POST在cap4只4个抵达上游，其他5个429。
11. 独立proxy进程真正发送HTTP且fixture已收到后SIGKILL，重开原dispatching预留占满cap1。
12. 原始DB/WAL字节检查无合成key、request body及response文本，SQLite integrity_check均ok。

报告包含断言组级真实耗时，保留所有失败。背压功能样本用于传输正确性，真实provider的网络、首token与生成性能保持NOT_TESTED。

## 后续独立核验边界

当前共12个集中断言组，业务验收与真实UI请求全覆盖保持NOT_TESTED。后续需在旧A/新版B实际配置上确认所有模型请求确实走该route及同一个DB，并将ledger序号与runtime实际request/Run交叉对应。正式HTTPS/TLS、provider端响应、真实SDK重试模式和系统断电存储耐久性本轮未执行。SIGKILL证据覆盖进程强停，WAL/FULL持久提交依赖文件系统与硬件的既有保证。

reserved/dispatching而无finishedAt代表未知预留，始终计入used；需要保留与真实日志关联，额度无退款入口。配置标签仅为预绑定维度，UI提交与HTTP次数分别观察。SDK式重试在专项中由多个真实POST模拟，逐HTTP硬计数不依赖SDK重试事件。

回滚辅助接线前停止proxy并保留共享SQLite、WAL和证据，预算记录继续沿固定数据库保存。完成使用后解除测试baseURL接线，原业务数据及生产单Run预算沿原系统。
