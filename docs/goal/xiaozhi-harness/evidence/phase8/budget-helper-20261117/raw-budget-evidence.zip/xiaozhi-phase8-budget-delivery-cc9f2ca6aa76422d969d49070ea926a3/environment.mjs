import {DatabaseSync} from 'node:sqlite';
const database = new DatabaseSync(':memory:');
console.log(JSON.stringify({node:process.version,sqlite:database.prepare('SELECT sqlite_version() AS version').get().version}));
database.close();
