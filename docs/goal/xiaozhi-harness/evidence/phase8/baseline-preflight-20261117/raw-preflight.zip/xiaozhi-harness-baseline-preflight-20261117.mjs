import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const desktop = fs.realpathSync(process.cwd());
const load = relative => import(pathToFileURL(path.join(desktop, relative)).href);
const { _electron } = await load('node_modules/playwright/index.mjs');
const { fingerprint, sha256 } = await load('scripts/acceptance/evidence.mjs');
const { testMain, assertIsolatedPiMain } = await load('scripts/acceptance/build-root.mjs');
const output = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaozhi-harness-baseline-preflight-'));
const data = path.join(output, 'data');
const profile = path.join(output, 'profile');
const before = fingerprint(path.join(desktop, 'out'));
const report = {
  scope: 'Old d50ef330 own dependency/build startup only. Real-model A/B remains NOT_TESTED.',
  success: false,
  paidCalls: 0,
  desktop,
  output,
  build: { files: before.files.length, sha256: before.sha256 },
  lockSha256: sha256(fs.readFileSync(path.join(desktop, 'package-lock.json'))),
  errors: [],
  screenshots: [],
  checks: [],
};
let app;
try {
  const env = {
    ...process.env,
    OMNI_EDU_DATA_ROOT: data,
    OMNI_EDU_REPO_ROOT: path.resolve(desktop, '../..'),
    OMNI_EDU_XIAOZHI_PI: '1',
    OMNI_EDU_E2E_DIALOG_MODE: '1',
    DEEPSEEK_API_KEY: '',
    DEEPSEEK_MODEL: '',
  };
  delete env.ELECTRON_RUN_AS_NODE;
  delete env.NODE_OPTIONS;
  app = await _electron.launch({
    args: [testMain(desktop), `--user-data-dir=${profile}`],
    env,
    timeout: 60000,
  });
  const page = await app.firstWindow();
  page.on('pageerror', error => report.errors.push(String(error)));
  await page.getByTestId('xiaozhi-pi-workspace').waitFor({ timeout: 60000 });
  await page.getByTestId('office-prompt-input').waitFor({ state: 'visible' });
  report.isolation = await assertIsolatedPiMain(app, testMain(desktop), profile);
  report.process = await app.evaluate(({ app }) => ({
    pid: process.pid,
    versions: process.versions,
    appPath: app.getAppPath(),
  }));
  for (const [width, height] of [[1366, 768], [1920, 1080]]) {
    await app.evaluate(({ BrowserWindow }, bounds) => {
      const window = BrowserWindow.getAllWindows().find(value => value.isVisible());
      if (window.isMaximized()) window.unmaximize();
      window.setBounds(bounds);
    }, { width, height });
    await page.getByTestId('office-prompt-input').waitFor({ state: 'visible' });
    const file = path.join(output, `baseline-${width}x${height}.png`);
    await page.screenshot({ path: file });
    report.screenshots.push({ file, sha256: sha256(fs.readFileSync(file)) });
  }
  const db = new DatabaseSync(path.join(data, 'app.db'), { readOnly: true });
  try {
    report.tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
    assert(report.tables.length > 0);
  } finally {
    db.close();
  }
  assert.equal(report.errors.length, 0);
  report.checks.push({ name: 'Own old baseline launches Pi workspace with isolated profile and SQLite', pass: true });
  report.checks.push({ name: 'Original composer visible at both native window sizes', pass: true });
  await app.close();
  app = undefined;
  const after = fingerprint(path.join(desktop, 'out'));
  assert.equal(after.sha256, before.sha256);
  report.checks.push({ name: 'Exact build bytes unchanged after clean close', pass: true });
  report.success = true;
} catch (error) {
  report.error = String(error.stack || error);
  process.exitCode = 1;
} finally {
  if (app) await app.close().catch(error => { report.closeError = String(error); });
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
  fs.writeFileSync(path.join(output, 'build-fingerprint.json'), JSON.stringify(before, null, 2) + '\n');
  console.log(JSON.stringify({ success: report.success, output, error: report.error, checks: report.checks.length }));
}
