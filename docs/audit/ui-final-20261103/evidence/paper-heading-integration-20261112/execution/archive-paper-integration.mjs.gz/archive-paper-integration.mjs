import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const repository = path.resolve(desktop, '../..');
const evidence = path.join(repository, 'docs/audit/ui-final-20261103/evidence');
const destination = path.join(evidence, 'paper-heading-integration-20261112');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  assert(fs.realpathSync(root).startsWith(owned + path.sep));
  for (const name of names) selected.push({source:path.join(root, name), name:prefix + '/' + name});
}
add(base, ['archive-paper-integration.mjs', 'capture.mjs', 'paper-heading-integrated-before.json',
  'paper-heading-integrated-pins.json', 'paper-heading-renderer-identity.json',
  'build-paper-heading-integrated.log', 'capture-paper-heading-integrated.log',
  'paper-heading-integrated-interactions.log', 'workbench-paper-heading-integrated.log',
  'capability-protocol-paper-integrated.log', 'capability-protocol-paper-integrated-report.json',
  'capability-production-paper-integrated.log', 'components-paper-integrated.log',
  'styles-paper-integrated.log', 'audit-paper-integrated.json', 'merge-paper-phase1.log'], 'execution');
const knownImages = new Map();
for (const directory of ['teaching-alignment-20261112', 'library-settings-alignment-20261112',
  'studio-students-20261112', 'paper-heading-20261112']) {
  const root = path.join(evidence, directory);
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json')));
  for (const file of manifest.files.filter(file => file.file.endsWith('.png'))) {
    knownImages.set(file.sha256, path.join(root, file.file));
  }
}
const capture = path.join(base, 'paper-heading-integrated-0YlYJn');
const report = JSON.parse(fs.readFileSync(path.join(capture, 'report.json')));
assert.equal(report.success, true);
const geometry = report.samples.filter(sample => sample.page === 'paper').map(sample => {
  const heading = {x:sample.actual.heading.x - sample.reference.heading.x,
    y:sample.actual.heading.y - sample.chrome.actual - sample.reference.heading.y + sample.chrome.reference,
    height:sample.actual.heading.height - sample.reference.heading.height};
  const mainStart = sample.actual.studio.layout.y - sample.chrome.actual -
    sample.reference.studio.layout.y + sample.chrome.reference;
  for (const value of Object.values(heading)) assert.equal(value, 0);
  assert.equal(mainStart, 0);
  return {width:sample.width, heading, mainStart};
});
add(capture, ['report.json'], 'current');
const reusedImages = [];
for (const name of fs.readdirSync(capture).filter(name => name.endsWith('.png'))) {
  const digest = sha256(fs.readFileSync(path.join(capture, name)));
  const known = knownImages.get(digest);
  if (!known) {
    add(capture, [name], 'current');
    continue;
  }
  const repositoryPath = path.relative(repository, known).replaceAll('\\', '/');
  const blob = execFileSync('git', ['show', 'HEAD:' + repositoryPath], {cwd:repository, maxBuffer:2000000});
  assert.equal(sha256(blob), digest);
  reusedImages.push({currentName:name, file:path.relative(destination, known).replaceAll('\\', '/'), sha256:digest});
}
for (const [directory, prefix, names] of [
  ['paper-first-entry-ghq8Xo', 'paper', ['report.json']],
  ['workbench-z1u6Gh', 'workbench', ['report.json']],
  ['xiaozhi-agent/capability-phase1-production-XVoHik', 'capability-production', ['report.json', 'worker.log']],
]) {
  const root = path.join(owned, directory);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, true);
  add(root, names, prefix);
}
const files = [];
for (const {source, name} of selected) {
  const raw = fs.readFileSync(source), png = name.endsWith('.png');
  if (!png) assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalSha256:sha256(raw),
    encoding:png ? 'original-png' : 'gzip'});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope:'Formal ee1a7bd integration with independent main-process Phase1 changes. Current 27 pairs, 11 paper, 25 workbench, 32 protocol, 8 controlled loopback production checks. No profiles, databases or builds.',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'paper-heading-integrated-pins.json'))),
  geometry, reusedImages, files,
}, null, 2));
console.log(JSON.stringify({destination, files:files.length, reusedImages:reusedImages.length}));
