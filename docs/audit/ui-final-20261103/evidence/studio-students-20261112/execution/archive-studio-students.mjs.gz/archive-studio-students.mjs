import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/studio-students-20261112');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  assert(fs.realpathSync(root).startsWith(owned + path.sep));
  for (const name of names) selected.push({source:path.join(root, name), name:prefix + '/' + name});
}
add(base, ['archive-studio-students.mjs', 'capture.mjs', 'studio-students-before.json',
  'studio-students-pins.json', 'studio-students-geometry.json', 'build-studio-students.log',
  'components-studio-students.log', 'styles-studio-students.log', 'audit-studio-students.json',
  'capture-studio-students.log', 'capture-studio-students-diagnostic.log', 'paper-studio-students.log',
  'workbench-studio-students.log', 'start-resumed-main.log', 'resumed-runtime-process.json'], 'execution');
for (const [name, prefix, expected] of [
  ['studio-students-IfJQJ5', 'first-launch-failed', false],
  ['studio-students-Mya1wB', 'current', true],
]) {
  const root = path.join(base, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, expected);
  add(root, fs.readdirSync(root).filter(file => ['report.json', 'bootstrap-state.json'].includes(file) ||
    /^(paper|students)-.*\.png$/.test(file)), prefix);
}
const before = path.join(base, 'library-settings-integrated-cvXMjp');
add(before, fs.readdirSync(before).filter(file => /^(paper|students)-.*-actual\.png$/.test(file)), 'before');
for (const [name, prefix, images] of [
  ['paper-first-entry-5vnF8B', 'paper', true], ['workbench-dlnDCn', 'workbench', false],
]) {
  const root = path.join(owned, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, true);
  add(root, fs.readdirSync(root).filter(file => file === 'report.json' || images && file.endsWith('.png')), prefix);
}
const files = [];
for (const {source, name} of selected) {
  const raw = fs.readFileSync(source), png = name.endsWith('.png');
  if (!png) assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalSha256:sha256(raw),
    encoding:png ? 'original-png' : 'gzip'});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope:'Student heading and first-entry paper responsive alignment. Controlled empty/manual QA. Retains initial window timeout. Excludes databases, profiles, builds and daily screenshots.',
  visualAcceptance:'Partial. Three student title comparisons and paper column widths match. Paper header offset and further source/chapter UI remain.',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'studio-students-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination, files:files.length, bytes:files.reduce((sum, file) => sum + file.bytes, 0)}));
