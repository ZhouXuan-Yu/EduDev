// Attach only to the already launched diagnostic page supplied by the caller.
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite');
module.exports=function controller(page,mainRead){
  const output=__dirname;
  const report=JSON.parse(fs.readFileSync(path.join(output,'diagnosis.json')));
  const persist=()=>fs.writeFileSync(path.join(output,'diagnosis.json'),JSON.stringify(report,null,2));
  const trigger=()=>page.locator('.office-composer-container:visible button[aria-label="添加本地附件"]');
  const wrapper=()=>trigger().locator('..');
  const input=()=>page.locator('.office-composer-container:visible [data-testid="office-prompt-input"]');
  const fileInput=()=>page.locator('.office-composer-container:visible input[type="file"]');
  const ledger=()=>{
    const db=new DatabaseSync(path.join(output,'data/app.db'),{readOnly:true});
    try{return Object.fromEntries(Object.keys(report.ledgerBefore).map(table=>[table,db.prepare(`SELECT count(*) n FROM ${table}`).get().n]));}
    finally{db.close();}
  };
  async function noAdmission(label){
    const network=await mainRead('globalThis.__composerHttp');assert(Array.isArray(network)&&network.length===0);report.networkAttempts=network;
    const value=ledger();assert.deepEqual(value,report.ledgerBefore);
    const sessions=await page.evaluate(async()=>{
      const list=await window.omniEdu.listAiConversations();
      return Promise.all(list.sessions.map(async session=>{const snapshot=await window.omniEdu.getXiaozhiSnapshot(session.id);return {id:session.id,running:snapshot.running,turns:snapshot.projection.turns.length,approvals:snapshot.approvals.length};}));
    });
    assert(sessions.every(s=>!s.running&&s.turns===0&&s.approvals===0));
    report.lastZeroAdmission={label,ledger:value,sessions};persist();
  }
  async function config(){return page.evaluate(async()=>{
    const id=document.querySelector('.office-composer-container').getAttribute('data-session-id');
    const snapshot=await window.omniEdu.getXiaozhiSnapshot(id);
    const settings=await window.omniEdu.getXiaozhiSettings({sessionId:id});
    if(!settings.ok)throw Error('Local model settings unavailable');
    return {permission:localStorage.getItem('xiaozhi.permissionMode.v1'),workspace:snapshot.workspace??null,memoryScope:snapshot.memoryScope??null,fileWritesEnabled:snapshot.fileWritesEnabled??null,approvals:snapshot.approvals,models:settings.value};
  });}
  async function snapshot(label){
    const value=await page.evaluate(()=>{
      const describe=element=>({tag:element.tagName,role:element.getAttribute('role'),label:element.getAttribute('aria-label'),slot:element.getAttribute('data-slot'),tabIndex:element.tabIndex,focused:element===document.activeElement});
      const button=document.querySelector('.office-composer-container button[aria-label="添加本地附件"]');
      return {hasFocus:document.hasFocus(),active:describe(document.activeElement),ancestors:[button,button.parentElement].map(describe),events:window.__composerDiagnosticEvents.splice(0)};
    });
    report.events.push({label,...value});persist();return value;
  }
  async function attempt(label,prepare){
    const draft=await input().inputValue(),before=await config();
    assert.equal(await trigger().count(),1);assert(!await trigger().isDisabled());
    assert.equal(await fileInput().count(),1);assert(await fileInput().getAttribute('accept'));assert.equal(await fileInput().getAttribute('multiple'),'');
    await prepare();await snapshot(label+'-before');
    const start=Date.now();
    const pending=page.waitForEvent('filechooser').then(value=>({value}),error=>({error:String(error.message)}));
    await page.keyboard.press('Enter');
    const result=await pending;
    const attempt={label,elapsedMs:Date.now()-start,chooser:!!result.value,error:result.error};
    if(result.value){
      assert(result.value.isMultiple());await result.value.setFiles([]);
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      await page.keyboard.press('Escape');
      attempt.innerButtonFocused=await trigger().evaluate(element=>document.activeElement===element);
      attempt.wrapperFocused=await wrapper().evaluate(element=>document.activeElement===element);
    }
    assert.equal(await fileInput().evaluate(element=>element.files.length),0);
    assert.equal(await input().inputValue(),draft);assert.deepEqual(await config(),before);
    attempt.configUnchanged=true;attempt.draftUnchanged=true;attempt.emptyFileList=true;
    report.attempts.push(attempt);await snapshot(label+'-after');await noAdmission(label);
    await page.screenshot({path:path.join(output,label+'.png')});persist();return attempt;
  }
  async function originalSequence(){
    const {composerJourney}=await import('../../../scripts/acceptance/ui-final-composer-journey.mjs');
    const stop=Symbol('diagnostic-terminal');
    report.sequence=[];
    try{
      await composerJourney({getPage:()=>page,output,report,check:async(id,name,work)=>{
        if(id==='A03-session-drafts')throw stop;
        try{await work();await noAdmission(id);report.sequence.push({id,status:'PASS'});}
        catch(error){report.sequence.push({id,status:'FAIL',message:String(error.message)});throw error;}
        finally{persist();}
      },notRun:(id,reason)=>{throw Error(id+reason);},assertNoAdmission:noAdmission,resize:()=>{throw Error('outside scope');},relaunch:()=>{throw Error('launch limit');}});
    }catch(error){if(error!==stop)report.sequenceError=String(error.stack);}
    await snapshot('immediate-original-sequence-after');await noAdmission('immediate-original-sequence');
    await page.screenshot({path:path.join(output,'immediate-original-sequence.png')});persist();return report.sequence;
  }
  return {report,persist,trigger,wrapper,input,fileInput,ledger,noAdmission,snapshot,attempt,originalSequence};
};
