import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {fingerprint} from '../../../scripts/acceptance/evidence.mjs';
const output=path.dirname(fileURLToPath(import.meta.url));
const reportPath=path.join(output,'diagnosis.json');
const report=JSON.parse(fs.readFileSync(reportPath));
const desktop=path.resolve(output,'../../..');
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const db=new DatabaseSync(path.join(output,'data/app.db'),{readOnly:true});
try{report.finalLedgerReadback=Object.fromEntries(Object.keys(report.ledgerBefore).map(table=>[table,db.prepare(`SELECT count(*) n FROM ${table}`).get().n]));}
finally{db.close();}
assert.deepEqual(report.finalLedgerReadback,report.ledgerBefore);
assert(Object.values(report.finalLedgerReadback).every(n=>n===0));
report.sourceAfter=fingerprint(path.join(desktop,'src')).sha256;
report.buildAfter=fingerprint(report.pins.buildRoot).sha256;
assert.equal(report.sourceAfter,report.pins.source);
assert.equal(report.buildAfter,report.pins.build);
report.catalogue.sourceAfter=hash(report.catalogue.source);
report.catalogue.destinationAfter=hash(path.join(output,'data/xiaozhi-pi/deepseek-capabilities.v1.json'));
assert.equal(report.catalogue.sourceAfter,report.catalogue.sha256);
assert.equal(report.catalogue.destinationAfter,report.catalogue.sha256);
assert.equal(hash(report.originalFailure.file),report.originalFailure.sha256);
const original=JSON.parse(fs.readFileSync(report.originalFailure.file));
report.qaScriptIntegrity=original.scriptBefore.map(entry=>({file:entry.file,sha256:hash(entry.file),originalSha256:entry.sha256}));
for(const entry of report.qaScriptIntegrity)assert.equal(entry.sha256,entry.originalSha256);
report.assertionConservation={originalTargets:13,qaScriptsByteUnchanged:true,keyboard:'Enter',filechooserTimeoutMs:12000,emptyFileList:true,focus:true,config:true,draft:true,ledger:true,full13Revalidation:'NOT_RUN'};
report.originalFailure.status='FAIL';
report.classification='UNRESOLVED_INTERMITTENT';
report.reproductionStatus='NOT_REPRODUCED';
report.closed=false;
report.closeStatus='BLOCKED_NORMAL_QUIT_TIMEOUT';
report.closeEvidence=JSON.parse(fs.readFileSync(path.join(output,'close-attempt.json')));
report.handoff={guiOperationsReleased:true,liveNativePid:190724,windowTitle:'Error',windowHandle:4393674,launchSessionId:79444,driverNodePid:55264,launcherCmdPid:173652,parentOwnsTeardown:true};
report.teardownNotes=[
  'Initial inspector timer-based quit/exit used require in the evaluation context. An Error window was subsequently observed. Its exact dialog text was not inspected. Attribution to an unavailable require in that context is an inference. Diagnostic teardown remains unresolved.',
  'A normal CloseMainWindow request returned true. The Error window remained with a new HWND.',
  'close-owned.cjs issued the ESM-safe normal electron.app.quit expression through the existing owned inspector. No response arrived within 8 seconds.',
  'No force termination or further GUI action. Parent receives the original launch session and native handle.'
];
report.integrityVerified=true;
report.integrityVerifiedAt=new Date().toISOString();
fs.writeFileSync(reportPath,JSON.stringify(report,null,2));
console.log(JSON.stringify({classification:report.classification,reproductionStatus:report.reproductionStatus,closed:report.closed,integrityVerified:report.integrityVerified,finalLedger:report.finalLedgerReadback,network:report.terminalBeforeClose.network,source:report.sourceAfter,build:report.buildAfter,catalogue:report.catalogue.sourceAfter}));
