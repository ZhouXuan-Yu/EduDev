import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
import {_electron as electron} from 'playwright';
import {fingerprint} from '../../../scripts/acceptance/evidence.mjs';
import {zeroNetworkBootstrap} from '../../../scripts/acceptance/zero-network-bootstrap.mjs';
import {assertIsolatedPiMain} from '../../../scripts/acceptance/build-root.mjs';
import {composerJourney} from '../../../scripts/acceptance/ui-final-composer-journey.mjs';

export const output=path.dirname(fileURLToPath(import.meta.url));
const desktop=path.resolve(output,'../../..');
const pins=JSON.parse(fs.readFileSync(path.join(output,'../pins.json')));
const main=path.join(pins.buildRoot,'main/index.js');
const data=path.join(output,'data'),profile=path.join(output,'profile');
const originalReport=path.resolve(output,'../../ui-final-composer-vw2bFr/report.json');
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const originalHash=hash(originalReport);
assert(!fs.existsSync(data)&&!fs.existsSync(profile),'One fresh diagnostic launch only');
export const report={kind:'bounded-Composer-diagnosis',launchLimit:1,checks:[],events:[],attempts:[],pins,originalFailure:{file:originalReport,sha256:originalHash},errors:[]};
export const persist=()=>fs.writeFileSync(path.join(output,'diagnosis.json'),JSON.stringify(report,null,2));
function verify(){
  assert.equal(fingerprint(path.join(desktop,'src')).sha256,pins.source);
  assert.equal(fingerprint(pins.buildRoot).sha256,pins.build);
  assert.equal(hash(originalReport),originalHash);
}
function ledger(){
  const db=new DatabaseSync(path.join(data,'app.db'),{readOnly:true});
  try{return Object.fromEntries(['ai_agent_runs','ai_agent_run_requests','ai_agent_run_actions','ai_agent_events','xiaozhi_event_journal'].map(table=>[table,db.prepare(`SELECT count(*) n FROM ${table}`).get().n]));}
  finally{db.close();}
}
verify();
const catalogueRelative='data/xiaozhi-pi/deepseek-capabilities.v1.json';
const catalogueSource=path.join(output,'../catalogue',catalogueRelative);
const catalogueDestination=path.join(output,catalogueRelative);
fs.mkdirSync(path.dirname(catalogueDestination),{recursive:true});
fs.copyFileSync(catalogueSource,catalogueDestination,fs.constants.COPYFILE_EXCL);
report.catalogue={source:catalogueSource,sha256:hash(catalogueSource)};
const env={...process.env};
for(const key of Object.keys(env)){
  if(key==='DEEPSEEK_API_KEY')continue;
  if(/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(key)||key.startsWith('OMNI_EDU_')||['ELECTRON_RUN_AS_NODE','NODE_OPTIONS','ELECTRON_RENDERER_URL'].includes(key))delete env[key];
}
Object.assign(env,{OMNI_EDU_DATA_ROOT:data,OMNI_EDU_REPO_ROOT:path.resolve(desktop,'../..'),OMNI_EDU_XIAOZHI_PI:'1',OMNI_EDU_E2E_VISIBLE:'1'});
const bootstrap=zeroNetworkBootstrap({output,main,profile,counter:'__composerHttp'});
export const app=await electron.launch({args:[bootstrap,'--force-device-scale-factor=1'],cwd:desktop,env,timeout:60000});
export const page=await app.firstWindow();
page.setDefaultTimeout(12000);
report.launch={pid:app.process().pid,...await assertIsolatedPiMain(app,main,profile)};
page.on('pageerror',error=>report.errors.push({kind:'pageerror',sha256:createHash('sha256').update(String(error)).digest('hex')}));
await page.getByTestId('xiaozhi-pi-workspace').waitFor({timeout:60000});
await page.waitForFunction(()=>{const input=document.querySelector('[data-testid="office-prompt-input"]');return input&&!input.disabled;});
assert.equal(path.resolve(await page.evaluate(()=>window.omniEdu.getDataRoot())),data);
await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setContentSize(1366,768));
report.ledgerBefore=ledger();
assert(Object.values(report.ledgerBefore).every(n=>n===0));
export async function assertNoAdmission(label){
  const network=await app.evaluate(()=>globalThis.__composerHttp);
  assert.deepEqual(network,[]);report.networkAttempts=network;
  const value=ledger();assert.deepEqual(value,report.ledgerBefore);
  const sessions=await page.evaluate(async()=>{
    const list=await window.omniEdu.listAiConversations();
    return Promise.all(list.sessions.map(async session=>{const snapshot=await window.omniEdu.getXiaozhiSnapshot(session.id);return {id:session.id,running:snapshot.running,turns:snapshot.projection.turns.length,approvals:snapshot.approvals.length};}));
  });
  assert(sessions.every(s=>!s.running&&s.turns===0&&s.approvals===0));
  report.lastZeroAdmission={label,ledger:value,sessions};persist();
}
const stop=Symbol('before-attachment');
try{
  await composerJourney({getPage:()=>page,output,report,check:async(id,name,work)=>{
    if(id==='X01-attachment-chooser')throw stop;
    await work();await assertNoAdmission(id);report.checks.push({id,name,status:'PASS'});persist();
  },notRun:(id,reason)=>{throw Error(id+reason);},assertNoAdmission,resize:()=>{throw Error('outside diagnostic scope');},relaunch:()=>{throw Error('Launch limit');}});
}catch(error){if(error!==stop)throw error;}
await page.evaluate(()=>{
  const describe=element=>element instanceof Element?{tag:element.tagName,role:element.getAttribute('role'),label:element.getAttribute('aria-label'),slot:element.getAttribute('data-slot'),testId:element.getAttribute('data-testid'),type:element.getAttribute('type'),tabIndex:element.tabIndex}:null;
  window.__composerDiagnosticEvents=[];
  for(const capture of [true,false])for(const type of ['focusin','focusout','keydown','keyup','click','input','change','cancel']){
    document.addEventListener(type,event=>{
      window.__composerDiagnosticEvents.push({type,key:event.key,phase:capture?'capture':'bubble',target:describe(event.target),active:describe(document.activeElement),path:event.composedPath().filter(e=>e instanceof Element).slice(0,7).map(describe),defaultPrevented:event.defaultPrevented,trusted:event.isTrusted,hasFocus:document.hasFocus(),time:performance.now()});
    },capture);
  }
});
export async function snapshot(label){
  const state=await page.evaluate(()=>{
    const button=document.querySelector('.office-composer-container button[aria-label="添加本地附件"]');
    const describe=element=>({tag:element.tagName,role:element.getAttribute('role'),label:element.getAttribute('aria-label'),slot:element.getAttribute('data-slot'),type:element.getAttribute('type'),tabIndex:element.tabIndex,disabled:element.disabled,focused:element===document.activeElement,attributes:Object.fromEntries([...element.attributes].filter(a=>!['style','class'].includes(a.name)).map(a=>[a.name,a.value]))});
    return {hasFocus:document.hasFocus(),active:describe(document.activeElement),ancestors:[button,button.parentElement,button.parentElement.parentElement].map(describe),events:window.__composerDiagnosticEvents.splice(0)};
  });
  report.events.push({label,...state});persist();return state;
}
export async function attempt(label,prepare){
  await prepare();await snapshot(label+'-before');
  const start=Date.now();
  const pending=page.waitForEvent('filechooser').then(value=>({value}),error=>({error:String(error.message)}));
  await page.keyboard.press('Enter');
  const result=await pending;
  const attempt={label,elapsedMs:Date.now()-start,chooser:!!result.value,error:result.error};
  if(result.value){assert(result.value.isMultiple());await result.value.setFiles([]);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await page.keyboard.press('Escape');}
  report.attempts.push(attempt);await snapshot(label+'-after');await assertNoAdmission(label);
  await page.screenshot({path:path.join(output,label+'.png')});persist();return attempt;
}
export async function close(){
  await assertNoAdmission('terminal');await snapshot('terminal');
  await app.close();report.ledgerAfterClose=ledger();assert.deepEqual(report.ledgerAfterClose,report.ledgerBefore);
  verify();assert.equal(hash(catalogueSource),report.catalogue.sha256);assert.equal(hash(catalogueDestination),report.catalogue.sha256);
  report.integrityVerified=true;report.closed=true;persist();
}
await snapshot('before-A');
persist();
