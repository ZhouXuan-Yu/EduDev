// Normal quit for the single already identified owned diagnostic main.
const fs=require('node:fs');
const path=require('node:path');
const WS=require('ws');
const output=__dirname;
const evidence={nativePid:190724,endpoint:'http://127.0.0.1:53041/json/list',action:'electron.app.quit',startedAt:new Date().toISOString()};
const persist=()=>fs.writeFileSync(path.join(output,'close-attempt.json'),JSON.stringify(evidence,null,2));
persist();
const timeout=setTimeout(()=>{
  evidence.status='CLOSE_REQUEST_TIMEOUT';persist();process.exit(2);
},8000);
fetch(evidence.endpoint).then(response=>response.json()).then(targets=>{
  const socket=new WS(targets[0].webSocketDebuggerUrl);
  socket.on('open',()=>socket.send(JSON.stringify({id:1,method:'Runtime.evaluate',params:{
    expression:"process.getBuiltinModule('module').createRequire('D:/WorkProject/EduProject/apps/desktop/package.json')('electron').app.quit()",
    returnByValue:true
  }})));
  socket.on('message',bytes=>{
    const message=JSON.parse(bytes.toString());
    if(message.id!==1)return;
    evidence.status=message.error||message.result?.exceptionDetails?'CLOSE_EVALUATION_FAILED':'QUIT_RETURNED';
    persist();socket.close();clearTimeout(timeout);process.exit(evidence.status==='QUIT_RETURNED'?0:1);
  });
  socket.on('close',()=>{evidence.connectionClosed=true;persist();});
  socket.on('error',()=>{evidence.status='INSPECTOR_CONNECTION_FAILED';persist();clearTimeout(timeout);process.exit(1);});
}).catch(()=>{evidence.status='INSPECTOR_DISCOVERY_FAILED';persist();clearTimeout(timeout);process.exit(1);});
