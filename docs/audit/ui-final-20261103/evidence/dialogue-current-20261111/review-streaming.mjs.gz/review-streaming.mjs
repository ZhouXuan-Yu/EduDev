import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const report = JSON.parse(fs.readFileSync(path.join(desktop, 'test-results/ui-final-streaming-cascade-p8WzOP/report.json')));
assert(report.success && report.integrityVerified);
assert.equal(report.samples.length, 14);
const summary = {samples: 14, officialProperties: 0, inheritedProperties: [], overrides: [], unresolved: 0};
for (const sample of report.samples) {
  assert(sample.nativeWindow.visible && sample.nativeWindow.focused && !sample.nativeWindow.minimized);
  for (const [property, evidence] of Object.entries(sample.properties)) {
    if (evidence.status === 'unresolved') summary.unresolved++;
    const winner = evidence.winner;
    if (!winner) continue;
    assert.equal(winner.state, 'Active');
    const original = winner.originalSource;
    if (original?.status === 'exact-source' && /^src\/renderer\/heroui-pro\//.test(original.file)) {
      assert.equal(sha256(fs.readFileSync(path.join(desktop, original.file))), original.sourceSha256);
      summary.officialProperties++;
    } else if (winner.inherited && ['font-family', 'font-size', 'font-weight', 'line-height', 'color'].includes(property)) {
      summary.inheritedProperties.push({id: sample.id, property, selector: winner.selector});
    } else {
      summary.overrides.push({id: sample.id, property, selector: winner.selector, original});
    }
  }
}
fs.writeFileSync(path.join(import.meta.dirname, 'streaming-review.json'), JSON.stringify(summary, null, 2));
assert.equal(summary.unresolved, 0);
assert.deepEqual(summary.overrides, []);
console.log(JSON.stringify(summary));
