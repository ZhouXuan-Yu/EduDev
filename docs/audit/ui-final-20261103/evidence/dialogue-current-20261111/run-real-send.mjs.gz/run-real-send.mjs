import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';

const desktop = path.resolve(import.meta.dirname, '../..');
const config = fs.readFileSync(path.join(desktop, '.env.local'), 'utf8');
const pick = name => config.match(new RegExp('^' + name + '\\s*=\\s*["\']?([^\\r\\n"\']+)', 'm'))?.[1]?.trim();
const key = pick('DEEPSEEK_API_KEY');
const model = pick('DEEPSEEK_MODEL') || 'deepseek-flash';
assert(key, 'Existing local credential required');
assert(/^[a-zA-Z0-9._-]{1,120}$/.test(model));
const output = path.join(import.meta.dirname, 'real-send.log');
assert(!fs.existsSync(output), 'One scenario attempt only, preserve prior result');
const handle = fs.openSync(output, 'wx');
const child = spawn(process.execPath, ['scripts/ui-final-composer-send-live.mjs', '--run-ui', '--allow-paid',
  '--pins=test-results/ui-final-dialogue-20261111/pins.json', '--model=' + model],
  {cwd: desktop, env: {...process.env, DEEPSEEK_API_KEY: key}, stdio: ['ignore', handle, handle], windowsHide: true});
fs.closeSync(handle);
child.once('error', error => {console.error(String(error.message).replaceAll(key, '[credential]')); process.exitCode = 1;});
child.once('exit', (code, signal) => {
  console.log(JSON.stringify({command: 'ui-final-composer-send-live', exit: code, signal,
    budget: {plannedRuns: 3, maxRuns: 5, maxProviderRequests: 8, automaticRetries: 0}}));
  process.exitCode = code ?? 1;
});
