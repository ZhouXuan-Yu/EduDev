import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fingerprint} from '../../scripts/acceptance/evidence.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const file = path.join(import.meta.dirname, 'integration-identity.json');
const source = fingerprint(path.join(desktop, 'src'));
if (process.argv.includes('--before')) {
  assert(!fs.existsSync(file), 'Preserve previous build identity');
  fs.writeFileSync(file, JSON.stringify({sourceBefore: source.sha256}, null, 2));
} else {
  const before = JSON.parse(fs.readFileSync(file));
  assert.equal(source.sha256, before.sourceBefore);
  const baseline = JSON.parse(fs.readFileSync(path.join(desktop, 'test-results/ui-alignment-20261111/before-pins.json')));
  const protectedFiles = baseline.protectedFiles.filter(item => item.file.startsWith('renderer/'));
  const current = new Map(source.files.map(item => [item.file, item.sha256]));
  const changedProtected = protectedFiles.filter(item => current.get(item.file) !== item.sha256);
  assert.deepEqual(changedProtected, []);
  const result = {root: desktop, source: source.sha256, buildRoot: path.join(desktop, 'out'),
    build: fingerprint(path.join(desktop, 'out')).sha256,
    integrationCommit: '6aa0f66', sourceStable: true, protectedFiles: protectedFiles.length, changedProtected,
    boundary: 'Current npm start build; prior frozen dialogue evidence retains its own pins'};
  fs.writeFileSync(file, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
}
