import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const repository = path.resolve(import.meta.dirname, '../../../..');
const read = file => fs.readFileSync(path.join(repository, file), 'utf8');
const acceptance = read('docs/design/system/UI_FINAL_ACCEPTANCE.md');
const result = read('docs/audit/ui-final-20261103/RESULT.md');
const goal = read('docs/goal/UI_FINAL_RECONCILED_GOAL.md');
const rows = text => text.split(/\r?\n/).filter(line => /^\| A\d{2} \|/.test(line)).map(line => line.split('|').slice(1, 3).map(cell => cell.trim()));
const original = rows(acceptance);
const copied = result.split('## 固定36项')[1]?.split('## 原有效增补断言')[0];
assert(copied, 'Canonical copied acceptance table required');
assert.deepEqual(rows(copied), original);
assert.equal(original.length, 36);
assert.deepEqual(original.map(row => row[0]), Array.from({length: 36}, (_, index) => 'A' + String(index + 1).padStart(2, '0')));
const additions = goal.split('## 固定验收集合')[1]?.split('## 原次数')[0];
const ids = [...additions.matchAll(/^\| (X\d{2}) \|/gm)].map(match => match[1]);
assert.deepEqual(ids, Array.from({length: 8}, (_, index) => 'X' + String(index + 1).padStart(2, '0')));
console.log(JSON.stringify({pass: true, originalAcceptanceRows: 36, unchangedBehaviorDescriptions: true,
  additionalProtectionIds: ids, total: 44, scope: 'Contract preservation only; no runtime acceptance claim'}));
