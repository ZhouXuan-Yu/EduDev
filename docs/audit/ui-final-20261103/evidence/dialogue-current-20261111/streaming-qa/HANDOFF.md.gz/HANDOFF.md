# Streaming native visibility QA handoff

本轮状态为 STATIC_PASS_RUNTIME_NOT_RUN。根使用当前冻结 pins 和原 runner 入口统一运行。

## 精确修改

- `apps/desktop/scripts/ui-final-streaming-cascade-live.mjs` 的差异为 +11 / -2，净增 9 行。
- 第 41 行起，在每个 sample 的首个操作中枚举真实 BrowserWindow，要求唯一产品窗口，调用 focus，读取 visible/focused/minimized，断言可见、聚焦且未最小化。
- 第 65 行将本次三项布尔值作为 sample.nativeWindow 保存。
- 第 79 行在环境清理后的 Object.assign 设置 OMNI_EDU_E2E_VISIBLE=1。

## 静态证据

- `node --check apps/desktop/scripts/ui-final-streaming-cascade-live.mjs`，exit 0。
- TypeScript 5.9.3 AST 解析零诊断。移除上述四项新增节点后，规范换行的全文和完整 AST 与修改前一致。
- 原 39 个 assert 调用按序完整保留，新增 1 个窗口状态断言。原 5 个 check 调用及其文案逐项相等。
- 原循环静态展开为 8 个 streaming sample 和 6 个 completed sample，共 14 个。
- 原所有 until/setTimeout/launch/firstWindow/defaultTimeout 调用逐项相等，budget AST 相等。
- 预算为 180000ms、1 task、2 controlled responses、0 external requests、0 paid models；首窗口与工具/第二响应等待均为 25000ms。
- 真实 Pi/office_list_attachments、winner/token 来源及 DevTools scope/source/known-message 归因由完整 AST 守恒证明保留。
- 新增 runtime 操作为每次 sample 的单次 main-process 窗口状态求值，执行耗时待根测量。

## 根运行验收

- 本轮 native 页面、窗口焦点、14 samples、5 checks、真实 Pi/工具执行、网络/模型运行账本与性能状态均为 NOT_RUN。
- 根运行后须核对每个 sample.nativeWindow 的 visible=true、focused=true、minimized=false，并依据本次构建的新 report 判定。
- 原受控 provider SSE 是本 runner 的验收边界，自然模型质量另行验收。
- 本轮执行计数为 Electron 0、网页 0、Git 命令 0。本轮实际写入范围见 JSON authoredFiles。
- 详细 SHA、AST 摘要与静态核验工具恢复记录见同目录 native-visibility-static.json。

## 回滚

回滚范围为新增窗口声明/断言、sample.nativeWindow 字段及 E2E_VISIBLE 环境项。根可按上述三处差异恢复原 runner。
