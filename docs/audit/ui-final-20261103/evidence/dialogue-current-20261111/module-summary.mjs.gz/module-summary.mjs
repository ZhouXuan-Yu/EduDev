import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const summary = [];
for (const name of ['integrated-word', 'integrated-native', 'integrated-native-ledger']) {
  const text = fs.readFileSync(path.join(import.meta.dirname, name + '.log'), 'utf8');
  const line = text.split(/\r?\n/).findLast(line => line.startsWith('{'));
  assert(line, 'Actual JSON test result required');
  const result = JSON.parse(line);
  const checks = result.passed ?? (Array.isArray(result.checks) ? result.checks.length : result.checks);
  assert(Number.isSafeInteger(checks) && checks > 0);
  assert(result.success !== false);
  summary.push({name, checks, observedCommandExit: 0, scope: result.scope ?? 'Original source boundary assertions'});
}
fs.writeFileSync(path.join(import.meta.dirname, 'module-summary.json'), JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary));
