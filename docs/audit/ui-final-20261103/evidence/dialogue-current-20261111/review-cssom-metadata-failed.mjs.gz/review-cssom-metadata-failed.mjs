import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const root = path.join(desktop, 'test-results/ui-final-cssom-Fr7ZXR');
const report = JSON.parse(fs.readFileSync(path.join(root, 'report.json')));
assert.equal(report.success, true);
assert.equal(report.samples.length, 28);
assert.equal(report.attribution.unresolved, 0);
const summary = {samples: 28, attribution: report.attribution, winners: {},
  officialInternalProperties: 0, applicationInheritedProperties: [], nativeProperties: 0,
  variableStatuses: {}, forbiddenInternalOverrides: []};
for (const sample of report.samples) {
  assert(sample.nativeWindow.visible && sample.nativeWindow.focused && !sample.nativeWindow.minimized);
  for (const [property, evidence] of Object.entries(sample.properties)) {
    for (const variable of evidence.variables ?? []) {
      summary.variableStatuses[variable.status] = (summary.variableStatuses[variable.status] ?? 0) + 1;
    }
    if (!evidence.winner) continue;
    const winner = evidence.winner;
    assert.equal(winner.state, 'Active');
    const original = winner.originalSource;
    const identity = original?.status === 'exact-source' ? original.file : winner.selector;
    summary.winners[identity] = (summary.winners[identity] ?? 0) + 1;
    if (original?.status === 'exact-source') {
      const file = path.resolve(desktop, original.file);
      assert(file.startsWith(desktop + path.sep));
      assert.equal(sha256(fs.readFileSync(file)), original.sourceSha256);
    }
    if (sample.component.startsWith('Native button')) { summary.nativeProperties++; continue; }
    if (original?.status === 'exact-source' && /^src\/renderer\/heroui-pro\//.test(original.file)) {
      summary.officialInternalProperties++;
      continue;
    }
    if (winner.inherited && ['font-family', 'font-size', 'font-weight', 'line-height', 'color'].includes(property)) {
      summary.applicationInheritedProperties.push({sample: sample.id, property, selector: winner.selector});
      continue;
    }
    summary.forbiddenInternalOverrides.push({sample: sample.id, property, selector: winner.selector, original});
  }
}
fs.writeFileSync(path.join(import.meta.dirname, 'cssom-review.json'), JSON.stringify(summary, null, 2));
assert.deepEqual(summary.forbiddenInternalOverrides, []);
console.log(JSON.stringify(summary));
