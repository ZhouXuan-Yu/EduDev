import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fingerprint} from '../../scripts/acceptance/evidence.mjs';

const root = path.resolve(import.meta.dirname, '../..');
const accepted = JSON.parse(fs.readFileSync(path.join(root, 'test-results/ui-alignment-20261111/integrated-latest-pins.json')));
const source = fingerprint(path.join(root, 'src'));
const build = fingerprint(path.join(root, 'out'));
assert.equal(source.sha256, accepted.source);
assert.equal(build.sha256, accepted.build);
const buildRoot = path.join(import.meta.dirname, 'frozen-out');
assert(!fs.existsSync(buildRoot), 'Preserve any existing frozen build');
fs.cpSync(path.join(root, 'out'), buildRoot, {recursive: true, errorOnExist: true, force: false});
assert.equal(fingerprint(buildRoot).sha256, build.sha256);
assert.equal(fingerprint(path.join(root, 'src')).sha256, source.sha256);
const pins = {root, buildRoot, source: source.sha256, build: build.sha256,
  sourceCommit: '1af1da3ee8e27c9e0f6be99c154dd41665c569d5',
  method: 'Byte-exact copy of actual canonical npm start build', sourceStable: true};
fs.writeFileSync(path.join(import.meta.dirname, 'pins.json'), JSON.stringify(pins, null, 2));
console.log(JSON.stringify(pins));
