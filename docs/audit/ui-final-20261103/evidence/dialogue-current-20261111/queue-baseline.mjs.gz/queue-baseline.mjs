import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {boundedTree, cloneTree, captureFacts, hash, assertQuiescent} from '../../scripts/acceptance/ui-final-queue-recovery.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const source = path.join(desktop, 'test-results/ui-final-composer-send-bCY90z');
const target = path.join(import.meta.dirname, 'queue-baseline');
assert(!fs.existsSync(target), 'Preserve any existing baseline');
const original = JSON.parse(fs.readFileSync(path.join(source, 'report.json')));
assert(original.success && original.integrityVerified);
const trees = ['data', 'profile'].map(name => boundedTree(path.join(source, name)));
const before = captureFacts(path.join(source, 'data'));
assertQuiescent(before);
for (let index = 0; index < trees.length; index++) cloneTree(trees[index], path.join(target, ['data', 'profile'][index]));
const clonedFacts = captureFacts(path.join(target, 'data'));
assert.equal(hash(clonedFacts), hash(before));
const file = path.join(target, 'data/app.db');
assert(fs.realpathSync(file).startsWith(fs.realpathSync(target) + path.sep));
const db = new DatabaseSync(file);
try {
  const checkpoint = db.prepare('PRAGMA wal_checkpoint(TRUNCATE)').get();
  assert.equal(checkpoint.busy, 0);
  assert.equal(db.prepare('PRAGMA journal_mode=DELETE').get().journal_mode, 'delete');
  assert.equal(db.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
} finally { db.close(); }
assert.equal(hash(captureFacts(path.join(target, 'data'))), hash(before));
for (let index = 0; index < trees.length; index++) assert.equal(boundedTree(trees[index].root).sha256, trees[index].sha256);
assert(!fs.existsSync(file + '-wal') && !fs.existsSync(file + '-shm'));
const report = {success: true, source, target, originalSuccess: true,
  originalTrees: trees.map(tree => ({root: tree.root, sha256: tree.sha256, files: tree.files.length, bytes: tree.bytes})),
  factsBefore: before.summary, factsAfter: captureFacts(path.join(target, 'data')).summary,
  unchangedOriginalTrees: true, unchangedBusinessRecords: true,
  scope: 'Owned byte-exact clone; SQLite checkpoint and journal cleanup only on copied database. No facts or native sessions reconstructed.'};
fs.writeFileSync(path.join(import.meta.dirname, 'queue-baseline.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({success: true, unchangedOriginalTrees: true, unchangedBusinessRecords: true, target}));
