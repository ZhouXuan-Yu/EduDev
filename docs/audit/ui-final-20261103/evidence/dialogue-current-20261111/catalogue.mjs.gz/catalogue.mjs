import '../../scripts/office-agent/register-source.mjs';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const {fetchDeepSeekCatalogue} = await import('../../src/main/xiaozhi-agent/model-capabilities.ts');
const desktop = path.resolve(import.meta.dirname, '../..');
const cfg = fs.readFileSync(path.join(desktop, '.env.local'), 'utf8');
const key = cfg.match(/^DEEPSEEK_API_KEY\s*=\s*["']?([^\r\n"']+)/m)?.[1]?.trim();
assert(key, 'Existing local model configuration required');
const root = path.join(import.meta.dirname, 'catalogue/data/xiaozhi-pi');
assert(!fs.existsSync(root), 'Preserve previously captured catalogue');
const report = {success: false, endpoint: 'https://api.deepseek.com/v1/models', modelRequests: 0,
  scope: 'Original production catalogue fetch/parser, metadata GET only, owned cache root'};
try {
  const catalogue = await fetchDeepSeekCatalogue(root, key);
  report.observedAt = catalogue.observedAt;
  report.modelIds = catalogue.models.map(model => model.id);
  report.cacheSha256 = sha256(fs.readFileSync(path.join(root, 'deepseek-capabilities.v1.json')));
  report.success = true;
} catch (error) {
  report.error = String(error.message).replaceAll(key, '[credential]').slice(0, 500);
  process.exitCode = 1;
}
fs.writeFileSync(path.join(import.meta.dirname, 'catalogue.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
