import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fingerprint} from '../../scripts/acceptance/evidence.mjs';
import {continuationBootstrap, continuationGuardRead} from '../../scripts/acceptance/paper-adaptation-continuation.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const pins = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, 'preview-status-integrated-pins.json')));
assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
assert.equal(fingerprint(path.join(desktop, 'out')).sha256, pins.build);
const original = path.join(owned, 'paper-preview-status-integrated-HLWoPw');
assert(fs.realpathSync(original).startsWith(owned + path.sep));
const output = fs.mkdtempSync(path.join(owned, 'paper-preview-status-native-'));
const data = path.join(output, 'data'), profile = path.join(output, 'profile');
const originalData = fingerprint(path.join(original, 'data'));
fs.cpSync(path.join(original, 'data'), data, {recursive: true, errorOnExist: true, force: false});
fs.cpSync(path.join(original, 'profile'), profile, {recursive: true, errorOnExist: true, force: false});
assert.equal(fingerprint(data).sha256, originalData.sha256);
const bootstrap = path.join(output, 'bootstrap.cjs');
const guardFile = path.join(output, 'native-guard.json');
const guardReady = path.join(output, 'native-ready-guard.json');
fs.writeFileSync(bootstrap, continuationBootstrap({main: path.join(desktop, 'out/main/index.js'), profile,
  diagnosticFile: path.join(output, 'bootstrap-state.json')}) + `
const nativeReadGuard=${continuationGuardRead.toString()};
const nativeGuardKeys=['networkAttempts','modelAttempts','rendererErrors','formalRegistrations','policyProbe'];
const nativeSafeGuard=verify=>{const value=nativeReadGuard(electron,verify);return Object.fromEntries(nativeGuardKeys.map(key=>[key,value[key]]));};
electron.app.on('browser-window-created',(_event,window)=>{
  window.webContents.once('did-finish-load',()=>{
    fs.writeFileSync(${JSON.stringify(guardReady)},JSON.stringify(nativeSafeGuard(true),null,2));
  });
});
electron.app.on('will-quit',()=>{
  fs.writeFileSync(${JSON.stringify(guardFile)},JSON.stringify(nativeSafeGuard(false),null,2));
});
`);
const env = {...process.env};
for (const key of Object.keys(env)) if (/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(key) || key.startsWith('OMNI_EDU_') ||
  ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL'].includes(key)) delete env[key];
Object.assign(env, {OMNI_EDU_DATA_ROOT: data, OMNI_EDU_REPO_ROOT: path.resolve(desktop, '../..'),
  OMNI_EDU_XIAOZHI_PI: '1', OMNI_EDU_E2E_VISIBLE: '1', NODE_ENV: 'development'});
const child = spawn(path.join(desktop, 'node_modules/electron/dist/electron.exe'),
  [bootstrap, '--user-data-dir=' + profile], {env, cwd: output, detached: true, windowsHide: false, stdio: 'ignore'});
await new Promise((resolve, reject) => {child.once('spawn', resolve); child.once('error', reject);});
child.unref();
const report = {output, data, profile, pid: child.pid, pins, original, originalDataSha256: originalData.sha256,
  canonicalMain: path.join(desktop, 'out/main/index.js'), scope: 'Native Windows interaction with copied controlled teacher fixtures and original canonical main; HTTP/model blocked, daily data untouched.'};
fs.writeFileSync(path.join(import.meta.dirname, 'preview-status-native.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
