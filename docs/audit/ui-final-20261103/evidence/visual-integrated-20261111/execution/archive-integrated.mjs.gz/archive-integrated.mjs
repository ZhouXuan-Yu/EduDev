import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/visual-integrated-20261111');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  for (const name of names) selected.push({source:path.join(root, name),file:prefix + '/' + name});
}
add(base, ['archive-integrated.mjs','capture.mjs','integrated-before.json','integrated-pins.json',
  'build-integrated.log','components-integrated.log','styles-integrated.log',
  'reasoning-integrated.log','capture-integrated.log','paper-entry-integrated.log',
  'integrated-screen-comparison.json','formal-before.json','formal-verified.json',
  'formal-launch.json','formal-runtime.json'], 'execution');
add(path.join(desktop, 'test-results/ui-alignment-20261111'), ['reference-identity.json'], 'reference');
for (const [root, prefix] of [
  [path.join(base, 'integrated-5rk2wx'), 'pages'],
  [path.join(desktop, 'test-results/paper-first-entry-OvOox8'), 'paper'],
]) {
  const report = JSON.parse(fs.readFileSync(path.join(root, 'report.json')));
  assert.equal(report.success, true);
  add(root, fs.readdirSync(root).filter(file=>file.endsWith('.png') || file==='report.json'), prefix);
}
const files = [];
for (const {source, file:name} of selected) {
  const raw = fs.readFileSync(source);
  const png = name.endsWith('.png');
  if (png) assert(raw.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalSha256:sha256(raw),
    encoding:png ? 'original-png' : 'gzip',
    ...(png ? {width:raw.readUInt32BE(16), height:raw.readUInt32BE(20)} : {})});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope:'Integrated b182806 formal Pi UI build, 27 approved-HTML/empty-production sample pairs, actual manual question path, native canonical launch metadata. Excludes real daily screenshots, databases, profiles and credentials.',
  visualAcceptance:'PARTIAL; workbench navigation regression remains BLOCKED after two adapter repairs',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'integrated-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination,count:files.length,bytes:files.reduce((sum,file)=>sum+file.bytes,0)}));
