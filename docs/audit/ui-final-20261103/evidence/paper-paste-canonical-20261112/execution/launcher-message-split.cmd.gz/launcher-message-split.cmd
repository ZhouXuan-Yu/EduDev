@echo off
chcp 65001 >nul
echo [小智] 正在构建当前源码并启动新版桌面工作台…
echo [小智] 首次构建需要一些时间，请等待。
echo [小智] 构建失败不会打开旧版。
exit /b 0
