@echo off
chcp 65001 >nul
echo [小智] 正在构建当前源码并启动新版桌面工作台…
echo [Xiaozhi] First build may take a few minutes. Build failures stop launch.
exit /b 0
