import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';

const root = path.resolve(import.meta.dirname, '../../../..');
const results = path.join(root, 'apps/desktop/test-results');
const destination = path.join(root, 'docs/audit/ui-final-20261103/evidence/paper-paste-canonical-20261112');
const files = new Map();
const folders = new Set();
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
for (const name of fs.readdirSync(import.meta.dirname)) {
  if (!/paste.*(?:canonical|daily|git-line|source-after|protected-final)|launcher-message/.test(name)) continue;
  if (!/\.(json|log|cmd|mjs)$/.test(name)) continue;
  const source = path.join(import.meta.dirname, name);
  files.set('execution/' + name + '.gz', source);
  if (!name.endsWith('.log')) continue;
  for (const line of fs.readFileSync(source, 'utf8').split(/\r?\n/)) {
    let output = line.startsWith('REPORT ') ? line.slice(7) : undefined;
    try { output ||= JSON.parse(line).output; } catch { /* Ordinary console line. */ }
    if (!output || !fs.existsSync(path.join(output, 'report.json'))) continue;
    assert.equal(path.dirname(path.resolve(output)), results);
    folders.add(path.basename(output));
  }
}
for (const folder of folders) {
  const source = path.join(results, folder);
  files.set(folder + '/report.json.gz', path.join(source, 'report.json'));
  for (const entry of fs.readdirSync(source, {recursive: true, withFileTypes: true})) {
    if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
    const absolute = path.join(entry.parentPath, entry.name);
    const inside = path.relative(source, absolute);
    if (inside.split(path.sep).some(part => ['data', 'profile', 'workspace'].includes(part))) continue;
    files.set(folder + '/' + inside, absolute);
  }
}
const smokeStart = fs.statSync(path.join(import.meta.dirname, 'smoke-paste-modal-canonical.log')).birthtimeMs;
for (const entry of fs.readdirSync(path.join(results, 'electron-e2e'), {withFileTypes: true})) {
  if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
  const source = path.join(results, 'electron-e2e', entry.name);
  if (fs.statSync(source).mtimeMs >= smokeStart) files.set('smoke-current/' + entry.name, source);
}
fs.mkdirSync(destination, {recursive: true});
const manifest = [];
for (const [name, source] of files) {
  const file = name.replaceAll('\\', '/');
  const original = fs.readFileSync(source);
  const bytes = file.endsWith('.gz') ? gzipSync(original) : original;
  const target = path.join(destination, file);
  fs.mkdirSync(path.dirname(target), {recursive: true});
  fs.writeFileSync(target, bytes);
  assert.deepEqual(file.endsWith('.gz') ? gunzipSync(fs.readFileSync(target)) : fs.readFileSync(target), original);
  manifest.push({file, bytes: bytes.length, sha256: sha(bytes), originalBytes: original.length, originalSha256: sha(original)});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope: 'Exact canonical launch output acceptance after Git line-ending conversion. Controlled test screens only. Private daily screenshots and user databases excluded.',
  fullUiFinalAccepted: false, files: manifest,
}, null, 2));
console.log(JSON.stringify({files: manifest.length, bytes: manifest.reduce((sum, row) => sum + row.bytes, 0)}));
