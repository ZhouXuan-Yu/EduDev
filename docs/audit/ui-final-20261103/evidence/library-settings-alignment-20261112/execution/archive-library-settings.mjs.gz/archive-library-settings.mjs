import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/library-settings-alignment-20261112');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  assert(fs.realpathSync(root).startsWith(owned + path.sep));
  for (const name of names) selected.push({source: path.join(root, name), name: prefix + '/' + name});
}
add(base, ['archive-library-settings.mjs', 'capture.mjs',
  'library-settings-before.json', 'library-settings-pins.json', 'library-settings-r1-before.json',
  'library-settings-r1-pins.json', 'library-settings-geometry.json', 'library-settings-r1-geometry.json',
  'build-library-settings.log', 'build-library-settings-r1.log',
  'components-library-settings.log', 'styles-library-settings.log',
  'components-library-settings-r1.log', 'styles-library-settings-r1.log',
  'catalog-library-settings.log', 'settings-library-settings.log',
  'catalog-library-settings-r1.log', 'settings-library-settings-r1.log',
  'capture-library-settings.log', 'capture-library-settings-r1.log',
  'audit-library-settings-bounded.json', 'teaching-runtime-readback.json'], 'execution');
for (const [name, prefix, allImages] of [
  ['ui-current-TE0DgQ', 'before', false],
  ['library-settings-NwCzZu', 'initial', false],
  ['library-settings-r1-SJWIk6', 'current', true],
]) {
  const root = path.join(base, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, true);
  add(root, fs.readdirSync(root).filter(file => file === 'report.json' ||
    file.endsWith('.png') && (allImages || /^(library|settings)-/.test(file))), prefix);
}
for (const [name, prefix] of [
  ['ui-final-material-catalog-live-5cbwEs', 'initial-catalog'],
  ['ui-final-settings-z1S1k1', 'initial-settings'],
  ['ui-final-material-catalog-live-1mi4FF', 'catalog'],
  ['ui-final-settings-zuTLrG', 'settings'],
]) {
  const root = path.join(owned, name);
  const report = JSON.parse(fs.readFileSync(path.join(root, 'report.json')));
  assert(report.success || report.code === 'A11_CATALOG_PASS');
  add(root, fs.readdirSync(root).filter(file => file === 'report.json' || file.endsWith('.png')), prefix);
}
const files = [];
for (const {source, name} of selected) {
  const raw = fs.readFileSync(source);
  const png = name.endsWith('.png');
  if (png) assert(raw.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive: true});
  fs.writeFileSync(target, encoded, {flag: 'wx'});
  files.push({file, bytes: encoded.length, sha256: sha256(encoded), originalSha256: sha256(raw),
    encoding: png ? 'original-png' : 'gzip'});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope: 'Approved library/settings typography and responsive width. Controlled empty/manual QA only. Excludes profiles, databases, builds, and ordinary runtime screenshots.',
  visualAcceptance: 'Six page/size title geometry comparisons exact. Whole UI-FINAL remains active.',
  pins: JSON.parse(fs.readFileSync(path.join(base, 'library-settings-r1-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination, files: files.length, bytes: files.reduce((sum, file) => sum + file.bytes, 0)}));
