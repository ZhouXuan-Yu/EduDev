import assert from 'node:assert/strict';import fs from 'node:fs';import {spawn} from 'node:child_process';
import {c2OfficeContractHash,c2OfficeDeliveryManifest} from '../scripts/acceptance/paper-template-office-ui.mjs';
const [mode,matrix]=process.argv.slice(2);assert(['send','office','queue'].includes(mode));assert(mode==='send'?!matrix:!!matrix);
const pinsFile='test-results/ui-final-fixed-merged-pins.json',pins=JSON.parse(fs.readFileSync(pinsFile));
let key=process.env.DEEPSEEK_API_KEY;
if(!key&&fs.existsSync('.env.local')){const line=fs.readFileSync('.env.local','utf8').split(/\r?\n/).map(s=>s.trim()).find(s=>s.startsWith('DEEPSEEK_API_KEY='));if(line)key=line.slice(line.indexOf('=')+1).trim().replace(/^['"]|['"]$/g,'');}
assert(typeof key==='string'&&key.trim(),'LOCAL_PROVIDER_KEY_REQUIRED');
let args;
if(mode==='send')args=['scripts/ui-final-composer-send-live.mjs','--run-ui','--allow-paid','--pins='+pinsFile,'--model=deepseek-flash'];
else if(mode==='queue')args=['scripts/ui-final-queue-recovery-live.mjs','--run-ui','--baseline='+matrix,'--model=deepseek-flash','--pins='+pinsFile];
else{const saved=JSON.parse(fs.readFileSync(matrix));assert(saved.success&&saved.integrityVerified&&saved.pins.source===pins.source&&saved.pins.build===pins.build);
 const office='test-results/ui-final-fixed-merged-office-pins.json';fs.writeFileSync(office,JSON.stringify({...pins,contract:c2OfficeContractHash(),officeContract:c2OfficeDeliveryManifest().qaBundleSha256},null,2));
 args=['scripts/ui-final-c2-office-live.mjs','--run-ui','--live','--pins='+office,'--matrix='+matrix];}
const child=spawn(process.execPath,args,{cwd:process.cwd(),env:{...process.env,DEEPSEEK_API_KEY:key,DEEPSEEK_MODEL:'deepseek-flash',OMNI_EDU_TEST_BUILD_ROOT:pins.buildRoot},stdio:'inherit'});
child.on('error',error=>{console.error(error.code);process.exitCode=1;});child.on('exit',code=>{process.exitCode=code??1;});
