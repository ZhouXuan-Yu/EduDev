import fs from 'node:fs';import assert from 'node:assert/strict';import{spawn}from'node:child_process';
const pinsFile='test-results/ui-final-fixed-merged-pins.json',pins=JSON.parse(fs.readFileSync(pinsFile));
const tasks={
 basket:['scripts/ui-goal-paper-basket.mjs','--run-ui','--from=test-results/ui-goal-paper-9G2OGc','--owner=aisession_7a4a1a6c-ad0d-4614-bef7-33b9be2322b2','--active-session=aisession_8b649d13-87fc-4285-b1a1-e8e69e942300','--questions=question_d0ed2e88-704b-4b96-90f1-d4f880ab7e10,question_5326992e-9786-418b-829e-8be64ee8e237'],
 number:['scripts/ui-final-paper-number-live.mjs','--run-ui','--pins='+pinsFile],
 paste:['scripts/ui-final-paper-paste-live.mjs','--run-ui','--pins='+pinsFile],
 purpose:['scripts/ui-final-paper-purpose-live.mjs','--run-ui','--pins='+pinsFile],
 disclosure:['scripts/ui-goal-disclosure-live.mjs','--run-after-build']
};const mode=process.argv[2];assert(Object.hasOwn(tasks,mode));
const child=spawn(process.execPath,tasks[mode],{env:{...process.env,OMNI_EDU_TEST_BUILD_ROOT:pins.buildRoot},stdio:'inherit'});child.on('exit',code=>process.exitCode=code??1);child.on('error',e=>{console.error(e.code);process.exitCode=1});
