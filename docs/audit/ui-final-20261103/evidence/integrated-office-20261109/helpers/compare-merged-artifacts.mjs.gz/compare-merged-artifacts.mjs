import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {fingerprint} from '../scripts/acceptance/evidence.mjs';
const old=JSON.parse(fs.readFileSync('test-results/ui-final-settings-nav-results-pins.json')),current=JSON.parse(fs.readFileSync('test-results/ui-final-fixed-merged-pins.json'));
const compared=Object.fromEntries(['renderer','preload','main'].map(dir=>{const a=fingerprint(path.join(old.buildRoot,dir)),b=fingerprint(path.join(current.buildRoot,dir));return[dir,{before:a.sha256,after:b.sha256,identical:a.sha256===b.sha256}];}));
assert(current.sourceUnchanged);assert.equal(fingerprint('src').sha256,current.source);assert.equal(fingerprint('out').sha256,current.build);
const report={success:true,scope:'Exact artifact comparison; renderer identity is not proof of changed main/data behavior',before:old,current,compared};
fs.writeFileSync('test-results/ui-final-fixed-merged-artifact-comparison.json',JSON.stringify(report,null,2));console.log(JSON.stringify({success:true,source:current.source,build:current.build,root:current.buildRoot,compared}));
