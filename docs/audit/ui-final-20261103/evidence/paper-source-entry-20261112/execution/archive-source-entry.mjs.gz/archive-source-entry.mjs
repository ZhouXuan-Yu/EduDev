import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'../../../..');
const results=path.join(root,'apps/desktop/test-results');
const destination=path.join(root,'docs/audit/ui-final-20261103/evidence/paper-source-entry-20261112');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const files=new Map();
for(const name of fs.readdirSync(import.meta.dirname)){
  if(/source-entry|source-ready|source-focus|source-integrated|paper-source-|before-source-draft/.test(name)&&/\.(log|json|mjs|tsx)$/.test(name)){
    files.set('execution/'+name+'.gz',path.join(import.meta.dirname,name));
  }
}
const folders=['paper-source-entry-3zqT2t','paper-source-entry-RdPdCI','paper-source-entry-36zJzj',
  'paper-source-entry-6PugI3','paper-source-entry-ZdJYHJ',...process.argv.slice(2)];
for(const folder of folders){
  assert(!path.isAbsolute(folder)&&!folder.split(/[\\/]/).includes('..'));
  const source=path.join(results,folder);
  assert(fs.existsSync(path.join(source,'report.json')),folder);
  files.set(folder+'/report.json.gz',path.join(source,'report.json'));
  for(const entry of fs.readdirSync(source,{recursive:true,withFileTypes:true})){
    if(!entry.isFile()||!entry.name.endsWith('.png'))continue;
    const absolute=path.join(entry.parentPath,entry.name),inside=path.relative(source,absolute);
    if(inside.split(path.sep).some(part=>['data','profile','workspace'].includes(part)))continue;
    files.set(folder+'/'+inside,absolute);
  }
}
fs.mkdirSync(destination,{recursive:true});
const manifest=[];
for(const [name,source]of files){
  const file=name.replaceAll('\\','/'),original=fs.readFileSync(source),bytes=file.endsWith('.gz')?gzipSync(original):original;
  const target=path.join(destination,file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);
  assert.deepEqual(file.endsWith('.gz')?gunzipSync(fs.readFileSync(target)):fs.readFileSync(target),original);
  manifest.push({file,bytes:bytes.length,sha256:sha(bytes),originalBytes:original.length,originalSha256:sha(original)});
}
fs.writeFileSync(path.join(destination,'manifest.json'),JSON.stringify({scope:'Controlled real first-source UI evidence, original failures and interrupted pre-fix smoke retained. No user database/profile/private daily screenshots.',fullUiFinalAccepted:false,files:manifest},null,2));
console.log(JSON.stringify({files:manifest.length,bytes:manifest.reduce((sum,row)=>sum+row.bytes,0)}));
