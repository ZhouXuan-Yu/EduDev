import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';
const root = path.resolve(import.meta.dirname, '../../../..');
const results = path.join(root, 'apps/desktop/test-results');
const destination = path.join(root, 'docs/audit/ui-final-20261103/evidence/paper-editor-20261112');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const files = new Map();
const folders = new Set();
for (const name of ['archive-editor.mjs', 'launch-editor-native.mjs']) files.set('execution/' + name + '.gz', path.join(import.meta.dirname, name));
for (const name of fs.readdirSync(import.meta.dirname)) {
  const source = path.join(import.meta.dirname, name);
  if (!name.startsWith('editor-') || !fs.statSync(source).isFile() || !/\.(json|log|mjs|exit)$/.test(name)) continue;
  files.set('execution/' + name + '.gz', source);
  if (!name.endsWith('.log')) continue;
  for (const line of fs.readFileSync(source, 'utf8').split(/\r?\n/)) {
    let output = line.startsWith('RAW_REPORT ') ? line.slice(11) : line.startsWith('REPORT ') ? line.slice(7) : undefined;
    try {output ||= JSON.parse(line).output;} catch {}
    if (output && path.basename(output) === 'report.json') output = path.dirname(output);
    if (!output || !fs.existsSync(path.join(output, 'report.json'))) continue;
    const actual = path.resolve(output);
    assert(actual.startsWith(results + path.sep));
    folders.add(actual);
  }
}
for (const source of folders) {
  const folder = path.relative(results, source);
  files.set(folder + '/report.json.gz', path.join(source, 'report.json'));
  for (const entry of fs.readdirSync(source, {recursive: true, withFileTypes: true})) {
    if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
    const absolute = path.join(entry.parentPath, entry.name), inside = path.relative(source, absolute);
    if (inside.split(path.sep).some(part => ['data', 'profile', 'workspace'].includes(part))) continue;
    files.set(folder + '/' + inside, absolute);
  }
}
for (const folder of ['editor-r0-source', 'editor-original-tests']) {
  const source = path.join(import.meta.dirname, folder);
  for (const entry of fs.readdirSync(source, {withFileTypes: true, recursive: true})) {
    if (entry.isFile()) files.set(folder + '/' + path.relative(source, path.join(entry.parentPath, entry.name)) + (entry.name.endsWith('.png') ? '' : '.gz'), path.join(entry.parentPath, entry.name));
  }
}
const smokeLog = path.join(import.meta.dirname, 'editor-integrated-smoke.log');
if (fs.existsSync(smokeLog)) {
  const start = fs.statSync(smokeLog).birthtimeMs;
  for (const name of fs.readdirSync(path.join(results, 'electron-e2e'))) {
    const source = path.join(results, 'electron-e2e', name);
    if (name.endsWith('.png') && fs.statSync(source).mtimeMs >= start) {
      const previous = path.join(destination, 'integrated-smoke', name);
      files.set('integrated-smoke/' + name, fs.existsSync(previous) ? previous : source);
    }
  }
}
const finalSmokeLog = path.join(import.meta.dirname, 'editor-final-smoke.log');
if (fs.existsSync(finalSmokeLog)) {
  const start = fs.statSync(finalSmokeLog).birthtimeMs;
  for (const name of fs.readdirSync(path.join(results, 'electron-e2e'))) {
    const source = path.join(results, 'electron-e2e', name);
    if (name.endsWith('.png') && fs.statSync(source).mtimeMs >= start) files.set('final-smoke/' + name, source);
  }
}
fs.mkdirSync(destination, {recursive: true});
const manifest = [];
for (const [name, source] of files) {
  const file = name.replaceAll('\\', '/'), original = fs.readFileSync(source);
  const bytes = file.endsWith('.gz') ? gzipSync(original) : original;
  const target = path.join(destination, file);
  fs.mkdirSync(path.dirname(target), {recursive: true}); fs.writeFileSync(target, bytes);
  assert.deepEqual(file.endsWith('.gz') ? gunzipSync(fs.readFileSync(target)) : fs.readFileSync(target), original);
  manifest.push({file, bytes: bytes.length, sha256: sha(bytes), originalBytes: original.length, originalSha256: sha(original)});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({scope: 'Actual formal Electron editor/settings/modal, original source/version/permission guards. All QA failures retained. Teacher data/profiles and private daily screenshots excluded.', fullUiFinalAccepted: false, files: manifest}, null, 2));
console.log(JSON.stringify({files: manifest.length, bytes: manifest.reduce((n, r) => n + r.bytes, 0)}));
