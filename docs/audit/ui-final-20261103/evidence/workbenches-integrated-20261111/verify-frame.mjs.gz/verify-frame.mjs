import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {_electron as electron} from 'playwright';
import {fingerprint, sha256} from '../../scripts/acceptance/evidence.mjs';
import {assertIsolatedPiMain} from '../../scripts/acceptance/build-root.mjs';
import {continuationBootstrap, continuationGuardRead} from '../../scripts/acceptance/paper-adaptation-continuation.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const pins = JSON.parse(fs.readFileSync(path.join(base, 'pins-integrated.json')));
const output = fs.mkdtempSync(path.join(base, 'frame-'));
const data = path.join(output, 'data');
const profile = path.join(output, 'profile');
fs.mkdirSync(data);
fs.mkdirSync(profile);
const main = path.join(pins.buildRoot, 'main/index.js');
const bootstrap = path.join(output, 'bootstrap.cjs');
fs.writeFileSync(bootstrap, continuationBootstrap({main, profile}));
const report = {success:false, pins, output, samples:[], errors:[],
  scope:'Actual integrated Electron composer application frame in three light viewports. Empty genuine profile. Does not establish full-page pixel parity or populated teaching quality.'};
const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
const verify = () => {
  assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
  assert.equal(fingerprint(pins.buildRoot).sha256, pins.build);
};
const env = {...process.env};
for (const key of Object.keys(env)) {
  if (/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(key) || key.startsWith('OMNI_EDU_') ||
      ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL'].includes(key)) delete env[key];
}
Object.assign(env, {OMNI_EDU_DATA_ROOT:data, OMNI_EDU_REPO_ROOT:path.resolve(desktop, '../..'),
  OMNI_EDU_XIAOZHI_PI:'1', OMNI_EDU_E2E_VISIBLE:'1'});
let app;
const timer = setTimeout(() => {
  report.errors.push({code:'FRAME_TOTAL_DEADLINE'});
  save();
  if (app) spawn('taskkill.exe', ['/PID', String(app.process().pid), '/T', '/F'], {windowsHide:true, stdio:'ignore'});
}, 120000);
try {
  verify();
  const reference = fs.readFileSync(path.join(desktop, '../../docs/design/system/ideal/composer.css'), 'utf8');
  assert(reference.includes('border: 1px solid #e3e5eb; border-radius: 16px;'));
  assert(reference.includes('border-color: #91a5c9; box-shadow: none;'));
  report.referenceSha256 = sha256(reference);
  app = await electron.launch({args:[bootstrap, '--user-data-dir=' + profile, '--force-device-scale-factor=1'],
    cwd:output, env, timeout:30000});
  report.pid = app.process().pid;
  const page = await app.firstWindow({timeout:30000});
  page.setDefaultTimeout(10000);
  page.on('pageerror', error => report.errors.push({kind:'pageerror', hash:sha256(String(error))}));
  page.on('console', message => {
    if (message.type() === 'error') report.errors.push({kind:'console', hash:sha256(message.text())});
  });
  await page.getByTestId('workbench-home').waitFor();
  report.identity = await assertIsolatedPiMain(app, main, profile);
  await page.emulateMedia({colorScheme:'light'});
  const input = page.getByTestId('office-prompt-input');
  assert.equal(await input.inputValue(), '');
  for (const [width, height] of [[1366,768], [1920,1080], [800,768]]) {
    await app.evaluate(({BrowserWindow}, size) => BrowserWindow.getAllWindows()[0].setContentSize(size.width, size.height), {width,height});
    await page.waitForFunction(size => innerWidth === size.width && innerHeight === size.height, {width,height});
    for (const state of ['normal', 'focus']) {
      if (state === 'normal') await page.getByTestId('workbench-home').getByRole('heading').click();
      else await input.click();
      const sample = await page.locator('.wb-input-frame:visible').evaluate(element => {
        const style = getComputedStyle(element), rect = element.getBoundingClientRect();
        const main = document.querySelector('main');
        return {width:innerWidth, height:innerHeight, dpr:devicePixelRatio,
          borderWidth:style.borderTopWidth, borderStyle:style.borderTopStyle,
          borderColor:style.borderTopColor, radius:style.borderTopLeftRadius,
          boxShadow:style.boxShadow, focusWithin:element.matches(':focus-within'),
          rect:{left:rect.left,right:rect.right,top:rect.top,bottom:rect.bottom},
          main:main && {clientWidth:main.clientWidth,scrollWidth:main.scrollWidth}};
      });
      assert.equal(sample.borderWidth, '1px');
      assert.equal(sample.borderStyle, 'solid');
      assert.equal(sample.radius, '16px');
      assert.equal(sample.borderColor, state === 'normal' ? 'rgb(227, 229, 235)' : 'rgb(145, 165, 201)');
      assert.equal(sample.boxShadow, 'none');
      assert.equal(sample.focusWithin, state === 'focus');
      assert(sample.rect.left >= 0 && sample.rect.right <= width && sample.rect.bottom <= height);
      assert(sample.main.scrollWidth <= sample.main.clientWidth);
      const file = path.join(output, `composer-${width}-${state}.png`);
      await page.screenshot({path:file});
      report.samples.push({state, ...sample, file, sha256:sha256(fs.readFileSync(file))});
      save();
    }
  }
  assert.equal(await input.inputValue(), '');
  report.guard = await app.evaluate(continuationGuardRead, true);
  assert.equal(report.guard.networkAttempts, 0);
  assert.equal(report.guard.modelAttempts, 0);
  assert.equal(report.guard.rendererErrors, 0);
  assert.deepEqual(report.errors, []);
  verify();
  report.success = true;
} catch (error) {
  report.failure = {message:error.message, stackHash:sha256(String(error.stack))};
  process.exitCode = 1;
} finally {
  clearTimeout(timer);
  try { await app?.close(); report.closed = true; }
  catch (error) { report.success = false; report.closeError = sha256(String(error)); process.exitCode = 1; }
  save();
  console.log(JSON.stringify({success:report.success, samples:report.samples.length, output, failure:report.failure}));
}
