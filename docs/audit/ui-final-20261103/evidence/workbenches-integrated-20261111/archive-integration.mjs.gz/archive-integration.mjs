import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const destination = path.resolve(base, '../../../../docs/audit/ui-final-20261103/evidence/workbenches-integrated-20261111');
assert(!fs.existsSync(destination));
const selected = ['pins-integrated.json', 'integration-before.json', 'integrated-build.log',
  'components-integrated.log', 'styles-integrated.log', 'integrated-word.log', 'integrated-folder.log',
  'integrated-smoke.log', 'integrated-smoke-adapted.log', 'smoke-query-diagnostic.json',
  'smoke-first-failure.png', 'electron-smoke-before.mjs', 'frame-integrated.log',
  'verify-frame.mjs', 'formal-launch.json', 'formal-launch-verified.json', 'archive-integration.mjs'];
for (const name of fs.readdirSync(path.join(base, 'frame-gehyzu'))) {
  if (name === 'report.json' || name.endsWith('.png')) selected.push('frame-gehyzu/' + name);
}
const files = [];
for (const name of selected) {
  const raw = fs.readFileSync(path.join(base, name));
  const png = name.endsWith('.png');
  if (png) assert(raw.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalBytes:raw.length,
    originalSha256:sha256(raw), encoding:png ? 'original-png' : 'gzip',
    ...(png ? {width:raw.readUInt32BE(16), height:raw.readUInt32BE(20)} : {})});
}
const manifest = {scope:'Current integrated build, exact composer frame and focused states, complete legacy smoke with original failure, current native launch metadata. Excludes user screenshots, all data/profile/native sessions and the backup output.',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'pins-integrated.json'))), files};
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2));
console.log(JSON.stringify({destination, files:files.length, bytes:files.reduce((sum, file) => sum + file.bytes, 0)}));
