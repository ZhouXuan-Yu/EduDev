import fs from 'node:fs';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';

const base=path.resolve(import.meta.dirname,'../ui-alignment-20261111');
const result=[];
for(const name of fs.readdirSync(base).filter(name=>name.startsWith('before-state-archive-'))) {
  const file=path.join(base,name,'data/app.db');
  if(!fs.existsSync(file))continue;
  const db=new DatabaseSync(file,{readOnly:true});
  try {
    const tables=db.prepare("SELECT name FROM sqlite_schema WHERE type='table' AND name LIKE '%classroom%'").all();
    const counts=tables.map(({name})=>({table:name,count:db.prepare(`SELECT count(*) AS n FROM "${name}"`).get().n}));
    const confirmationTable=db.prepare("SELECT 1 FROM sqlite_schema WHERE type='table' AND name='ai_confirmation_items'").get();
    const classroomRows=confirmationTable?db.prepare("SELECT status,count(*) AS count FROM ai_confirmation_items WHERE action_type='pi_classroom_candidate' GROUP BY status").all():[];
    result.push({file,counts,classroomRows});
  } finally {db.close();}
}
fs.writeFileSync(path.join(import.meta.dirname,'owned-classroom-inventory.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
