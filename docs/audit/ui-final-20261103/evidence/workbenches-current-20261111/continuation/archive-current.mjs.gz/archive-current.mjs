import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {spawnSync} from 'node:child_process';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const source = import.meta.dirname;
const desktop = path.resolve(source, '../..');
const repository = path.resolve(desktop, '../..');
const destination = path.join(repository, 'docs/audit/ui-final-20261103/evidence/workbenches-current-20261111');
assert(!fs.existsSync(destination));
const files = [];

function include(file, label) {
  const bytes = fs.readFileSync(file);
  const raster = /\.(png|jpe?g)$/.test(file);
  let metadata;
  if (raster) {
    const check = spawnSync('python', ['-c', 'import sys,json; from PIL import Image; im=Image.open(sys.argv[1]); im.verify(); im=Image.open(sys.argv[1]); print(json.dumps({"format":im.format,"width":im.width,"height":im.height}))', file], {encoding:'utf8', windowsHide:true});
    assert.equal(check.status, 0);
    metadata = JSON.parse(check.stdout);
  } else {
    assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(bytes.toString('utf8')), label);
  }
  const encoded = raster ? bytes : gzipSync(bytes);
  assert.deepEqual(raster ? encoded : gunzipSync(encoded), bytes);
  const relative = label.replaceAll('\\', '/') + (raster ? '' : '.gz');
  const target = path.resolve(destination, relative);
  assert(target.startsWith(destination + path.sep));
  files.push({target, encoded, entry:{file:relative, originalBytes:bytes.length,
    originalSha256:sha256(bytes), bytes:encoded.length, sha256:sha256(encoded),
    encoding:raster ? 'original-' + metadata.format.toLowerCase() : 'gzip', ...metadata}});
}

function top(directory, label) {
  for (const name of fs.readdirSync(directory)) {
    const file = path.join(directory, name);
    if (fs.statSync(file).isFile() && /\.(json|png|jpe?g|log|md|mjs|cjs|txt)$/.test(name)) {
      if (name === 'local-failure.json') continue;
      include(file, path.join(label, name));
    }
  }
}

top(source, 'continuation');
for (const directory of ['settings-qa', 'settings-qa/configuration', 'teaching-qa',
  'reading-source-GG21id', 'reading-source-PIn6jW', 'reading-source-XEU7H0', 'reading-source-AGSqEp']) {
  top(path.join(source, directory), directory);
}
for (const directory of ['ui-final-settings-5WeKTp', 'ui-final-settings-NXpXo7',
  'ui-final-configuration-fEwMlR', 'ui-final-teaching-editors-uI5c4g',
  'ui-final-teaching-editors-jxrUZe', 'ui-final-teaching-editors-70s46g']) {
  top(path.join(desktop, 'test-results', directory), directory);
}
assert.equal(new Set(files.map(item => item.entry.file)).size, files.length);
const manifest = {
  scope:'Owned synthetic reading source, actual teaching/settings/configuration UI, original failures and pure controls. Excludes DB, profiles, native sessions and daily screenshots.',
  pins:JSON.parse(fs.readFileSync(path.join(source, 'pins.json'))),
  files:files.map(item => item.entry),
};
for (const item of files) {
  fs.mkdirSync(path.dirname(item.target), {recursive:true});
  fs.writeFileSync(item.target, item.encoded, {flag:'wx'});
  assert.equal(sha256(fs.readFileSync(item.target)), item.entry.sha256);
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2), {flag:'wx'});
console.log(JSON.stringify({files:files.length, destination,
  encodedBytes:files.reduce((total, item) => total + item.entry.bytes, 0)}));
