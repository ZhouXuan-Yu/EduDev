# Configuration fixture 选择适配交接

已完成并释放单文件写集 scripts/ui-final-configuration-live.mjs。

## 参数与来源

原 --run-ui --pins 两参数继续使用原 ui-final-public-handoff-dMY7kj 路径与 success=true 断言。新增可选 --fixture-source=<owned raw report>，要求唯一、非空；仅新分支动态加载原 readPersistedFixtureSource(file,desktop,pins)。该 qualifier 负责 owned 路径、固定 pins、真实 SQLite/native/来源/图片/批准和 pending 事实认证。

qualified.reference 直接作为 original，原 data/profile 复制语句和全部原 sourceHash 检查保留。原 producer report success=false 及其 cold QA 失败身份保留，runner 新报告增加 sourceQualification 和 producerReport，包含文件、SHA、FAIL、success=false 及原 failure。

当前 producer 为 retained-qa/run-2PLnoP/report.json，SHA256 为 599051c5b0acfaaed60050bbfecf22d959a0c8c5484e5632aa4dad37ab236370。原 2 Pi tasks、9 responses、两个 confirmed 和一个 pending 由既有 qualifier 实际只读校验通过。

## sourceReport 消费者核对

原 sourceReport 只用于 ctx.sessionId 与冷启末轮 runId。三例实际属于同一 session，两例已批准题共享前一轮；pending 例为后一停止轮。因此新分支从 qualifier 的 pending case 投影 sessionId/runId，保留原 cold turns.at(-1).id 断言。只读 SQL 已核对该 run 为最新 ai_agent_runs 行且状态 blocked。该身份映射属于本次适配决策。

## 验证与守恒

在仓库根执行下列纯核验，19/19 PASS，Nodecheck exit0。

```powershell
node apps/desktop/test-results/ui-final-workbenches-20261111/settings-qa/configuration/verify.mjs
```

内部 Nodecheck 命令为 node --check scripts/ui-final-configuration-live.mjs。完整 stdout、AST 结果与前后 SHA 在 static-report.json。

AST 证明来源选择之后的全部原语句逐字保留，仅报告增加两个 provenance 字段。原 17 check 名称及三个 journey/provider 文件 SHA 保留，原所有 assert 保留，仅参数数量断言扩展为允许可选参数。全部 timeout、180s、launch 调用、受控 catalogue、真实 loopback MCP、零 chat、密钥清理/脱敏/加密检查、IPC、ledger 与 sourceHash 完整性语句保留。原 producer 文件与 baseline source tree SHA 前后一致。

本轮 launches/http/models 为 0。root 提供的 retained wUcOc7 三次实际冷读 PASS 属于该独立 reader 的证据。configuration 原实际路径、冷启和耗时验证状态为 NOT_RUN，由 root 使用同 pins 执行。

## root 命令

在 apps/desktop 执行原 --run-ui --pins 命令，追加以下参数。

```text
--fixture-source="D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-content-20261111\retained-qa\run-2PLnoP\report.json"
```

回滚先核对 static-report.json 中 runner 修改后 SHA，仅撤销参数、来源选择与两个报告字段差异，对照 configuration-before.mjs 保留后续协作修改。
