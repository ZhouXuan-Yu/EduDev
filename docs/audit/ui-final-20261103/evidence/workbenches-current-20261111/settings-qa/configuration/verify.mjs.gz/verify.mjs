/** AST, argument parsing and read-only qualifier evidence. No runner import. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
const evidence=path.dirname(fileURLToPath(import.meta.url)),desktop=path.resolve(evidence,'../../../..');
const require=createRequire(path.join(desktop,'package.json')),ts=require('typescript');
const {sha256,fingerprint}=await import(pathToFileURL(path.join(desktop,'scripts/acceptance/evidence.mjs')));
const {readPersistedFixtureSource,readSql}=await import(pathToFileURL(path.join(desktop,'scripts/acceptance/retained-fixture-evidence.mjs')));
const baseline=JSON.parse(fs.readFileSync(path.join(evidence,'before.json'),'utf8'));
const file=path.join(desktop,baseline.files[0].file),text=fs.readFileSync(file,'utf8'),oldText=fs.readFileSync(path.join(evidence,'configuration-before.mjs'),'utf8');
const parse=value=>ts.createSourceFile('configuration.mjs',value,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const old=parse(oldText),current=parse(text),code=node=>node.getText(node.getSourceFile());
function nodes(root,predicate){const found=[];function visit(node){if(predicate(node))found.push(node);ts.forEachChild(node,visit);}visit(root);return found;}
const checks=[];async function check(name,action){await action();checks.push({name,status:'PASS'});}
await check('all_statements_after_source_selection_preserved_except_two_report_fields',()=>{
 const start="assert(!fs.existsSync(path.join(original,'data/app.db-wal'))";
 assert.equal(text.slice(text.indexOf(start)).replace('sourceQualification,producerReport,',''),oldText.slice(oldText.indexOf(start)));
});
await check('legacy_default_own_and_success_guard_preserved',()=>{
 assert(text.includes("own('test-results/ui-final-public-handoff-dMY7kj')"));
 assert(text.includes("sourceReport=JSON.parse(fs.readFileSync(path.join(original,'report.json')));assert.equal(sourceReport.success,true)"));
});
const assertions=ast=>nodes(ast,node=>ts.isCallExpression(node)&&/^assert(?:\.|$)/.test(code(node.expression))).map(code);
await check('all_original_assertions_retained_except_optional_argument_arity',()=>{
 const available=assertions(current);
 for(const statement of assertions(old).filter(value=>value!=='assert.equal(args.length,2)')){
  const index=available.indexOf(statement);assert(index>=0,statement);available.splice(index,1);
 }
});
await check('all_timeouts_launches_controlled_services_and_sourceHash_guards_preserved',()=>{
 const timing=ast=>nodes(ast,node=>ts.isPropertyAssignment(node)&&code(node.name)==='timeout'||ts.isCallExpression(node)&&/^(setTimeout|clearTimeout|electron\.launch|launch|startMcpFixture)$/.test(code(node.expression))).map(code);
 assert.deepEqual(timing(current),timing(old));
 assert(text.includes('const deadline=Date.now()+180000'));
});
await check('all_seventeen_check_names_and_journey_dependencies_preserved',()=>{
 const names=ast=>nodes(ast,node=>ts.isCallExpression(node)&&code(node.expression)==='check').map(node=>node.arguments[0].text);
 assert.deepEqual(names(current),names(old));let count=names(current).length;
 for(const item of baseline.files.slice(1)){
  const bytes=fs.readFileSync(path.join(desktop,item.file));assert.equal(sha256(bytes),item.sha256,item.file);
  if(/configuration-(model|skill|mcp)-journey/.test(item.file))count+=names(parse(bytes.toString())).length;
 }
 assert.equal(count,17);
});
const argumentCode=text.slice(text.indexOf('const fixtureArgs='),text.indexOf('const owned='));
function argumentsOnly(args){return vm.runInNewContext(argumentCode+'\n({fixtureArgs,arg})',{args,assert});}
await check('original_two_arguments_and_new_three_arguments_accept',()=>{
 assert.equal(argumentsOnly(['--run-ui','--pins=p.json']).fixtureArgs.length,0);
 assert.equal(argumentsOnly(['--fixture-source=owned/report.json','--pins=p.json','--run-ui']).fixtureArgs.length,1);
});
for(const [name,args]of [
 ['empty_fixture',['--run-ui','--pins=p.json','--fixture-source=']],
 ['blank_fixture',['--run-ui','--pins=p.json','--fixture-source=  ']],
 ['duplicate_fixture',['--run-ui','--pins=p.json','--fixture-source=a','--fixture-source=b']],
 ['missing_pins',['--run-ui','--fixture-source=a']],
 ['unknown_option',['--run-ui','--pins=p.json','--extra']],
 ['missing_run',['--pins=p.json','--fixture-source=a']],
 ['split_fixture',['--run-ui','--pins=p.json','--fixture-source','a']]
])await check(name+'_rejected',()=>assert.throws(()=>argumentsOnly(args)));
const producer=JSON.parse(fs.readFileSync(baseline.rawReport,'utf8')),pins=producer.pins;
const sourceBefore=fingerprint(producer.sourceRoot).sha256;
const qualified=readPersistedFixtureSource(baseline.rawReport,desktop,pins);
await check('actual_qualifier_preserves_original_failed_producer_and_three_genuine_cases',()=>{
 assert.equal(producer.success,false);assert.equal(qualified.qualification.producerStatus,'FAIL');
 assert.deepEqual(qualified.cases.map(item=>[item.role,item.status]),[['single','confirmed'],['multi','confirmed'],['pending','pending']]);
 assert.equal(qualified.reference,producer.sourceRoot);
});
const selection=text.slice(text.indexOf('const original=qualified?'),text.indexOf("assert(!fs.existsSync(path.join(original,'data/app.db-wal'))"));
const own=value=>fs.realpathSync(path.resolve(desktop,value));
const observed=vm.runInNewContext(selection+'\n({original,sourceHash,sourceReport,sourceQualification,producerReport})',{qualified,fs,path,fingerprint,assert,own});
const runs=readSql(path.join(qualified.reference,'data'),query=>query('SELECT * FROM ai_agent_runs ORDER BY created_at,id'));
await check('sourceReport_maps_to_actual_latest_stopped_run_for_unchanged_cold_assertion',()=>{
 assert.equal(observed.sourceReport.sessionId,qualified.cases.find(item=>item.role==='pending').sessionId);
 assert.equal(observed.sourceReport.runId,runs.at(-1).id);assert.equal(runs.at(-1).status,'blocked');
 assert(text.includes('old.projection.turns.at(-1).id,sourceReport.runId'));
});
await check('legacy_missing_source_still_fails_and_does_not_fall_back',()=>assert.throws(()=>vm.runInNewContext(selection,{qualified:undefined,fs,path,fingerprint,assert,own}),/ENOENT/));
await check('qualification_rejects_other_pins_and_outside_owned_report',()=>{
 assert.throws(()=>readPersistedFixtureSource(baseline.rawReport,desktop,{...pins,source:'0'.repeat(64)}));
 assert.throws(()=>readPersistedFixtureSource(path.join(desktop,'package.json'),desktop,pins));
});
await check('original_producer_bytes_and_source_tree_preserved',()=>{
 assert.equal(sha256(fs.readFileSync(baseline.rawReport)),baseline.rawReportSha256);
 assert.equal(fingerprint(qualified.reference).sha256,sourceBefore);
});
const syntax=spawnSync(process.execPath,['--check',file],{cwd:desktop,encoding:'utf8',windowsHide:true,timeout:10000});
await check('nodecheck_exit_zero',()=>assert.equal(syntax.status,0,syntax.stderr));
const report={status:'PASS',checks,runner:{file:baseline.files[0].file,beforeSha256:baseline.files[0].sha256,afterSha256:sha256(fs.readFileSync(file))},
 producerReport:observed.producerReport,sourceQualification:observed.sourceQualification,sourceReference:observed.original,boundRun:observed.sourceReport,
 originalChecks:17,nodecheck:{command:'node --check scripts/ui-final-configuration-live.mjs',cwd:desktop,exitCode:syntax.status,stdout:syntax.stdout,stderr:syntax.stderr},
 launches:0,http:0,models:0,actualConfigurationAcceptance:'NOT_RUN',runtimePerformance:'NOT_RUN',writeSetReleased:true};
fs.writeFileSync(path.join(evidence,'static-report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({status:report.status,checks:checks.length,originalChecks:17,nodecheckExitCode:syntax.status,launches:0,actualConfigurationAcceptance:'NOT_RUN'}));
