# A17 设置分层适配交接

已完成并释放单 helper 写集。仅修改 scripts/acceptance/ui-final-settings-journey.mjs 首个 A17-layering callback。

## 修改与来源

models 下继续断言 models、permissions、interface、backup 四项日常入口可见，保持 skills 初始折叠检查和原截图。随后通过原 tab helper 进入 backup，断言真实 archives 按钮可见且 enabled，进入 archives 等待原 pi-settings-archive-empty，再回 models，继续原 skills/tools/key 路径。

层级依据为 approved settings.js 四个日常组、生产 SettingsNavigation.tsx 的 daily4，以及 PiSettingsWorkspace.tsx 的 backup/archives 内部 sectionNavigation 和真实归档空态。fresh 合成数据仍要求零归档的原空态。

## 已完成验证

- Nodecheck exit 0。
- 7 项 AST／源码守恒检查 PASS。
- 原 14 个 check ID 及顺序保持，后 13 个完整正文逐字保留。
- 首 callback 外所有字节相同。首 callback 仅改变日常数组并加入 backup→archives→models 路径。
- 全部原 assert 保留，新增 archives 可见/可用两条断言。全部显式 timeout、三个 relaunch 调用、backup/restore/authority/cold 保证保持原文。
- 原 5WeKTp FAIL 报告 SHA 及生产 workspace SHA 前后一致。

命令为 node --check scripts/acceptance/ui-final-settings-journey.mjs，工作目录为 apps/desktop。精确 AST 结果与修改前后 SHA 保存在 static-report.json，修改前全文为 journey-before.mjs。

## root 接续

本轮 launches=0。原四 launch／14 checks、当前同 pins 的实际 Electron 验收及运行耗时由 root 执行，当前状态 NOT_RUN。source b582/build 00ccd 为 root 指定身份，本轮修改限定 QA helper。

回滚先核对 static-report.json 的修改后 SHA，仅撤销首 callback 内本次数组及归档路径差异，保护后续协作修改。
