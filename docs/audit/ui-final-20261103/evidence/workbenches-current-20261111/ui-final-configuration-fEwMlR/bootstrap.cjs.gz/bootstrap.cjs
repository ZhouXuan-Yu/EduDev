const e=require('electron'),fs=require('node:fs');const startup={pid:process.pid,startedAt:Date.now(),phases:[]};const mark=name=>{startup.phases.push({name,at:Date.now()});fs.writeFileSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-configuration-fEwMlR\\startup.json",JSON.stringify(startup));};mark('bootstrap-start');e.app.on('browser-window-created',()=>mark('window-created'));process.on('exit',()=>mark('process-exit'));e.app.setPath('userData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-configuration-fEwMlR\\profile");e.app.setPath('sessionData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-configuration-fEwMlR\\profile");
globalThis.__configurationBrowserAttempts=0;e.app.whenReady().then(async()=>{
mark('app-ready');
e.session.defaultSession.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*']},(d,cb)=>{const ok=d.url==="http://127.0.0.1:58352/mcp";if(!ok)globalThis.__configurationBrowserAttempts++;cb({cancel:!ok});});
(function installConfigurationProvider(electron){
 const state=globalThis.__configurationProvider={catalogues:0,invalidCredentials:0,failNext:false,externalAttempts:0,modelAttempts:0};
 electron.net.fetch=async(input,init)=>{
  const url=new URL(typeof input==='string'?input:input.url);
  if(url.origin!=='https://api.deepseek.com'){state.externalAttempts++;throw Error('CONFIG_EXTERNAL_DENIED');}
  if(url.pathname.replace(/^\/v1(?=\/)/,'')!=='/models'){state.modelAttempts++;throw Error('CONFIG_GENERATION_DENIED');}
  if(++state.catalogues>18)throw Error('CONFIG_CATALOGUE_BUDGET');
  const headers=new Headers(init?.headers??input.headers),token=headers.get('authorization')||'';
  if(!token.startsWith('Bearer owned-config-valid-')){state.invalidCredentials++;return new Response('{}',{status:401});}
  if(state.failNext){state.failNext=false;return new Response('{}',{status:503});}
  return new Response(JSON.stringify({object:'list',data:['deepseek-flash','deepseek-v4-pro'].map(id=>({id,name:id,context_window:1048576,max_output_tokens:393216,effort:{supported_levels:['low','high','max'],default_level:'high'}}))}));
 };
})(e);
mark('before-main-import');
await import(require('node:url').pathToFileURL("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\frozen-out-integrated\\main\\index.js").href);
mark('after-main-import');
}).catch(error=>{require('node:fs').writeFileSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-configuration-fEwMlR\\bootstrap-error.json",JSON.stringify({code:error.code,hash:require('node:crypto').createHash('sha256').update(String(error.stack)).digest('hex')}));e.app.exit(1);});