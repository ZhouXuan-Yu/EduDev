/** Synthetic validator inputs stay in memory. This produces no saved-reading evidence. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256,fingerprint} from '../../../scripts/acceptance/evidence.mjs';
import {readPersistedFixtureSource} from '../../../scripts/acceptance/retained-fixture-evidence.mjs';
import {readingSnapshot,readingFiles,transportSnapshot,assertReadingDelta,readingContracts,sourceChunk,
  validateReadingRow,assertReadingGuard,readOwnedReadingReport} from '../../../scripts/acceptance/reading-source-evidence.mjs';

const output=path.dirname(fileURLToPath(import.meta.url)),desktop=path.resolve(output,'../../..');
const pins=JSON.parse(fs.readFileSync(path.join(output,'../pins.json')));
const source=readPersistedFixtureSource(path.join(desktop,'test-results/ui-final-content-20261111/retained-qa/run-2PLnoP/report.json'),desktop,pins);
const originalBefore=fingerprint(source.reference).sha256,data=path.join(source.reference,'data');
const before=readingSnapshot(data),controls=[];
const check=async(name,work)=>{
  try{await work();controls.push({name,status:'PASS'});}
  catch(error){
    controls.push({name,status:'FAIL',hash:sha256(error.stack||String(error))});
    fs.writeFileSync(path.join(output,'pure-controls-failure.json'),JSON.stringify({controls,launches:0,modelRequests:0},null,2)+'\n');
    throw Error('PURE_CONTROL_FAILED '+name);
  }
};
const {materialBodyVersion}=await readingContracts(desktop);
const resource=before.tables.teacher_resources[0];
const chunk=before.tables.resource_chunks.filter(row=>row.resource_id===resource.id)
  .sort((a,b)=>a.chunk_index-b.chunk_index||(a.id<b.id?-1:1))[0];
const anchor={schemaVersion:'xiaozhi.material-source.v1',resourceId:resource.id,version:resource.content_hash,
  offset:0,chunkId:chunk.id,bodyVersion:materialBodyVersion(sourceChunk(chunk))};
// No INSERT, no report.savedReading, no successful reading-source report is written.
const memoryRow={sequence:1,id:'read_00000000-0000-4000-8000-000000000001',resource_id:resource.id,
  source_json:JSON.stringify(anchor),note:'人工 QA 阅读笔记（合成测试文字，非 AI 结果）。\nValidator input only.',
  completed:0,updated_at:'2026-11-11T00:00:00.000Z'};
const memoryAfter=()=>{
  const after=structuredClone(before);after.tables.material_reading_entries.push(memoryRow);
  after.tables.sqlite_sequence.push({name:'material_reading_entries',seq:1});
  after.tables.sqlite_sequence.sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));return after;
};
await check('Genuine source retains two approved questions and a pending proposal',()=>{
  assert.deepEqual(source.cases.map(row=>row.role),['single','multi','pending']);
  assert(source.cases.filter(row=>row.role!=='pending').every(row=>row.questionId));
});
await check('All real table/schema snapshots stable under read-only inspection',()=>assert.deepEqual(readingSnapshot(data),before));
await check('Transport changes only clone local_path in memory',()=>{
  const transported=transportSnapshot(before,data,path.join(output,'nonexistent-owned-clone/data'));
  assert.equal(transported.files.length,1);
  const normalized=structuredClone(transported.expected);
  normalized.tables.teacher_resources[0].local_path=resource.local_path;assert.deepEqual(normalized,before);
  assert(!fs.existsSync(path.join(output,'nonexistent-owned-clone')));
});
await check('Exact single-note delta accepted by pure comparison',()=>assertReadingDelta(before,memoryAfter(),memoryRow));
await check('Extra note rejected',()=>{
  const after=memoryAfter();after.tables.material_reading_entries.push({...memoryRow,id:'extra'});
  assert.throws(()=>assertReadingDelta(before,after,memoryRow));
});
await check('Old question, approval, pending decision, usage and native binding mutation rejected',()=>{
  for(const table of ['question_bank_items','ai_confirmation_items','xiaozhi_pi_usage','xiaozhi_pi_session_bindings']){
    const after=memoryAfter();assert(after.tables[table].length);after.tables[table][0].qaForbidden='changed';
    assert.throws(()=>assertReadingDelta(before,after,memoryRow));
  }
  const after=memoryAfter();after.tables.ai_confirmation_items.find(row=>row.status==='pending').status='confirmed';
  assert.throws(()=>assertReadingDelta(before,after,memoryRow));
});
await check('Schema, chunk and AUTOINCREMENT changes rejected',()=>{
  for(const change of [after=>after.schema.pop(),after=>after.tables.resource_chunks[0].content_md+='changed',
    after=>after.tables.sqlite_sequence.find(row=>row.name==='material_reading_entries').seq=2]){
    const after=memoryAfter();change(after);assert.throws(()=>assertReadingDelta(before,after,memoryRow));
  }
});
await check('Production source/body validators accept the exact genuine first-chunk anchor in memory',async()=>{
  const proof=await validateReadingRow(data,memoryRow,desktop);assert.deepEqual(proof.source,anchor);
  assert.equal(proof.proof.originalPdfSha256,resource.content_hash);
});
await check('Forged source version, body hash, chunk, resource and offset rejected',async()=>{
  for(const patch of [{version:'0'.repeat(64)},{bodyVersion:'0'.repeat(64)},{chunkId:'chunk_missing'},
    {resourceId:'resource_missing'},{offset:1}]){
    await assert.rejects(()=>validateReadingRow(data,{...memoryRow,source_json:JSON.stringify({...anchor,...patch})},desktop));
  }
});
await check('AI-labelled note, unknown field, bad revision and completed marker rejected',async()=>{
  for(const patch of [{note:'AI generated answer'},{extra:true},{id:'fake'},{completed:1}])
    await assert.rejects(()=>validateReadingRow(data,{...memoryRow,...patch},desktop));
});
await check('Network, model, early renderer and policy-composition failures rejected',()=>{
  const guard={networkAttempts:0,modelAttempts:0,rendererErrors:0,formalRegistrations:1,policyProbe:'FORMAL_FRAME_AND_ZERO_HTTP_VERIFIED'};
  assertReadingGuard(guard);
  for(const patch of [{networkAttempts:1},{modelAttempts:1},{rendererErrors:1},{formalRegistrations:0},{policyProbe:'wrong'}])
    assert.throws(()=>assertReadingGuard({...guard,...patch}));
});
await check('Preflight cannot be consumed as successful reading report',async()=>{
  const preflight=fs.readdirSync(path.dirname(output)).filter(name=>name.startsWith('reading-source-'))
    .map(name=>path.join(output,'..',name,'report.json')).find(file=>fs.existsSync(file)&&JSON.parse(fs.readFileSync(file)).status==='PREFLIGHT_READY');
  assert(preflight);await assert.rejects(()=>readOwnedReadingReport(path.resolve(preflight),desktop));
});
await check('Original FAIL report cannot be used as an owned reading note',async()=>{
  await assert.rejects(()=>readOwnedReadingReport(source.producerReportFile,desktop));
});
await check('Every genuine non-SQLite/native byte remains stable',()=>{
  assert(readingFiles(data).some(row=>row.file.includes('xiaozhi-pi/')));
  assert.equal(fingerprint(source.reference).sha256,originalBefore);
});
const runner=fs.readFileSync(path.join(desktop,'scripts/ui-final-reading-source-live.mjs'),'utf8');
const editor=fs.readFileSync(path.join(desktop,'scripts/ui-final-teaching-editors-live.mjs'),'utf8');
await check('Static producer permits one save click and owned transport UPDATE only',()=>{
  assert.equal((runner.match(/await click\(tid\(["']material-study-save["']\)\)/g)||[]).length,1);
  assert.equal((runner.match(/await electron\.launch\(/g)||[]).length,1);
  assert.equal((runner.match(/UPDATE teacher_resources SET local_path=/g)||[]).length,1);
  assert(!/INSERT INTO|DELETE FROM|\.getByTestId\(["']material-study-ask["']\)/.test(runner));
  assert(/OMNI_EDU_E2E_VISIBLE:\s*["']1["']/.test(runner));
  const bootstrap=runner.search(/continuationBootstrap\(\{\s*main,\s*profile/);
  assert(bootstrap>=0&&bootstrap<runner.indexOf('await electron.launch('));
});
await check('Static editor retains ten checks, two launches, 180s, legacy TEMP guards and actual row assertion',()=>{
  const codes=editor.match(/const codes=\[([\s\S]+?)\];/)[1].match(/'[A-Z_0-9]+'/g);assert.equal(codes.length,10);
  for(const token of ['deadlineAt=Date.now()+180000','budget:{launches:2,totalSeconds:180,http:0,models:0}',
    'ui-goal-20261101/materials-live/run-rEHMi2/report.json','ownedExact(noteData,fs.realpathSync(os.tmpdir()))',
    '^edudev-materials-live-[A-Za-z0-9]+$',"assert.deepEqual(actualNote,noteReport.savedReading",
    'await close();await launch();',"'QUESTION_CANCEL_SAVE_RETURN'",'materialBodyVersion(sourceChunk(anchor))'])assert(editor.includes(token),token);
});
const report={status:'PASS',controls,launches:0,modelRequests:0,businessWrites:0,
  originalUnchanged:fingerprint(source.reference).sha256===originalBefore,
  evidenceKind:'Pure validator controls. Synthetic inputs remain in memory. No reading note produced.',
  files:['ui-final-reading-source-live.mjs','acceptance/reading-source-evidence.mjs','ui-final-teaching-editors-live.mjs']
    .map(file=>({file,sha256:sha256(fs.readFileSync(path.join(desktop,'scripts',file)))}))};
fs.writeFileSync(path.join(output,'pure-controls.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,controls:controls.length,launches:0,modelRequests:0,businessWrites:0,output}));
