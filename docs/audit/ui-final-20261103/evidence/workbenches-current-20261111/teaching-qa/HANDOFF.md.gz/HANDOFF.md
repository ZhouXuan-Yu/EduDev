# A14 reading-source release

Prepared on 2026-11-11 in `D:\WorkProject\EduProject`, branch `codex/ui-goal-implementation-20261101`, observed HEAD `af6a403b57bc5ff00e1372ad6f98fe3a6894ed94`.

## Released files

- `apps/desktop/scripts/ui-final-reading-source-live.mjs`
- `apps/desktop/scripts/acceptance/reading-source-evidence.mjs`
- `apps/desktop/scripts/ui-final-teaching-editors-live.mjs`, with optional `--reading-report` input

The work is bounded QA preparation for A14. Root owns the fixed 36+8 Goal, RESULT, SETTINGS scheduling, actual UI execution, integration and final acceptance. Actual reading-note production and editor UI acceptance remain NOT_RUN in this preparation.

## Source and frozen identity

Pins are `apps/desktop/test-results/ui-final-workbenches-20261111/pins.json`.

- Source SHA256 `b5825248f1a3d4e071773f622bf3b82f4438b0e9edf7b7745de682152ff25a9c`
- Build SHA256 `00ccd8e65272c20335e118e68e45b307c439c5624b77e3b71602cf21667bf77a`
- Frozen build `apps/desktop/test-results/ui-final-content-20261111/frozen-out-integrated`
- Explicit input `apps/desktop/test-results/ui-final-content-20261111/retained-qa/run-2PLnoP/report.json`
- Genuine single question `question_4ba62e2b-403b-47bc-a045-ee9755653340`
- Genuine multi question `question_41c6c31c-bc65-48fe-a89b-1aadd26dab9d`
- Resource `resource_ef6dcaa6-a36c-47ce-a32e-c7e13e56c1c9`
- Original PDF SHA256 `83b25d81ee82f3a93eb7b53d7f0ff5d3c8b30483cbe7d69a93ab9ddfc2929939`

`readPersistedFixtureSource` independently requalifies the original FAIL report, two actual Pi tasks, nine retained responses, both approved canonical questions, pending decision, native calls/adopted plan/admissions, original PDF and PNG identities. The original FAIL status is retained in the new report's `input.qualification`. Historical wUcOc7 has three cold groups with zero added rule candidates. A read-only comparison against its first clone found only the transported teacher_resources path among all SQLite tables, and only app.db among data files.

## Execute after SETTINGS is free

Run these commands from `D:\WorkProject\EduProject\apps\desktop`. The first command launches the producer exactly once. Root schedules it after the current actual SETTINGS process has finished.

```powershell
node scripts/ui-final-reading-source-live.mjs --run-ui --pins=test-results/ui-final-workbenches-20261111/pins.json --from=test-results/ui-final-content-20261111/retained-qa/run-2PLnoP/report.json
```

Use the `output` path printed by that command. Each execution creates a new `test-results/ui-final-workbenches-20261111/reading-source-<random>` root. Set `$readingRoot` to that exact successful output path, then run the editor preflight and actual acceptance sequentially.

```powershell
$readingRoot = 'D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-workbenches-20261111\reading-source-REPLACE_WITH_ACTUAL_OUTPUT'
$readingReport = Join-Path $readingRoot 'report.json'
$reading = Get-Content -LiteralPath $readingReport -Raw | ConvertFrom-Json
if ($reading.success -ne $true) { throw 'Reading producer did not pass' }
$singleQuestion = ($reading.input.cases | Where-Object role -eq 'single').questionId
if ($singleQuestion -ne 'question_4ba62e2b-403b-47bc-a045-ee9755653340') { throw 'Unexpected single-question identity' }
node scripts/ui-final-teaching-editors-live.mjs --inspect-only --pins=test-results/ui-final-workbenches-20261111/pins.json "--fixture=$readingRoot" "--question=$singleQuestion" "--reading-report=$readingReport"
if ($LASTEXITCODE -ne 0) { throw 'Editor preflight failed' }
node scripts/ui-final-teaching-editors-live.mjs --run-ui --pins=test-results/ui-final-workbenches-20261111/pins.json "--fixture=$readingRoot" "--question=$singleQuestion" "--reading-report=$readingReport"
```

The producer report is the actual saved source. The existing editor suite creates a further owned clone. Root can retain both failed and successful output directories independently.

## Producer contract

- Explicit `--run-ui`, `--pins` and `--from` are required for UI work. `--inspect-only` qualifies the source without cloning or launching.
- Full genuine data is copied into the new owned data directory. An empty owned profile is created. Source-tree identity is checked before and after the run.
- The only direct SQL write is a transactional CAS update of clone `teacher_resources.local_path`. Original and copied file bytes must match the stored content hash. All table/schema snapshots must otherwise match immediately after transport.
- Existing `continuationBootstrap` installs the composed zero-network/frame policy before importing formal main. Credentials, inherited OMNI_EDU configuration, NODE_OPTIONS and Electron runtime overrides are stripped. `OMNI_EDU_E2E_VISIBLE=1` is explicit.
- Actual loaded main modules, profile/session storage, data root and native window visibility are observed. One launch and a 120-second total budget apply, with time reserved for finally cleanup.
- Visible production navigation follows `nav-knowledge`, catalogue, the actual PDF, `materials-section-notes`, `material-study-note` and `material-study-save`. The note is clearly labelled synthetic manual QA text. There is one save click.
- Read-only SQLite readback supplies the entire actual `material_reading_entries` row. The production source and study validators authenticate resource/version, ordered chunk offset, chunk ID, bodyVersion and original PDF SHA256. The report carries the full source resource/chunk proof.
- All 179 SQLite tables, schema and all non-SQLite data files are checked. The one permitted business delta is the append-only note row, together with its exact SQLite AUTOINCREMENT bookkeeping. Native session bytes, questions, approvals, pending state, source chunks and all other facts remain strict invariants.
- Two actual UI PNG screenshots and hashes are recorded. Final success requires a final guard observation, owned process closure, original source requalification and an independent read of the newly produced report.
- The producer has zero permitted network/model/provider requests. Failed guards or unexpected startup changes fail the report. Cleanup failure also fails the report.

## Editor compatibility

The optional source branch requires a successful owned reading-source report, matching full fixture root and explicit genuine approved question. It independently reads the typed saved row, source version/body hash, original PDF, all-table conservation, native bytes, screenshot bytes, pins, bootstrap identity and successful cleanup. The existing exact `actualNote` comparison and production source validation still run afterward.

The old default reading report path, TEMP ownership rule, `edudev-materials-live-*` name guard and legacy default question remain in the default branch. All existing code following `const actualNote` is preserved. The ten existing checks, 180-second budget, two launches, startup validator, cancellation/save/reopen assertions, cold readback, source/approval/image preservation and zero-model guard remain in place. The legacy materials producer is unchanged.

## Executed preparation evidence

- Three released scripts and `pure-controls.mjs` passed `node --check`.
- `node test-results/ui-final-workbenches-20261111/teaching-qa/pure-controls.mjs` passed 16 controls, exit 0. `pure-controls.json` records zero launches, model requests and business writes. Synthetic validator inputs exist only in memory.
- `node scripts/acceptance/paper-adaptation-continuation.mjs --self-test` passed 26 controls, exit 0. Full output is in `bootstrap-selftest.log`. It records zero provider requests and Electron launches.
- `node scripts/ui-final-reading-source-live.mjs --inspect-only --pins=test-results/ui-final-workbenches-20261111/pins.json --from=test-results/ui-final-content-20261111/retained-qa/run-2PLnoP/report.json` passed, exit 0. Latest preflight is `reading-source-a6Opjp/report.json`, with `success=false`, `status=PREFLIGHT_READY`, zero launches and no clone. It cannot be consumed as saved-reading evidence. Full output is in `preflight.log`.
- A read-only diff whitespace check earlier in preparation exited 0. Source/build pin fingerprints passed again in the final preflight. Changes are limited to the three released QA script paths and this ignored evidence directory.

The first pure-control attempt had a relative import one directory too high. The second used an unsorted in-memory SQLite sequence array. Both preparation errors were fixed before the 16-control PASS. `preparation-history.json` retains those failures. They involved zero UI launches and zero SQLite writes.

Actual UI, cold editor readback, performance comparison, build, shared smoke, model/provider generation, commit and push have not run in this preparation. The optional editor branch still needs end-to-end execution using a genuine newly saved note. Root should record its actual outcome in RESULT and preserve prior failures.

## Ownership and rollback

Production src, vendors, Goal/Master/RESULT, root collaboration documents, protected unrelated documents and daily193456 were left to their respective owners. This sidecar changed QA scripts and ignored evidence only. Source/build hashes still match the supplied pins.

Rollback is limited to removing the two new QA modules and reversing the small optional-reading-report branch in the existing editor runner. Retain the ignored run evidence and original genuine fixture. There is no production migration or dependency change. Any future generated note belongs only to its owned QA clone.
