
const e = require('electron'), fs = require('node:fs');
const start = Date.now(), phases = [];
function mark(stage) {
  phases.push({stage, elapsed: Date.now() - start});
  fs.writeFileSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-settings-5WeKTp\\startup.json", JSON.stringify(phases));
}
mark('started');
e.app.on('browser-window-created', () => mark('window-created'));
process.on('exit', () => mark('exit'));
e.app.setPath('userData', "D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-settings-5WeKTp\\profile");
e.app.setPath('sessionData', "D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-settings-5WeKTp\\profile");
globalThis["__settingsHttp"] = [];
function guarded(fetch, receiver) {
  return function (...args) {
    const value = args[0], url = typeof value === 'string' ? value : value?.url || String(value);
    if (/^https?:/i.test(url)) {
      globalThis["__settingsHttp"].push('blocked-http');
      return Promise.reject(new Error('Owned acceptance forbids network'));
    }
    return fetch.apply(receiver, args);
  };
}
globalThis.fetch = guarded(globalThis.fetch, globalThis);
e.app.whenReady().then(async () => {
  mark('app-ready');
  e.net.fetch = guarded(e.net.fetch, e.net);
  e.session.defaultSession.webRequest.onBeforeRequest(
    {urls: ['http://*/*', 'https://*/*']}, (_details, callback) => {
      globalThis["__settingsHttp"].push('blocked-http');
      callback({cancel: true});
    });
  mark('before-main-import');
  await import(require('node:url').pathToFileURL("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\frozen-out-integrated\\main\\index.js").href);
  mark('after-main-import');
}).catch(error => {
  fs.writeFileSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-settings-5WeKTp\\bootstrap-error.json", JSON.stringify({
    code: error.code,
    hash: require('node:crypto').createHash('sha256').update(String(error.stack)).digest('hex')
  }));
  e.app.exit(1);
});
