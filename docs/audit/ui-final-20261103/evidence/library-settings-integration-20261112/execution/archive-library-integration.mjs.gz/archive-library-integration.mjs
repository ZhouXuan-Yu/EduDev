import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/library-settings-integration-20261112');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  assert(fs.realpathSync(root).startsWith(owned + path.sep));
  for (const name of names) selected.push({source: path.join(root, name), name: prefix + '/' + name});
}
add(base, ['archive-library-integration.mjs', 'capture.mjs', 'library-settings-integrated-before.json',
  'library-settings-integrated-pins.json', 'library-settings-integrated-geometry.json',
  'build-library-settings-integrated.log', 'components-library-settings-integrated.log',
  'styles-library-settings-integrated.log', 'capture-library-settings-integrated.log',
  'catalog-library-settings-integrated.log', 'settings-library-settings-integrated.log',
  'paper-library-settings-integrated.log', 'workbench-library-settings-integrated.log',
  'word-metafiles-library-integrated.log', 'word-metafiles-library-integrated-transform.log'], 'execution');
const comparison = JSON.parse(fs.readFileSync(path.join(base, 'library-settings-integrated-geometry.json')));
add(path.join(base, 'library-settings-integrated-cvXMjp'),
  ['report.json', ...comparison.images.filter(file => !file.equal).map(file => file.file)], 'current');
for (const [name, prefix] of [
  ['ui-final-material-catalog-live-L864F9', 'catalog'], ['ui-final-settings-A3JHms', 'settings'],
  ['paper-first-entry-SdLA6q', 'paper'], ['workbench-5aBTip', 'workbench'],
]) {
  const root = path.join(owned, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, true);
  add(root, ['report.json'], prefix);
}
const files = [];
for (const {source, name} of selected) {
  const raw = fs.readFileSync(source);
  const png = name.endsWith('.png');
  if (!png) assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive: true});
  fs.writeFileSync(target, encoded, {flag: 'wx'});
  files.push({file, bytes: encoded.length, sha256: sha256(encoded), originalSha256: sha256(raw),
    encoding: png ? 'original-png' : 'gzip'});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope: 'UI integration d50ef33 with collaborator d8236b7. Current full-build capture and 59 real UI checks. No profiles, data, builds or private daily screenshots.',
  priorEvidence: '../library-settings-alignment-20261112/manifest.json',
  unchangedImageReuse: comparison.images.filter(file => file.equal).map(file => ({
    file: '../library-settings-alignment-20261112/current/' + file.file, sha256: file.sha256,
  })),
  pins: JSON.parse(fs.readFileSync(path.join(base, 'library-settings-integrated-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination, files: files.length, reusedImages: comparison.images.filter(file => file.equal).length}));
