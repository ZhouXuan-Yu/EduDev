import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

const root = path.resolve(import.meta.dirname, '../../../..');
const results = path.join(root, 'apps/desktop/test-results');
const destination = path.join(root, 'docs/audit/ui-final-20261103/evidence/paper-selection-20261112');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const files = new Map();
const collect = (source, target) => files.set(target.replaceAll('\\', '/'), source);
for (const name of fs.readdirSync(import.meta.dirname)) {
  if (/first-selection|selection-components|selection-integrated|usePaperLibrarySelection-before-/.test(name) &&
      /\.(json|log|mjs|ts|diff)$/.test(name)) collect(path.join(import.meta.dirname, name), 'logs/' + name + '.gz');
}
const ids = ['Tjyga7','5pGy3Y','y3CbpC','pgXxUc','CclfUi','mI7A2u','gp2lRJ','5Cdm0D'];
for (const id of ids) {
  const source = path.join(results, 'paper-library-selection-' + id);
  assert(fs.existsSync(path.join(source, 'report.json')), id);
  collect(path.join(source, 'report.json'), id + '/report.json.gz');
  for (const entry of fs.readdirSync(source, {recursive:true, withFileTypes:true})) {
    if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
    const absolute = path.join(entry.parentPath, entry.name);
    const relative = path.relative(source, absolute);
    if (relative.split(path.sep).some(part => ['data','profile'].includes(part))) continue;
    collect(absolute, id + '/' + relative);
  }
}
// Only controlled screenshots and reports are archived. Profiles and databases stay local.
const extra = process.argv.slice(2);
for (const relative of extra) {
  assert(!path.isAbsolute(relative) && !relative.split(/[\\/]/).includes('..'));
  const source = path.join(results, relative);
  for (const entry of fs.readdirSync(source, {recursive:true, withFileTypes:true})) {
    if (!entry.isFile() || !/\.(json|png)$/.test(entry.name)) continue;
    const absolute = path.join(entry.parentPath, entry.name);
    const inside = path.relative(source, absolute);
    if (inside.split(path.sep).some(part => ['data','profile','workspace'].includes(part))) continue;
    if (entry.name !== 'report.json' && !entry.name.endsWith('.png')) continue;
    collect(absolute, relative + '/' + inside + (entry.name.endsWith('.json') ? '.gz' : ''));
  }
}
fs.mkdirSync(destination, {recursive:true});
const manifest = [];
for (const [target, source] of files) {
  const bytes = fs.readFileSync(source);
  const saved = target.endsWith('.gz') ? gzipSync(bytes) : bytes;
  const absolute = path.join(destination, target);
  fs.mkdirSync(path.dirname(absolute), {recursive:true});
  fs.writeFileSync(absolute, saved);
  assert.deepEqual(target.endsWith('.gz') ? gunzipSync(fs.readFileSync(absolute)) : fs.readFileSync(absolute), bytes);
  manifest.push({file:target, originalBytes:bytes.length, originalSha256:hash(bytes), bytes:saved.length, sha256:hash(saved)});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({scope:'Owned UI first-selection controlled evidence. Historical failures retained. No user profiles or databases.',files:manifest}, null, 2));
console.log(JSON.stringify({destination, files:manifest.length, bytes:manifest.reduce((sum,row)=>sum+row.bytes,0)}));
