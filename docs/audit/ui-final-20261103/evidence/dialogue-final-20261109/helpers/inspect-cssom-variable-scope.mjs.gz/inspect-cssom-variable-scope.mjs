import fs from 'node:fs';const r=JSON.parse(fs.readFileSync('test-results/ui-final-cssom-JP2qrX/report.json'));
const found=[];function visit(values,sample,property,parents=[]){for(const v of values??[]){const d=v.declaration;if(d?.state==='Overloaded')found.push({sample,property,name:v.name,parents,status:v.status,inherited:d.inherited,selector:d.selector,file:d.originalSource?.file});visit(v.references,sample,property,[...parents,v.name]);}}
for(const s of r.samples)for(const [p,v]of Object.entries(s.properties))visit(v.variables,s.id,p);
fs.writeFileSync('test-results/ui-final-fixed-cssom-variable-scope.json',JSON.stringify(found,null,2));console.log(JSON.stringify({count:found.length,examples:found.slice(0,3)}));
