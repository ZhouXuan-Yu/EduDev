import fs from 'node:fs';const r=JSON.parse(fs.readFileSync('test-results/ui-final-cssom-JP2qrX/report.json'));
const found=[];function visit(values,sample,property){for(const v of values??[]){if(v.declaration&&v.declaration.state===undefined)found.push({sample,property,status:v.status,name:v.name,declaration:v.declaration});visit(v.references,sample,property);}}
for(const s of r.samples)for(const [p,v]of Object.entries(s.properties))visit(v.variables,s.id,p);
const result={count:found.length,examples:found.slice(0,3)};fs.writeFileSync('test-results/ui-final-fixed-cssom-variable-schema.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
