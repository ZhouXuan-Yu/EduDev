import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {sha256} from '../scripts/acceptance/evidence.mjs';
const output=path.resolve('test-results/ui-final-cssom-JP2qrX'),report=JSON.parse(fs.readFileSync(path.join(output,'report.json')));
assert(report.success&&report.samples.length===28&&report.attribution.unresolved===0);
const owners={},applicationInherited=[],records=[],variableOwners={};
function checkVariables(variables){for(const variable of variables??[]){
  const d=variable.declaration;
  if(d){const source=d.originalSource,key=source?.file??d.origin;variableOwners[key]=(variableOwners[key]??0)+1;
    if(d.kind==='registered-property'){
      assert.equal(variable.status,'resolved');assert.equal(source?.status,'exact-source');
      const raw=fs.readFileSync(source.file,'utf8');
      assert(raw.slice(Math.max(0,source.utf16Offset-128),source.utf16Offset).includes('@property '+d.name));
      assert(source.text.replace(/\s/g,'').includes('initial-value:'+d.value.replace(/\s/g,'')),'Registered property initial value must match original source');
    }else if(d.state==='Overloaded'){
      // computeCSSVariable resolves in the declaration owner's style context;
      // propertyState separately describes the sampled node's cascade. Retain
      // the distinction for inherited official theme references, never for a
      // property's actual winner (which remains strictly Active below).
      assert.equal(variable.status,'resolved');assert.equal(d.inherited,true);
      assert.equal(d.selector,':root, .light, .default, [data-theme=light], [data-theme=default]');
      assert.equal(source?.file,'src/renderer/heroui-pro/heroui-oss.min.css');
    }else assert.equal(d.state,'Active');
    assert(!d.overriddenByAnimation);
    if(source?.status==='exact-source')assert.equal(sha256(fs.readFileSync(source.file)),source.sourceSha256);
    if(d.origin==='regular')assert(source?.status==='exact-source'&&source.file.startsWith('src/renderer/heroui-pro/'),'Unexpected application variable winner '+variable.name);
  }
  checkVariables(variable.references);
}}
for(const sample of report.samples){
  assert.deepEqual(sample.hazards,[]);assert.equal(sha256(fs.readFileSync(path.join(output,sample.rawFile))),sample.rawSha256);assert.equal(sha256(fs.readFileSync(path.join(output,sample.screenshot))),sample.screenshotSha256);
  for(const [property,value]of Object.entries(sample.properties)){
    checkVariables(value.variables);
    if(value.status==='no-active-declaration'){assert(!value.winner);assert(!value.candidates.some(c=>c.state==='Active'));continue;}
    assert.equal(value.status,'active-declaration');const w=value.winner;assert.equal(w.state,'Active');assert(!w.overriddenByAnimation);
    const source=w.originalSource,official=source?.status==='exact-source'&&source.file.startsWith('src/renderer/heroui-pro/');
    if(source?.status==='exact-source')assert.equal(sha256(fs.readFileSync(source.file)),source.sourceSha256);
    const isOfficialControl=sample.component!=='Native button (not HeroUI)';
    if(isOfficialControl&&!official&&w.origin==='regular'){
      assert(w.inherited,'Application rule must not win inside official controls: '+sample.id+' '+property);
      assert(['.edu-shell','html[data-edu-modern] body','body'].includes(w.selector),'Review new inherited selector');
      applicationInherited.push({sample:sample.id,property,selector:w.selector,url:w.url,range:w.range});
    }
    const owner=official?source.file:w.origin==='user-agent'?'user-agent':isOfficialControl?'application-inherited':'application-native-control';owners[owner]=(owners[owner]??0)+1;
    records.push({sample:sample.id,component:sample.component,state:sample.state,property,value:value.computed,selector:w.selector,layers:w.layers.map(l=>l.text),url:w.url,range:w.range,source:source?.file??null,inherited:w.inherited,owner});
  }
}
const summary={success:true,scope:'Independent current sampled cascade ownership review; no claim of every application control',samples:28,active:records.length,noActive:report.attribution.noActiveDeclaration,owners,variableOwners,applicationInherited,records,fullAcceptance:false};
fs.writeFileSync(path.join(output,'ownership-review.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify({success:true,samples:28,active:records.length,noActive:summary.noActive,owners,variableOwners,applicationInherited:applicationInherited.length}));
