import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';
const base=import.meta.dirname, desktop=path.resolve(base,'../..');
const owned=fs.realpathSync(path.join(desktop,'test-results'));
const destination=path.resolve(desktop,'../../docs/audit/ui-final-20261103/evidence/paper-filters-integration-20261112');
assert(!fs.existsSync(destination));
const selected=[];
function add(root,names,prefix){
 assert(fs.realpathSync(root).startsWith(owned+path.sep));
 for(const name of names)selected.push({source:path.join(root,name),name:prefix+'/'+name});
}
function fromLog(file){
 const row=fs.readFileSync(path.join(base,file),'utf8').trim().split(/\r?\n/).filter(line=>line.startsWith('{')).map(line=>JSON.parse(line)).at(-1);
 assert.equal(row.success,true);return row.output;
}
const workbenchLog=fs.readFileSync(path.join(base,'workbench-paper-filters-integrated.log'),'utf8');
const workbenchReport=workbenchLog.match(/REPORT (.+report.json)/)?.[1];assert(workbenchReport);
assert.equal(JSON.parse(fs.readFileSync(workbenchReport)).success,true);
const visual=fromLog('capture-paper-filters-integrated.log');
const filters=fromLog('paper-library-filters-cssom.log');
const entry=fromLog('paper-entry-filters-host-ready.log');
add(base,['archive-paper-filters-integration.mjs','capture.mjs','paper-filters-integrated-before.json','paper-filters-integrated-pins.json',
 'build-paper-filters-integrated.log','components-paper-filters-integrated.log','styles-paper-filters-integrated.log',
 'boundaries-paper-filters-integrated.log','paper-filters-kb-regressions.json','paper-entry-before-host-ready.mjs',
 'paper-library-filters-integrated.log','paper-library-filters-cssom.log','paper-entry-filters-integrated.log','paper-entry-filters-host-ready.log',
 'workbench-paper-filters-integrated.log','capture-paper-filters-integrated.log','smoke-paper-filters-integrated.log',
 'paper-filters-protected-before.json',...fs.readdirSync(base).filter(name=>/^integrated-kb-.+\.log$/.test(name))],'execution');
for(const [root,prefix,images] of [[filters,'filters',true],[entry,'original-entry',false],
 [fromLog('paper-library-filters-integrated.log'),'initial-filters',false],
 [path.dirname(workbenchReport),'workbench',false],[path.join(owned,'paper-library-view-eg7qJN'),'boundaries',false],
 [path.join(owned,'paper-first-entry-biUIhh'),'first-host-loading-failure',true]]){
 add(root,fs.readdirSync(root).filter(file=>file==='report.json'||images&&file.endsWith('.png')),prefix);
}
add(visual,['report.json',...['1366','1920','800'].map(size=>'paper-'+size+'-actual.png')],'visual');
const files=[];
for(const {source,name} of selected){
 const raw=fs.readFileSync(source),png=name.endsWith('.png');
 if(!png)assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
 const encoded=png?raw:gzipSync(raw);assert.deepEqual(png?encoded:gunzipSync(encoded),raw);
 const file=name+(png?'':'.gz'),target=path.resolve(destination,file);
 assert(target.startsWith(destination+path.sep));
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,encoded,{flag:'wx'});
 files.push({file,bytes:encoded.length,sha256:sha256(encoded),originalSha256:sha256(raw),encoding:png?'original-png':'gzip'});
}
fs.writeFileSync(path.join(destination,'manifest.json'),JSON.stringify({
 scope:'Normal main integration with the KB Word-source slice, stable full build, controlled actual Electron tests and targeted source regressions. No user profile, original user files or databases.',
 fullUiFinalAccepted:false,files,totalBytes:files.reduce((sum,file)=>sum+file.bytes,0),
},null,2));
console.log(JSON.stringify({destination,files:files.length,bytes:files.reduce((sum,file)=>sum+file.bytes,0)}));
