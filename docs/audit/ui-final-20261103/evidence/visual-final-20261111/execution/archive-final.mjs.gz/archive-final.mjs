import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/visual-final-20261111');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  for (const name of names) selected.push({source:path.join(root,name),file:prefix+'/'+name});
}
add(base, ['archive-final.mjs','capture.mjs','final-before.json','final-pins.json','build-final.log',
  'components-final.log','styles-final.log','execution-final.log','quality-final.log',
  'capture-final.log','paper-entry-final.log','final-formal-before.json','final-formal-verified.json',
  'final-formal-launch.json','final-formal-runtime.json','workbench-context-fixed.log',
  'workbench-context-complete.log','workbench-context-before-more.mjs'], 'execution');
add(path.join(desktop,'scripts'), ['workbench-ui.mjs'], 'qa');
for (const [root,prefix,expected] of [
  [path.join(base,'final-BqRDTe'),'pages',true],
  [path.join(desktop,'test-results/paper-first-entry-k3A2QI'),'paper',true],
  [path.join(desktop,'test-results/workbench-l3gAVs'),'workbench-context-fail',false],
  [path.join(desktop,'test-results/workbench-1sggZQ'),'workbench-complete',true],
]) {
  assert.equal(JSON.parse(fs.readFileSync(path.join(root,'report.json'))).success,expected);
  add(root,fs.readdirSync(root).filter(file=>file.endsWith('.png')||file==='report.json'),prefix);
}
const files=[];
for (const {source,file:name} of selected) {
  const raw=fs.readFileSync(source);
  const png=name.endsWith('.png');
  if (png) assert(raw.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded=png?raw:gzipSync(raw);
  assert.deepEqual(png?encoded:gunzipSync(encoded),raw);
  const file=name+(png?'':'.gz');
  const target=path.resolve(destination,file);
  assert(target.startsWith(destination+path.sep));
  fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.writeFileSync(target,encoded,{flag:'wx'});
  files.push({file,bytes:encoded.length,sha256:sha256(encoded),originalSha256:sha256(raw),
    encoding:png?'original-png':'gzip',
    ...(png?{width:raw.readUInt32BE(16),height:raw.readUInt32BE(20)}:{})});
}
fs.writeFileSync(path.join(destination,'manifest.json'),JSON.stringify({
  scope:'19f0793 formal Pi build and canonical native launch, 27 HTML/actual pairs, 8 real paper checks, 25 full workbench checks after adapter correction. Failed attempt and exact adapter retained. No daily screenshots, databases, profiles or credentials.',
  visualAcceptance:'PARTIAL; full fixed UI-FINAL scope remains active',
  pins:JSON.parse(fs.readFileSync(path.join(base,'final-pins.json'))),files,
},null,2));
console.log(JSON.stringify({destination,count:files.length,bytes:files.reduce((sum,file)=>sum+file.bytes,0)}));
