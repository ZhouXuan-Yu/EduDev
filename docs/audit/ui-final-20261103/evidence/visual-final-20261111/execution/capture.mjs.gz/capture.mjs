import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {chromium, _electron as electron} from 'playwright';
import {fingerprint, sha256} from '../../scripts/acceptance/evidence.mjs';
import {continuationBootstrap, continuationGuardRead} from '../../scripts/acceptance/paper-adaptation-continuation.mjs';
import {assertIsolatedPiMain} from '../../scripts/acceptance/build-root.mjs';
import {productEntry} from '../../scripts/product-navigation.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const round = process.argv[2];
assert(['before', 'after', 'r2', 'integrated', 'final'].includes(round));
const pins = JSON.parse(fs.readFileSync(path.join(base, round + '-pins.json')));
const reference = JSON.parse(fs.readFileSync(path.join(desktop, 'test-results/ui-alignment-20261111/reference-server.json')));
assert(reference.url.startsWith('http://127.0.0.1:'));
const output = fs.mkdtempSync(path.join(base, round + '-'));
const data = path.join(output, 'data'), profile = path.join(output, 'profile');
fs.mkdirSync(data);
fs.mkdirSync(profile);
const report = {success:false, visualAcceptance:'PENDING_REVIEW', scope:'Actual current Electron versus approved HTML. Reference sample records and genuine empty production state are labelled separately.',
  output, pins, reference, samples:[], errors:[], geometryFailures:[], referenceErrors:[]};
const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
const main = path.join(pins.buildRoot, 'main/index.js');
const bootstrap = path.join(output, 'bootstrap.cjs');
fs.writeFileSync(bootstrap, continuationBootstrap({main, profile}));
const env = {...process.env};
for (const key of Object.keys(env)) {
  if (/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(key) || key.startsWith('OMNI_EDU_') ||
      ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL'].includes(key)) delete env[key];
}
Object.assign(env, {OMNI_EDU_DATA_ROOT:data, OMNI_EDU_REPO_ROOT:path.resolve(desktop, '../..'),
  OMNI_EDU_XIAOZHI_PI:'1', OMNI_EDU_E2E_VISIBLE:'1', NODE_ENV:'development'});
const routes = [
  {id:'chat', space:'ask', ready:'workbench-home', hash:'page=chat'},
  {id:'library', space:'materials', ready:'materials-workspace', hash:'page=library'},
  {id:'teaching', space:'teaching', ready:'teaching-artifacts-workspace', hash:'page=teaching&tab=教学文件'},
  {id:'notebook', space:'teaching', tab:'notebook', ready:'teacher-notebook-workspace', hash:'page=teaching&tab=备课本'},
  {id:'book', space:'teaching', tab:'book', ready:'teaching-book-workspace', hash:'page=teaching&tab=讲义'},
  {id:'questions', space:'teaching', tab:'question_notebook', ready:'question-notebook-workspace', hash:'page=teaching&tab=题本'},
  {id:'paper', space:'teaching', tab:'paper', ready:'paper-basket-workspace', hash:'page=teaching&tab=组卷'},
  {id:'students', space:'students', ready:'student-workbench-layout', hash:'page=students'},
  {id:'settings', space:'settings', ready:'pi-settings-workspace', hash:'page=settings'},
];
let app, browser;
const metrics = (referencePage) => {
  const main = referencePage ? document.querySelector('.workspace')
    : [...document.querySelectorAll('main.edu-workspace')].find(element => element.getClientRects().length > 0);
  const sidebar = document.querySelector(referencePage ? '.sidebar' : '[data-testid="edu-navigation"]');
  const heading = main?.querySelector('h1,h2');
  const style = element => {
    if (!element) return null;
    const rect = element.getBoundingClientRect(), css = getComputedStyle(element);
    return {x:rect.x, y:rect.y, width:rect.width, height:rect.height,
      font:css.fontFamily, fontSize:css.fontSize, lineHeight:css.lineHeight, color:css.color,
      padding:css.padding, gap:css.gap, scrollWidth:element.scrollWidth, clientWidth:element.clientWidth};
  };
  return {viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},
    body:style(document.body), main:style(main), sidebar:style(sidebar), heading:style(heading),
    headingText:heading?.textContent,
    disclosures:[...document.querySelectorAll('summary')].filter(el=>el.getClientRects().length)
      .map(el=>({text:el.textContent, listStyle:getComputedStyle(el).listStyleType})),
    visibleAlerts:[...document.querySelectorAll('[role="alert"]')].filter(el=>el.getClientRects().length).map(el=>el.textContent)};
};
try {
  assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
  assert.equal(fingerprint(pins.buildRoot).sha256, pins.build);
  app = await electron.launch({args:[bootstrap, '--user-data-dir=' + profile, '--force-device-scale-factor=1'],
    cwd:output, env, timeout:30000});
  report.pid = app.process().pid;
  const page = await app.firstWindow({timeout:30000});
  page.setDefaultTimeout(12000);
  page.on('pageerror', error => report.errors.push({type:'page', hash:sha256(String(error))}));
  page.on('console', message => {if (message.type() === 'error') report.errors.push({type:'console', hash:sha256(message.text())});});
  await page.getByTestId('workbench-home').waitFor();
  report.identity = await assertIsolatedPiMain(app, main, profile);
  await page.emulateMedia({colorScheme:'light'});
  browser = await chromium.launch({headless:true});
  const ref = await browser.newPage({viewport:{width:1366,height:760}, deviceScaleFactor:1});
  await ref.route('**/*', route => route.request().url().startsWith(reference.url) ? route.continue() : route.abort());
  ref.on('pageerror', error => report.referenceErrors.push(String(error)));
  for (const route of routes) {
    await app.evaluate(({BrowserWindow}) => BrowserWindow.getAllWindows()[0].setContentSize(1366,768));
    await page.waitForFunction(() => innerWidth === 1366 && innerHeight === 768);
    await productEntry(page, route.space).click();
    if (route.tab) await page.getByTestId('teaching-page-navigation').getByTestId('hub-entry-' + route.tab).click();
    await page.getByTestId(route.ready).waitFor();
    await page.waitForFunction(() => !document.querySelector('[aria-busy="true"]'));
    await page.waitForFunction(id => {
      const root = document.querySelector(`[data-testid="${id}"]`);
      return root && !/正在读取|正在从宿主恢复|正在查找|正在载入|正在加载|正在检索/.test(root.innerText);
    }, route.ready);
    for (const [width,height] of [[1366,768],[1920,1080],[800,768]]) {
      await app.evaluate(({BrowserWindow}, size) => BrowserWindow.getAllWindows()[0].setContentSize(size.width,size.height), {width,height});
      await page.waitForFunction(size=>innerWidth===size.width&&innerHeight===size.height, {width,height});
      await page.mouse.move(1,1);
      const top = await page.getByTestId('desktop-titlebar').evaluate(el=>Math.round(el.getBoundingClientRect().bottom));
      const live = await page.evaluate(metrics, false);
      const actualFile = path.join(output, route.id + '-' + width + '-actual.png');
      await page.screenshot({path:actualFile, clip:{x:0,y:top,width,height:height-top}});
      await ref.setViewportSize({width,height:height-top+36});
      await ref.goto(reference.url + '#' + new URLSearchParams(route.hash).toString());
      await ref.locator('.app').waitFor();
      await ref.evaluate(() => document.fonts.ready);
      await ref.locator('.nav-item[aria-current="page"]').first().waitFor();
      const ideal = await ref.evaluate(metrics, true);
      const referenceFile = path.join(output, route.id + '-' + width + '-reference.png');
      await ref.locator('.app').screenshot({path:referenceFile});
      report.samples.push({page:route.id,width,height,chrome:{actual:top,reference:36},actual:live,reference:ideal,
        files:[actualFile,referenceFile].map(file=>({file,sha256:sha256(fs.readFileSync(file))}))});
      if (live.main && live.main.scrollWidth > live.main.clientWidth) report.geometryFailures.push({page:route.id,width,reason:'MAIN_HORIZONTAL_OVERFLOW',main:live.main});
      save();
    }
  }
  report.guard = await app.evaluate(continuationGuardRead, true);
  assert.equal(report.guard.networkAttempts, 0);
  assert.equal(report.guard.modelAttempts, 0);
  assert.equal(report.guard.rendererErrors, 0);
  assert.deepEqual(report.errors, []);
  assert.deepEqual(report.referenceErrors, []);
  assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
  report.captureComplete = true;
  report.success = report.geometryFailures.length === 0;
} catch (error) {
  report.failure = {message:error.message, stack:String(error.stack)};
  process.exitCode = 1;
} finally {
  try {await browser?.close(); await app?.close(); report.closed = true;}
  catch (error) {report.closeFailure = String(error); report.success = false; process.exitCode = 1;}
  save();
  console.log(JSON.stringify({success:report.success, output, samples:report.samples.length, failures:report.geometryFailures, failure:report.failure}));
}
