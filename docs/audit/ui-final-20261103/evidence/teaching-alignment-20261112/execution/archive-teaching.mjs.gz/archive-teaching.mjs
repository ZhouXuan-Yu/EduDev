import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base=import.meta.dirname;
const desktop=path.resolve(base,'../..');
const owned=fs.realpathSync(path.join(desktop,'test-results'));
const destination=path.resolve(desktop,'../../docs/audit/ui-final-20261103/evidence/teaching-alignment-20261112');
assert(!fs.existsSync(destination));
const selected=[];
function add(root,names,prefix) {
  for(const name of names)selected.push({source:path.join(root,name),file:prefix+'/'+name});
}
add(base,['archive-teaching.mjs','capture.mjs','teaching-before-pins.json','teaching-after-pins.json',
  'teaching-r1-pins.json','teaching-r2-pins.json','teaching-build-before.json','teaching-r1-before.json',
  'teaching-r2-before.json','teaching-r2-initial-before.json','teaching-r2-initial-output.json',
  'build-teaching.log','build-teaching-r1.log','build-teaching-r2-initial.log','build-teaching-r2.log',
  'components-teaching.log','components-teaching-r1.log','components-teaching-r2.log',
  'styles-teaching.log','styles-teaching-r1.log','styles-teaching-r2.log',
  'terminal-teaching-r2.log','audit-teaching.json','teaching-before.log','teaching-after.log',
  'teaching-r1.log','ui-current.log','workbench-teaching-r1.log','workbench-teaching-r2.log',
  'paper-teaching-r1.log','paper-teaching-r2.log','editors-teaching-r2.log','editors-teaching-r2-consumer.log',
  'reading-evidence-before-consumer.mjs','teaching-editors-before-consumer.mjs',
  'check-reading-consumer.mjs','reading-consumer-checks.json','reading-consumer-checks.log',
  'primary-actions-before-cleanup.mjs','primary-teaching-r2.log','primary-teaching-r2-final.log',
  'teaching-geometry.json'],'execution');
add(path.join(desktop,'scripts'),['teaching-primary-actions-ui.mjs','workbench-ui.mjs',
  'ui-final-teaching-editors-live.mjs','acceptance/reading-source-evidence.mjs'],'qa');
for(const name of ['teaching-before-nJgKgm','ui-current-TE0DgQ']) {
  const root=path.join(base,name);
  add(root,fs.readdirSync(root).filter(file=>file==='report.json'||file.endsWith('.png')),name);
}
for(const name of ['teaching-after-X9eZCn','teaching-r1-jqf8UI']) {
  add(path.join(base,name),['report.json','notebook-1366-actual.png','teaching-1366-actual.png'],name);
}
for(const [name,prefix,expected,images] of [
  ['workbench-6C5qD1','r1-workbench',true,false],
  ['paper-first-entry-vIH5Bd','r1-source-changed',false,false],
  ['workbench-Mu1oGU','workbench',true,true],
  ['paper-first-entry-UUw2aN','paper',true,true],
  ['ui-final-teaching-editors-oG8560','editors',true,true],
  ['teaching-primary-yqWrP2','primary-before-cleanup',true,false],
  ['teaching-primary-bZjNO0','primary',true,true],
]) {
  const root=fs.realpathSync(path.join(owned,name));
  assert(root.startsWith(owned+path.sep));
  assert.equal(JSON.parse(fs.readFileSync(path.join(root,'report.json'))).success,expected);
  add(root,fs.readdirSync(root).filter(file=>file==='report.json'||images&&file.endsWith('.png')),prefix);
}
const files=[];
for(const {source,file:name} of selected) {
  const raw=fs.readFileSync(source),png=name.endsWith('.png');
  if(png)assert(raw.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded=png?raw:gzipSync(raw);
  assert.deepEqual(png?encoded:gunzipSync(encoded),raw);
  const file=name+(png?'':'.gz');
  const target=path.resolve(destination,file);
  assert(target.startsWith(destination+path.sep));
  fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.writeFileSync(target,encoded,{flag:'wx'});
  files.push({file,bytes:encoded.length,sha256:sha256(encoded),originalSha256:sha256(raw),
    encoding:png?'original-png':'gzip',...(png?{width:raw.readUInt32BE(16),height:raw.readUInt32BE(20)}:{})});
}
fs.writeFileSync(path.join(destination,'manifest.json'),JSON.stringify({
  scope:'Teaching placement and density before/implementation/R1/R2, latest 27-page samples, real editor and navigation checks, strict historical producer/current consumer qualification. Zero model/HTTP calls in UI QA. Excludes data/profile/build/native daily screenshots.',
  visualAcceptance:'PARTIAL; 24 app heading geometry comparisons exact, 9 table heights exact, full UI-FINAL remains active',
  pins:JSON.parse(fs.readFileSync(path.join(base,'teaching-r2-pins.json'))),files,
},null,2));
console.log(JSON.stringify({destination,count:files.length,bytes:files.reduce((sum,file)=>sum+file.bytes,0)}));
