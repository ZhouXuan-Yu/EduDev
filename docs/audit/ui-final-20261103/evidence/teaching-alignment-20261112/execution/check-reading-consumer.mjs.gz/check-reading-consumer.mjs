import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {readOwnedReadingReport} from '../../scripts/acceptance/reading-source-evidence.mjs';

const base=import.meta.dirname;
const desktop=path.resolve(base,'../..');
const producer=path.join(desktop,'test-results/ui-final-workbenches-20261111/reading-source-AGSqEp/report.json');
const pins=JSON.parse(fs.readFileSync(path.join(base,'teaching-r2-pins.json')));
const options={producerCommit:'0d23c86f16f8f0c8824e620a240181341c3399db',consumerPinsFile:path.join(base,'teaching-r2-pins.json')};
const checks=[];
for (const [name,change] of [
  ['Current consumer source must match',{source:'0'.repeat(64)}],
  ['Current consumer output must match',{build:'0'.repeat(64)}],
  ['Consumer output must stay in owned test-results',{buildRoot:path.join(desktop,'out')}],
]) {
  const file=path.join(base,'negative-'+checks.length+'-pins.json');
  fs.writeFileSync(file,JSON.stringify({...pins,...change}));
  await assert.rejects(()=>readOwnedReadingReport(producer,desktop,{...options,consumerPinsFile:file}));
  checks.push(name);
}
await assert.rejects(()=>readOwnedReadingReport(producer,desktop,{...options,producerCommit:'invalid'}));
checks.push('Historical commit must be a full Git SHA');
await assert.rejects(()=>readOwnedReadingReport(producer,desktop));
checks.push('Default same-build producer contract stays strict');
const result=await readOwnedReadingReport(producer,desktop,options);
assert.equal(result.actualNote.id,'read_5d11bec4-126f-4194-ab31-0d963c14b9f7');
checks.push('Explicit historical producer and current consumer retain exact real note and conservation');
fs.writeFileSync(path.join(base,'reading-consumer-checks.json'),JSON.stringify({success:true,checks},null,2));
console.log(JSON.stringify({success:true,checks:checks.length}));
