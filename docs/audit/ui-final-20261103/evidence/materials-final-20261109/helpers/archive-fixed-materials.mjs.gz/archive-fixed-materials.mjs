import fs from 'node:fs';import path from 'node:path';import {gzipSync,gunzipSync} from 'node:zlib';import {sha256} from '../scripts/acceptance/evidence.mjs';
const root=path.resolve('../../docs/audit/ui-final-20261103/evidence/materials-final-20261109');fs.mkdirSync(root,{recursive:true});const rows=[];
function add(source,name){const raw=fs.readFileSync(source),zip=!name.endsWith('.png'),file=name+(zip?'.gz':''),bytes=zip?gzipSync(raw):raw,target=path.join(root,file);fs.mkdirSync(path.dirname(target),{recursive:true});if(fs.existsSync(target)&&sha256(fs.readFileSync(target))!==sha256(bytes))throw Error('Archive changed');fs.writeFileSync(target,bytes);if(sha256(zip?gunzipSync(bytes):bytes)!==sha256(raw))throw Error('Lossless archive mismatch');if(zip&&/sk-[A-Za-z0-9]{20,}/.test(raw.toString()))throw Error('Possible credential');rows.push({file,source,bytes:bytes.length,sha256:sha256(bytes),uncompressedSha256:sha256(raw)});}
for(const run of ['ui-final-material-catalog-live-AXfxR1','ui-final-material-metadata-recovery-live-JtvAIm','ui-final-material-parse-live-FFsAmV']){
  const base=path.join('test-results',run),r=JSON.parse(fs.readFileSync(path.join(base,'report.json')));
  if(!r.success||r.status!=='PASS'||r.errors.length||r.checks.some(c=>c.status!=='PASS'))throw Error('Invalid actual run');
  for(const entry of fs.readdirSync(base,{withFileTypes:true}))if(entry.isFile()&&(entry.name==='report.json'||/^bootstrap-state.*\.json$/.test(entry.name)||entry.name.endsWith('.png')))add(path.join(base,entry.name),run+'/'+entry.name);
}
for(const file of ['ui-final-fixed-catalog-current.log','ui-final-fixed-metadata-current.log','ui-final-fixed-parser-current.log','ui-final-settings-nav-results-pins.json'])add(path.join('test-results',file),'logs/'+file);
add('test-results/archive-fixed-materials.mjs','helpers/archive-fixed-materials.mjs');
fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({root,entries:rows.length,bytes:rows.reduce((sum,r)=>sum+r.bytes,0)}));
