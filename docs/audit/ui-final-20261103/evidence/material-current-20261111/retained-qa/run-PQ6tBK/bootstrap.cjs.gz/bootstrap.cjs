const e=require('electron'),fs=require('node:fs');
e.app.setPath('userData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\retained-qa\\run-PQ6tBK\\baseline\\profile");e.app.setPath('sessionData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\retained-qa\\run-PQ6tBK\\baseline\\profile");
e.app.whenReady().then(async()=>{
  (function installRetainedFixtureProvider(electron,options) {
  const hash=value=>process.getBuiltinModule('crypto').createHash('sha256').update(String(value)).digest('hex');
  const state={responses:0,externalAttempts:0,rendererErrors:0,formalRegistrations:0,requests:[],fatal:null,tasks:0};
  const fail=code=>{state.fatal??=code;return Error(code);};
  let formal,armed,stage,lastCalls=[];
  const web=electron.session.defaultSession.webRequest,register=web.onBeforeRequest.bind(web);
  const combined=(details,callback,probe=false)=>{
    if(/^(https?|wss?):/i.test(details.url)) {
      if(!probe){state.externalAttempts++;fail('RETAINED_NATIVE_NETWORK_DENIED');}
      callback({cancel:true});return;
    }
    if(formal)formal(details,callback);else callback({cancel:false});
  };
  web.onBeforeRequest=(...args)=>{
    if(args.length!==1||args[0]!==null&&typeof args[0]!=='function')throw fail('RETAINED_NETWORK_REGISTRATION');
    formal=args[0];if(formal)state.formalRegistrations++;register(combined);
  };
  register(combined);
  electron.app.on('web-contents-created',(_event,contents)=>{
    contents.on('console-message',(details,level)=>{if(typeof details?.level==='string'?details.level==='error':level===3)state.rendererErrors++;});
    contents.on('preload-error',()=>state.rendererErrors++);
    contents.on('render-process-gone',(_e,value)=>{if(value.reason!=='clean-exit')state.rendererErrors++;});
  });
  globalThis.fetch=async()=>{state.externalAttempts++;throw fail('RETAINED_GLOBAL_FETCH_DENIED');};
  const text=message=>typeof message.content==='string'?message.content:(message.content||[]).map(p=>p.text||'').join('\n');
  function realResult(messages,id) {
    const row=messages.findLast(m=>m.role==='tool'&&m.tool_call_id===id);
    if(!row)throw fail('RETAINED_REAL_TOOL_RESULT_REQUIRED');
    const raw=text(row),start=raw.indexOf('{');let value;
    // Pi appends host notes after JSON. Parse the original leading object only.
    let depth=0,quoted=false,escaped=false;
    for(let i=start;i>=0&&i<raw.length;i++) {
      const c=raw[i];
      if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;}
      else if(c==='"')quoted=true;
      else if(c==='{')depth++;
      else if(c==='}'&&--depth===0){value=JSON.parse(raw.slice(start,i+1));break;}
    }
    if(!value||value.success===false||value.isError===true)throw fail('RETAINED_REAL_TOOL_FAILED');
    return value;
  }
  const packet=(delta,finish_reason=null)=>'data: '+JSON.stringify({id:'owned-retained-input',object:'chat.completion.chunk',model:options.model,choices:[{index:0,delta,finish_reason}]})+'\n\n';
  const respond=calls=>new Response(packet({role:'assistant',content:'<xiaozhi_progress>请对照本地合成原图核对，等待实际工具与教师决定。',tool_calls:calls.map((call,index)=>({index,id:call.id,type:'function',function:{name:call.name,arguments:JSON.stringify(call.args)}}))})+packet({},'tool_calls')+'data: [DONE]\n\n',{headers:{'content-type':'text/event-stream'}});
  electron.net.fetch=async(input,init={})=>{
    try {
      if(state.fatal)throw Error(state.fatal);
      if(Date.now()>=options.deadlineAt)throw fail('RETAINED_240S_DEADLINE');
      const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);
      const method=String(init.method??input?.method??'GET').toUpperCase();
      if(url.protocol!=='https:'||url.hostname!=='api.deepseek.com'||url.port||url.username||url.password||url.search||
        !['/chat/completions','/v1/chat/completions'].includes(url.pathname)||method!=='POST') {
        state.externalAttempts++;throw fail('RETAINED_ENDPOINT_DENIED');
      }
      if(!armed||options.cold||state.responses>=8)throw fail('RETAINED_RESPONSE_BUDGET');
      const raw=typeof init.body==='string'?init.body:await input.clone().text();
      if(Buffer.byteLength(raw)>2*1024*1024)throw fail('RETAINED_REQUEST_SIZE');
      const body=JSON.parse(raw),signal=init.signal??input?.signal;
      if(signal?.aborted)throw fail('RETAINED_ABORTED_REQUEST');
      if(body.model!==options.model||body.stream!==true||!Array.isArray(body.messages))throw fail('RETAINED_REQUEST_SCOPE');
      const definitions=body.tools?.map(t=>t.function?.name??t.name)||[];
      state.responses++;
      state.requests.push({index:state.responses,task:state.tasks,stage,requestSha256:hash(raw),tools:definitions});
      const prior=lastCalls.map(c=>({call:c,result:realResult(body.messages,c.id)}));
      let calls=[];
      const call=(name,args)=>{if(!definitions.includes(name))throw fail('RETAINED_REAL_TOOL_MISSING_'+name);return {name,args,id:'retained_'+state.tasks+'_'+state.responses+'_'+calls.length};};
      if(stage==='catalogue') {
        calls.push(call('office_list_materials',{query:armed.fileName,offset:0}));
        if(!definitions.includes('education_propose_original_question'))calls.push(call('find_education_tools',{query:'education_propose_original_question'}));
        stage='read';
      } else if(stage==='read') {
        const result=prior.find(v=>v.call.name==='office_list_materials')?.result;
        const matches=result?.materials?.filter(r=>r.resourceId===armed.resourceId&&r.title===armed.fileName&&r.bodyAvailable);
        if(matches?.length!==1)throw fail('RETAINED_REAL_MATERIAL_NOT_READY');
        for(let offset=0;offset<armed.chunks;offset++)calls.push(call('office_read_material',{resourceId:armed.resourceId,offset}));
        stage='propose';
      } else if(stage==='propose') {
        if(prior.length!==armed.chunks||prior.some((v,i)=>v.call.name!=='office_read_material'||v.result.success!==true||v.result.offset!==i||v.result.totalChunks!==armed.chunks||v.result.truncated||v.result.source?.version!==armed.version))throw fail('RETAINED_REAL_COMPLETE_READ_REQUIRED');
        calls.push(call('education_propose_original_question',armed.proposals[0]));stage='next';
      } else if(stage==='next') {
        if(prior.length!==1||prior[0].result.success!==true||prior[0].result.state!=='confirmed')throw fail('RETAINED_REAL_CONFIRMATION_REQUIRED');
        if(armed.proposals.length===2){calls.push(call('education_propose_original_question',armed.proposals[1]));stage='finish';}
        else throw fail('RETAINED_PENDING_MUST_STOP');
      } else if(stage==='finish') {
        if(prior.length!==1||prior[0].result.success!==true||prior[0].result.state!=='confirmed')throw fail('RETAINED_REAL_CONFIRMATION_REQUIRED');
        armed=null;stage='idle';lastCalls=[];
        return new Response(packet({role:'assistant',content:'<xiaozhi_answer>本次审核已处理，请以原图、已保存题面和实际审核记录为准。'})+packet({},'stop')+'data: [DONE]\n\n',{headers:{'content-type':'text/event-stream'}});
      } else throw fail('RETAINED_PROVIDER_STAGE');
      lastCalls=calls;return respond(calls);
    } catch(error) {state.fatal??=error.message;throw error;}
  };
  globalThis.__retainedFixture={state,combined,arm(value){
    if(options.cold||armed||state.tasks>=2||!value||!Number.isInteger(value.chunks)||value.chunks<1||value.chunks>8||value.proposals.length!==(state.tasks===0?2:1))throw fail('RETAINED_TASK_BUDGET');
    armed=value;stage='catalogue';lastCalls=[];state.tasks++;
  }};
})(e,{"model":"deepseek-flash","deadlineAt":1794397422686,"cold":false});
  await import(require('node:url').pathToFileURL("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\frozen-out\\main\\index.js").href);
}).catch(error=>{fs.writeFileSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\retained-qa\\run-PQ6tBK\\bootstrap-error.json",JSON.stringify({code:error.code,hash:require('node:crypto').createHash('sha256').update(String(error.stack)).digest('hex')}));e.app.exit(1);});
