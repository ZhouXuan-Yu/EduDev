# 当前交接 · SDK user-role protected context 适配

本轮仅修改retained-fixture-provider.mjs和retained-fixture-selftest.mjs，纯检查已完成，交由root执行一次有界实际重跑。原9响应、2tasks、2launches、240秒、0外网/付费、0自动重试及原retained 220秒断言继续适用。

## 实际包装与修补

RwLhR6的真实native system消息content为空，sections为preamble/skills/cwd。当前宿主上下文位于user消息text，长度5251，task JSON markerOffset3099。来源由Pi正式session.prompt拼接，先是固定的[小智本会话本地记录，非新增授权]，然后教师来源索引和本轮宿主任務JSON，最后经空行[教师本次请求]边界进入教师正文。

QA只从最后一条user消息的该受保护前缀解析当前task与教师来源。要求唯一任务头、相邻的唯一完整task JSON行、唯一当前taskSource教师来源与唯一请求边界。拒绝当前owner重复包装、重复任务/教师记录、正文伪造task marker和缺固定包装的文本。历史不同owner上下文可保留，system sections作为结构化稳定提示继续存在。实际版本与owner校验、真实read_teacher_request/read_session_process/资料工具回执、update_task_plan采用、executing taskStepId、宿主unwrap和全部digest校核继续执行。

没有从app_settings填入任何QA请求字段。读取的旧owned native文件仅用于纯测试消息形状输入与历史指纹核对，日志只保留role/keys/length/section keys/marker/boundary位置及SHA。

## 静态结果与历史

6文件nodecheck、32项纯self-test通过。九响应完整内存生产plan-runtime/admission流程采用真实SDK user text-parts + system sections形状。新增7项回归含RwLhR6原消息形状、重复/伪造包装拒绝、sections不能覆盖当前owner、历史不同owner并存及RwLhR6失败字节守恒。

证据为context-nodecheck.log、context-selftest.log、context-selftest.stderr.log、context-file-sha256.json和context-static-controls.json。旧plan/static日志与两次实际失败继续保留。PQ6tBK 4响应FAIL、RwLhR6 1响应FAIL的原pins/report/native/整树SHA通过核对，本轮实际运行0次。已知历史5响应加下一次上限9为14，实际累计由root在启动前登记。

## root当前入口

root已整合de86afd并生成pins-integrated.json，该文件已被本轮静态控制记录。根runner按传入文件核对当前源码/构建SHA。执行目录为D:\WorkProject\EduProject\apps\desktop。

```powershell
node scripts/ui-final-retained-fixture-live.mjs --run-ui --pins=test-results/ui-final-content-20261111/pins-integrated.json
```

新基线实际成功并输出manifest后，沿同一pins执行原reader。

```powershell
node scripts/ui-final-retained-sources-live.mjs --pins=test-results/ui-final-content-20261111/pins-integrated.json --fixture-manifest="<上一步真实manifest绝对路径>"
```

当前仍无成功新manifest，实际UI/原图/审核/冷启及三尺寸由root重跑核验。JSON像素截图问题继续由root处理。回退本轮可撤回两个QA文件中的包装适配和新增形状测试，历史失败及静态证据保留。

---

## 前一版交接历史
# 当前交接 · 真实 task-plan 准入修补

当前代码及纯检查已完成，交由 root 做一次有界实际运行。下面的初版交接保留为历史，本节覆盖其中旧8响应和未发生实际运行的时态描述。固定44项及原retained的220秒与原断言继续保留。

## 实际失败与本轮结果

run-PQ6tBK已通过IMPORTED_PDF，随后真实 education_propose_original_question 被宿主 task_admission 拒绝，reason=task_plan_required、delivery=not_delivered。历史success=false、4响应、1task、1launch、0external、无proposal。原native session、原report、原0a480f... pins及全目录指纹在纯检查前后相同，保存在plan-static-controls.json。本轮实际运行次数为0。

当前6文件nodecheck及25项纯self-test通过，日志为plan-nodecheck.log、plan-selftest.log、plan-selftest.stderr.log。纯测试复用生产TASK_PLAN_PARAMETERS、validTaskPlanInput、createTaskPlanRuntime/createTaskState/createTaskResources及宿主unwrap。生产计划状态存放在纯测试内存SQLite，教师/资料/候选回执的替身仅用于该内存lab。原生产工具、事件、来源和业务DB沿真实路径由root验证。

新增回归覆盖真实无计划准入拒绝、单in_progress schema、实际宿主拒绝旧revision/旧要求版本、缺当前context/教师/过程回执拒绝、未执行状态不可路由、真实taskStepId unwrap及额外字段拒绝、PQ6失败字节守恒，以及来源/proposal/effect/question版本原断言。

## 本次有限预算修订

新基线runner采用9响应上限，2Pi任务、2launch、240秒、0外网/付费、0自动重试。该上限属于本次QA调度。

生产validTaskSteps规定至多一个reported=in_progress。两道原题分别采用saved_questions target=current独立步骤，第一道完成实际审核后，用单独的update_task_plan请求将single_save报告为completed并将multi_save切为in_progress，等待真实adopted回执后才能提出第二道。因此在原8次分配上增加1次响应，实际分配为6+3。

- 响应1，同批真实safe_read教师全文、会话过程、资料目录、必要工具发现，以及当前任务计划采用请求。safe_read保持无taskStepId，生产准入允许独立于计划checkpoint执行。
- 响应2，先核验实际采用回执及教师/过程/目录回执，再实读全部资料段落。
- 响应3，核验真实来源版本/段落回执，再以宿主实际采用且executing的single_save身份提出单页原题，等待可见审核。
- 响应4，收到真实confirmed工具结果后，按实际采用回执的revision/requirementsVersion请求计划修订，保留原步骤、criterion映射与最终human核对。
- 响应5，收到实际修订adopted回执、确认multi_save处于executing后，以该回执返回id提出跨页原题，等待审核。
- 响应6，收到第二道真实confirmed工具结果后结束第一轮公开回答。
- 响应7，第二条明确“新任务”请求建立新的宿主task，登记pending_crop与最终human核对，同批执行真实教师/过程/目录safe_read。
- 响应8，核验第二次实际计划采用、当前要求全文和safe_read回执，再实读全部资料段落。
- 响应9，核验本轮来源回执，以第二个task采用回执返回的executing身份提出待裁图候选。根runner通过可见停止按钮结束实际运行，proposal保持pending。

初始版本读取正式plan-runtime.context的当前宿主JSON，此后读取实际update_task_plan返回值。版本没有0/1默认值。read_session_process只证明实际安全过程已读取，其trace不作为计划版本来源。计划中reported=completed仍由宿主决定实际state，最终human保持pending。

第二条请求必须产生不同的真实taskId/runId，旧task及各版本/准入/已保存题保留历史，旧任务app_settings记录逐字段守恒。冷启再次核对所有task-plan历史与admission事实。新任务仅执行pending_crop，旧候选保持原身份。

已知历史PQ6实际4响应，加本次单次上限9，已知合计上限13。其他会话/模块开销由root统一计账，实际launch前记录累计值。

## 原生身份与写集

修改只涉及retained-fixture-input/provider/selftest、窄runner及本次授权的retained-fixture-evidence。原retained主runner本轮保持现状。

native toolCall完整保留taskStepId。证据读取使用生产unwrapTaskArguments取得原领域输入，逐字校原proposal参数，继续原source版本、原proposalDigest、effectDigest、questionFacts版本和PNG身份/SHA断言。额外核对真实app_settings admission的stepId、planRevision、requirementsVersion、原unwrapped inputDigest，以及native update_task_plan实际adopted/executing回执。任何计划拒绝被记录为真实reason，等待proposal的UI轮询及时暴露该失败。

脚本SHA清单为plan-file-sha256.json，冻结预算、旧失败指纹及新pins身份为plan-static-controls.json。旧静态日志、历史失败和初版交接继续保留。纯测试首次揭示双in_progress无效，第二次为VM跨realm数组比较适配错误，两份stderr保留，当前25项通过。

## root下一次实际运行

本机pins-after.json当前记录source=73a52945bb041b89090fbe174ac36c441c51c1cf6e2153df4818f13baf99caba。main/preload一致性及实际构建由root核验，runner按传入pins在开头和结尾严格核对源码/构建SHA。

在D:\WorkProject\EduProject\apps\desktop内，先记录累计预算，再仅运行一次新基线。

```powershell
node scripts/ui-final-retained-fixture-live.mjs --run-ui --pins=test-results/ui-final-content-20261111/pins-after.json
```

成功输出实际manifest绝对路径后，使用同一pins执行原retained reader。

```powershell
node scripts/ui-final-retained-sources-live.mjs --pins=test-results/ui-final-content-20261111/pins-after.json --fixture-manifest="<上一步真实manifest绝对路径>"
```

当前尚无成功新manifest，实际任务计划/教师审核/裁图/冷启和三尺寸验收等待root这一次有界执行。原retained默认、reference-root、三旧身份、220秒、原件/账本/来源/键盘/取消/焦点/三尺寸断言保留。产品性能前后数据待实际运行观察。

---

## 初版交接历史
# Retained genuine fixture QA 静态交接

本轮完成有限 QA 代码和静态验证，固定 A01–A36、X01–X08 共44项继续沿原合同。真实 UI 验收由 root 执行。当前未生成 genuine 基线、成功运行报告或 manifest.json。

## 写集

- apps/desktop/scripts/ui-final-retained-fixture-live.mjs，新增显式 --run-ui / --self-test 入口。
- apps/desktop/scripts/acceptance/retained-fixture-input.mjs，teacher-authored 三页算术 PDF，使用 original-multi-journey 已有 PDF/xref 构造方式，嵌入真实 RGB 图像。第一页为单页2+3，第二、三页为跨页 x+2=5 的条件、未知量图框与点数图。输入没有答案或审批标志。
- apps/desktop/scripts/acceptance/retained-fixture-provider.mjs，仅受控 SSE 工具请求，实际 Pi、工具结果、OCR/parser、事件、审批与持久化沿生产链。
- apps/desktop/scripts/acceptance/retained-fixture-evidence.mjs，ownedExact、逐级无重定向/符号链接/硬链接检查、只读 SQLite、生产 schema 与 questionFacts、native toolCall/toolResult、PNG身份/尺寸/SHA、原件与全树守恒、成功报告/manifest 读取。
- apps/desktop/scripts/acceptance/retained-fixture-selftest.mjs，内存工具传输 lab、生产 schema 与 AST 检查。
- apps/desktop/scripts/ui-final-retained-sources-live.mjs，仅显式新参数、三 case 选择和源根/profile适配。新增 --fixture-manifest 与 --reference-root 互斥。新 case 名称保持 arithmetic-*，与历史 education-journey-* 分开记录。

本轮写入的静态交接位于本目录。脚本指纹见 static-file-sha256.json。

## 原 retained 兼容及断言

旧 default 和 --reference-root 的三原 case 身份继续保留。

- education-journey-YlBdIe / question_78d96406-9590-4678-99f7-64c829651a1a，单图1。
- education-journey-0T0vdK / question_10934996-88dc-4e32-87df-10a71b9f07e0，多图3。
- education-journey-mnXCtZ，原 pending multi proposal。

旧 --reference-root 仍要求成功的历史 retained report 和上述三身份。原 prepare 中克隆后 local_path 的 SHA 校核/重定位保留。原 220000ms、三个 launch 路径、pre-launch 来源/有序 offset/bodyVersion 校核、startup rule_extracted 约束、五类原事实逐字段守恒、零网络/零模型/renderer error 门禁、原件 SHA 和原根指纹均保留。

原 reader 的原图解码、图数、唯一容器、键盘水平/竖直滚动及800/1366/1920三尺寸断言保留。原 pending 的真实原页 PNG、键盘移动选框、Apply/Cancel 可达、取消、焦点归还、三尺寸及最终退出守恒断言保留。新增参数仅将单图/多图/待裁图分别显式映射到新 manifest 身份，多图仍要求大于1。本次新多图为跨两页的2图。

历史缺失 app.db 和0字节 WAL继续属于原历史现场。旧缺失路径仍会失败。

## 新基线真实执行步骤

在 D:\WorkProject\EduProject\apps\desktop 中由 root 按顺序执行。

```powershell
node scripts/ui-final-retained-fixture-live.mjs --run-ui --pins=test-results/ui-final-content-20261111/pins.json
```

runner 创建全新、独占的 test-results/ui-final-content-20261111/retained-qa/run-<随机值>/baseline。data、profile、workspace均在该根。通过当前可见工作目录授权入口授权该 workspace，经 materials-import 原生选择器返回导入该根实际 PDF，等待真实 parser 与原 archive 队列完成。

第一项 Pi 任务通过实际目录/正文工具及必要的实际工具发现，依次提出单页和跨页原题。QA代理按明确作者输入逐项操作原六项转写 UI、完整题面 checkbox 和确认保存按钮。答案/解析保持 missing，sourceChecked 保持 false，由原宿主产生 proposal、PNG、审批 effect、question/document 及版本。

第二项 Pi 任务重新实际查找/读取同一 PDF，提出新身份的跨页待裁图 proposal。QA通过可见停止按钮结束该任务，校核终态和未确认 proposal。不会审批该 proposal。

随后第二次冷启动，校核持久终态、待裁图 UI、零重放，以及来源/题目/审批/运行/命令/usage/事件和原生 session 守恒。应用退出后只读 SQLite 对照生产 schema、proposal/effect digest、questionFacts 版本、native工具调用和实际PNG。报告、截图、原件、完整基线树与六个QA脚本均绑定SHA。全部通过后发布 manifest.json。

成功输出含真实 manifest 的绝对路径。再由 root 将该实际路径传给原 retained。

```powershell
node scripts/ui-final-retained-sources-live.mjs --pins=test-results/ui-final-content-20261111/pins.json --fixture-manifest="D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-content-20261111\retained-qa\run-<实际随机值>\manifest.json"
```

新 manifest 中每个 case 记录真实 sourceRoot/dataRoot/profileRoot、resourceId/sourceVersion、proposalId/sessionId/runId、原图资产身份与SHA。两个已保存 case 另有 questionId/questionVersion/questionSha256/effectDigest。三 case共用同一真实新基线根，原 retained为各case分别克隆。没有旧 case 重命名。

## 预算与依赖

新 runner固定最多2 Pi任务、8受控SSE响应、2启动、0外网/付费、240秒，guard在正式main导入前安装，并与原frame policy组合。第一项5响应，第二项3响应，第二项的待裁图保持待审核并由教师UI停止。冷启0响应。没有自动QA重试或预算覆盖参数。

仅 bytecopy 下列真实官方 cache，保留原 observedAt、模型能力、字节与SHA，由已有 validateCatalogue 校验。

D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-dialogue-20261111\catalogue\data\xiaozhi-pi\deepseek-capabilities.v1.json

执行仍依赖 pins源码/构建一致、现有本地PDF解析和pdfium预览组件、系统可用的原工具/权限、官方cache仍在既有24小时有效窗口。cache过期、工具未授权、parser失败或任务门禁要求其他实际步骤时，runner保留具体失败和预算，root据实决定最小修复。现有代码未发现必须放宽门禁的依赖。运行可行性尚待root实际验证。

## 静态验证与未运行边界

6个写集文件 node --check 通过。新 runner --self-test 的16项通过，含真实生产 schema、PDF三页/xref、受控8响应、真实工具结果缺失/失败拒绝、能力缺失拒绝、全局fetch/models拒绝、原frame组合、cold拒绝调用、路径拒绝、usage run_id守恒及旧 retained AST断言。selftest.log保存实际输出，scope为纯QA内存测试，Electron启动0、Pi任务0、外网0、业务DB写入0。node:sqlite ExperimentalWarning 为本机Node提示。

尚未执行新runner的任何Electron/UI路径、实际PDF导入/parser、Pi/host裁图、教师审批、SQLite应用事实建立、冷启动或原retained三尺寸验收。当前没有新case的实际question/proposal ID，没有生成成功manifest。全部44项状态由root原RESULT继续管理。

本轮检查产生的性能数据仅为纯脚本执行，未做产品性能前后测量。新代码局限QA，生产src/vendor无本轮改动。

回退可停用新runner并撤回原retained新增的参数/选择适配，保持原默认及reference-root入口。保留全部历史失败、静态日志及将来真实运行目录。


