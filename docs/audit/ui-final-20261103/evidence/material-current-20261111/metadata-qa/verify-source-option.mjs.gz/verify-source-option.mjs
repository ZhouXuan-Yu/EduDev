/** Read-only AST/preflight evidence. No runner import, clone, build or Electron launch. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';

const evidence = path.dirname(fileURLToPath(import.meta.url));
const desktop = path.resolve(evidence, '../../..');
const require = createRequire(path.join(desktop, 'package.json'));
const ts = require('typescript');
const helperFile = path.join(desktop, 'scripts/ui-final-material-metadata-recovery-helper.mjs');
const {contract, need, hash, tree, facts, readDb, logical} = await import(pathToFileURL(helperFile));
const {ownedExact} = await import(pathToFileURL(path.join(desktop, 'scripts/acceptance/paper-adaptation-continuation.mjs')));
const runnerFile = path.join(desktop, 'scripts/ui-final-material-metadata-recovery-live.mjs');
const before = JSON.parse(fs.readFileSync(path.join(evidence, 'before.json'), 'utf8'));
const originalText = fs.readFileSync(path.join(evidence, 'runner-before.mjs'), 'utf8');
const currentText = fs.readFileSync(runnerFile, 'utf8');
const parse = text => ts.createSourceFile('runner.mjs', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
const originalAst = parse(originalText);
const currentAst = parse(currentText);
const textOf = (node, ast = currentAst) => node.getText(ast);
const nodes = (root, predicate) => {
  const found = [];
  function visit(node) {
    if (predicate(node)) found.push(node);
    ts.forEachChild(node, visit);
  }
  visit(root);
  return found;
};
const variable = (name, ast = currentAst) => nodes(ast, node => ts.isVariableDeclaration(node) && textOf(node.name, ast) === name)[0];
const run = currentAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'run');
const statements = run.body.statements.find(ts.isTryStatement).tryBlock.statements;
const dependencyIndex = statements.findIndex(node => ts.isVariableStatement(node) && node.declarationList.declarations.some(decl => textOf(decl.name) === 'dependencies'));
assert(dependencyIndex > 0);
const preflight = statements.slice(0, dependencyIndex).map(node => textOf(node)).join('\n');
assert(!/electron\.launch|cloneBaseline|writeFileSync|mkdtempSync/.test(preflight));
const resultFields = '{source,sourceReportFile,sourceReportHash,old,specs,pins,pinsFile,pinsHash,build,main}';
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const source = path.join(owned, 'ui-final-material-catalog-live-LhntPx');
const sourceReportFile = path.join(source, 'report.json');
const sourceBefore = tree(source);
const old = JSON.parse(fs.readFileSync(sourceReportFile, 'utf8'));
const work = fs.mkdtempSync(path.join(evidence, 'static-fixtures-'));
const build = path.join(work, 'build');
fs.mkdirSync(path.join(build, 'main'), {recursive: true});
fs.writeFileSync(path.join(build, 'main/index.js'), '// Static path fixture. Never imported.\n', {flag: 'wx'});
const pinsFile = path.join(work, 'pins.json');
fs.writeFileSync(pinsFile, JSON.stringify({source: '1'.repeat(64), build: '2'.repeat(64), buildRoot: build}), {flag: 'wx'});
const baseArgs = ['--run-ui', '--pins=' + pinsFile];
const checks = [];
function check(name, work) {
  work();
  checks.push({name, status: 'PASS'});
}
function evaluate(args, overrides = {}) {
  const observedFs = new Proxy(fs, {get: (target, key) => overrides[key] ?? target[key]});
  const own = file => ownedExact(path.resolve(desktop, file), owned);
  return vm.runInNewContext(preflight + '\n(' + resultFields + ')', {args, fs: observedFs, path, owned, own, contract, hash, need});
}
const sourceArgs = [...baseArgs, '--source=' + source];
const patchReport = edit => ({readFileSync(file, ...options) {
  if (file !== sourceReportFile) return fs.readFileSync(file, ...options);
  const changed = structuredClone(old);
  edit(changed);
  return Buffer.from(JSON.stringify(changed));
}});
const rejectReport = (name, edit, expected) => check(name, () => assert.throws(() => evaluate(sourceArgs, patchReport(edit)), expected));

check('absolute_owned_source_accepts_actual_original_report', () => assert.equal(evaluate(sourceArgs).source, source));
check('desktop_relative_owned_source', () => assert.equal(evaluate([...baseArgs, '--source=' + path.relative(desktop, source)]).source, source));
check('argument_order_is_independent', () => assert.equal(evaluate([...sourceArgs].reverse()).source, source));
const selected = evaluate(sourceArgs);
check('source_sha_is_original_report_bytes', () => assert.equal(selected.sourceReportHash, hash(fs.readFileSync(sourceReportFile))));
check('default_still_targets_missing_K61_without_fallback', () => assert.throws(() => evaluate(baseArgs), error => error.code === 'ENOENT' && error.path.includes(contract.source)));
for (const [name, args, expected] of [
  ['duplicate_source', [...sourceArgs, '--source=' + source], /ARGS_INVALID/],
  ['empty_source', [...baseArgs, '--source='], /SOURCE_PATH_REQUIRED/],
  ['whitespace_source', [...baseArgs, '--source=  '], /SOURCE_PATH_REQUIRED/],
  ['split_source_syntax', [...baseArgs, '--source', source], /ARGS_INVALID/],
  ['unknown_option', [...sourceArgs, '--unknown'], /ARGS_INVALID/],
  ['missing_run_flag', sourceArgs.slice(1), /ARGS_INVALID/],
  ['duplicate_run_flag', [...sourceArgs, '--run-ui'], /ARGS_INVALID/],
  ['duplicate_pins', [...sourceArgs, '--pins=' + pinsFile], /ARGS_INVALID/],
  ['missing_pins', ['--run-ui', '--source=' + source], /ARGS_INVALID/],
  ['outside_owned', [...baseArgs, '--source=' + desktop], /Owned evidence required/],
  ['owned_root_itself', [...baseArgs, '--source=' + owned], /Owned evidence required/],
  ['traversal_outside_owned', [...baseArgs, '--source=test-results/../scripts'], /Owned evidence required/],
  ['file_as_source', [...baseArgs, '--source=' + sourceReportFile], /SOURCE_DIRECTORY_REQUIRED/],
  ['missing_source', [...baseArgs, '--source=' + path.join(work, 'missing')], /ENOENT/]
]) check(name + '_rejected', () => assert.throws(() => evaluate(args), expected));

const junction = path.join(work, 'source-junction');
fs.symlinkSync(source, junction, 'junction');
try {
  check('real_directory_junction_rejected', () => assert.throws(() => evaluate([...baseArgs, '--source=' + junction]), /No redirected evidence path/));
} finally {
  fs.unlinkSync(junction);
}
const parentJunction = path.join(work, 'parent-junction');
fs.symlinkSync(path.dirname(source), parentJunction, 'junction');
try {
  check('real_parent_directory_junction_rejected', () => assert.throws(() => evaluate([...baseArgs, '--source=' + path.join(parentJunction, path.basename(source))]), /No redirected evidence path/));
} finally {
  fs.unlinkSync(parentJunction);
}
check('report_hardlink_stat_rejected', () => assert.throws(() => evaluate(sourceArgs, {
  lstatSync(file) {
    const stat = fs.lstatSync(file);
    if (file === sourceReportFile) Object.defineProperty(stat, 'nlink', {value: 2});
    return stat;
  }
}), /SOURCE_REPORT_FILE_REQUIRED/));
check('report_symlink_stat_rejected', () => assert.throws(() => evaluate(sourceArgs, {
  lstatSync(file) {
    const stat = fs.lstatSync(file);
    if (file === sourceReportFile) stat.isSymbolicLink = () => true;
    return stat;
  }
}), /SOURCE_REPORT_FILE_REQUIRED/));
check('report_directory_stat_rejected', () => assert.throws(() => evaluate(sourceArgs, {
  lstatSync(file) {
    const stat = fs.lstatSync(file);
    if (file === sourceReportFile) stat.isFile = () => false;
    return stat;
  }
}), /SOURCE_REPORT_FILE_REQUIRED/));

rejectReport('source_success_false_rejected', report => {report.success = false;}, /SOURCE_ACCEPTANCE_REQUIRED/);
rejectReport('source_status_fail_rejected', report => {report.status = 'FAIL';}, /SOURCE_ACCEPTANCE_REQUIRED/);
rejectReport('source_suite_changed_rejected', report => {report.suite = 'other';}, /SOURCE_ACCEPTANCE_REQUIRED/);
rejectReport('source_eleven_checks_rejected', report => {report.checks.pop();}, /SOURCE_ACCEPTANCE_REQUIRED/);
rejectReport('source_thirteen_checks_rejected', report => {report.checks.push(report.checks[0]);}, /SOURCE_ACCEPTANCE_REQUIRED/);
rejectReport('source_nonpass_check_rejected', report => {report.checks[0].status = 'NOT_RUN';}, /SOURCE_ACCEPTANCE_REQUIRED/);
for (const key of ['output', 'data', 'profile']) rejectReport('renamed_' + key + '_identity_rejected', report => {report[key] = path.join(owned, contract.source, key);}, /SOURCE_IDENTITY_MISMATCH/);
rejectReport('two_fixtures_rejected', report => {report.fixtures.pop();}, /GENUINE_FIXTURE_REQUIRED/);
rejectReport('non_txt_fixture_rejected', report => {report.fixtures[0].name = 'QA-catalog-alpha.pdf';}, /GENUINE_FIXTURE_REQUIRED/);
rejectReport('non_catalog_fixture_rejected', report => {report.fixtures[0].name = 'other.txt';}, /GENUINE_FIXTURE_REQUIRED/);
rejectReport('duplicate_fixture_id_rejected', report => {report.fixtures[1].id = report.fixtures[0].id;}, /FIXTURE_ID_INVALID/);
rejectReport('changed_original_fixture_sha_rejected', report => {report.fixtures[0].sha256 = '0'.repeat(64);}, /ORIGINAL_FIXTURE_CHANGED/);
const sourceFacts = facts(path.join(source, 'data'));
check('actual_three_resources_and_original_local_parser', () => {
  assert.equal(sourceFacts.resources.length, 3);
  for (const spec of selected.specs) {
    const row = sourceFacts.resources.find(row => row.id === spec.id);
    assert.equal(row.content_hash, spec.sha256);
    assert.equal(row.original_file_name, spec.name);
    assert.equal(row.parse_engine, 'local-text-v1');
    assert(['ready', 'parsed', 'chunked', 'indexed', 'graph_extracted'].includes(row.parse_status));
    assert.equal(ownedExact(row.local_path, owned), row.local_path);
    assert(row.local_path.startsWith(path.join(source, 'data') + path.sep));
    assert.equal(hash(fs.readFileSync(row.local_path)), spec.sha256);
  }
});

const assertionCalls = ast => nodes(ast, node => ts.isCallExpression(node) && /^(need|assert(?:\.|$))/.test(textOf(node.expression, ast))).map(node => textOf(node, ast));
const originalAssertions = assertionCalls(originalAst);
const currentAssertions = assertionCalls(currentAst);
check('all_original_strong_assertions_preserved_except_argument_arity', () => {
  const remaining = [...currentAssertions];
  const originalArgumentAssertion = "need(args.length===2&&args.includes('--run-ui')&&args.filter(a=>a.startsWith('--pins=')).length===1,'ARGS_INVALID')";
  assert(originalAssertions.includes(originalArgumentAssertion));
  for (const text of originalAssertions.filter(text => text !== originalArgumentAssertion)) {
    const index = remaining.indexOf(text);
    assert(index >= 0, 'Missing original assertion ' + text);
    remaining.splice(index, 1);
  }
});
check('all_original_timeouts_and_wait_caps_preserved', () => {
  const timing = ast => nodes(ast, node => ts.isCallExpression(node) && /^(remaining|setTimeout|wait|waitContinuationBootstrap|closeContinuationRuntime|confirmExit|electron\.launch)$/.test(textOf(node.expression, ast))).map(node => textOf(node, ast));
  assert.deepEqual(timing(currentAst), timing(originalAst));
});
check('one_launch_call_and_all_runtime_mutation_recovery_bytes_preserved', () => {
  const runtimeStart = '    const targetBefore=baseline.metadata.find';
  assert.equal(currentText.slice(currentText.indexOf(runtimeStart)), originalText.slice(originalText.indexOf(runtimeStart)));
  assert.equal(nodes(currentAst, node => ts.isCallExpression(node) && textOf(node.expression) === 'electron.launch').length, 1);
});
check('helper_contract_seam_selftests_and_6_checks_byte_identical', () => {
  assert.equal(hash(fs.readFileSync(helperFile)), before.helperSha256);
  assert.equal(contract.source, 'ui-final-material-catalog-live-K61IFq');
  assert.equal(contract.launches, 1);
  assert.equal(contract.totalMs, 120000);
  assert.equal(contract.cleanupMs, 12000);
  assert.equal(contract.saveCalls, 1);
  assert.equal(contract.http, 0);
  assert.equal(contract.models, 0);
  assert.equal(contract.checks.length, 6);
});
check('self_test_dispatch_byte_identical', () => {
  assert.equal(textOf(currentAst.statements.find(ts.isIfStatement)), textOf(originalAst.statements.find(ts.isIfStatement), originalAst));
});
check('report_records_selected_source_sha_and_original_identity', () => {
  const assignments = nodes(currentAst, node => ts.isBinaryExpression(node) && textOf(node.left) === 'report' && ts.isObjectLiteralExpression(node.right));
  const assignment = assignments.find(node => node.right.properties.some(prop => prop.name && textOf(prop.name) === 'originalGeneration'));
  const property = assignment.right.properties.find(prop => prop.name && textOf(prop.name) === 'originalGeneration');
  const observed = vm.runInNewContext('(' + textOf(property.initializer) + ')', selected);
  assert.deepEqual(JSON.parse(JSON.stringify(observed)), {source, report: sourceReportFile, sha256: hash(fs.readFileSync(sourceReportFile)), pins: old.pins,
    identity: {suite: old.suite, status: old.status, success: old.success, output: old.output, data: old.data, profile: old.profile}});
});
check('source_report_hash_revalidated_before_inventory_and_each_verify', () => {
  const verify = variable('verify').initializer;
  const guard = verify.body.statements.find(node => textOf(node).includes('own(source)===source'));
  assert(guard);
  const verifyCode = textOf(guard);
  const own = file => ownedExact(path.resolve(desktop, file), owned);
  vm.runInNewContext(verifyCode, {...selected, own, need, hash, fs});
  const changedFs = new Proxy(fs, {get: (target, key) => key === 'readFileSync' ? () => Buffer.from('changed report') : target[key]});
  assert.throws(() => vm.runInNewContext(verifyCode, {...selected, own, need, hash, fs: changedFs}), /SOURCE_EVIDENCE_CHANGED/);
});
const sourceLogical = readDb(path.join(source, 'data/app.db'), logical);
check('actual_source_original_files_report_and_full_tree_unchanged', () => assert.deepEqual(tree(source), sourceBefore));
const report = {
  status: 'PASS', productAcceptance: false, launches: 0, http: 0, models: 0,
  scope: 'AST-extracted actual preflight and read-only source observations',
  runner: {file: runnerFile, beforeSha256: before.runnerSha256, afterSha256: hash(fs.readFileSync(runnerFile))},
  helper: {file: helperFile, sha256: before.helperSha256},
  source: {root: source, report: sourceReportFile, reportSha256: selected.sourceReportHash, suite: old.suite, status: old.status, success: old.success,
    checks: old.checks.length, fixtures: selected.specs, fullTreeSha256: sourceBefore.sha256, logicalSha256: sourceLogical.sha256,
    ledger: sourceFacts.ledger, sourceTables: sourceFacts.sourceTables, native: sourceFacts.native},
  assertions: {original: originalAssertions.length, current: currentAssertions.length, originalArgumentArityOnlyReplacement: true},
  checks, notRun: ['Actual live runner / Electron user journey', 'Current root build and frozen pins', 'Runtime timing/performance comparison'],
  limits: ['Report file type/link rejection cases use read-only fs-stat overlays. Directory and ancestor redirect cases use real Windows junctions.',
    'Altered source report cases use memory-only read overlays. The original PASS report and its identity remain byte-identical.']
};
fs.writeFileSync(path.join(evidence, 'static-report.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({status: report.status, checks: checks.length, originalAssertions: originalAssertions.length, currentAssertions: currentAssertions.length,
  sourceReportSha256: selected.sourceReportHash, launches: 0, productAcceptance: false}));
