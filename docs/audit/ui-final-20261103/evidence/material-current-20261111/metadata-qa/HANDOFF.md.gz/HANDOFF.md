# UI-FINAL S2 metadata QA source 参数交接

## 根因与写集

runner 从 helper 的固定 contract.source 拼出历史 K61IFq 路径，该目录的 report.json 当前缺失，原两参数调用会在预检读取来源时失败。现新增显式可选 --source= 路径，缺省仍读取原 contract.source。业务修改由 root 负责，本次交付为验收适配器修复。

本轮源码写集仅 apps/desktop/scripts/ui-final-material-metadata-recovery-live.mjs，共新增 22 行、删除 5 行。其余本轮文件均在当前 ignored metadata-qa 目录。helper SHA 与开工记录相同，源码下半部自 targetBefore 起逐字相同。现场已有其他协作者文档修改，归属与本次写集独立。

当前任务分支经只读检查为 codex/ui-goal-implementation-20261101。Git 操作限于关闭可选锁的 status/diff/diff --check 读取。

## 调用兼容与参数验证

| 项目 | 执行行为 | 静态/预检证据 |
| --- | --- | --- |
| 原 --self-test | 原单参数分派及 helper 自测原文保留 | AST 分派逐字比较，26 项原自测 PASS |
| 原 --run-ui --pins= | 两参数继续合法，source 缺省仍为 K61IFq，缺失保持真实失败 | AST 执行预检后 ENOENT 路径包含原 contract.source |
| 新 --source= | 最多一个，接受三参数任意顺序 | 绝对路径、desktop 相对路径、反向顺序均 PASS |
| 参数数量/名字 | 必须含原 --run-ui 与唯一 --pins=，仅额外接受一个 --source= | 缺 run、重复 run、缺 pins、重复 pins、重复 source、未知选项均拒绝 |
| 参数值 | 显式空串与纯空白拒绝，路径保持原始字符传入解析 | 空串/空白均 SOURCE_PATH_REQUIRED；分离 --source value 形式 ARGS_INVALID |
| source 所有权 | 按 desktop 解析后调用原 ownedExact，要求真实路径严格位于 test-results 内部 | 外部目录、test-results 根本身、向外穿越路径均拒绝 |
| source 类型和链接 | 必须为真实目录，拒绝 symlink/重定向 | 文件路径、缺失路径、真实 Windows junction 及祖先 junction 均拒绝 |
| report 所有权/类型 | 原 ownedExact 校验 report.json，lstat 要求普通文件、非 symlink、nlink=1 | 文件类型/symlink/hardlink 的内存 stat 反例均拒绝 |
| 原 pins | JSON 后缀、source/build 64 位 SHA、owned build/main 路径、当前 source/build 指纹全部继续校验 | 原断言逐字守恒 |
| 原报告身份 | success=true、status=PASS、原 suite、12 项全 PASS；output/data/profile 必须指向被选择原目录 | success/status/suite/11 项/13 项/非 PASS/三种改名身份反例均拒绝 |
| 三原 TXT | 原名称前后缀、数量、唯一资源 ID、alpha/beta、fixture 文件 SHA 全部继续校验 | 原实际三 TXT 与 SQLite local-text-v1 资源对应；缺项/类型/ID/SHA 反例均拒绝 |

相对路径遵循原 pins 的 desktop 基准。推荐 root 显式传入绝对 source 路径。

## 报告与来源身份

runner 读取一次原报告字节后冻结 SHA。每次 verify 均重新核对其路径与字节摘要，完整来源目录 inventory 继续按原机制校验。originalGeneration 保留原 report/sha256/pins 字段，并增加 source 与 identity 中的原 suite/status/success/output/data/profile。snapshot.sourceReferences 记录实际选择目录。

实际选择源为 D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-material-catalog-live-LhntPx。

原报告 SHA256 为 a5b16cd51ba885b02d0a7374f3fdec373aa23f46d8df4c0a7dd1c3a0ce3bf07b。

原报告与完整来源目录在静态验证前后的 inventory 完全一致。static-report.json 保存实际三份 TXT 的资源 ID/SHA、全部逻辑快照 SHA、17 个账本投影、来源表投影及 native 观察。参数反例通过 AST 提取的真实预检代码执行，报告内容反例使用内存读取覆盖，原成功报告字节与身份始终保留。

## 原断言和预算守恒

AST 收集原 runner 的 76 个 need/assert 调用，除原参数数量断言由支持可选 source 的严格数量断言替换外，其余每个调用原文及次数均保留。当前共有 81 个 need/assert 调用。

- 六个原 checks 与原最终全 PASS 判定保留。
- 原 source success/status/suite/12 项全 PASS、三 TXT 名称/资源 ID/SHA、解析状态、原文件字节与来源目录约束保留。
- 原只读 SQLite backup、所有表逻辑 SHA、冷克隆事实、全部文件 inventory、17 个账本、native、sourceTables 与最终 source/pins 完整性保留。
- 原一次真实 save、提交后 ACK 丢失、相同 operation 只读核实、revision/source/patch digest 与其他对象迟到响应检查保留。
- 原唯一 electron.launch 调用、所有 remaining/wait/setTimeout/bootstrap/close 调用 AST 原文完全一致。
- contract 保持 120000ms、cleanup 12000ms、1 launch、1 save、0 model、0 HTTP。helper 自测断言及 transport seam 通过 helper 全文件 SHA 守恒证明。

## 实际验证结果

以下 Node 命令在 D:\WorkProject\EduProject\apps\desktop 执行，详细 stdout/stderr/exit/耗时见 node-validation.json。

```powershell
node --check scripts/ui-final-material-metadata-recovery-live.mjs
node --check scripts/ui-final-material-metadata-recovery-helper.mjs
node scripts/ui-final-material-metadata-recovery-live.mjs --self-test
```

两个 Nodecheck 均 exit 0。原自测 26/26、exit 0，记录 launches/models/http 均为 0。原自测使用其既有临时 SQLite fixture 行为。

以下命令在仓库根执行，AST 提取预检/参数反例、实际源只读观察及断言守恒 47/47 PASS，记录 launches/models/http 均为 0。

```powershell
node apps/desktop/test-results/ui-final-content-20261111/metadata-qa/verify-source-option.mjs
git --no-optional-locks diff --check
```

仓库级 diff --check exit 0。静态证据中的 report 文件类型/链接反例使用 fs-stat 内存覆盖，目录及祖先重定向使用真实 Windows junction。测试 pins/main 是 ignored 静态路径 fixture，仅供 AST 预检解析，从未导入或启动。

## root 接续

root 构建并冻结当前 source/build pins 后，从 desktop 运行以下命令。PINS.json 由 root 替换为本次实际冻结路径。

```powershell
node scripts/ui-final-material-metadata-recovery-live.mjs --run-ui --pins="D:\WorkProject\EduProject\apps\desktop\test-results\PINS.json" --source="D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-material-catalog-live-LhntPx"
```

完整 Electron 六 checks、真实窗口/保存回执与 root 当前构建配对验收状态为 NOT_RUN，仍由 root 执行。原默认路径的缺失现状保留，新入口须显式传 source。

## 性能与回滚

静态证据证明所有预算与 timeout 调用原文一致。新增开销为预检路径/身份认证及每次 verify 对原报告的路径和 SHA 复核，实际 Electron 前后耗时尚待 root 同机同数据测量。

回滚可对照 runner-before.mjs 仅撤销本次 source 参数、身份校验与报告字段差异，先核对当前 runner SHA 与 static-report.json 中 afterSha256 以保护后续协作修改。源目录、原报告与业务数据没有本轮迁移。
