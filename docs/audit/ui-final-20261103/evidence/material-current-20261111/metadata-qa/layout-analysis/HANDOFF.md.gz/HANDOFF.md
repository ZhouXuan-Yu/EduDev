# 原页操作区溢出修复交接

本真实缺陷修复 1/2。源码写集已释放，CSS 冻结。root 已批准精确 5 行补丁，并报告开始正式 after build。当前没有本 agent 仍在运行的检查。

## 源码与影响范围

唯一源码改动为 src/renderer/ui-system/material-library/material-library.module.css，在 .workspace .detail :global(.material-original-actions) 增加 flex-wrap:wrap、min-width:0、max-width:100%。300px 详情栏与原断点继续沿原规则。

MaterialOriginalPreview 由 MaterialBodyPanel 和 MaterialAiPagePanel 共享使用。新增规则只匹配资料库 workspace/detail 内的预览操作容器，所有页码、跳转、重读或停止、收起按钮保留。组件实现、HeroUI 内部、teacher-library.css 及全局 CSS 均属本轮源码写集之外。

## 原因与原始证据

Aq0O7B 原 CSSOM 指向 teacher-library.css 第 64 行的 .material-original-actions，编译位置 index-1MrkosSr.css 第 4425 行。原容器为 flex/nowrap、min-width:auto、max-width:none，子项 103+60+108+44 和三处 8px gap 总宽 339px，父区仅 247px。

E0B0GK/Aq0O7B 的 1366 和 1920 原页区域实际横向溢出，document 宽度仍等于 viewport。root 原截图显示主区横向条与首屏以下按钮，原报告和截图继续保留。800 堆叠时当前证据没有同类溢出。

## 已完成与待 root 验证

已实际执行 npm run test:ui-style-isolation，9/9 PASS、exit 0。此后没有追加或扩展检查。static-report.json 保存精确状态、源码 SHA 和影响范围。

正式 after build、246 组件检查、三尺寸实际界面、获胜 CSSOM、main/detail 严格溢出、键盘与内层放大滚动由 root 验证，当前本 agent 的 after 实际验收为 NOT_RUN。运行耗时前后对比待 root 实测。

overview 隐藏 curriculum 的额外宽度保留为原审查发现，本补丁仅覆盖已批准的原页 actions 缺陷。

回滚时核对 static-report.json 的修改后 SHA，仅撤销该 5 行规则，保留后续协作变更。没有业务或数据迁移。
