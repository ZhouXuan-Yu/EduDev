/** AST and isolated selection controls. No live runner import or GUI. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
const evidence=path.dirname(fileURLToPath(import.meta.url)),desktop=path.resolve(evidence,'../../../..');
const require=createRequire(path.join(desktop,'package.json')),ts=require('typescript');
const {sha256,fingerprint}=await import(pathToFileURL(path.join(desktop,'scripts/acceptance/evidence.mjs')));
const baseline=JSON.parse(fs.readFileSync(path.join(evidence,'before.json'),'utf8'));
const runner=path.join(desktop,baseline.files[0].file);
const oldText=fs.readFileSync(path.join(evidence,'runner-before.mjs'),'utf8'),text=fs.readFileSync(runner,'utf8');
const parse=value=>ts.createSourceFile('runner.mjs',value,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const old=parse(oldText),current=parse(text),catalog=parse(fs.readFileSync(path.join(desktop,'scripts/ui-final-material-catalog-live.mjs'),'utf8'));
const nodes=(root,predicate)=>{
  const found=[];
  function visit(node){if(predicate(node))found.push(node);ts.forEachChild(node,visit);}
  visit(root);return found;
};
const code=node=>node.getText(node.getSourceFile());
const select=ast=>nodes(ast,node=>ts.isFunctionDeclaration(node)&&node.name.text==='select')[0];
const beforeSelect=select(old),afterSelect=select(current);
const checks=[];
async function check(name,action){await action();checks.push({name,status:'PASS'});}
await check('all_bytes_outside_select_preserved',()=>{
  assert.equal(text.slice(0,afterSelect.getStart()),oldText.slice(0,beforeSelect.getStart()));
  assert.equal(text.slice(afterSelect.end),oldText.slice(beforeSelect.end));
});
await check('original_selection_and_object_enabled_wait_preserved',()=>assert.deepEqual(afterSelect.body.statements.slice(0,2).map(code),beforeSelect.body.statements.map(code)));
await check('three_added_statements_exactly_reuse_catalog_QA',()=>assert.deepEqual(afterSelect.body.statements.slice(2).map(code),select(catalog).body.statements.slice(2).map(code)));
const assertions=ast=>nodes(ast,node=>ts.isCallExpression(node)&&/^(need$|assert(?:\.|$))/.test(code(node.expression))).map(code);
await check('all_original_assertions_preserved_with_one_expanded_assert_added',()=>{
  const added="assert.equal(await metadata.getAttribute('aria-expanded'),'true')";
  assert.equal(assertions(current).filter(value=>value===added).length,1);
  assert.deepEqual(assertions(current).filter(value=>value!==added),assertions(old));
});
await check('all_timeouts_timers_original_waits_and_launch_calls_preserved',()=>{
  const timing=ast=>nodes(ast,node=>ts.isPropertyAssignment(node)&&code(node.name)==='timeout'||ts.isCallExpression(node)&&/^(setTimeout|clearTimeout|remaining|wait|waitContinuationBootstrap|closeContinuationRuntime|electron\.launch)$/.test(code(node.expression))).map(code);
  assert.deepEqual(timing(current),timing(old));
});
await check('helper_six_checks_120s_guards_noop_manifest_and_catalog_bytes_preserved',()=>{
  for(const file of baseline.files.slice(1))assert.equal(sha256(fs.readFileSync(path.join(desktop,file.file))),file.sha256,file.file);
});
async function run(ast,options={}){
  const state={expanded:options.expanded??'false',metadataClicks:0,trace:[]};
  const spec={id:'qa-alpha'},material={kind:'material'};
  const metadata={kind:'metadata',getAttribute:async name=>{assert.equal(name,'aria-expanded');return state.expanded;}};
  const tid=id=>{
    if(id==='material-catalog-editor')return {getAttribute:async name=>{assert.equal(name,'data-resource-id');return options.wrongObject?'qa-beta':spec.id;}};
    if(id==='material-catalog-directory')return {isEnabled:async()=>!options.disabled};
    assert.equal(id,'materials-metadata');
    return {getByRole(role,query){
      assert.equal(role,'button');assert.equal(query.name,'编辑目录、标签与元数据');assert.equal(query.exact,true);
      state.trace.push('exact-original-disclosure');if(options.missingDisclosure)throw Error('MISSING_DISCLOSURE');return metadata;
    }};
  };
  const page={locator(selector){assert.equal(selector,`[data-testid="material-${spec.id}"] button`);return material;}};
  const click=async locator=>{
    state.trace.push('click:'+locator.kind);
    if(locator===metadata){state.metadataClicks++;if(!options.staysClosed)state.expanded='true';}
  };
  const wait=async predicate=>{if(!await predicate())throw Error('WAIT_DEADLINE');state.trace.push('object-enabled');};
  const invoke=vm.runInNewContext('('+code(select(ast))+')',{assert,tid,page,click,wait});
  await invoke(spec);return state;
}
await check('old_helper_leaves_hidden_disclosure_closed',async()=>assert.equal((await run(old)).expanded,'false'));
await check('closed_disclosure_opens_once_after_original_object_wait',async()=>{
  const state=await run(current);assert.equal(state.expanded,'true');assert.equal(state.metadataClicks,1);
  assert(state.trace.indexOf('object-enabled')<state.trace.indexOf('click:metadata'));
});
await check('open_disclosure_retained_without_second_click',async()=>assert.equal((await run(current,{expanded:'true'})).metadataClicks,0));
for(const [name,options,expected]of [
  ['wrong_object',{wrongObject:true},/WAIT_DEADLINE/],['disabled_object',{disabled:true},/WAIT_DEADLINE/],
  ['missing_disclosure',{missingDisclosure:true},/MISSING_DISCLOSURE/],['still_closed_after_click',{staysClosed:true},undefined],
  ['invalid_expanded_attribute',{expanded:'unknown'},undefined]
])await check(name+'_rejected',()=>assert.rejects(run(current,options),expected));
await check('original_7XZLY6_FAIL_directory_all_bytes_preserved',()=>assert.equal(fingerprint(baseline.historyRoot).sha256,baseline.history.sha256));
const results=[];
for(const args of [['--check','scripts/ui-final-material-metadata-recovery-live.mjs'],['scripts/ui-final-material-metadata-recovery-live.mjs','--self-test']]){
  const result=spawnSync(process.execPath,args,{cwd:desktop,encoding:'utf8',windowsHide:true,timeout:30000});
  assert.equal(result.status,0,result.stderr);
  const parsed=result.stdout.trim()?JSON.parse(result.stdout.trim()):null;
  if(parsed)assert.equal(parsed.checks.length,26);
  results.push({command:['node',...args].join(' '),cwd:desktop,exitCode:result.status,stdout:result.stdout,stderr:result.stderr,parsed});
}
const report={status:'PASS',checks,assertions:{before:assertions(old).length,after:assertions(current).length},results,
  files:baseline.files.map(item=>({...item,afterSha256:sha256(fs.readFileSync(path.join(desktop,item.file)))})),
  oldSelect:code(beforeSelect),newSelect:code(afterSelect),historicalFailurePreserved:true,
  launches:0,http:0,models:0,actualElectronAcceptance:'NOT_RUN',runtimePerformance:'NOT_RUN',
  scope:'AST-extracted select with isolated locator model; actual UI validation belongs to root'};
fs.writeFileSync(path.join(evidence,'static-report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({status:report.status,checks:checks.length,assertions:report.assertions,selfTests:26,nodecheckExitCode:0,launches:0,actualElectronAcceptance:report.actualElectronAcceptance}));
