# Metadata select 披露面板适配交接

## 根因与修改

7XZLY6 的 startup NoOp 已通过，原报告在 COMMITTED_ACK_LOSS_UNKNOWN_DRAFT 的 directory 可见性检查超时，saveCalls=0。root 提供的截图观察为 materials-metadata 折叠。

源码写集仅 scripts/ui-final-material-metadata-recovery-live.mjs 的 select()，追加三行，逐字复用当前 ui-final-material-catalog-live.mjs 的原逻辑。在原对象 ID/输入可用等待后，定位 materials-metadata 内精确名称“编辑目录、标签与元数据”的 button，aria-expanded=false 时沿原 click 点击，再断言 aria-expanded=true。

## 静态验证

仓库根执行以下命令，15/15 静态及隔离模型检查通过。内部运行 Nodecheck exit0，原 self-test 26/26 PASS。

```powershell
node apps/desktop/test-results/ui-final-content-20261111/metadata-qa/disclosure-20261111/verify.mjs
```

AST 证明 select 外所有字节相同、原 select 两条语句逐字保留、追加三条语句与 catalog QA 逐字相同。原 81 条 need/assert 原文和顺序保留，仅增加展开断言至 82 条。所有 timeout/timer、原 wait、启动/清理调用相同。helper、NoOp、manifest、catalog 文件 SHA 相同，六 checks、120s、一 launch、一 save、guards 及零 HTTP/model 预算守恒。

隔离模型覆盖旧 helper 仍折叠、新 helper 在对象就绪后点击一次、已展开不重复点击，以及对象错误/禁用、缺面板、点击后仍折叠和非法展开属性拒绝。7XZLY6 原 FAIL 目录完整 inventory 前后一致。

## root 接续与回滚

static-report.json 保存命令、结果、源码前后 SHA 和 AST 证据。完整 Electron 六 checks、真实保存/回执/迟到响应与运行耗时由 root 使用既有 pins/source 命令复验，当前均为 NOT_RUN。本轮 launches/http/models 为 0。

交接后释放本轮写集。回滚先核对 static-report.json 中 runner 修改后 SHA，再对照 runner-before.mjs 仅撤销 select() 新增三行，保护后续协作改动。
