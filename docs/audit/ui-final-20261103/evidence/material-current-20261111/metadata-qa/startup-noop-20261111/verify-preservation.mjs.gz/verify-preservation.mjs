/** Static provenance and preservation evidence. No application startup. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';

const evidence=path.dirname(fileURLToPath(import.meta.url));
const desktop=path.resolve(evidence,'../../../..');
const require=createRequire(path.join(desktop,'package.json')),ts=require('typescript');
const {sha256,fingerprint}=await import(pathToFileURL(path.join(desktop,'scripts/acceptance/evidence.mjs')));
const baseline=JSON.parse(fs.readFileSync(path.join(evidence,'before.json'),'utf8'));
const manifestFile='scripts/acceptance/material-metadata-startup-20261106.json';
const manifest=JSON.parse(fs.readFileSync(path.join(desktop,manifestFile),'utf8'));
const parse=text=>ts.createSourceFile('review.mjs',text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const textOf=node=>node.getText(node.getSourceFile());
const nodes=(root,predicate)=>{
  const found=[];
  function visit(node){if(predicate(node))found.push(node);ts.forEachChild(node,visit);}
  visit(root);return found;
};
const oldHelperText=fs.readFileSync(path.join(evidence,'ui-final-material-metadata-recovery-helper.mjs.before'),'utf8');
const helperText=fs.readFileSync(path.join(desktop,'scripts/ui-final-material-metadata-recovery-helper.mjs'),'utf8');
const oldCurrentText=fs.readFileSync(path.join(evidence,'material-metadata-startup-current.mjs.before'),'utf8');
const currentText=fs.readFileSync(path.join(desktop,'scripts/acceptance/material-metadata-startup-current.mjs'),'utf8');
const oldHelper=parse(oldHelperText),helper=parse(helperText),oldCurrent=parse(oldCurrentText),current=parse(currentText);
const named=(ast,name)=>ast.statements.find(node=>ts.isFunctionDeclaration(node)&&node.name.text===name);
const checks=[];
function check(name,action){action();checks.push({name,status:'PASS'});}

check('only_exact_179_to_179_dispatch_added',()=>{
  const old=named(oldHelper,'assertStartupMigration'),now=named(helper,'assertStartupMigration');
  assert.equal(textOf(now.body.statements[0]),'if(before.logical.tables.length===179&&after.logical.tables.length===179)return assertCurrentStartupNoop(before,after);');
  assert.deepEqual(now.body.statements.slice(1).map(textOf),old.body.statements.map(textOf));
});
check('helper_all_other_statements_including_26_selftests_and_contract_unchanged',()=>{
  const skip=node=>ts.isFunctionDeclaration(node)&&node.name.text==='assertStartupMigration'||
    ts.isImportDeclaration(node)&&node.moduleSpecifier.text==='./acceptance/material-metadata-startup-current.mjs';
  assert.deepEqual(helper.statements.filter(node=>!skip(node)).map(textOf),oldHelper.statements.filter(node=>!skip(node)).map(textOf));
});
check('all_original_current_migration_and_derived_reader_statements_unchanged',()=>{
  const kept=current.statements.filter(node=>!(ts.isFunctionDeclaration(node)&&node.name.text==='assertCurrentStartupNoop'));
  assert.deepEqual(kept.map(textOf),oldCurrent.statements.map(textOf));
});
const assertionCalls=ast=>nodes(ast,node=>ts.isCallExpression(node)&&/^(assert(?:\.|$)|need$)/.test(textOf(node.expression))).map(textOf);
check('all_original_helper_and_current_assertions_preserved',()=>{
  for(const [old,now]of [[oldHelper,helper],[oldCurrent,current]]){
    const remaining=assertionCalls(now);
    for(const call of assertionCalls(old)){
      const index=remaining.indexOf(call);assert(index>=0,call);remaining.splice(index,1);
    }
  }
});
const preservedFiles=baseline.files.filter(item=>!['scripts/ui-final-material-metadata-recovery-helper.mjs','scripts/acceptance/material-metadata-startup-current.mjs'].includes(item.file));
check('live_source_option_6_checks_budget_manifest_and_old_current_selftest_bytes_preserved',()=>{
  for(const item of preservedFiles)assert.equal(sha256(fs.readFileSync(path.join(desktop,item.file))),item.sha256,item.file);
});
const timing=ast=>nodes(ast,node=>ts.isCallExpression(node)&&/^(setTimeout|clearTimeout|spawnSync)$/.test(textOf(node.expression))||
  ts.isPropertyAssignment(node)&&textOf(node.name)==='timeout').map(textOf);
check('all_helper_and_current_timeouts_unchanged',()=>{
  assert.deepEqual(timing(helper),timing(oldHelper));assert.deepEqual(timing(current),timing(oldCurrent));
});
check('noop_compares_entire_schema_logical_facts_derived_control_and_state',()=>{
  const body=textOf(named(current,'assertCurrentStartupNoop'));
  for(const field of ['schema','logical','facts','derivedCounts','control'])assert(body.includes('assert.deepEqual(after.'+field+',before.'+field+','));
  assert(body.includes("assert.deepEqual(after,before,'NOOP_STATE_CHANGED')"));
  assert(body.includes('manifest.afterTables===179&&manifest.afterSources===94&&manifest.sectionPolicy===4'));
});
const productionFile='src/main/assets/material-book-answer-index.ts';
const productionText=fs.readFileSync(path.join(desktop,productionFile),'utf8'),productionAst=parse(productionText);
const literals=nodes(productionAst,node=>ts.isStringLiteral(node)).map(node=>({sql:node.text,line:productionAst.getLineAndCharacterOfPosition(node.getStart(productionAst)).line+1}));
const policySql='UPDATE material_book_answer_control_v1 SET cursor=0,section_policy=4 WHERE id=1 AND section_policy<4';
const policy=literals.find(row=>row.sql===policySql);
check('production_policy4_and_manifest_policy4_exactly_match',()=>{assert.equal(manifest.sectionPolicy,4);assert(policy);assert.equal(policy.line,36);});
const baseTables=manifest.changed.filter(change=>change.before.type==='table'&&change.before.name.startsWith('material_book_answer_'));
check('book_index_control_dirty_ddl_bases_are_exact_production_literals',()=>{
  assert.equal(baseTables.length,3);
  for(const change of baseTables)assert(literals.some(row=>row.sql===change.before.sql.replace('CREATE TABLE ','CREATE TABLE IF NOT EXISTS ')));
});
const requiredAlters=[
  'ALTER TABLE material_book_answer_control_v1 ADD COLUMN section_policy INTEGER NOT NULL DEFAULT 0',
  "ALTER TABLE material_book_answer_index_v1 ADD COLUMN lookup_key TEXT NOT NULL DEFAULT ''",
  'ALTER TABLE material_book_answer_dirty_v1 ADD COLUMN context_only INTEGER NOT NULL DEFAULT 0'
];
check('current_book_columns_and_lookup_index_are_reviewed_production_sql',()=>{
  for(const sql of requiredAlters)assert(literals.some(row=>row.sql===sql));
  assert(productionText.includes("['book_role','proof_sha','review_state']"));
  assert(productionText.includes('ALTER TABLE material_book_answer_index_v1 ADD COLUMN ${name} TEXT NOT NULL DEFAULT'));
  const lookup=manifest.added.find(row=>row.name==='material_book_answer_lookup_v2');
  assert(literals.some(row=>row.sql===lookup.sql.replace('CREATE INDEX ','CREATE INDEX IF NOT EXISTS ')));
  assert(baseTables.find(row=>row.after.name==='material_book_answer_index_v1').after.sql.includes("lookup_key TEXT NOT NULL DEFAULT ''"));
});
check('manifest_current_ddl_and_legacy_absence_are_both_authenticated_before_equality',()=>{
  const body=textOf(named(current,'assertCurrentStartupNoop'));
  assert(body.includes('[...manifest.added,...manifest.changed.map(change=>change.after)]'));
  assert(body.includes('rows.length===1&&hash(rows[0])===hash(expected)'));
  assert(body.includes('for(const removed of manifest.removed)'));
  assert(!/\.push\(|\.splice\(|writeFile|DatabaseSync|\.exec\(/.test(body));
});
const history=baseline.histories.map(item=>({...item,currentInventorySha256:fingerprint(item.root).sha256}));
check('qualified_source_12_PASS_identity_and_original_FAIL_all_bytes_preserved',()=>{
  for(const item of history)assert.equal(item.currentInventorySha256,item.inventory.sha256);
  const source=history[0];assert.equal(source.success,true);assert.equal(source.status,'PASS');
  assert.equal(source.checks.length,12);assert(source.checks.every(row=>row.status==='PASS'));
  const failed=history[1];assert.equal(failed.success,false);assert.equal(failed.status,'FAIL');
  assert.equal(failed.failure.code,'MIGRATION_TABLE_COUNT');assert.equal(failed.seamOnExit.saveCalls,0);
});
const observed=JSON.parse(fs.readFileSync(path.join(evidence,'actual-readonly-noop.json'),'utf8'));
check('retained_actual_179_94_policy4_states_pass_readonly_noop',()=>{
  assert.equal(observed.receipt.code,'EXACT_CURRENT_STARTUP_NOOP_VERIFIED');assert.equal(observed.unchanged,true);
  assert.deepEqual(observed.after,observed.before);
});
const validation=JSON.parse(fs.readFileSync(path.join(evidence,'node-validation.json'),'utf8'));
check('nodechecks_40_pure_controls_and_26_original_selftests_pass',()=>{
  assert(validation.results.every(row=>row.exitCode===0));
  assert.equal(validation.results.find(row=>row.parsed&&row.command.includes('startup-noop-test')).parsed.checks.length,40);
  assert.equal(validation.results.find(row=>row.command.includes('--self-test')).parsed.checks.length,26);
});
const report={status:'PASS',scope:'Static provenance, original-contract preservation and read-only retained snapshot evidence',
  actualElectronAcceptance:'NOT_RUN',launches:0,http:0,models:0,checks,
  files:baseline.files.map(item=>({...item,afterSha256:sha256(fs.readFileSync(path.join(desktop,item.file)))})),
  newTest:{file:'scripts/acceptance/material-metadata-startup-noop-test.mjs',sha256:sha256(fs.readFileSync(path.join(desktop,'scripts/acceptance/material-metadata-startup-noop-test.mjs')))},
  sourceReview:{file:productionFile,policy,baseTables,requiredAlters,manifestFile,manifestVersion:manifest.version,sectionPolicy:manifest.sectionPolicy},
  assertions:{helperBefore:assertionCalls(oldHelper).length,helperAfter:assertionCalls(helper).length,currentBefore:assertionCalls(oldCurrent).length,currentAfter:assertionCalls(current).length},
  receipt:observed.receipt,history,
  oldCurrentSnapshotTest:{status:'NOT_RUN',reason:'Original K61IFq report/data missing; file and assertions preserved. Pure 173-to-179 compatibility control passed.'}};
fs.writeFileSync(path.join(evidence,'static-report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({status:report.status,checks:checks.length,assertions:report.assertions,actualElectronAcceptance:report.actualElectronAcceptance,launches:0}));
