# Metadata 当前已迁移源 NoOp 启动校验交接

## 根因与本轮范围

LhntPx 是原 suite 的 qualified source，原报告 success=true、status=PASS、12 项全 PASS、三份原 TXT 的真实导入解析与来源证据继续保留。当前源已经是 179 表、94 sourceTables、section_policy=4。lD3WDl owned clone 启动前后完全相同，旧入口仍调用要求 before173/after179 的迁移校验，因此在零 save 时触发 MIGRATION_TABLE_COUNT。

当前 material-metadata-startup-20261106.json 的 sectionPolicy 已为 4。本轮复用该文件的精确 added、changed.after、removed SQL 记录及 policy4。

源码写集为以下三份文件。

- scripts/ui-final-material-metadata-recovery-helper.mjs，仅增加导入和精确 before179/after179 分派。
- scripts/acceptance/material-metadata-startup-current.mjs，追加独立 assertCurrentStartupNoop。
- scripts/acceptance/material-metadata-startup-noop-test.mjs，新增纯对象正向与负控制测试。

本轮其余文件均在当前 ignored metadata-qa/startup-noop-20261111 目录。现有 live runner 的 source 选择补丁和全部原断言保持当前字节身份。

## 生产来源审查

src/main/assets/material-book-answer-index.ts 第 36 行明确保存以下 SQL。

```sql
UPDATE material_book_answer_control_v1 SET cursor=0,section_policy=4 WHERE id=1 AND section_policy<4
```

同文件第 14–33 行提供 index/dirty/control 三份基础 CREATE TABLE、section_policy/context_only、book_role/proof_sha/review_state/lookup_key 增量列、lookup_v2 索引和 v2 triggers。新静态验证从这些生产字面 SQL、列名和模板中核对现有 manifest 的书册对象来源。sourceReview 保存精确片段、行号及文件 SHA，生产源码只读。

NoOp 先核对原 manifest 的全部 added 和 changed.after 对象在 before 中精确存在一次，并要求 removed 旧对象缺席。之后完整 after 必须与 before 相等。全部允许的当前对象来自既有冻结 manifest，after 数据库只参与相等性检查。

## 三个分派与严格条件

| 分支 | 条件与行为 |
| --- | --- |
| 新当前 NoOp | 仅 before179/after179，分别要求 94 sourceTables，冻结 manifest 必须仍为 179/94/policy4 |
| 原当前迁移 | 原 after179 分派及 assertCurrentStartupMigration 全部原文保留，仍要求 manifest 中 before173/after179 |
| 原 legacy | 原 173/88 到 173/88 的全部 DDL、policy3、行及事实断言保留 |

NoOp 还要求以下条件同时成立。

- manifest 当前精确 SQL 对象与 before 对应，旧删除对象均缺席。
- before/after schema 的全部对象及 SQL 严格相等，schema SHA 与实际 schema 匹配。
- before control 精确为 [{id:1,cursor:0,section_policy:4}]，after control 全部相等。
- logical 全部字段严格相等，覆盖全部 179 表的 count/SHA、userVersion、applicationId、schema SHA 和完整 logical SHA。
- facts 全部字段严格相等，包括 ledger、native、全部 sourceTables、resources、metadata、tags 及任何附加字段。
- derivedCounts 必须存在，所有资源计数、cursor、indexed 及附加字段严格相等。
- 整个 startupState 再做一次严格相等，覆盖顶层新增字段变化。

## 实际验证

Node v24.12.0 下，以下命令在 apps/desktop 执行，全部 exit 0，精确 stdout/stderr/耗时见 node-validation.json。

```powershell
node --check scripts/ui-final-material-metadata-recovery-helper.mjs
node --check scripts/acceptance/material-metadata-startup-current.mjs
node --check scripts/acceptance/material-metadata-startup-noop-test.mjs
node --check scripts/ui-final-material-metadata-recovery-live.mjs
node scripts/acceptance/material-metadata-startup-noop-test.mjs
node scripts/ui-final-material-metadata-recovery-live.mjs --self-test
```

新纯控制 40/40 PASS，含合法 NoOp、公开分派、DDL/列变化、冻结对象缺失/重复、旧 trigger 恢复、policy3/未知 policy、control 行、两个 pragma、facts 每个字段、derivedCounts 每个字段以及顶层变化拒绝。另逐一变更全部 179 表的行投影，所有变更均拒绝。使用同一 manifest 构造的纯 173→179 兼容控制通过。

原自测 26/26 PASS，原 selfTest 函数及所有断言逐字保留。

在仓库根执行下列静态核验，14/14 PASS。

```powershell
node apps/desktop/test-results/ui-final-content-20261111/metadata-qa/startup-noop-20261111/verify-preservation.mjs
```

AST 证明 helper 新首分派之后的整个旧分支按原顺序逐字保留，其余全部原语句包含 contract、seam、自测与 post-startup 保护逐字保留。current 文件的全部原语句和 derived reader 逐字保留，仅追加新函数。helper 原 78 条断言全部保留，current 原 13 条断言全部保留，追加后为 26 条。原所有 timeout、120s、1 launch、1 save、0 model/HTTP、六 checks 及 source 默认值守恒。

原 material-metadata-startup-current-test.mjs 及 manifest 文件 SHA 保留。该旧实库测试依赖缺失的 K61IFq，状态仍为 NOT_RUN。新增纯兼容测试验证原 173→179 分支可达。

首次静态汇总器误选 Nodecheck 的空 parsed 输出，已修正结果选择条件并保留 static-first-failure.json。完整静态复验 14 项通过。

## 当前真实源与 retained clone 的只读核验

actual-readonly-noop.json 保存 LhntPx 与 lD3WDl 的完整 startupState 及返回回执，两者严格相等并通过新公开分派。读取前后两个目录完整 inventory SHA 均一致。

原源报告 SHA256 为 a5b16cd51ba885b02d0a7374f3fdec373aa23f46d8df4c0a7dd1c3a0ce3bf07b。

原 lD3WDl FAIL 报告 SHA256 为 e30c8126cd1f87e35e5b4d084f6c3c692474efc21c2ff856652c6604a12b0784。

两个状态的 schema SHA256 均为 b9f84950d5d9d94c374202d8de76d6599e756b4b6d7fc361947bf476e35fc96c。

两个状态的 logical SHA256 均为 b4ff6bead615d2dfdd26f7778b4ccb3b394aeaf6c456185a2543c3dbb664174c。

lD3WDl 原报告的独立字段按原值保留。

| 字段 | 原值 |
| --- | --- |
| status / success | FAIL / false |
| failure.code | MIGRATION_TABLE_COUNT |
| seamOnExit.saveCalls / committed | 0 / 0 |
| sourceAndPinsFinalIntegrity | true |
| integrity | false |
| readOnlyFinalIntegrity | 原报告缺省 |
| integrityFailure.code | POSTSTARTUP_BASELINE_REQUIRED |

这些字段及全部原目录字节记录在 static-report.json。原 FAIL 的身份保持其原报告。

## root 接续与性能

本轮执行 launches/HTTP/models 均为 0。完整 Electron 六 checks 和实际保存/回执/跨对象迟到路径状态为 NOT_RUN，root 使用现有冻结 pins/source 命令实际复验一次。

新 NoOp 只做内存 snapshot 校验，所有原 timeout 与总预算保留。实际 Electron 前后耗时待 root 记录。

回滚时先核对 static-report.json 中修改后 SHA，再对照两份 .before 文件仅撤销新导入、首分派和 NoOp 函数，以及新增独立纯测试文件，保护后续协作修改。原源文件、失败报告和业务数据没有本轮迁移。
