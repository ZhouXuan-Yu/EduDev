import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fingerprint} from '../../scripts/acceptance/evidence.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const file = path.join(import.meta.dirname, 'inputs-integrated.json');
const source = fingerprint(path.join(desktop, 'src'));
if (process.argv.includes('--before')) {
  assert(!fs.existsSync(file));
  fs.writeFileSync(file, JSON.stringify(source, null, 2));
} else {
  assert.equal(source.sha256, JSON.parse(fs.readFileSync(file)).sha256);
  const buildRoot = path.join(import.meta.dirname, 'frozen-out-integrated');
  for (const entry of ['main/index.js', 'preload/index.cjs', 'renderer/index.html']) assert(fs.existsSync(path.join(buildRoot, entry)));
  const pins = {root: desktop, buildRoot, source: source.sha256, build: fingerprint(buildRoot).sha256,
    sourceCommit: 'de86afd plus scoped material original action wrapping',
    sourceStable: true, method: 'Actual npm build including tsc; source observed during build and checked after bundling'};
  const prior = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, 'pins-after.json')));
  const comparison = Object.fromEntries(['renderer', 'preload'].map(directory => [directory,
    fingerprint(path.join(prior.buildRoot, directory)).sha256 === fingerprint(path.join(buildRoot, directory)).sha256]));
  assert(comparison.renderer && comparison.preload);
  fs.writeFileSync(path.join(import.meta.dirname, 'pins-integrated.json'), JSON.stringify(pins, null, 2));
  fs.writeFileSync(path.join(import.meta.dirname, 'integrated-ui-comparison.json'), JSON.stringify(comparison, null, 2));
  console.log(JSON.stringify({pins, comparison}));
}
