import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {readSql, nativeMessages} from '../../scripts/acceptance/retained-fixture-evidence.mjs';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const directory = path.resolve(import.meta.dirname, '../ui-final-retained-sources-wUcOc7');
const report = JSON.parse(fs.readFileSync(path.join(directory, 'report.json')));
assert(report.success && report.exitIntegrity);
function state(root) {
  const data = path.join(root, 'data');
  return {tasks: readSql(data, query => query("SELECT * FROM app_settings WHERE key LIKE 'xiaozhi.task.v1:%' ORDER BY key")),
    native: nativeMessages(data).map(({sessionId, sha256}) => ({sessionId, sha256}))};
}
const comparisons = [];
for (const item of report.cases) {
  const before = state(item.original), after = state(item.clone);
  assert.deepEqual(after, before, 'Cold task-plan revisions, admission history and native sessions remain unchanged');
  comparisons.push({name: item.name, tasks: before.tasks.length, nativeSessions: before.native.length,
    beforeSha256: sha256(JSON.stringify(before)), afterSha256: sha256(JSON.stringify(after))});
}
const result = {success: true, sourceReportSuccess: false, currentReaderSuccess: true, comparisons,
  scope: 'Independent read-only comparison after three real cold launches. No task or tool execution.'};
fs.writeFileSync(path.join(import.meta.dirname, 'retained-cold-independent.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
