import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fingerprint} from '../../scripts/acceptance/evidence.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const file = path.join(import.meta.dirname, 'inputs-after.json');
const source = fingerprint(path.join(desktop, 'src'));
if (process.argv.includes('--before')) {
  assert(!fs.existsSync(file));
  fs.writeFileSync(file, JSON.stringify(source, null, 2));
} else {
  const before = JSON.parse(fs.readFileSync(file));
  assert.equal(source.sha256, before.sha256);
  const buildRoot = path.join(import.meta.dirname, 'frozen-out-after');
  for (const entry of ['main/index.js', 'preload/index.cjs', 'renderer/index.html']) assert(fs.existsSync(path.join(buildRoot, entry)));
  const pins = {root: desktop, buildRoot, source: source.sha256, build: fingerprint(buildRoot).sha256,
    sourceCommit: '83caa47 plus scoped material original action wrapping', sourceStable: true,
    method: 'Actual npm build including tsc into isolated owned output'};
  fs.writeFileSync(path.join(import.meta.dirname, 'pins-after.json'), JSON.stringify(pins, null, 2));
  console.log(JSON.stringify(pins));
}
