import {nativeMessages} from '../../scripts/acceptance/retained-fixture-evidence.mjs';

const root = 'test-results/ui-final-content-20261111/retained-qa/run-RwLhR6/baseline/data';
for (const session of nativeMessages(root)) {
  for (const message of session.messages) {
    const text = typeof message.content === 'string' ? message.content :
      (message.content || []).map(part => part.text || '').join('\n');
    const marker = '{"schemaVersion":"xiaozhi.task-plan.v3","taskId":';
    console.log(JSON.stringify({role: message.role, keys: Object.keys(message),
      length: text.length, markerOffset: text.lastIndexOf(marker), schemaOffset: text.indexOf('xiaozhi.task-plan.v3')}));
  }
}
