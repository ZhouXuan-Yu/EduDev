import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {_electron} from 'playwright';
import {fingerprint, sha256} from '../../scripts/acceptance/evidence.mjs';
import {continuationBootstrap, continuationGuardRead} from '../../scripts/acceptance/paper-adaptation-continuation.mjs';
import {startupState} from '../../scripts/ui-final-material-metadata-recovery-helper.mjs';
import {assertIsolatedPiMain} from '../../scripts/acceptance/build-root.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const pins = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, 'pins.json')));
const source = path.join(import.meta.dirname, 'source-review');
const data = path.join(source, 'data');
const output = fs.mkdtempSync(path.join(import.meta.dirname, 'layout-review-'));
const profile = path.join(output, 'profile');
const main = path.join(pins.buildRoot, 'main/index.js');
const before = startupState(data);
const report = {success: false, output, data, profile, pins, samples: [], errors: [], launches: 1,
  scope: 'Real previously parsed owned data, visible read-only detail tabs and page image. No generation, save, import or approval.'};
let app;
const verify = () => {
  assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
  assert.equal(fingerprint(pins.buildRoot).sha256, pins.build);
};
const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
const timer = setTimeout(() => {report.deadline = true; save(); app?.close().catch(() => {});}, 120000);
try {
  verify();
  const bootstrap = path.join(output, 'bootstrap.cjs');
  fs.writeFileSync(bootstrap, continuationBootstrap({main, profile, diagnosticFile: path.join(output, 'startup.json')}));
  const env = {...process.env};
  for (const key of Object.keys(env)) {
    if (/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(key) || key.startsWith('OMNI_EDU_') ||
        ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL'].includes(key)) delete env[key];
  }
  Object.assign(env, {OMNI_EDU_DATA_ROOT: data, OMNI_EDU_REPO_ROOT: path.resolve(desktop, '../..'),
    OMNI_EDU_XIAOZHI_PI: '1', OMNI_EDU_E2E_DIALOG_MODE: '1', OMNI_EDU_E2E_VISIBLE: '1'});
  app = await _electron.launch({args: [bootstrap, '--force-device-scale-factor=1'], cwd: output, env, timeout: 30000});
  const page = await app.firstWindow({timeout: 30000});
  page.setDefaultTimeout(8000);
  page.on('pageerror', error => report.errors.push({type: 'page', sha256: sha256(String(error))}));
  page.on('console', message => {if (message.type() === 'error') report.errors.push({type: 'console', sha256: sha256(message.text())});});
  await page.getByTestId('xiaozhi-pi-workspace').waitFor();
  report.identity = await assertIsolatedPiMain(app, main, profile);
  assert.equal(await page.evaluate(() => window.omniEdu.getDataRoot()), data);
  await app.evaluate(continuationGuardRead, true);
  await page.getByTestId('nav-knowledge').click();
  await page.getByRole('button', {name: /QA A13 three real pages/}).click();
  async function capture(id, width, height) {
    await app.evaluate(({BrowserWindow}, size) => {
      const window = BrowserWindow.getAllWindows()[0];
      window.setContentSize(...size); window.show(); window.focus();
    }, [width, height]);
    await page.waitForFunction(size => innerWidth === size[0] && innerHeight === size[1], [width, height]);
    const metrics = await page.evaluate(() => {
      const box = element => {
        const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
        return {tag: element.tagName, testId: element.getAttribute('data-testid'), classes: String(element.className),
          width: rect.width, height: rect.height, clientWidth: element.clientWidth, scrollWidth: element.scrollWidth,
          overflowX: style.overflowX, overflowY: style.overflowY, minWidth: style.minWidth, display: style.display};
      };
      return {width: innerWidth, height: innerHeight, dpr: devicePixelRatio, document: box(document.documentElement),
        detail: box(document.querySelector('aside[aria-label="资料详情"]')),
        overflowing: [...document.querySelectorAll('main, section, aside, div')].filter(element =>
          element.getBoundingClientRect().width > 0 && element.clientWidth > 0 && element.scrollWidth > element.clientWidth + 1).slice(0, 30).map(box),
        image: [...document.querySelectorAll('[data-testid="materials-original-image"]')].map(image =>
          ({...box(image), complete: image.complete, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight}))};
    });
    const file = path.join(output, id + '.png');
    await page.screenshot({path: file});
    report.samples.push({id, file, metrics, zoom: await app.evaluate(({BrowserWindow}) => BrowserWindow.getAllWindows()[0].webContents.getZoomFactor())}); save();
  }
  for (const section of ['overview', 'original', 'content', 'questions', 'notes', 'advanced']) {
    await page.getByTestId('materials-section-' + section).click();
    if (section === 'original') {
      await page.getByTestId('materials-original-open').click();
      await page.getByTestId('materials-original-image').waitFor();
      await page.waitForFunction(() => {const image = document.querySelector('[data-testid="materials-original-image"]'); return image?.complete && image.naturalWidth > 0;});
    }
    await capture(section + '-1366', 1366, 768);
  }
  await page.getByTestId('materials-section-original').click();
  for (const width of [1920, 800]) await capture('original-' + width, width, width === 1920 ? 1080 : 768);
  report.guard = await app.evaluate(continuationGuardRead, true);
  assert.equal(report.guard.networkAttempts, 0); assert.equal(report.guard.modelAttempts, 0);
  assert.equal(report.guard.rendererErrors, 0); assert.deepEqual(report.errors, []);
  await app.close(); app = undefined;
  report.after = startupState(data);
  assert.deepEqual(report.after.facts, before.facts, 'Original resources, metadata, source/approval/model ledgers unchanged');
  verify(); report.success = true;
} catch (error) {
  report.failure = {message: error.message, stackSha256: sha256(String(error.stack))};
  process.exitCode = 1;
} finally {
  if (app) await app.close().catch(() => {});
  clearTimeout(timer); save(); console.log(JSON.stringify({success: report.success, output, failure: report.failure}));
}
