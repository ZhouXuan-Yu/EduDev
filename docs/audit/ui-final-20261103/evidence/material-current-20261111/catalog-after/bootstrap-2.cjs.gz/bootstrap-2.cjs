const electron=require('electron'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const state=globalThis.__paperContinuationBootstrapState={phase:'BOOTSTRAP_PROFILE_BIND',timeline:[]};
const diagnosticFile="D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-material-catalog-live-adn756\\bootstrap-state-2.json",diagnostic=function continuationDiagnostic(error,phase='PREFLIGHT'){
  const phases=['PREFLIGHT','ARCHIVE','BOOTSTRAP_WRITE','LAUNCH','LAUNCH_RETURNED','MAIN_IDENTITY','STORAGE_PATH','GUARD_POLICY','WINDOW_READY','COLD_TERMINAL','BASKET_READBACK','ACCEPTED_REVIEW','FINAL_GUARD','CLOSE','FINAL_SAVED_INTEGRITY','FINAL_GUARD_INTEGRITY','DONE','BOOTSTRAP_PROFILE_BIND','BOOTSTRAP_WAIT_READY','BOOTSTRAP_INSTALL_GUARD','BOOTSTRAP_MAIN_IMPORT','BOOTSTRAP_MAIN_IMPORTED'];
  const message=String(error?.message||''),stack=String(error?.stack||error),names=['Error','AssertionError','TypeError','ReferenceError','SyntaxError','TimeoutError','RangeError'];
  const messages=[['BOOTSTRAP_READY_DEADLINE','BOOTSTRAP_READY_DEADLINE'],['BOOTSTRAP_FAILED','BOOTSTRAP_FAILED'],['Main module inventory unavailable','MAIN_INVENTORY_UNAVAILABLE'],['NO_ZERO_MODEL_GUARD','ZERO_MODEL_GUARD_MISSING'],['NETWORK_POLICIES_NOT_COMPOSED','NETWORK_POLICY_COMPOSITION_FAILED'],['ASYNC_NETWORK_POLICY','NETWORK_POLICY_ASYNC'],['UNSUPPORTED_NETWORK_REGISTRATION','NETWORK_REGISTRATION_UNSUPPORTED'],['CONTINUATION_NETWORK_DENIED','NETWORK_DENIED'],['Owned defaultSession partition','PROFILE_STORAGE_MISMATCH'],['Electron preferences must use the owned profile','PROFILE_USER_DATA_MISMATCH'],['Chromium data must use the owned profile','PROFILE_SESSION_DATA_MISMATCH'],['ZERO network attempts','NETWORK_ATTEMPT_DETECTED'],['ZERO model attempts','MODEL_ATTEMPT_DETECTED'],['Early renderer error latched','EARLY_RENDERER_ERROR'],['Runtime error latched','RUNTIME_ERROR_LATCHED'],['No ledger row may change','LEDGER_CHANGED'],['No native session replay','NATIVE_SESSION_CHANGED'],['Historical archive changed','ARCHIVE_CHANGED'],['Historical evidence changed or added','ORIGINAL_EVIDENCE_CHANGED'],['Final guard observation unavailable','FINAL_GUARD_OBSERVATION_FAILED'],['Target page, context or browser has been closed','ELECTRON_TARGET_CLOSED'],['Target closed','ELECTRON_TARGET_CLOSED']];
  const files=['scripts/acceptance/build-root.mjs','scripts/acceptance/evidence.mjs','scripts/acceptance/paper-adaptation-continuation.mjs','scripts/acceptance/paper-adaptation-live-ui.mjs','scripts/acceptance/paper-basket-ui-driver.mjs','scripts/acceptance/paper-basket-ui-locators.mjs','scripts/acceptance/paper-instance-ui-driver.mjs','scripts/acceptance/paper-instance-ui-wait.mjs','scripts/product-navigation.mjs','scripts/ui-final-paper-adaptation-continuation-live.mjs','scripts/xiaozhi-agent/capture-workspace-metrics.mjs'];
  const qaFrames=[],normalized=stack.replaceAll('\\','/');
  for(const match of normalized.matchAll(/(?:\/|^)(scripts\/[A-Za-z0-9_./-]+\.mjs):(\d+):(\d+)/g))if(files.includes(match[1])&&qaFrames.length<8)qaFrames.push({file:match[1],line:Number(match[2]),column:Number(match[3])});
  for(const match of normalized.matchAll(/\/ui-final-paper-adaptation-continuation-[A-Za-z0-9]+\/owned-bootstrap\.cjs:(\d+):(\d+)/g))if(qaFrames.length<8)qaFrames.push({file:'owned-bootstrap.cjs',line:Number(match[1]),column:Number(match[2])});
  const fixed=['FINAL_GUARD_DEADLINE','FINAL_CLOSE_DEADLINE','GLOBAL_UI_DEADLINE','BOOTSTRAP_CHILD_EXITED','BOOTSTRAP_STATE_REDIRECTED','BOOTSTRAP_STATE_INVALID'];
  const protocol=[['Resulting promise was garbage collected.','CDP_PROMISE_COLLECTED'],['Promise was collected','CDP_PROMISE_COLLECTED'],['Execution context was destroyed, most likely because of a navigation.','CDP_EXECUTION_CONTEXT_DESTROYED'],['JSHandle is disposed!','CDP_HANDLE_DISPOSED'],['JSHandles can be evaluated only in the context they were created!','CDP_HANDLE_CONTEXT_MISMATCH'],['Cannot serialize result: object reference chain is too long.','CDP_SERIALIZATION_LIMIT']];
  const systemCodes=['EPERM','EACCES','EBUSY','EEXIST','ENOENT','EIO','ENOSPC'],system=systemCodes.includes(error?.code)?{systemCode:error.code,...(['open','write','rename','lstat','stat','read','realpath'].includes(error?.syscall)?{syscall:error.syscall}:{})}:{};
  const code=error?.code==='SQLITE_BUSY'||error?.errcode===5?'SQLITE_BUSY':system.systemCode?'FILESYSTEM_OPERATION_FAILED':fixed.includes(message)?message:message==='Owned application close not verified'?'OWNED_CLOSE_UNVERIFIED':protocol.find(([text])=>message===text||message==='electronApplication.evaluate: '+text)?.[1]||messages.find(([text])=>message.includes(text))?.[1]||'CONTINUATION_UNCLASSIFIED_ERROR';
  return {code,name:names.includes(error?.name)?error.name:'Error',phase:phases.includes(phase)?phase:'UNKNOWN',qaFrames,...system,hash:process.getBuiltinModule('crypto').createHash('sha256').update(stack).digest('hex')};
},publish=function publishContinuationBootstrap(fs,path,file,state){
  const target=path.resolve(file),parent=path.dirname(target);
  assert.equal(target,file,'BOOTSTRAP_STATE_REDIRECTED');
  assert.equal(fs.realpathSync(parent),parent,'BOOTSTRAP_STATE_REDIRECTED');
  const directory=fs.lstatSync(parent);assert(directory.isDirectory()&&!directory.isSymbolicLink(),'BOOTSTRAP_STATE_REDIRECTED');
  for(const name of [target,target+'.tmp']){
    try{fs.lstatSync(name);}catch(error){if(error.code==='ENOENT')continue;throw error;}
    throw Error('BOOTSTRAP_STATE_EXISTS');
  }
  const bytes=JSON.stringify(state);assert(Buffer.byteLength(bytes)<=65536,'BOOTSTRAP_STATE_INVALID');
  fs.writeFileSync(target+'.tmp',bytes,{flag:'wx',mode:0o600});
  const temp=fs.lstatSync(target+'.tmp');assert(temp.isFile()&&!temp.isSymbolicLink(),'BOOTSTRAP_STATE_REDIRECTED');
  assert.equal(fs.realpathSync(target+'.tmp'),target+'.tmp','BOOTSTRAP_STATE_REDIRECTED');
  fs.renameSync(target+'.tmp',target);
};
const stamp=()=>({wallTimeMs:Date.now(),monotonicNs:process.getBuiltinModule('process').hrtime.bigint().toString()});
const persist=file=>{if(file)publish(fs,path,file,state);};
const trace=event=>{
  assert(state.timeline.length<7,'BOOTSTRAP_STATE_INVALID');
  const point={sequence:state.timeline.length+1,event,phase:state.phase,...stamp()};state.timeline.push(point);
  if(diagnosticFile)publish(fs,path,diagnosticFile+'.phase-'+String(point.sequence).padStart(2,'0')+'.json',{schemaVersion:'xiaozhi.qa.bootstrap-phase.v1',...point});
};
const record=phase=>{state.phase=phase;trace(phase);};
const fail=error=>{state.error=diagnostic(error,state.phase);state.failed=true;if(globalThis.__paperContinuationGuard)state.guardAtFailure=JSON.parse(JSON.stringify(globalThis.__paperContinuationGuard.state));try{persist(diagnosticFile?diagnosticFile+'.error.json':null);}catch(publicationError){process.stderr?.write?.(JSON.stringify({code:'BOOTSTRAP_ERROR_PUBLISH_FAILED',error:state.error,publication:diagnostic(publicationError,state.phase)})+'\n');}electron.app.exit(1);};
try{
  record('BOOTSTRAP_PROFILE_BIND');fs.mkdirSync("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-material-catalog-live-adn756\\profile",{recursive:true});
  electron.app.setPath('userData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-material-catalog-live-adn756\\profile");electron.app.setPath('sessionData',"D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-material-catalog-live-adn756\\profile");
  record('BOOTSTRAP_WAIT_READY');
  (async()=>{
    await electron.app.whenReady();record('BOOTSTRAP_INSTALL_GUARD');
    (function installContinuationNoModel({app,net,session}){
  const state={networkAttempts:0,modelAttempts:0,rendererErrors:0,formalRegistrations:0},web=session.defaultSession.webRequest,register=web.onBeforeRequest.bind(web);
  const crypto=process.getBuiltinModule('crypto'),hash=value=>crypto.createHash('sha256').update(String(value)).digest('hex');
  state.events=[];let formal;
  const rendererError=(code,value)=>{state.rendererErrors++;if(state.events.length<32)state.events.push({code,hash:hash(value)});};
  // Attach before formal main creates its first webContents; late Playwright listeners
  // alone cannot observe errors emitted during loadFile/preload.
  app?.on('web-contents-created',(_event,contents)=>{
    contents.on('console-message',(details,level,message)=>{const modern=typeof details?.level==='string';if(modern?details.level==='error':level===3)rendererError('EARLY_CONSOLE_ERROR',modern?details.message:message);});
    contents.on('preload-error',(_e,_file,error)=>rendererError('PRELOAD_ERROR',error));
    contents.on('render-process-gone',(_e,details)=>{if(details.reason!=='clean-exit')rendererError('RENDER_PROCESS_GONE',details.reason);});
  });
  const attempt=(code,value)=>{state.networkAttempts++;if(code==='MODEL_ATTEMPT_BLOCKED')state.modelAttempts++;if(state.events.length<32)state.events.push({code,hash:hash(value)});};
  const block=async(input,init={})=>{const url=typeof input==='string'?input:input instanceof URL?input.href:input.url;attempt(/chat\/completions/.test(url)?'MODEL_ATTEMPT_BLOCKED':'NETWORK_ATTEMPT_BLOCKED',url);throw Error('CONTINUATION_NETWORK_DENIED');};
  net.fetch=block;globalThis.fetch=block;
  const combined=(details,callback,probe=false)=>{
    if(/^https?:/.test(details.url)){if(!probe)attempt(/chat\/completions/.test(details.url)?'MODEL_ATTEMPT_BLOCKED':'NETWORK_ATTEMPT_BLOCKED',details.url);callback({cancel:true});return;}
    if(formal)formal(details,callback);else callback({cancel:false});
  };
  web.onBeforeRequest=(...args)=>{if(args.length!==1||(args[0]!==null&&typeof args[0]!=='function'))throw Error('UNSUPPORTED_NETWORK_REGISTRATION');formal=args[0];if(formal)state.formalRegistrations++;register(combined);};register(combined);
  globalThis.__paperContinuationGuard={state,combined};
})(electron);
    trace('GUARD_INSTALLED');record('BOOTSTRAP_MAIN_IMPORT');
    await import(require('node:url').pathToFileURL("D:\\WorkProject\\EduProject\\apps\\desktop\\test-results\\ui-final-content-20261111\\frozen-out-after\\main\\index.js").href);
    record('BOOTSTRAP_MAIN_IMPORTED');trace('TERMINAL_PUBLISH_START');
    state.terminalPublishStarted=stamp();persist(diagnosticFile);
  })().catch(fail);
}catch(error){fail(error);}
