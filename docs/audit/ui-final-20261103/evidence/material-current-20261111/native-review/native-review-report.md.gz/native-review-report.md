# Native Electron material review — 2026-11-11

Status: PARTIAL. GUI work stopped and released; normal close requested through the owned window's Close button. PID 79280 was absent from Get-Process afterward and startup.json records exit. HWND 14290772 belonged to PID 79280; executable was the canonical project Electron and bootstrap imported frozen-out/main/index.js. Accessibility reported frozen-out/renderer/index.html. No other window was operated. PID 189384 was not returned by the process query; no inference about its prior state.

Fixture: cloned Qm48vA data, A13 PDF and completed-control TXT, per source-review-launch.json. No import, generation, metadata save, question approval, temporary draft, config or Git changes. Bootstrap HTTP guard is installed; main-process counter not observed, so no zero-counter claim. HTTP activity was not independently measured in this UI review.

## Observations

- Navigation through the actual sidebar to 资料库 initially displayed 正在读取资料; settled list contained 2 records, PDF and TXT, both 可用于查找. PDF selection opened 资料详情; overview showed the correct filename, 185.5 KB, 正文已收录, 4 segments, and the warning that text availability does not imply teacher verification.
- 原页 tab > 查看原页 showed 正在打开原页 with disabled page controls while loading; settled page 1 displayed 1 / 3 and an image with the PDF material name in its accessible label. Next produced page 2 then page 3, each with a distinct visibly rendered image and correct accessible page label. Page 1 previous and page 3 next were disabled; page 2 both enabled. Previous from 3 to 2 and 2 to 1 worked after loading. This verifies visible image rendering, not pixel-level decode metadata or OCR correctness.
- Default fitted preview was extremely narrow in the right detail pane even at the maximized captured window, so page text was not practically legible at that scale. A bottom horizontal scrollbar was visibly present; no DOM overflow metrics were read, and causation/extent remain unverified. Enlarging the original preview made text larger but clipped within the narrow pane, with inner horizontal and vertical scrollbars; vertical scrolling changed the visible portion. Horizontal scrolling was not tested. Relevant captures 02–06.
- Prototype README describes material organization, original-page checking and derived-result review; this live capture shows a large largely empty central list alongside a cramped detail/preview pane. This is a visual observation, not a full prototype conformance verdict.

## Evidence and limits

- 01-overview-913x601.png: initial restored window screenshot; 02-page1-max-1707x1019.png, 03-page2-max-1707x1019.png, 04-page3-max-1707x1019.png: settled original pages; 05 enlarged, 06 enlarged and scrolled. These dimensions are screenshot capture dimensions returned by the native tool, not verified CSS viewport dimensions. Actual viewport width/height, devicePixelRatio and Electron zoom are UNKNOWN. Launch command included --force-device-scale-factor=1, which is not a measurement of those values. Frame/zoom settings were not changed; window was maximized for inspection.
- Exact 1366×768, 1920×1080, 800×768 viewports were NOT VERIFIED; A31 or responsive acceptance is not claimed. No forced resizing or DevTools used.
- 概要 and 原页 visited; 正文, 题目与校正, 阅读笔记, 处理详情 were visible in navigation but their actual contents were NOT reviewed. No A12 full-tab claim. PDF page jump, horizontal scroll, text selection/recognition, file-location action, persisted state, metadata, loading/error scenarios beyond observed loading, and true model/HTTP activity remain unverified.
- The browser-window capture may be scaled; judge readability against this evidence with that limitation. No instrumentation or injected UI/CSS/events used.
