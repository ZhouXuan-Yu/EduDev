import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {DatabaseSync, backup} from 'node:sqlite';
import {fingerprint, sha256} from '../../scripts/acceptance/evidence.mjs';
import {zeroNetworkBootstrap} from '../../scripts/acceptance/zero-network-bootstrap.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const source = path.join(desktop, 'test-results/ui-final-material-parse-live-Qm48vA');
const output = path.join(import.meta.dirname, 'source-review');
const pins = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, 'pins.json')));
assert.equal(fingerprint(path.join(desktop, 'src')).sha256, pins.source);
assert.equal(fingerprint(pins.buildRoot).sha256, pins.build);
assert(JSON.parse(fs.readFileSync(path.join(source, 'report.json'))).success);
assert(!fs.existsSync(output));
fs.mkdirSync(output);
const sourceFiles = fingerprint(source).files.filter(file => !/(?:-wal|-shm|-journal)$/.test(file.file));
for (const name of ['data', 'profile']) {
  const files = fingerprint(path.join(source, name)).files;
  for (const file of files) {
    if (/(?:-wal|-shm|-journal)$/.test(file.file) || name === 'data' && file.file === 'app.db') continue;
    const target = path.join(output, name, file.file);
    fs.mkdirSync(path.dirname(target), {recursive: true});
    fs.copyFileSync(path.join(source, name, file.file), target, fs.constants.COPYFILE_EXCL);
    assert.equal(sha256(fs.readFileSync(target)), file.sha256);
  }
}
const sourceDb = new DatabaseSync(path.join(source, 'data/app.db'), {readOnly: true});
const resources = sourceDb.prepare('SELECT id,local_path,content_hash FROM teacher_resources ORDER BY id').all();
try { await backup(sourceDb, path.join(output, 'data/app.db')); } finally { sourceDb.close(); }
const db = new DatabaseSync(path.join(output, 'data/app.db'));
const rebased = [];
try {
  db.exec('PRAGMA journal_mode=DELETE; BEGIN IMMEDIATE;');
  for (const resource of resources) {
    const original = fs.realpathSync(resource.local_path);
    const relative = path.relative(path.join(source, 'data/teacher_resources'), original);
    assert(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
    const target = path.join(output, 'data/teacher_resources', relative);
    assert.equal(sha256(fs.readFileSync(original)), resource.content_hash);
    assert.equal(sha256(fs.readFileSync(target)), resource.content_hash);
    db.prepare('UPDATE teacher_resources SET local_path=? WHERE id=?').run(target, resource.id);
    rebased.push({id: resource.id, sha256: resource.content_hash, from: original, to: target});
  }
  db.exec('COMMIT');
} finally { db.close(); }
assert.deepEqual(fingerprint(source).files.filter(file => !/(?:-wal|-shm|-journal)$/.test(file.file)), sourceFiles);
const profile = path.join(output, 'profile');
const main = path.join(pins.buildRoot, 'main/index.js');
const bootstrap = zeroNetworkBootstrap({output, main, profile, counter: '__sourceReviewHttp'});
const env = {...process.env};
for (const name of Object.keys(env)) if (/KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL/i.test(name) || name.startsWith('OMNI_EDU_') || ['NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE', 'ELECTRON_RENDERER_URL'].includes(name)) delete env[name];
Object.assign(env, {OMNI_EDU_DATA_ROOT: path.join(output, 'data'), OMNI_EDU_REPO_ROOT: path.resolve(desktop, '../..'),
  OMNI_EDU_E2E_DIALOG_MODE: '1', OMNI_EDU_E2E_VISIBLE: '1', OMNI_EDU_XIAOZHI_PI: '1'});
const child = spawn(path.join(desktop, 'node_modules/electron/dist/electron.exe'),
  [bootstrap, '--remote-debugging-port=0', '--force-device-scale-factor=1'],
  {cwd: output, env, detached: true, stdio: 'ignore', windowsHide: false});
child.once('error', error => {console.error(error.message); process.exitCode = 1;});
child.once('spawn', () => {
  const report = {pid: child.pid, source, output, data: path.join(output, 'data'), profile, main, pins,
    sourceFilesUnchanged: true, setup: 'Real parser PASS data snapshot, immutable files copied, only owned clone resource transport paths rebased', rebased,
    intendedOperations: 'Actual material source tabs and page preview; temporary local draft/cancel only. No generation, save, question approval or provider request.'};
  fs.writeFileSync(path.join(import.meta.dirname, 'source-review-launch.json'), JSON.stringify(report, null, 2));
  child.unref();
  console.log(JSON.stringify({pid: child.pid, output, main}));
});
