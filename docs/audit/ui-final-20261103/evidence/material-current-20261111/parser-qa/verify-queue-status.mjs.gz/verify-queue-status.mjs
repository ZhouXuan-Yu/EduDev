/** AST and isolated locator-model checks only. The live runner is never imported. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';

const evidence = path.dirname(fileURLToPath(import.meta.url));
const desktop = path.resolve(evidence, '../../..');
const require = createRequire(path.join(desktop, 'package.json'));
const ts = require('typescript');
const {fingerprint, sha256} = await import(pathToFileURL(path.join(desktop, 'scripts/acceptance/evidence.mjs')));
const baseline = JSON.parse(fs.readFileSync(path.join(evidence, 'before.json'), 'utf8'));
const beforeText = fs.readFileSync(path.join(evidence, 'runner-before.mjs'), 'utf8');
const afterText = fs.readFileSync(baseline.runner, 'utf8');
const parse = text => ts.createSourceFile('runner.mjs', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
const before = parse(beforeText), after = parse(afterText);
const queue = ast => ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name.text === 'queueStatus');
const oldQueue = queue(before), newQueue = queue(after);
const textOf = (node, ast) => node.getText(ts.isSourceFile(ast) ? ast : node.getSourceFile());
const nodes = (root, predicate) => {
  const found = [];
  function visit(node) {
    if (predicate(node)) found.push(node);
    ts.forEachChild(node, visit);
  }
  visit(root);
  return found;
};
const calls = (ast, expression) => nodes(ast, node => ts.isCallExpression(node) && expression.test(textOf(node.expression, ast)));
const assertions = ast => calls(ast, /^assert(?:\.|$)/).map(node => textOf(node, ast));
const stepCalls = ast => calls(ast, /^step$/);
const checks = [];
async function check(name, action) {
  await action();
  checks.push({name, status: 'PASS'});
}

await check('all_source_outside_queueStatus_is_byte_identical', () => {
  assert.equal(afterText.slice(0, newQueue.getStart(after)), beforeText.slice(0, oldQueue.getStart(before)));
  assert.equal(afterText.slice(newQueue.end), beforeText.slice(oldQueue.end));
});
await check('all_nine_step_bodies_and_order_are_byte_identical', () => {
  assert.equal(stepCalls(before).length, 9);
  assert.deepEqual(stepCalls(after).map(node => textOf(node, after)), stepCalls(before).map(node => textOf(node, before)));
});
await check('all_original_business_assertions_are_preserved_in_order', () => {
  const newAssertion = "assert(controlId,'Queue toggle must control an activity region')";
  assert.equal(assertions(after).filter(text => text === newAssertion).length, 1);
  assert.deepEqual(assertions(after).filter(text => text !== newAssertion), assertions(before));
});
await check('original_task_visibility_and_exact_status_wait_are_byte_identical', () => {
  const oldWaits = calls(oldQueue, /^wait$/).map(node => textOf(node, before));
  const newWaits = calls(newQueue, /^wait$/).map(node => textOf(node, after));
  assert.equal(oldWaits.length, 1);
  assert(newWaits.includes(oldWaits[0]));
});
await check('all_explicit_timeout_values_timers_and_remaining_calls_are_identical', () => {
  const timing = ast => nodes(ast, node => ts.isPropertyAssignment(node) && textOf(node.name, ast) === 'timeout' ||
    ts.isCallExpression(node) && /^(setTimeout|clearTimeout|remaining)$/.test(textOf(node.expression, ast))).map(node => textOf(node, ast));
  assert.deepEqual(timing(after), timing(before));
});
await check('all_original_wait_calls_retained_with_only_expansion_wait_added', () => {
  const original = calls(before, /^wait$/).map(node => textOf(node, before));
  const current = calls(after, /^wait$/).map(node => textOf(node, after));
  const added = "wait(async()=>await trigger.getAttribute('aria-expanded')==='true')";
  assert.equal(current.filter(text => text === added).length, 1);
  assert.deepEqual(current.filter(text => text !== added), original);
});
await check('original_real_click_and_conditional_expansion_are_preserved', () => {
  const conditions = ast => calls(queue(ast), /^click$/).map(node => textOf(node, ast));
  assert.deepEqual(conditions(after), conditions(before));
  assert.equal(textOf(newQueue.body.statements.find(ts.isIfStatement), after), textOf(oldQueue.body.statements.find(ts.isIfStatement), before));
  assert.equal(calls(newQueue, /evaluate|force|dispatchEvent/).length, 0);
});
await check('one_launch_three_parsers_180s_20s_ready_zero_http_model_budgets_preserved', () => {
  assert.equal(calls(after, /^electron\.launch$/).length, 1);
  const boot = calls(after, /^waitContinuationBootstrap$/);
  assert.equal(boot.length, 1);
  assert.match(textOf(boot[0], after), /timeout:remaining\(20000\)/);
  assert.match(afterText, /budget:\{launches:1,totalSeconds:180,models:0,http:0,parserAttempts:3\}/);
  assert.match(afterText, /deadlineAt=Date\.now\(\)\+180000/);
});

async function runHelper(ast, options = {}) {
  const state = {expanded: options.expanded ?? 'false', clicks: 0, waits: 0, trace: []};
  const controlId = options.controlId === undefined ? ':qa-activity:' : options.controlId;
  const trigger = {kind: 'toggle', visible: true, enabled: true,
    async getAttribute(name) {return name === 'aria-expanded' ? state.expanded : name === 'aria-controls' ? controlId : null;}};
  const queueSection = {kind: 'queue', visible: options.queueVisible !== false, enabled: true};
  const task = {kind: 'task', visible: options.taskVisible !== false, enabled: true,
    async isVisible() {state.trace.push('task-visible'); return this.visible;},
    async getAttribute(name) {assert.equal(name, 'data-status'); state.trace.push('task-status'); return options.taskStatus ?? 'cancelled';}};
  const tid = id => {
    state.trace.push('tid:' + id);
    if (id === 'materials-queue-toggle') return trigger;
    if (id === 'materials-task') return task;
    if (id === 'materials-queue') return {locator() {throw Error('REMOVED_NESTED_QUEUE_BUTTON');}};
    throw Error('UNEXPECTED_TEST_ID');
  };
  const page = {locator(selector) {
    assert.equal(selector, '[id=' + JSON.stringify(controlId) + ']');
    state.trace.push('controlled-region');
    return {getByTestId(id) {
      assert.equal(id, 'materials-queue');
      state.trace.push('controlled-queue');
      if (options.queueOutsideRegion) throw Error('QUEUE_MISSING_FROM_CONTROLLED_REGION');
      return queueSection;
    }};
  }};
  const unique = async locator => {
    assert(locator.visible && locator.enabled, 'VISIBLE_UNIQUE_ENABLED_REQUIRED');
    state.trace.push('unique:' + locator.kind);
    return locator;
  };
  const click = async locator => {
    assert.equal(locator, trigger);
    state.clicks++;
    state.trace.push('click:toggle');
    if (!options.noExpansion) state.expanded = 'true';
  };
  const wait = async predicate => {
    state.waits++;
    if (!await predicate()) throw Error('WAIT_DEADLINE');
  };
  const invoke = vm.runInNewContext('(' + textOf(queue(ast), ast) + ')', {assert, page, tid, unique, click, wait, JSON});
  await invoke(options.requestedStatus ?? 'cancelled');
  return state;
}

await check('regression_old_helper_fails_removed_nested_button', () => assert.rejects(runHelper(before), /REMOVED_NESTED_QUEUE_BUTTON/));
await check('closed_outer_toggle_is_clicked_once_and_controlled_queue_checked_first', async () => {
  const state = await runHelper(after);
  assert.equal(state.clicks, 1);
  assert.equal(state.expanded, 'true');
  assert(state.trace.indexOf('unique:queue') < state.trace.indexOf('task-visible'));
});
await check('already_open_toggle_is_not_closed', async () => assert.equal((await runHelper(after, {expanded: 'true'})).clicks, 0));
for (const status of ['cancelled', 'failed', 'succeeded']) await check('exact_task_status_' + status + '_accepted', () => runHelper(after, {requestedStatus: status, taskStatus: status}));
for (const [name, options, expected] of [
  ['missing_aria_controls', {controlId: null}, /Queue toggle must control/],
  ['empty_aria_controls', {controlId: ''}, /Queue toggle must control/],
  ['click_without_expansion', {noExpansion: true}, /WAIT_DEADLINE/],
  ['hidden_controlled_queue', {queueVisible: false}, /VISIBLE_UNIQUE_ENABLED_REQUIRED/],
  ['queue_outside_controlled_region', {queueOutsideRegion: true}, /QUEUE_MISSING_FROM_CONTROLLED_REGION/],
  ['hidden_selected_task', {taskVisible: false}, /WAIT_DEADLINE/],
  ['wrong_task_status', {taskStatus: 'running'}, /WAIT_DEADLINE/]
]) await check(name + '_rejected', () => assert.rejects(runHelper(after, options), expected));

const sourceEvidence = baseline.components.map(item => ({...item, currentSha256: sha256(fs.readFileSync(item.file))}));
await check('read_production_layout_and_activity_evidence_unchanged', () => {
  for (const item of sourceEvidence) assert.equal(item.currentSha256, item.sha256);
});
const history = baseline.history.map(item => ({...item, currentInventorySha256: fingerprint(item.root).sha256}));
await check('both_historical_FAIL_directories_retain_all_original_bytes', () => {
  for (const item of history) {
    assert.equal(item.currentInventorySha256, item.inventory.sha256);
    assert.equal(item.status, 'FAIL');
    assert.equal(item.success, false);
  }
});
const syntaxStarted = Date.now();
const syntax = spawnSync(process.execPath, ['--check', baseline.runner], {cwd: desktop, encoding: 'utf8', windowsHide: true, timeout: 10000});
await check('nodecheck_runner_exit_zero', () => assert.equal(syntax.status, 0));
const report = {
  status: 'PASS', scope: 'AST and isolated locator-model verification', actualElectronAcceptance: 'NOT_RUN', launches: 0, http: 0, models: 0,
  runner: {file: baseline.runner, beforeSha256: baseline.runnerSha256, afterSha256: sha256(fs.readFileSync(baseline.runner))},
  beforeHelper: textOf(oldQueue, before), afterHelper: textOf(newQueue, after),
  steps: stepCalls(after).map(node => ({code: node.arguments[0].text, sha256: sha256(textOf(node, after))})),
  assertions: {original: assertions(before).length, current: assertions(after).length, originalPreserved: true},
  timeouts: nodes(after, node => ts.isPropertyAssignment(node) && textOf(node.name, after) === 'timeout').map(node => textOf(node, after)),
  nodecheck: {command: 'node --check scripts/ui-final-material-parse-live.mjs', cwd: desktop, exitCode: syntax.status,
    elapsedMs: Date.now() - syntaxStarted, stdout: syntax.stdout, stderr: syntax.stderr},
  sourceEvidence, history, checks,
  limits: ['Helper behavior checks execute an AST-extracted function against an isolated locator model. Actual DOM click, parser, task and page acceptance remain for root.',
    'Current runtime performance is unmeasured. All original timeouts and the outer deadline are preserved.']
};
fs.writeFileSync(path.join(evidence, 'static-report.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({status: report.status, checks: checks.length, assertions: report.assertions, steps: report.steps.length,
  nodecheckExitCode: syntax.status, actualElectronAcceptance: report.actualElectronAcceptance, launches: 0, runnerSha256: report.runner.afterSha256}));
