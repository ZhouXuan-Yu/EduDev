# A13 parser queueStatus 精确 QA 修复

## 根因与源码写集

源码写集仅 apps/desktop/scripts/ui-final-material-parse-live.mjs 中的 queueStatus，4 行增加、1 行删除。其他本轮产物均位于当前 ignored parser-qa 目录。

旧定位 tid('materials-queue').locator('button[aria-expanded]') 假定展开按钮位于队列内部。当前 MaterialLibraryLayout.tsx 的展开入口是外层 materials-queue-toggle，通过 aria-controls 指向 activity 区域。MaterialLibraryActivity.tsx 中 materials-queue 为普通 section，materials-task 显示在选择资料的详情区域。

VQynm1 原失败栈指向 queueStatus 内旧定位器及其 cancelled 调用。root 已提供真实停止后保留第 1 页的 PNG 观察。本次归类为验收定位器适配修复。

## 修改后的真实操作顺序

1. 用原 unique 获取 materials-queue-toggle。
2. 读取并断言非空 aria-controls。
3. 沿原 aria-expanded 条件，通过原 click 实际点击折叠状态的 toggle。
4. 沿原 wait 确认 aria-expanded 为 true。
5. 用 aria-controls 关联区域的精确 id 属性定位，再用原 unique 确认该区域内 materials-queue 可见且唯一、可用。属性选择器支持 React useId 中的冒号。
6. 执行原 wait，确认 materials-task 可见且 data-status 严格等于调用状态。

queueStatus 通过原 unique/click/wait 操作。新增检查限于关联区域和展开状态，task 状态仍从原界面属性读取。

## AST 守恒证据

static-report.json 保存修改前后 helper 全文、源码 SHA、九个 step 的代码/SHA、断言数量、timeout 清单、历史目录完整指纹及逐项静态结果。

| 项目 | 证据 |
| --- | --- |
| 变更边界 | queueStatus 前后其余源码分别逐字节相等 |
| 九个 step | 每个完整调用正文及顺序逐字相等 |
| 原业务断言 | 原 87 个 assert 调用原文及顺序全部保留，当前 88 个，仅增加 controlId 断言 |
| 原 task 判定 | 原 materials-task 可见/data-status wait 原文保留 |
| 实际点击 | 原 if/aria-expanded 条件和 click(trigger) 原文保留，原 click 函数逐字节保留 |
| 全部显式 timeout | 所有 timeout 属性、setTimeout/clearTimeout/remaining 调用逐项原文相等 |
| 等待机制 | 原 wait 调用全部按序保留，仅增加无显式 cap 的展开状态 wait，沿原全局 deadline |
| 预算 | 1 launch、3 parser attempts、180s 总预算、20s bootstrap ready、0 HTTP、0 model 原值保留 |
| 来源/成功页/取消重试 | originals、retained、解析 seam、版本、来源文件、成功页、取消/失败/重试/skipPages、ledger 及最终判定全部属于逐字节保留部分 |

九个原 step 依次为 TXT_REAL_PARSER_COMPLETED_CONTROL、PDF_NATIVE_PAGE_ACK_AND_UI_STOP、STOP_PRESERVES_SUCCESS_PAGE_AND_OLDER_BODY、UI_CONTINUE_PRE_WORKER_FAILURE、FAILURE_PRESERVES_PAGE_SOURCE_AND_CONTROL、UI_RETRY_REAL_THREE_PAGE_COMPLETION、SUCCESS_PAGE_SKIP_AND_EXACT_RETENTION、LATE_ORIGINAL_BODY_RESPONSE_SELECTION_GUARD、FINAL_ZERO_HTTP_MODEL_AND_INTEGRITY。

## 实际静态验证

在 D:\WorkProject\EduProject 执行以下命令，24/24 PASS，Nodecheck exit 0。

```powershell
node apps/desktop/test-results/ui-final-content-20261111/parser-qa/verify-queue-status.mjs
```

验证器内部以单独 Node 进程运行以下语法检查，工作目录为 apps/desktop。

```powershell
node --check scripts/ui-final-material-parse-live.mjs
```

静态行为检查提取真实 queueStatus AST，在隔离 locator 模型内复现旧 helper 的失效定位，并检查新 helper 的闭合/展开状态、一次点击、控制区域先于 task 检查、cancelled/failed/succeeded 三状态，以及缺 controlId、点击未展开、队列隐藏/位于受控区域之外、task 隐藏/状态错误等拒绝分支。

这些行为检查使用隔离模型。真实 DOM 点击、worker、页保存、任务状态与完整九项 Electron 验收由 root 执行，当前 actualElectronAcceptance 为 NOT_RUN，launches/http/models 均为 0。

首次静态验证工具调用 TypeScript getText 时误将函数节点作为 sourceFile，已修正为其所属 SourceFile，并保留 static-initial-failure.json。随后完整 24 项通过。

## 历史失败保留

| 目录 | 原状态 | 原检查状态 | 原失败 |
| --- | --- | --- | --- |
| ui-final-material-parse-live-JTeveZ | FAIL | 9 NOT_RUN | BOOTSTRAP_READY_DEADLINE |
| ui-final-material-parse-live-VQynm1 | FAIL | 1 PASS、1 FAIL、7 NOT_RUN | PDF_NATIVE_PAGE_ACK_AND_UI_STOP / QA_TIMEOUT |

两目录所有文件的相对路径与 SHA inventory 在本轮前后完全相等，包含原报告、截图及已有失败证据。原成功/失败身份及检查结果均留在其原目录。

## root 固定命令

在 D:\WorkProject\EduProject\apps\desktop 使用 root 冻结 pins 执行既有命令一次。

```powershell
node scripts/ui-final-material-parse-live.mjs --run-ui --pins="D:\WorkProject\EduProject\apps\desktop\test-results\ui-final-content-20261111\pins.json"
```

该路径来自两份原报告的实际 pins.file。本轮未以当前构建运行该命令。完整九项结果待 root 实际报告。

## 性能与回滚

本次增加一次展开属性 wait 和一次受控队列可见性检查，全部等待使用原 helper 预算及全局 deadline。实际 Electron 前后耗时待 root 记录。

源码修改前 SHA256 为 c1d329e4ffae11de49c6d5afc538e428620ace8ea6b2b09bb6d682ffb15ddb13。

源码修改后 SHA256 为 a4a96d813b23c5ee0ddbcd8ec1a2118548c469fe92558183b4c808d58c2d2f8b。

回滚时先核对当前源码 SHA，参考 runner-before.mjs 仅撤销 queueStatus 差异，并保留之后的协作修改。该补丁没有数据迁移。
