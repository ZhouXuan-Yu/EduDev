import fs from 'node:fs';
import path from 'node:path';
import {startupState, hash} from '../../scripts/ui-final-material-metadata-recovery-helper.mjs';

const desktop = path.resolve(import.meta.dirname, '../..');
const before = startupState(path.join(desktop, 'test-results/ui-final-material-catalog-live-LhntPx/data'));
const after = startupState(path.join(desktop, 'test-results/ui-final-material-metadata-recovery-live-lD3WDl/data'));
const result = {beforeTables: before.logical.tables.length, afterTables: after.logical.tables.length,
  beforeSources: before.facts.sourceTables.length, afterSources: after.facts.sourceTables.length,
  sameSchema: hash(before.schema) === hash(after.schema), sameControl: hash(before.control) === hash(after.control),
  sameLogical: hash(before.logical) === hash(after.logical), sameFacts: hash(before.facts) === hash(after.facts),
  sameDerived: hash(before.derivedCounts) === hash(after.derivedCounts),
  controlBefore: before.control, controlAfter: after.control,
  changedTables: after.logical.tables.filter(table => hash(table) !== hash(before.logical.tables.find(prior => prior.table === table.table))).map(table => table.table)};
fs.writeFileSync(path.join(import.meta.dirname, 'metadata-startup-comparison.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
