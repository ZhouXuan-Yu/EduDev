import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/visual-priority-20261111');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  for (const name of names) selected.push({source:path.join(root, name), file:prefix + '/' + name});
}
add(base, ['archive.mjs','capture.mjs','before-pins.json','after-pins.json','r2-pins.json',
  'r2-before.json','build-r1.log','build-r2.log','components-r1.log','components-r2.log',
  'styles-r1.log','styles-r2.log','npm-audit-r2.json','before-capture.log','before-settled.log',
  'after-capture.log','capture-r2.log','paper-entry-r1.log','paper-entry-r2.log',
  'workbench-r2.log','workbench-r2-adapted.log','workbench-r2-final.log',
  'workbench-before.mjs','workbench-adapter-r1.mjs','workbench-adapter-r2.mjs'], 'execution');
for (const name of ['before-bjnpYo','r2-6x2TCf']) {
  const root = path.join(base, name);
  add(root, fs.readdirSync(root).filter(file => file.endsWith('.png') || file === 'report.json'), name);
}
add(path.join(base, 'before-pqW9zu'), ['report.json'], 'invalid-unsettled-first-capture');
add(path.join(base, 'after-AbmMPt'), ['report.json','paper-1366-actual.png'], 'r1');
add(path.join(desktop, 'test-results/paper-first-entry-pqfu1T'), ['report.json'], 'paper-r1');
const paper = path.join(desktop, 'test-results/paper-first-entry-nbbxdf');
add(paper, fs.readdirSync(paper).filter(file => file.endsWith('.png') || file === 'report.json'), 'paper-r2');
add(path.join(desktop, 'test-results/workbench-zETNYv'), ['report.json'], 'workbench-original-fail');
add(path.join(desktop, 'test-results/workbench-kXqkBd'), ['report.json'], 'workbench-adapter-r1-fail');
const logs = fs.readFileSync(path.join(base, 'workbench-r2-final.log'), 'utf8');
const reportPath = logs.match(/REPORT (.+report\.json)/)?.[1].trim();
assert(reportPath);
const workbenchRoot = fs.realpathSync(path.dirname(reportPath));
assert(workbenchRoot.startsWith(fs.realpathSync(path.join(desktop, 'test-results')) + path.sep));
const workbench = JSON.parse(fs.readFileSync(reportPath));
assert.equal(workbench.success, false);
assert.equal(workbench.summary.failed, 2);
add(workbenchRoot, fs.readdirSync(workbenchRoot).filter(file => file.endsWith('.png') || file === 'report.json'), 'workbench-adapter-r2-fail');
const files = [];
for (const {source, file:name} of selected) {
  const raw = fs.readFileSync(source);
  const png = name.endsWith('.png');
  if (png) assert(raw.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])));
  else assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalSha256:sha256(raw),
    encoding:png ? 'original-png' : 'gzip',
    ...(png ? {width:raw.readUInt32BE(16), height:raw.readUInt32BE(20)} : {})});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope:'Approved HTML and actual formal Pi UI, 27 matched empty-state samples before/R2; R1 defect and invalid first capture retained. Original workbench failure plus adapted actual result. Explicit manual question, no model calls. Excludes databases, profiles, daily screenshots and build output.',
  visualAcceptance:'PARTIAL; remaining tool-entry arrangement, list density and nonempty-state comparisons remain open',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'r2-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination, count:files.length, bytes:files.reduce((sum,file)=>sum+file.bytes,0)}));
