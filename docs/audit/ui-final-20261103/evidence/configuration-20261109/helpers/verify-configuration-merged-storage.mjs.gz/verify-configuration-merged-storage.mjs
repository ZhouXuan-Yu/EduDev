import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {DatabaseSync} from 'node:sqlite';import {createHash} from 'node:crypto';
const root=fs.realpathSync('test-results/ui-final-configuration-QE6JFf'),report=JSON.parse(fs.readFileSync(path.join(root,'report.json')));assert.equal(report.success,true);
const sha=b=>createHash('sha256').update(b).digest('hex'),data=path.join(root,'data'),original=report.sourceFixture;
const source=fs.readFileSync(path.join(root,'teacher-package/SKILL.md'),'utf8'),next=source+'\n教师补充：先核对实际来源，再作教学安排。\n',skills=path.join(data,'xiaozhi-pi/skills');
const versions=fs.readdirSync(skills,{recursive:true}).filter(n=>path.basename(n)==='SKILL.md').map(n=>({file:path.join(skills,n),text:fs.readFileSync(path.join(skills,n),'utf8')}));
const v1=versions.filter(v=>v.text===source),v2=versions.filter(v=>v.text===next);assert.equal(v1.length,1);assert.equal(v2.length,1);assert.notEqual(v1[0].file,v2[0].file);
const refs=fs.readFileSync(path.join(root,'teacher-package/references/course.md'));
for(const v of [...v1,...v2])assert.equal(sha(fs.readFileSync(path.join(path.dirname(v.file),'references/course.md'))),sha(refs));
const from=new DatabaseSync(path.join(original,'data/app.db'),{readOnly:true}),to=new DatabaseSync(path.join(data,'app.db'),{readOnly:true});
try{
 const bindings=from.prepare('SELECT conversation_id,session_file FROM xiaozhi_pi_session_bindings').all();assert.equal(bindings.length,1);
 const native=bindings.map(binding=>{
  const before=fs.realpathSync(path.join(original,'data/xiaozhi-pi',binding.session_file)),after=fs.realpathSync(path.join(data,'xiaozhi-pi',binding.session_file));
  assert(after.startsWith(data+path.sep));assert(before.startsWith(path.join(original,'data')+path.sep));assert.equal(sha(fs.readFileSync(before)),sha(fs.readFileSync(after)));
  assert.deepEqual(to.prepare('SELECT conversation_id,session_file FROM xiaozhi_pi_session_bindings').all(),bindings);return {sessionId:binding.conversation_id,sha256:sha(fs.readFileSync(after))};
 });
 const runs=to.prepare('SELECT id,status FROM ai_agent_runs').all();assert.equal(runs.length,1);assert.equal(runs[0].status,'succeeded');
 const result={success:true,runs,native,skillVersions:[...v1,...v2].map((v,i)=>({version:i+1,relative:path.relative(data,v.file),documentSha256:sha(Buffer.from(v.text)),referencesSha256:sha(refs)})),
  scope:'Read-only original immutable skill directories/reference bytes and exact pre-existing native Pi file; no SQL or filesystem mutation.'};
 fs.writeFileSync(path.join(root,'storage-receipt.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
}finally{from.close();to.close();}
