import fs from 'node:fs';import assert from 'node:assert/strict';
const read=p=>JSON.parse(fs.readFileSync('test-results/'+p+'/report.json'));
const before=read('ui-final-skill-layout-XqYnVX'),after=read('ui-final-skill-layout-PgOqcE'),functional=read('ui-final-configuration-QE6JFf');
assert(after.success&&functional.success);assert.deepEqual(after.pins,functional.pins);
const x=before.samples[0].nativeSwitch.before.computed,y=after.samples[0].nativeSwitch.before.computed;
assert(x&&y);assert.deepEqual(x,y);
for(const s of after.samples){assert(s.visualContract.pass);assert(s.layout.main.scrollWidth<=s.layout.main.clientWidth+1);assert(s.layout.details.width>=280);}
assert.equal(functional.checks.length,17);assert.equal(after.checks.length,4);assert.equal(functional.loopback.toolCalls,0);
const result={success:true,source:after.pins.source,build:after.pins.build,rows:after.samples.map(s=>({width:s.width,visual:s.visualContract,layout:s.layout})),nativeSwitchNormalRoot:{computed:x,scope:'Only sampled normal root computed values; not all states or inner slots.'},functionalChecks:17,layoutChecks:4,limitations:['Prior native startup timeouts remain unexplained, not resolved by adding phase diagnostics.','Settings navigation horizontal scroll at 800 is outside repaired skill content and remains open.','Controlled catalogue responses do not prove online credentials or natural model quality.']};
fs.writeFileSync('test-results/ui-final-configuration-merged-comparison.json',JSON.stringify(result,null,2));console.log(JSON.stringify({success:true,source:result.source,build:result.build,normalRootProperties:Object.keys(x).length}));
