$ErrorActionPreference = 'Stop'
$base = 'test-results/ui-visual-priority-20261111'
$deadline = (Get-Date).AddMinutes(5)
while (!(Test-Path -LiteralPath "$base/build-paste-modal-integrated.exit")) {
    if ((Get-Date) -gt $deadline) { throw 'Build has not reached a terminal exit' }
    Start-Sleep -Seconds 5
}
if ([int](Get-Content -LiteralPath "$base/build-paste-modal-integrated.exit") -ne 0) { throw 'Build failed' }
$freeze = @'
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fingerprint} from './scripts/acceptance/evidence.mjs';
const base = 'test-results/ui-visual-priority-20261111';
const before = JSON.parse(fs.readFileSync(base + '/paste-modal-integrated-before.json'));
const source = fingerprint('src').sha256;
assert.equal(source, before.sha256);
const buildRoot = path.resolve(base, 'paste-modal-integrated-out');
const pins = {root: process.cwd(), source, buildRoot, build: fingerprint(buildRoot).sha256,
  scope: 'Merged knowledge response recovery and HeroUI source modal; stable full production build'};
fs.writeFileSync(base + '/paste-modal-integrated-pins.json', JSON.stringify(pins, null, 2));
console.log(JSON.stringify(pins));
'@
& node --input-type=module -e $freeze
if ($LASTEXITCODE -ne 0) { throw 'Build identity changed' }
$pins = "$base/paste-modal-integrated-pins.json"
$jobs = @(
    @{name='layout'; arguments=@('scripts/paper-paste-layout-ui.mjs', $pins, 'integrated')},
    @{name='source'; arguments=@('scripts/paper-source-entry-ui.mjs', '--run-ui', "--pins=$pins")},
    @{name='entry'; arguments=@('scripts/paper-entry-ui.mjs', '--run-ui', "--pins=$pins")},
    @{name='selection'; arguments=@('scripts/paper-library-selection-ui.mjs', '--run-ui', "--pins=$pins")},
    @{name='filters'; arguments=@('scripts/paper-library-filters-ui.mjs', '--run-ui', "--pins=$pins")},
    @{name='workbench'; arguments=@('scripts/workbench-ui.mjs')}
)
$env:OMNI_EDU_TEST_BUILD_ROOT = Join-Path (Get-Location) "$base/paste-modal-integrated-out"
$summary = @()
foreach ($job in $jobs) {
    $log = "$base/$($job.name)-paste-modal-final.log"
    $arguments = $job.arguments
    & node @arguments *> $log
    $gate = $LASTEXITCODE
    $summary += @{name=$job.name; exit=$gate; log=$log}
    $summary | ConvertTo-Json | Set-Content -LiteralPath "$base/paste-modal-ui-exits.json"
    Write-Output ($job.name + ' exit=' + $gate)
    if ($gate -ne 0) {
        Get-Content -LiteralPath $log -Tail 6
        exit $gate
    }
}
exit 0
