import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {sha256} from '../../scripts/acceptance/evidence.mjs';

const base = import.meta.dirname;
const desktop = path.resolve(base, '../..');
const owned = fs.realpathSync(path.join(desktop, 'test-results'));
const destination = path.resolve(desktop, '../../docs/audit/ui-final-20261103/evidence/paper-heading-20261112');
assert(!fs.existsSync(destination));
const selected = [];
function add(root, names, prefix) {
  assert(fs.realpathSync(root).startsWith(owned + path.sep));
  for (const name of names) selected.push({source:path.join(root, name), name:prefix + '/' + name});
}
add(base, ['archive-paper-heading.mjs', 'capture.mjs', 'paper-heading-before.json', 'paper-heading-pins.json',
  'paper-heading-geometry.json', 'build-paper-heading.log', 'components-paper-heading.log',
  'components-paper-heading-serial.log', 'styles-paper-heading.log', 'audit-paper-heading.json',
  'capture-paper-heading.log', 'paper-heading-interactions.log', 'paper-heading-interactions-id-fixed.log',
  'paper-heading-interactions-discard-fixed.log', 'workbench-paper-heading.log',
  'paper-heading-entry-before-id-fix.mjs', 'paper-heading-entry-before-discard-fix.mjs'], 'execution');
for (const [name, prefix, expected, images] of [
  ['paper-heading-J5Wzm9', 'current', true, true],
  ['studio-students-Mya1wB', 'before', true, true],
]) {
  const root = path.join(base, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, expected);
  add(root, fs.readdirSync(root).filter(file => file === 'report.json' ||
    images && /^paper-.*\.png$/.test(file)), prefix);
}
for (const [name, prefix, expected, images] of [
  ['paper-first-entry-902EZO', 'qa-id-failed', false, false],
  ['paper-first-entry-WF8R56', 'qa-draft-failed', false, false],
  ['paper-first-entry-6yaLi7', 'paper', true, true],
  ['workbench-xiygFm', 'workbench', true, false],
]) {
  const root = path.join(owned, name);
  assert.equal(JSON.parse(fs.readFileSync(path.join(root, 'report.json'))).success, expected);
  add(root, fs.readdirSync(root).filter(file => file === 'report.json' || images && file.endsWith('.png')), prefix);
}
const files = [];
for (const {source, name} of selected) {
  const raw = fs.readFileSync(source), png = name.endsWith('.png');
  if (!png) assert(!/sk-[A-Za-z0-9]{24,}|Bearer\s+[A-Za-z0-9._-]{20,}/.test(raw.toString('utf8')));
  const encoded = png ? raw : gzipSync(raw);
  assert.deepEqual(png ? encoded : gunzipSync(encoded), raw);
  const file = name + (png ? '' : '.gz');
  const target = path.resolve(destination, file);
  assert(target.startsWith(destination + path.sep));
  fs.mkdirSync(path.dirname(target), {recursive:true});
  fs.writeFileSync(target, encoded, {flag:'wx'});
  files.push({file, bytes:encoded.length, sha256:sha256(encoded), originalSha256:sha256(raw),
    encoding:png ? 'original-png' : 'gzip'});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope:'Application paper heading, native back navigation and two public official Button size choices. Preserves failed QA adapters and initial Vite transport failure. Excludes profiles, data and builds.',
  component:{package:'@heroui/react', version:'3.2.2', api:'Button size=sm',
    documentation:'https://heroui.com/docs/react/components/button', internalChanges:false},
  visualAcceptance:'Three paper title x/y/height and main start comparisons exact. Further page source/chapter UI and full UI-FINAL remain active.',
  pins:JSON.parse(fs.readFileSync(path.join(base, 'paper-heading-pins.json'))), files,
}, null, 2));
console.log(JSON.stringify({destination, files:files.length, bytes:files.reduce((sum, file) => sum + file.bytes, 0)}));
