import fs from 'node:fs';
import {spawn} from 'node:child_process';
const pins = JSON.parse(fs.readFileSync('test-results/ui-final-settings-nav-results-pins.json'));
const child = spawn(process.execPath, [
  'scripts/ui-final-paper-template.mjs', '--run-ui',
  '--expect-build=' + pins.build, '--expect-source=' + pins.source,
  '--expect-contract=' + pins.contract,
  '--from=test-results/ui-goal-paper-export-intent-mOHpzM'
], {cwd: process.cwd(), env: {...process.env, OMNI_EDU_TEST_BUILD_ROOT: pins.buildRoot}, stdio: 'inherit'});
child.on('error', error => {console.error(error.code); process.exitCode = 1;});
child.on('exit', code => {process.exitCode = code ?? 1;});
