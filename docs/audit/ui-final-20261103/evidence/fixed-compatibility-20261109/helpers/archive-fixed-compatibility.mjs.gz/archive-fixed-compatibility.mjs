import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {gzipSync,gunzipSync} from 'node:zlib';
const root=path.resolve('../../docs/audit/ui-final-20261103/evidence/fixed-compatibility-20261109');
fs.mkdirSync(root,{recursive:true});const manifest=[],sha=b=>createHash('sha256').update(b).digest('hex');
function add(source,name){
  const bytes=fs.readFileSync(source),zip=!name.endsWith('.png'),file=name+(zip?'.gz':''),stored=zip?gzipSync(bytes):bytes,target=path.join(root,file);
  fs.mkdirSync(path.dirname(target),{recursive:true});
  if(fs.existsSync(target)&&sha(fs.readFileSync(target))!==sha(stored))throw Error('Evidence changed');
  fs.writeFileSync(target,stored);if(sha(zip?gunzipSync(stored):stored)!==sha(bytes))throw Error('Archive mismatch');
  manifest.push({file,source,bytes:stored.length,sha256:sha(stored),uncompressedSha256:sha(bytes)});
}
const runs=['ui-final-paper-template-4i91Qu','ui-final-paper-template-AxUbaf','ui-final-paper-template-aAfZsH',
  'ui-final-paper-adaptation-continuation-tifZ5g','ui-final-office-continuation-YN7HHg','ui-final-office-continuation-RhrrRA'];
for(const run of runs)for(const entry of fs.readdirSync(path.join('test-results',run),{withFileTypes:true}))
  if(entry.isFile()&&(/^(report|startup|storage-readback|continuation-pins|verified-six-facts|bootstrap-error)\.json$/.test(entry.name)||entry.name.endsWith('.png')))
    add(path.join('test-results',run,entry.name),run+'/'+entry.name);
for(const file of fs.readdirSync('test-results').sort())if(/^ui-final-fixed-.+\.(log|json)$/.test(file))add(path.join('test-results',file),'logs/'+file);
for(const file of ['run-current-template.mjs','verify-current-template.mjs','office-hash-differences.mjs','archive-fixed-compatibility.mjs'])add(path.join('test-results',file),'helpers/'+file);
for(const file of ['ui-final-settings-nav-results-pins.json','ui-final-resumed-office-pins.json'])add(path.join('test-results',file),'pins/'+file);
for(const row of manifest){const bytes=fs.readFileSync(path.join(root,row.file));assertHash(bytes,row.sha256);}
function assertHash(bytes,expected){if(sha(bytes)!==expected)throw Error('Stored archive changed');}
fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({root,entries:manifest.length,bytes:manifest.reduce((n,r)=>n+r.bytes,0)}));
