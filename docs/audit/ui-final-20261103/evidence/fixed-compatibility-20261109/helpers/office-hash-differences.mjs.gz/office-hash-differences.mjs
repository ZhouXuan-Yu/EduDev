import fs from 'node:fs';import path from 'node:path';import {sha256} from '../scripts/acceptance/evidence.mjs';
const r=JSON.parse(fs.readFileSync('test-results/ui-final-c2-office-live-AkJuza/pi-office-six.json'));
for(const f of [...r.scriptHashes,...r.sourceHashes]){const after=sha256(fs.readFileSync(f.path));if(after!==f.sha256)console.log(JSON.stringify({file:path.relative(process.cwd(),f.path),before:f.sha256,after}));}
