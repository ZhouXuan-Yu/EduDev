import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {sha256, fingerprint} from '../scripts/acceptance/evidence.mjs';
const output=path.resolve('test-results/ui-final-paper-template-aAfZsH');
const report=JSON.parse(fs.readFileSync(path.join(output,'report.json')));
const baseline=JSON.parse(fs.readFileSync(path.join(report.original,'report.json')));
assert(report.success&&report.integrityVerified&&report.checks.length===17);
assert.deepEqual(report.networkAttempts,[]);assert.deepEqual(report.errors,[]);
const db=new DatabaseSync(path.join(output,'data/app.db'),{readOnly:true});
const old=new DatabaseSync(path.join(report.original,'data/app.db'),{readOnly:true});
try{
  const saves=report.operations.filter(x=>x.kind==='save');assert.equal(saves.length,6);
  const versions=db.prepare('SELECT * FROM paper_template_versions ORDER BY template_id,version').all();
  assert.equal(versions.length,6);
  for(const save of saves){
    const rows=versions.filter(x=>x.template_id===save.templateId&&x.version===save.version);assert.equal(rows.length,1);
    assert.equal(rows[0].digest,save.digest);const version=JSON.parse(rows[0].data_json);
    assert.equal(version.digest,save.digest);assert.equal(version.version,save.version);
    if(save.mode==='copy'){assert.equal(version.version,1);assert.equal(version.derivedFrom.version,2);}
  }
  const original=old.prepare('SELECT * FROM paper_baskets WHERE id=?').get(baseline.normal.basketId);
  const current=db.prepare('SELECT * FROM paper_baskets WHERE id=?').get(baseline.normal.basketId);
  assert.deepEqual(JSON.parse(current.data_json).entries,JSON.parse(original.data_json).entries);
  const receipts=db.prepare('SELECT * FROM paper_template_receipts').all();assert.equal(receipts.length,11);
  const summary={success:true,scope:'Independent read-only persisted A28 evidence; not full product acceptance',
    versions:versions.length,receipts:receipts.length,source:report.pins.source,build:report.pins.build,
    basketMembersUnchanged:true,originalUnchanged:fingerprint(report.original).sha256===report.originalBefore,
    versionRowsSha256:sha256(JSON.stringify(versions)),receiptRowsSha256:sha256(JSON.stringify(receipts)),
    rendererErrors:0,networkAttempts:0};
  assert(summary.originalUnchanged);
  fs.writeFileSync(path.join(output,'storage-readback.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));
}finally{db.close();old.close();}
