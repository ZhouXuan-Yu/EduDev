import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync, gunzipSync} from 'node:zlib';

const root = path.resolve(import.meta.dirname, '../../../..');
const results = path.join(root, 'apps/desktop/test-results');
const destination = path.join(root, 'docs/audit/ui-final-20261103/evidence/paper-basket-panel-20261112');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const files = new Map();
const folders = new Set([
  'paper-basket-panel-before-cWofnr', 'paper-basket-panel-before-Xqylg8',
  'paper-basket-panel-after-WYUaui', 'paper-basket-panel-after-grGrnt',
  'paper-basket-panel-after-aiAFNu', 'paper-basket-panel-after-0UYXCi', 'paper-basket-panel-after-B2MnhX',
]);
for (const name of fs.readdirSync(import.meta.dirname)) {
  if (!/basket-panel/.test(name) || !/\.(json|log|mjs|tsx|exit)$/.test(name)) continue;
  const source = path.join(import.meta.dirname, name);
  files.set('execution/' + name + '.gz', source);
  if (!name.endsWith('.log')) continue;
  for (const line of fs.readFileSync(source, 'utf8').split(/\r?\n/)) {
    let output = line.startsWith('REPORT ') ? line.slice(7) : undefined;
    try {output ||= JSON.parse(line).output;} catch { /* Ordinary console line. */ }
    if (output && path.basename(output) === 'report.json') output = path.dirname(output);
    if (!output || !fs.existsSync(path.join(output, 'report.json'))) continue;
    assert.equal(path.dirname(path.resolve(output)), results);
    folders.add(path.basename(output));
  }
}
for (const folder of folders) {
  const source = path.join(results, folder);
  assert(fs.existsSync(path.join(source, 'report.json')), folder);
  files.set(folder + '/report.json.gz', path.join(source, 'report.json'));
  for (const entry of fs.readdirSync(source, {recursive: true, withFileTypes: true})) {
    if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
    const absolute = path.join(entry.parentPath, entry.name), inside = path.relative(source, absolute);
    if (inside.split(path.sep).some(part => ['data', 'profile', 'workspace'].includes(part))) continue;
    files.set(folder + '/' + inside, absolute);
  }
}
const smokeLog = path.join(import.meta.dirname, 'basket-panel-regression-smoke.log');
const smokeStart = fs.statSync(smokeLog).birthtimeMs;
for (const entry of fs.readdirSync(path.join(results, 'electron-e2e'), {withFileTypes: true})) {
  if (!entry.isFile() || !entry.name.endsWith('.png')) continue;
  const source = path.join(results, 'electron-e2e', entry.name);
  if (fs.statSync(source).mtimeMs >= smokeStart) files.set('smoke-current/' + entry.name, source);
}
fs.mkdirSync(destination, {recursive: true});
const manifest = [];
for (const [name, source] of files) {
  const file = name.replaceAll('\\', '/'), original = fs.readFileSync(source);
  const bytes = file.endsWith('.gz') ? gzipSync(original) : original;
  const target = path.join(destination, file);
  fs.mkdirSync(path.dirname(target), {recursive: true}); fs.writeFileSync(target, bytes);
  assert.deepEqual(file.endsWith('.gz') ? gunzipSync(fs.readFileSync(target)) : fs.readFileSync(target), original);
  manifest.push({file, bytes: bytes.length, sha256: sha(bytes), originalBytes: original.length, originalSha256: sha(original)});
}
fs.writeFileSync(path.join(destination, 'manifest.json'), JSON.stringify({
  scope: 'Selected-basket controlled real Electron/CSSOM evidence. Original adapter failures and R0 focus failure retained. User profiles, databases and private daily screenshots excluded.',
  fullUiFinalAccepted: false, files: manifest,
}, null, 2));
console.log(JSON.stringify({files: manifest.length, bytes: manifest.reduce((sum, row) => sum + row.bytes, 0)}));
